<div id="Clinica_right">
<div id="top_border">
  <div id="left_title">
    <h2>Admin</h2>
  </div>
</div>
<div id="Patient_table">
  <div id="Personal_Details">
     <div id="car_button">
     <ul>
     	<li><a href="<?php echo site_url('admin/company'); ?>">Company</a></li>
     	<li><a href="<?php echo site_url('admin/user'); ?>">User Management</a></li>
     	<li><a href="<?php echo site_url('admin/Shift'); ?>">Email Account</a></li>
     </ul></div>
  </div>
   
</div>
</div>

