<div class="pull-right">
	<button class="btn btn-primary" id="btn-submit" name="btn_submit" value="1"><i class="icon-ok icon-white"></i> <?php echo lang('save'); ?></button>
    <button class="btn btn-danger" id="btn-cancel" name="btn_cancel" value="1"><i class="icon-remove icon-white"></i> <?php echo lang('cancel'); ?></button>
</div>