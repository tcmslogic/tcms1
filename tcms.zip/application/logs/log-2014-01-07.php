<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-01-07 21:45:37 --> Config Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:45:37 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:45:37 --> URI Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Router Class Initialized
DEBUG - 2014-01-07 21:45:37 --> No URI present. Default controller set.
DEBUG - 2014-01-07 21:45:37 --> Output Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Security Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Input Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:45:37 --> Language Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Language Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Config Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Loader Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Controller Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Session Class Initialized
DEBUG - 2014-01-07 21:45:37 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:45:37 --> A session cookie was not found.
DEBUG - 2014-01-07 21:45:37 --> Session routines successfully run
DEBUG - 2014-01-07 21:45:37 --> Dashboard MX_Controller Initialized
DEBUG - 2014-01-07 21:45:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:45:37 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:45:38 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:45:38 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:45:38 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:45:38 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:45:38 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:45:38 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:45:38 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:45:38 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:45:38 --> Model Class Initialized
DEBUG - 2014-01-07 21:45:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:45:38 --> Model Class Initialized
DEBUG - 2014-01-07 21:45:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:45:38 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:45:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:45:38 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:45:39 --> Config Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:45:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:45:39 --> URI Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Router Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Output Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Security Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Input Class Initialized
DEBUG - 2014-01-07 21:45:39 --> XSS Filtering completed
DEBUG - 2014-01-07 21:45:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:45:39 --> Language Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Language Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Config Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Loader Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Controller Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:45:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:45:39 --> Session Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:45:39 --> Session routines successfully run
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:45:39 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:45:39 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:45:39 --> Model Class Initialized
DEBUG - 2014-01-07 21:45:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:45:39 --> Model Class Initialized
DEBUG - 2014-01-07 21:45:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:45:39 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:45:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:45:39 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:45:39 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:45:39 --> Final output sent to browser
DEBUG - 2014-01-07 21:45:39 --> Total execution time: 0.6096
DEBUG - 2014-01-07 21:46:16 --> Config Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:46:16 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:46:16 --> URI Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Router Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Output Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Security Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Input Class Initialized
DEBUG - 2014-01-07 21:46:16 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:16 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:16 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:16 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:46:16 --> Language Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Language Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Config Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Loader Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Controller Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:46:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:46:16 --> Session Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:46:16 --> Session routines successfully run
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:46:16 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:46:16 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:46:16 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:46:16 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:46:16 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:46:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:46:16 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:46:16 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-01-07 21:46:16 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:16 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:46:16 --> Final output sent to browser
DEBUG - 2014-01-07 21:46:16 --> Total execution time: 0.5197
DEBUG - 2014-01-07 21:46:26 --> Config Class Initialized
DEBUG - 2014-01-07 21:46:26 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:46:26 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:46:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:46:26 --> URI Class Initialized
DEBUG - 2014-01-07 21:46:26 --> Router Class Initialized
DEBUG - 2014-01-07 21:46:26 --> Output Class Initialized
DEBUG - 2014-01-07 21:46:26 --> Security Class Initialized
DEBUG - 2014-01-07 21:46:26 --> Input Class Initialized
DEBUG - 2014-01-07 21:46:26 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:26 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:26 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:26 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:46:26 --> Language Class Initialized
DEBUG - 2014-01-07 21:46:26 --> Language Class Initialized
DEBUG - 2014-01-07 21:46:26 --> Config Class Initialized
DEBUG - 2014-01-07 21:46:27 --> Loader Class Initialized
DEBUG - 2014-01-07 21:46:27 --> Controller Class Initialized
DEBUG - 2014-01-07 21:46:27 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:46:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:46:27 --> Session Class Initialized
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:46:27 --> Session routines successfully run
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:46:27 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:46:27 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:46:27 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:46:27 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:46:27 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:46:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:46:27 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:46:27 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-01-07 21:46:27 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:27 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:46:27 --> Final output sent to browser
DEBUG - 2014-01-07 21:46:27 --> Total execution time: 0.6001
DEBUG - 2014-01-07 21:46:38 --> Config Class Initialized
DEBUG - 2014-01-07 21:46:38 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:46:38 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:46:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:46:38 --> URI Class Initialized
DEBUG - 2014-01-07 21:46:38 --> Router Class Initialized
DEBUG - 2014-01-07 21:46:38 --> Output Class Initialized
DEBUG - 2014-01-07 21:46:38 --> Security Class Initialized
DEBUG - 2014-01-07 21:46:38 --> Input Class Initialized
DEBUG - 2014-01-07 21:46:38 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:38 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:38 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:39 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:46:39 --> Language Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Language Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Config Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Loader Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Controller Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:46:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:46:39 --> Session Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:46:39 --> Session routines successfully run
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:46:39 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:46:39 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:46:39 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:46:39 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:46:39 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:46:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:46:39 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:46:39 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-01-07 21:46:39 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:39 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:46:39 --> Final output sent to browser
DEBUG - 2014-01-07 21:46:39 --> Total execution time: 0.5756
DEBUG - 2014-01-07 21:46:51 --> Config Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:46:51 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:46:51 --> URI Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Router Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Output Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Security Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Input Class Initialized
DEBUG - 2014-01-07 21:46:51 --> XSS Filtering completed
DEBUG - 2014-01-07 21:46:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:46:51 --> Language Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Language Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Config Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Loader Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Controller Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:46:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:46:51 --> Session Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:46:51 --> Session routines successfully run
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:46:51 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:46:51 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:46:51 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:46:51 --> Model Class Initialized
DEBUG - 2014-01-07 21:46:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:46:51 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:46:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:46:51 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:46:51 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:46:51 --> Final output sent to browser
DEBUG - 2014-01-07 21:46:51 --> Total execution time: 0.4424
DEBUG - 2014-01-07 21:47:00 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:00 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:47:00 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:47:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:47:00 --> URI Class Initialized
DEBUG - 2014-01-07 21:47:00 --> Router Class Initialized
DEBUG - 2014-01-07 21:47:00 --> Output Class Initialized
DEBUG - 2014-01-07 21:47:00 --> Security Class Initialized
DEBUG - 2014-01-07 21:47:00 --> Input Class Initialized
DEBUG - 2014-01-07 21:47:00 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:00 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:00 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:01 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:47:01 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Loader Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Controller Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:47:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:47:01 --> Session Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:47:01 --> Session routines successfully run
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:47:01 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:47:01 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:47:01 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:47:01 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:47:01 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:47:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:47:01 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:47:01 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-01-07 21:47:01 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:01 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:47:01 --> Final output sent to browser
DEBUG - 2014-01-07 21:47:01 --> Total execution time: 1.0554
DEBUG - 2014-01-07 21:47:10 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:47:11 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:47:11 --> URI Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Router Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Output Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Security Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Input Class Initialized
DEBUG - 2014-01-07 21:47:11 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:11 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:11 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:11 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:47:11 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Loader Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Controller Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:47:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:47:11 --> Session Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:47:11 --> Session routines successfully run
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:47:11 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:47:11 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:47:11 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:47:11 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:47:11 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:47:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:47:11 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:47:11 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-01-07 21:47:11 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:11 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:47:11 --> Final output sent to browser
DEBUG - 2014-01-07 21:47:11 --> Total execution time: 0.5116
DEBUG - 2014-01-07 21:47:34 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:47:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:47:35 --> URI Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Router Class Initialized
DEBUG - 2014-01-07 21:47:35 --> No URI present. Default controller set.
DEBUG - 2014-01-07 21:47:35 --> Output Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Security Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Input Class Initialized
DEBUG - 2014-01-07 21:47:35 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:47:35 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Loader Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Controller Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Session Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:47:35 --> Session routines successfully run
DEBUG - 2014-01-07 21:47:35 --> Dashboard MX_Controller Initialized
DEBUG - 2014-01-07 21:47:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:47:35 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:47:35 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:47:35 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:47:35 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:47:35 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:47:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:47:35 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:47:36 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:47:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:47:36 --> URI Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Router Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Output Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Security Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Input Class Initialized
DEBUG - 2014-01-07 21:47:36 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:47:36 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Loader Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Controller Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:47:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:47:36 --> Session Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:47:36 --> Session routines successfully run
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:47:36 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:47:36 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:47:36 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:47:36 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:47:36 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:47:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:47:36 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:47:36 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:47:36 --> Final output sent to browser
DEBUG - 2014-01-07 21:47:36 --> Total execution time: 0.4749
DEBUG - 2014-01-07 21:47:49 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:47:49 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:47:49 --> URI Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Router Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Output Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Security Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Input Class Initialized
DEBUG - 2014-01-07 21:47:49 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:49 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:49 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:49 --> XSS Filtering completed
DEBUG - 2014-01-07 21:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:47:49 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Language Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Config Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Loader Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Controller Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:47:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:47:49 --> Session Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:47:49 --> Session routines successfully run
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:47:49 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:47:49 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:47:49 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:47:49 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:47:49 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:47:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:47:49 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:47:49 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-01-07 21:47:49 --> Model Class Initialized
DEBUG - 2014-01-07 21:47:49 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:47:49 --> Final output sent to browser
DEBUG - 2014-01-07 21:47:49 --> Total execution time: 0.5220
DEBUG - 2014-01-07 21:48:02 --> Config Class Initialized
DEBUG - 2014-01-07 21:48:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 21:48:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 21:48:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 21:48:02 --> URI Class Initialized
DEBUG - 2014-01-07 21:48:02 --> Router Class Initialized
DEBUG - 2014-01-07 21:48:02 --> Output Class Initialized
DEBUG - 2014-01-07 21:48:02 --> Security Class Initialized
DEBUG - 2014-01-07 21:48:02 --> Input Class Initialized
DEBUG - 2014-01-07 21:48:02 --> XSS Filtering completed
DEBUG - 2014-01-07 21:48:02 --> XSS Filtering completed
DEBUG - 2014-01-07 21:48:02 --> XSS Filtering completed
DEBUG - 2014-01-07 21:48:02 --> XSS Filtering completed
DEBUG - 2014-01-07 21:48:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 21:48:02 --> Language Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Language Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Config Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Loader Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Controller Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 21:48:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 21:48:03 --> Session Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: string_helper
DEBUG - 2014-01-07 21:48:03 --> Session routines successfully run
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: url_helper
DEBUG - 2014-01-07 21:48:03 --> Database Driver Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: form_helper
DEBUG - 2014-01-07 21:48:03 --> Form Validation Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: number_helper
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: date_helper
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 21:48:03 --> Model Class Initialized
DEBUG - 2014-01-07 21:48:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 21:48:03 --> Model Class Initialized
DEBUG - 2014-01-07 21:48:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 21:48:03 --> Helper loaded: language_helper
DEBUG - 2014-01-07 21:48:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 21:48:03 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 21:48:03 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-01-07 21:48:03 --> Model Class Initialized
DEBUG - 2014-01-07 21:48:03 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 21:48:03 --> Final output sent to browser
DEBUG - 2014-01-07 21:48:03 --> Total execution time: 0.5552
DEBUG - 2014-01-07 23:20:59 --> Config Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:20:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:20:59 --> URI Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Router Class Initialized
DEBUG - 2014-01-07 23:20:59 --> No URI present. Default controller set.
DEBUG - 2014-01-07 23:20:59 --> Output Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Security Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Input Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:20:59 --> Language Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Language Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Config Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Loader Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Controller Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Session Class Initialized
DEBUG - 2014-01-07 23:20:59 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:20:59 --> A session cookie was not found.
DEBUG - 2014-01-07 23:20:59 --> Session routines successfully run
DEBUG - 2014-01-07 23:20:59 --> Dashboard MX_Controller Initialized
DEBUG - 2014-01-07 23:20:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:20:59 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:20:59 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:21:00 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:21:00 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:21:00 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:21:00 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:21:00 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:21:00 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:21:00 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:21:00 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:21:00 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:21:00 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:21:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:21:00 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:21:00 --> Config Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:21:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:21:01 --> URI Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Router Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Output Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Security Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Input Class Initialized
DEBUG - 2014-01-07 23:21:01 --> XSS Filtering completed
DEBUG - 2014-01-07 23:21:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:21:01 --> Language Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Language Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Config Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Loader Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Controller Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 23:21:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:21:01 --> Session Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:21:01 --> Session routines successfully run
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:21:01 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:21:01 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:21:01 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:21:01 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:21:01 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:21:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:21:01 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:21:01 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 23:21:01 --> Final output sent to browser
DEBUG - 2014-01-07 23:21:01 --> Total execution time: 0.7222
DEBUG - 2014-01-07 23:21:32 --> Config Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:21:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:21:32 --> URI Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Router Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Output Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Security Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Input Class Initialized
DEBUG - 2014-01-07 23:21:32 --> XSS Filtering completed
DEBUG - 2014-01-07 23:21:32 --> XSS Filtering completed
DEBUG - 2014-01-07 23:21:32 --> XSS Filtering completed
DEBUG - 2014-01-07 23:21:32 --> XSS Filtering completed
DEBUG - 2014-01-07 23:21:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:21:32 --> Language Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Language Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Config Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Loader Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Controller Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 23:21:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:21:32 --> Session Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:21:32 --> Session routines successfully run
DEBUG - 2014-01-07 23:21:32 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:21:32 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:21:32 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:21:32 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:21:32 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:21:32 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:21:32 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:21:33 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:21:33 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:21:33 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:21:33 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:21:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:21:33 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:21:33 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-01-07 23:21:33 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:33 --> Config Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:21:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:21:34 --> URI Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Router Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Output Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Security Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Input Class Initialized
DEBUG - 2014-01-07 23:21:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:21:34 --> Language Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Language Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Config Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Loader Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Controller Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Session Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:21:34 --> Session routines successfully run
DEBUG - 2014-01-07 23:21:34 --> Dashboard MX_Controller Initialized
DEBUG - 2014-01-07 23:21:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:21:34 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:21:34 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:21:34 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:21:34 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:21:34 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:21:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:21:34 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:21:34 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-01-07 23:21:34 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:34 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:21:34 --> Model Class Initialized
DEBUG - 2014-01-07 23:21:34 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-01-07 23:21:34 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:21:34 --> Final output sent to browser
DEBUG - 2014-01-07 23:21:34 --> Total execution time: 0.5267
DEBUG - 2014-01-07 23:22:44 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:22:44 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:22:44 --> URI Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Router Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Output Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Security Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Input Class Initialized
DEBUG - 2014-01-07 23:22:44 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:22:44 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Loader Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Controller Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Session Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:22:44 --> Session routines successfully run
DEBUG - 2014-01-07 23:22:44 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:22:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:22:44 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:22:44 --> Database Driver Class Initialized
ERROR - 2014-01-07 23:22:44 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away D:\Hosting\11379054\html\renalemr\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-07 23:22:44 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:22:44 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:22:44 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:22:44 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:22:45 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:22:45 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:22:45 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:22:45 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:22:45 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:22:45 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:22:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:22:45 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:22:45 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:22:45 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:45 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:22:45 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-01-07 23:22:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:22:45 --> Final output sent to browser
DEBUG - 2014-01-07 23:22:45 --> Total execution time: 0.6579
DEBUG - 2014-01-07 23:22:54 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:22:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:22:54 --> URI Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Router Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Output Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Security Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Input Class Initialized
DEBUG - 2014-01-07 23:22:54 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:54 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:22:54 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Loader Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Controller Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Session Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:22:54 --> Session routines successfully run
DEBUG - 2014-01-07 23:22:54 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:22:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:22:54 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:22:54 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:22:54 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:22:54 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:22:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:22:54 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:22:54 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:22:54 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:22:54 --> Final output sent to browser
DEBUG - 2014-01-07 23:22:54 --> Total execution time: 0.4659
DEBUG - 2014-01-07 23:22:54 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:22:54 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:22:54 --> URI Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Router Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Output Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Security Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Input Class Initialized
DEBUG - 2014-01-07 23:22:54 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:54 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:22:54 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Loader Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Controller Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Session Class Initialized
DEBUG - 2014-01-07 23:22:54 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:22:54 --> Session routines successfully run
DEBUG - 2014-01-07 23:22:55 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:22:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:22:55 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:22:55 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:22:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:22:55 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:22:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:22:55 --> Final output sent to browser
DEBUG - 2014-01-07 23:22:55 --> Total execution time: 0.3975
DEBUG - 2014-01-07 23:22:55 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:22:55 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:22:55 --> URI Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Router Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Output Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Security Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Input Class Initialized
DEBUG - 2014-01-07 23:22:55 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:55 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:22:55 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Loader Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Controller Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Session Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:22:55 --> Session routines successfully run
DEBUG - 2014-01-07 23:22:55 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:22:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:22:55 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:22:55 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:22:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:22:55 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:22:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:22:55 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:55 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:22:55 --> Final output sent to browser
DEBUG - 2014-01-07 23:22:55 --> Total execution time: 0.4009
DEBUG - 2014-01-07 23:22:56 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:22:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:22:56 --> URI Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Router Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Output Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Security Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Input Class Initialized
DEBUG - 2014-01-07 23:22:56 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:56 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:22:56 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Loader Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Controller Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Session Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:22:56 --> Session routines successfully run
DEBUG - 2014-01-07 23:22:56 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:22:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:22:56 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:22:56 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:22:56 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:22:56 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:22:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:22:57 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:22:57 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:22:57 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:22:57 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:22:57 --> Final output sent to browser
DEBUG - 2014-01-07 23:22:57 --> URI Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Total execution time: 0.4574
DEBUG - 2014-01-07 23:22:57 --> Router Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Output Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Security Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Input Class Initialized
DEBUG - 2014-01-07 23:22:57 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:57 --> XSS Filtering completed
DEBUG - 2014-01-07 23:22:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:22:57 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Language Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Config Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Loader Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Controller Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Session Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:22:57 --> Session routines successfully run
DEBUG - 2014-01-07 23:22:57 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:22:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:22:57 --> Database Driver Class Initialized
ERROR - 2014-01-07 23:22:57 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away D:\Hosting\11379054\html\renalemr\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:22:57 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:22:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:22:57 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:22:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:22:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:22:57 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:22:57 --> Final output sent to browser
DEBUG - 2014-01-07 23:22:57 --> Total execution time: 0.4374
DEBUG - 2014-01-07 23:23:01 --> Config Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:23:01 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:23:01 --> URI Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Router Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Output Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Security Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Input Class Initialized
DEBUG - 2014-01-07 23:23:01 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:23:01 --> Language Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Language Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Config Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Loader Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Controller Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Session Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:23:01 --> Session routines successfully run
DEBUG - 2014-01-07 23:23:01 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:23:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:23:01 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:23:01 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:23:01 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:23:01 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:23:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:23:01 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:23:01 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:23:01 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:01 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:23:01 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-01-07 23:23:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:23:01 --> Final output sent to browser
DEBUG - 2014-01-07 23:23:01 --> Total execution time: 0.4890
DEBUG - 2014-01-07 23:23:20 --> Config Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:23:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:23:20 --> URI Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Router Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Output Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Security Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Input Class Initialized
DEBUG - 2014-01-07 23:23:20 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:23:20 --> Language Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Language Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Config Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Loader Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Controller Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Session Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:23:20 --> Session routines successfully run
DEBUG - 2014-01-07 23:23:20 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:23:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:23:20 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:23:20 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:23:20 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:23:20 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:23:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:23:20 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:23:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:23:20 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:20 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:23:20 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-01-07 23:23:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:23:20 --> Final output sent to browser
DEBUG - 2014-01-07 23:23:20 --> Total execution time: 0.3998
DEBUG - 2014-01-07 23:23:30 --> Config Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:23:30 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:23:30 --> URI Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Router Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Output Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Security Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Input Class Initialized
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:23:30 --> Language Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Language Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Config Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Loader Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Controller Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Session Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:23:30 --> Session routines successfully run
DEBUG - 2014-01-07 23:23:30 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:23:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:23:30 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:23:30 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:23:30 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:23:30 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:23:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:23:30 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:23:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:23:30 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:30 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:23:30 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-01-07 23:23:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:23:30 --> Final output sent to browser
DEBUG - 2014-01-07 23:23:30 --> Total execution time: 0.5346
DEBUG - 2014-01-07 23:23:34 --> Config Class Initialized
DEBUG - 2014-01-07 23:23:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:23:35 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:23:35 --> URI Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Router Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Output Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Security Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Input Class Initialized
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> XSS Filtering completed
DEBUG - 2014-01-07 23:23:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:23:35 --> Language Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Language Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Config Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Loader Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Controller Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Session Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:23:35 --> Session routines successfully run
DEBUG - 2014-01-07 23:23:35 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:23:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:23:35 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:23:35 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:23:35 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:23:35 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:23:35 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:23:35 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:23:35 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:23:35 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:23:36 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:23:36 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:23:36 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:23:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:23:36 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:23:36 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:23:36 --> Model Class Initialized
DEBUG - 2014-01-07 23:23:36 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:23:36 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-01-07 23:23:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:23:36 --> Final output sent to browser
DEBUG - 2014-01-07 23:23:36 --> Total execution time: 1.3240
DEBUG - 2014-01-07 23:24:29 --> Config Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:24:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:24:29 --> URI Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Router Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Output Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Security Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Input Class Initialized
DEBUG - 2014-01-07 23:24:29 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:24:29 --> Language Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Language Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Config Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Loader Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Controller Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Session Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:24:29 --> Session routines successfully run
DEBUG - 2014-01-07 23:24:29 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:24:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:24:29 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:24:29 --> Database Driver Class Initialized
ERROR - 2014-01-07 23:24:29 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away D:\Hosting\11379054\html\renalemr\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-07 23:24:29 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:24:29 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:24:29 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:24:29 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:24:29 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:24:29 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:24:29 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:24:29 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:24:30 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:24:30 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:24:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:24:30 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:24:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:24:30 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:30 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:24:30 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-01-07 23:24:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:24:30 --> Final output sent to browser
DEBUG - 2014-01-07 23:24:30 --> Total execution time: 0.8761
DEBUG - 2014-01-07 23:24:34 --> Config Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:24:34 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:24:34 --> URI Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Router Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Output Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Security Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Input Class Initialized
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:24:34 --> Language Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Language Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Config Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Loader Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Controller Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Session Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:24:34 --> Session routines successfully run
DEBUG - 2014-01-07 23:24:34 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:24:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:24:34 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:24:34 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:24:34 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:24:34 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:24:34 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:24:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:24:34 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:24:35 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:24:35 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:35 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:24:35 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-01-07 23:24:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:24:35 --> Final output sent to browser
DEBUG - 2014-01-07 23:24:35 --> Total execution time: 1.0169
DEBUG - 2014-01-07 23:24:41 --> Config Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:24:41 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:24:41 --> URI Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Router Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Output Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Security Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Input Class Initialized
DEBUG - 2014-01-07 23:24:41 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:24:41 --> Language Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Language Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Config Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Loader Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Controller Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Session Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:24:41 --> Session routines successfully run
DEBUG - 2014-01-07 23:24:41 --> Scheduler MX_Controller Initialized
DEBUG - 2014-01-07 23:24:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:24:41 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:24:41 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:24:41 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:24:41 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:24:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:24:41 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:24:41 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-01-07 23:24:41 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:41 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:24:41 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-01-07 23:24:42 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:42 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-01-07 23:24:42 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:42 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-01-07 23:24:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:24:42 --> Final output sent to browser
DEBUG - 2014-01-07 23:24:42 --> Total execution time: 0.8777
DEBUG - 2014-01-07 23:24:46 --> Config Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:24:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:24:46 --> URI Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Router Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Output Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Security Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Input Class Initialized
DEBUG - 2014-01-07 23:24:46 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:46 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:46 --> XSS Filtering completed
DEBUG - 2014-01-07 23:24:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:24:46 --> Language Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Language Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Config Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Loader Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Controller Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Session Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:24:46 --> Session routines successfully run
DEBUG - 2014-01-07 23:24:46 --> Scheduler MX_Controller Initialized
DEBUG - 2014-01-07 23:24:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:24:46 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:24:46 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:24:46 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:24:46 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:24:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:24:46 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:24:46 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-01-07 23:24:46 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:46 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:24:46 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-01-07 23:24:46 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:46 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-01-07 23:24:46 --> Model Class Initialized
DEBUG - 2014-01-07 23:24:46 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-01-07 23:24:46 --> Final output sent to browser
DEBUG - 2014-01-07 23:24:46 --> Total execution time: 0.5434
DEBUG - 2014-01-07 23:25:00 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:25:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:25:00 --> URI Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Router Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Output Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Security Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Input Class Initialized
DEBUG - 2014-01-07 23:25:00 --> XSS Filtering completed
DEBUG - 2014-01-07 23:25:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:25:00 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Loader Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Controller Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Session Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:25:00 --> Session routines successfully run
DEBUG - 2014-01-07 23:25:00 --> Admin MX_Controller Initialized
DEBUG - 2014-01-07 23:25:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:25:00 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:25:00 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:25:00 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:25:00 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:25:00 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:25:00 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:25:00 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:25:01 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:25:01 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:25:01 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:25:01 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:25:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:25:01 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:25:01 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-01-07 23:25:01 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:01 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:25:01 --> File loaded: application/modules/admin/views/Admin.php
DEBUG - 2014-01-07 23:25:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:25:01 --> Final output sent to browser
DEBUG - 2014-01-07 23:25:01 --> Total execution time: 0.9698
DEBUG - 2014-01-07 23:25:09 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:25:09 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:25:09 --> URI Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Router Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Output Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Security Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Input Class Initialized
DEBUG - 2014-01-07 23:25:09 --> XSS Filtering completed
DEBUG - 2014-01-07 23:25:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:25:09 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Loader Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Controller Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Session Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:25:09 --> Session routines successfully run
DEBUG - 2014-01-07 23:25:09 --> Admin MX_Controller Initialized
DEBUG - 2014-01-07 23:25:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:25:09 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:25:09 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:25:09 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:25:09 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:25:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:25:09 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:25:09 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-01-07 23:25:09 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:09 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:25:09 --> File loaded: application/modules/admin/views/user.php
DEBUG - 2014-01-07 23:25:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:25:09 --> Final output sent to browser
DEBUG - 2014-01-07 23:25:09 --> Total execution time: 0.6012
DEBUG - 2014-01-07 23:25:36 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:36 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:25:36 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:25:36 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:25:36 --> URI Class Initialized
DEBUG - 2014-01-07 23:25:36 --> Router Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Output Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Security Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Input Class Initialized
DEBUG - 2014-01-07 23:25:37 --> XSS Filtering completed
DEBUG - 2014-01-07 23:25:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:25:37 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Loader Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Controller Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Session Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:25:37 --> Session routines successfully run
DEBUG - 2014-01-07 23:25:37 --> Admin MX_Controller Initialized
DEBUG - 2014-01-07 23:25:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:25:37 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:25:37 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:25:37 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:25:37 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:25:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:25:37 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:25:37 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-01-07 23:25:37 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:37 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:25:37 --> File loaded: application/modules/admin/views/injection.php
DEBUG - 2014-01-07 23:25:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:25:37 --> Final output sent to browser
DEBUG - 2014-01-07 23:25:37 --> Total execution time: 0.8829
DEBUG - 2014-01-07 23:25:52 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:25:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:25:52 --> URI Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Router Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Output Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Security Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Input Class Initialized
DEBUG - 2014-01-07 23:25:52 --> XSS Filtering completed
DEBUG - 2014-01-07 23:25:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:25:52 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Loader Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Controller Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Session Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:25:52 --> Session routines successfully run
DEBUG - 2014-01-07 23:25:52 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:25:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:25:52 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:25:52 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:25:52 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:25:52 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:25:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:25:52 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:25:52 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:25:52 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:52 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:25:52 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-01-07 23:25:52 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:25:52 --> Final output sent to browser
DEBUG - 2014-01-07 23:25:52 --> Total execution time: 0.5138
DEBUG - 2014-01-07 23:25:58 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:25:58 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:25:58 --> URI Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Router Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Output Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Security Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Input Class Initialized
DEBUG - 2014-01-07 23:25:58 --> XSS Filtering completed
DEBUG - 2014-01-07 23:25:58 --> XSS Filtering completed
DEBUG - 2014-01-07 23:25:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:25:58 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Loader Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Controller Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Session Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:25:58 --> Session routines successfully run
DEBUG - 2014-01-07 23:25:58 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:25:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:25:58 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:25:58 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:25:58 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:25:58 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:25:59 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:25:59 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:25:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:25:59 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:25:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:25:59 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:25:59 --> Final output sent to browser
DEBUG - 2014-01-07 23:25:59 --> Total execution time: 0.7111
DEBUG - 2014-01-07 23:25:59 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:25:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:25:59 --> URI Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Router Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Output Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Security Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Input Class Initialized
DEBUG - 2014-01-07 23:25:59 --> XSS Filtering completed
DEBUG - 2014-01-07 23:25:59 --> XSS Filtering completed
DEBUG - 2014-01-07 23:25:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:25:59 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Language Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Loader Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Controller Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Session Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:25:59 --> Session routines successfully run
DEBUG - 2014-01-07 23:25:59 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:25:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:25:59 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:25:59 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:25:59 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:25:59 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:25:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:25:59 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:25:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:25:59 --> Model Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:25:59 --> Final output sent to browser
DEBUG - 2014-01-07 23:25:59 --> Total execution time: 0.4517
DEBUG - 2014-01-07 23:25:59 --> Config Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:25:59 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:25:59 --> URI Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Router Class Initialized
DEBUG - 2014-01-07 23:25:59 --> Output Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Security Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Input Class Initialized
DEBUG - 2014-01-07 23:26:00 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:00 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:26:00 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Loader Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Controller Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Session Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:26:00 --> Session routines successfully run
DEBUG - 2014-01-07 23:26:00 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:26:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:26:00 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:26:00 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:26:00 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:26:00 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:26:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:26:00 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:26:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:26:00 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:26:00 --> Final output sent to browser
DEBUG - 2014-01-07 23:26:00 --> Total execution time: 0.5189
DEBUG - 2014-01-07 23:26:00 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:26:00 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:26:00 --> URI Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Router Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Output Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Security Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Input Class Initialized
DEBUG - 2014-01-07 23:26:00 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:00 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:26:00 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Loader Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Controller Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Session Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:26:00 --> Session routines successfully run
DEBUG - 2014-01-07 23:26:00 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:26:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:26:00 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:26:00 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:26:00 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:26:00 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:26:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:26:00 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:26:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:26:00 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:00 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:26:00 --> Final output sent to browser
DEBUG - 2014-01-07 23:26:00 --> Total execution time: 0.4593
DEBUG - 2014-01-07 23:26:04 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:26:04 --> URI Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Router Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Output Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Security Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Input Class Initialized
DEBUG - 2014-01-07 23:26:04 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:26:04 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Loader Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Controller Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Session Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:26:04 --> Session routines successfully run
DEBUG - 2014-01-07 23:26:04 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:26:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:26:04 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:26:04 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:26:04 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:26:04 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:26:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:26:04 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:26:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:26:04 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:26:04 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-01-07 23:26:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:26:04 --> Final output sent to browser
DEBUG - 2014-01-07 23:26:04 --> Total execution time: 0.7507
DEBUG - 2014-01-07 23:26:04 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:26:04 --> URI Class Initialized
DEBUG - 2014-01-07 23:26:04 --> Router Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Output Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Security Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Input Class Initialized
DEBUG - 2014-01-07 23:26:05 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:05 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:26:05 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Loader Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Controller Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Session Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:26:05 --> Session routines successfully run
DEBUG - 2014-01-07 23:26:05 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:26:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:26:05 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:26:05 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:26:05 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:26:05 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:26:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:26:05 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:26:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:26:05 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:05 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:26:05 --> Final output sent to browser
DEBUG - 2014-01-07 23:26:05 --> Total execution time: 0.4865
DEBUG - 2014-01-07 23:26:17 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:17 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:26:17 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:26:17 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:26:17 --> URI Class Initialized
DEBUG - 2014-01-07 23:26:17 --> Router Class Initialized
DEBUG - 2014-01-07 23:26:17 --> Output Class Initialized
DEBUG - 2014-01-07 23:26:17 --> Security Class Initialized
DEBUG - 2014-01-07 23:26:17 --> Input Class Initialized
DEBUG - 2014-01-07 23:26:18 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:26:18 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Loader Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Controller Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Session Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:26:18 --> Session routines successfully run
DEBUG - 2014-01-07 23:26:18 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:26:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:26:18 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:26:18 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:26:18 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:26:18 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:26:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:26:18 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:26:18 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:26:18 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:18 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:26:18 --> File loaded: application/modules/patient/views/admission_data.php
DEBUG - 2014-01-07 23:26:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:26:18 --> Final output sent to browser
DEBUG - 2014-01-07 23:26:18 --> Total execution time: 0.7765
DEBUG - 2014-01-07 23:26:29 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:26:29 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:26:29 --> URI Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Router Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Output Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Security Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Input Class Initialized
DEBUG - 2014-01-07 23:26:29 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:26:29 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Loader Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Controller Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Session Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:26:29 --> Session routines successfully run
DEBUG - 2014-01-07 23:26:29 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:26:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:26:29 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:26:29 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:26:29 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:26:29 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:26:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:26:29 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:26:29 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:26:29 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:29 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:26:29 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-01-07 23:26:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:26:29 --> Final output sent to browser
DEBUG - 2014-01-07 23:26:30 --> Total execution time: 0.5328
DEBUG - 2014-01-07 23:26:38 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:26:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:26:38 --> URI Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Router Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Output Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Security Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Input Class Initialized
DEBUG - 2014-01-07 23:26:38 --> XSS Filtering completed
DEBUG - 2014-01-07 23:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:26:38 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Language Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Config Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Loader Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Controller Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Session Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:26:38 --> Session routines successfully run
DEBUG - 2014-01-07 23:26:38 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:26:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:26:38 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:26:38 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:26:38 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:26:38 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:26:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:26:38 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:26:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:26:38 --> Model Class Initialized
DEBUG - 2014-01-07 23:26:38 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:26:38 --> File loaded: application/modules/patient/views/add_note.php
DEBUG - 2014-01-07 23:26:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:26:38 --> Final output sent to browser
DEBUG - 2014-01-07 23:26:38 --> Total execution time: 0.6321
DEBUG - 2014-01-07 23:27:04 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:27:04 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:27:04 --> URI Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Router Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Output Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Security Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Input Class Initialized
DEBUG - 2014-01-07 23:27:04 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:04 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:04 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:04 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:04 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:27:04 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Loader Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Controller Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Session Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:27:04 --> Session routines successfully run
DEBUG - 2014-01-07 23:27:04 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:27:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:27:04 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:27:04 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:27:04 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:27:04 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:27:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:27:04 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:27:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:27:04 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:04 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:27:05 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:27:05 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:27:05 --> URI Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Router Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Output Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Security Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Input Class Initialized
DEBUG - 2014-01-07 23:27:05 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:27:05 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Loader Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Controller Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Session Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:27:05 --> Session routines successfully run
DEBUG - 2014-01-07 23:27:05 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:27:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:27:05 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:27:05 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:27:05 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:27:05 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:27:05 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:27:05 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:27:05 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:27:05 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:27:05 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:27:06 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:27:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:27:06 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:27:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:27:06 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:06 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:27:06 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-01-07 23:27:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:27:06 --> Final output sent to browser
DEBUG - 2014-01-07 23:27:06 --> Total execution time: 0.4167
DEBUG - 2014-01-07 23:27:39 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:39 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:27:39 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:27:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:27:39 --> URI Class Initialized
DEBUG - 2014-01-07 23:27:39 --> Router Class Initialized
DEBUG - 2014-01-07 23:27:39 --> Output Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Security Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Input Class Initialized
DEBUG - 2014-01-07 23:27:40 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:27:40 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Loader Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Controller Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Session Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:27:40 --> Session routines successfully run
DEBUG - 2014-01-07 23:27:40 --> Clinicalchart MX_Controller Initialized
DEBUG - 2014-01-07 23:27:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:27:40 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:27:40 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:27:40 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:27:40 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:27:40 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:27:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:27:40 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:27:40 --> File loaded: application/modules/clinicalchart/models/mdl_clinicalchart.php
DEBUG - 2014-01-07 23:27:40 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:40 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:27:40 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:40 --> Pagination Class Initialized
DEBUG - 2014-01-07 23:27:40 --> File loaded: application/modules/clinicalchart/views/clinicalchart.php
DEBUG - 2014-01-07 23:27:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:27:40 --> Final output sent to browser
DEBUG - 2014-01-07 23:27:40 --> Total execution time: 0.5985
DEBUG - 2014-01-07 23:27:42 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:27:42 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:27:42 --> URI Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Router Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Output Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Security Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Input Class Initialized
DEBUG - 2014-01-07 23:27:42 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:27:42 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Loader Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Controller Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Session Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:27:42 --> Session routines successfully run
DEBUG - 2014-01-07 23:27:42 --> Bloodtest MX_Controller Initialized
DEBUG - 2014-01-07 23:27:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:27:42 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:27:42 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:27:42 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:27:42 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:27:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:27:42 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:27:42 --> File loaded: application/modules/bloodtest/models/mdl_bloodtest.php
DEBUG - 2014-01-07 23:27:42 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:27:42 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:42 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:27:43 --> File loaded: application/modules/bloodtest/views/bloodtest.php
DEBUG - 2014-01-07 23:27:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:27:43 --> Final output sent to browser
DEBUG - 2014-01-07 23:27:43 --> Total execution time: 0.5164
DEBUG - 2014-01-07 23:27:43 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:27:43 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:27:43 --> URI Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Router Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Output Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Security Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Input Class Initialized
DEBUG - 2014-01-07 23:27:43 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:27:43 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Loader Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Controller Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Session Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:27:43 --> Session routines successfully run
DEBUG - 2014-01-07 23:27:43 --> Medication MX_Controller Initialized
DEBUG - 2014-01-07 23:27:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:27:43 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:27:43 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:27:43 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:27:43 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:27:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:27:43 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:27:43 --> File loaded: application/modules/medication/models/mdl_medication.php
DEBUG - 2014-01-07 23:27:43 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:27:43 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:43 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:27:43 --> File loaded: application/modules/medication/views/medication.php
DEBUG - 2014-01-07 23:27:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:27:43 --> Final output sent to browser
DEBUG - 2014-01-07 23:27:43 --> Total execution time: 0.4818
DEBUG - 2014-01-07 23:27:48 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:27:48 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:27:48 --> URI Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Router Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Output Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Security Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Input Class Initialized
DEBUG - 2014-01-07 23:27:48 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:27:48 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Loader Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Controller Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Session Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:27:48 --> Session routines successfully run
DEBUG - 2014-01-07 23:27:48 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:27:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:27:48 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:27:48 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:27:48 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:27:48 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:27:48 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:27:49 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:27:49 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:27:49 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:27:49 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:27:49 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:27:49 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:27:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:27:49 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:27:49 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:27:49 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:49 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:27:49 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-01-07 23:27:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:27:49 --> Final output sent to browser
DEBUG - 2014-01-07 23:27:49 --> Total execution time: 0.5178
DEBUG - 2014-01-07 23:27:52 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:52 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:27:52 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:27:53 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:27:53 --> URI Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Router Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Output Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Security Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Input Class Initialized
DEBUG - 2014-01-07 23:27:53 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:27:53 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Loader Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Controller Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Session Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:27:53 --> Session routines successfully run
DEBUG - 2014-01-07 23:27:53 --> Scheduler MX_Controller Initialized
DEBUG - 2014-01-07 23:27:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:27:53 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:27:53 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:27:53 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:27:53 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:27:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:27:53 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:27:53 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-01-07 23:27:53 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:53 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:27:53 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-01-07 23:27:53 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:53 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-01-07 23:27:53 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:53 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-01-07 23:27:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:27:53 --> Final output sent to browser
DEBUG - 2014-01-07 23:27:53 --> Total execution time: 0.6944
DEBUG - 2014-01-07 23:27:56 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:27:56 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:27:56 --> URI Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Router Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Output Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Security Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Input Class Initialized
DEBUG - 2014-01-07 23:27:56 --> XSS Filtering completed
DEBUG - 2014-01-07 23:27:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:27:56 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Language Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Config Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Loader Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Controller Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Session Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:27:56 --> Session routines successfully run
DEBUG - 2014-01-07 23:27:56 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:27:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:27:56 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:27:56 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:27:56 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:27:56 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:27:56 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:27:56 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:27:57 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:27:57 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:27:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:27:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:27:57 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:27:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:27:57 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:27:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:27:57 --> Model Class Initialized
DEBUG - 2014-01-07 23:27:57 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:27:57 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-01-07 23:27:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:27:57 --> Final output sent to browser
DEBUG - 2014-01-07 23:27:57 --> Total execution time: 0.4651
DEBUG - 2014-01-07 23:28:02 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:28:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:28:02 --> URI Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Router Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Output Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Security Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Input Class Initialized
DEBUG - 2014-01-07 23:28:02 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:28:02 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Loader Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Controller Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Session Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:28:02 --> Session routines successfully run
DEBUG - 2014-01-07 23:28:02 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:28:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:28:02 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:28:02 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:28:02 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:28:02 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:28:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:28:02 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:28:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:28:02 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:28:02 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-01-07 23:28:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:28:02 --> Final output sent to browser
DEBUG - 2014-01-07 23:28:02 --> Total execution time: 0.4283
DEBUG - 2014-01-07 23:28:02 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:28:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:28:02 --> URI Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Router Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Output Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Security Class Initialized
DEBUG - 2014-01-07 23:28:02 --> Input Class Initialized
DEBUG - 2014-01-07 23:28:02 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:28:03 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Loader Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Controller Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Session Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:28:03 --> Session routines successfully run
DEBUG - 2014-01-07 23:28:03 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:28:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:28:03 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:28:03 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:28:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:28:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:28:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:28:03 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:28:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:28:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:03 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:28:03 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-01-07 23:28:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:28:03 --> Final output sent to browser
DEBUG - 2014-01-07 23:28:03 --> Total execution time: 0.3861
DEBUG - 2014-01-07 23:28:26 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:28:26 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:28:26 --> URI Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Router Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Output Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Security Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Input Class Initialized
DEBUG - 2014-01-07 23:28:26 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:26 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:28:26 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Loader Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Controller Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Session Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:28:26 --> Session routines successfully run
DEBUG - 2014-01-07 23:28:26 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:28:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:28:26 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:28:26 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:28:26 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:28:26 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:28:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:28:26 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:28:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:28:26 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:26 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:28:26 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-01-07 23:28:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:28:26 --> Final output sent to browser
DEBUG - 2014-01-07 23:28:26 --> Total execution time: 0.3910
DEBUG - 2014-01-07 23:28:32 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:28:32 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:28:32 --> URI Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Router Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Output Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Security Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Input Class Initialized
DEBUG - 2014-01-07 23:28:32 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:32 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:28:32 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Loader Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Controller Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Session Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:28:32 --> Session routines successfully run
DEBUG - 2014-01-07 23:28:32 --> Dashboard MX_Controller Initialized
DEBUG - 2014-01-07 23:28:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:28:32 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:28:32 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:28:32 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:28:32 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:28:32 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:28:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:28:33 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:28:33 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-01-07 23:28:33 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:28:33 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:33 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-01-07 23:28:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:28:33 --> Final output sent to browser
DEBUG - 2014-01-07 23:28:33 --> Total execution time: 0.7618
DEBUG - 2014-01-07 23:28:38 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:28:38 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:28:38 --> URI Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Router Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Output Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Security Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Input Class Initialized
DEBUG - 2014-01-07 23:28:38 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:38 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:28:38 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Loader Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Controller Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Session Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:28:38 --> Session routines successfully run
DEBUG - 2014-01-07 23:28:38 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:28:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:28:38 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:28:38 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:28:38 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:28:38 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:28:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:28:38 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:28:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:28:38 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:38 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:28:38 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-01-07 23:28:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:28:39 --> Final output sent to browser
DEBUG - 2014-01-07 23:28:39 --> Total execution time: 0.4560
DEBUG - 2014-01-07 23:28:46 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:46 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:28:46 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:28:46 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:28:46 --> URI Class Initialized
DEBUG - 2014-01-07 23:28:46 --> Router Class Initialized
DEBUG - 2014-01-07 23:28:46 --> Output Class Initialized
DEBUG - 2014-01-07 23:28:46 --> Security Class Initialized
DEBUG - 2014-01-07 23:28:46 --> Input Class Initialized
DEBUG - 2014-01-07 23:28:46 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:46 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:28:47 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Loader Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Controller Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Session Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:28:47 --> Session routines successfully run
DEBUG - 2014-01-07 23:28:47 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:28:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:28:47 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:28:47 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:28:47 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:28:47 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:28:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:28:47 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:28:47 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:28:47 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:47 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:28:47 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-01-07 23:28:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:28:47 --> Final output sent to browser
DEBUG - 2014-01-07 23:28:47 --> Total execution time: 0.7243
DEBUG - 2014-01-07 23:28:52 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:28:52 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:28:52 --> URI Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Router Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Output Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Security Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Input Class Initialized
DEBUG - 2014-01-07 23:28:52 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:52 --> XSS Filtering completed
DEBUG - 2014-01-07 23:28:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:28:52 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Language Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Config Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Loader Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Controller Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Session Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:28:52 --> Session routines successfully run
DEBUG - 2014-01-07 23:28:52 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:28:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:28:52 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:28:52 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:28:52 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:28:52 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:28:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:28:52 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:28:52 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:28:52 --> Model Class Initialized
DEBUG - 2014-01-07 23:28:52 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:28:52 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-01-07 23:28:52 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:28:52 --> Final output sent to browser
DEBUG - 2014-01-07 23:28:52 --> Total execution time: 0.4026
DEBUG - 2014-01-07 23:29:02 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:02 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:29:02 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:29:02 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:29:02 --> URI Class Initialized
DEBUG - 2014-01-07 23:29:02 --> Router Class Initialized
DEBUG - 2014-01-07 23:29:02 --> Output Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Security Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Input Class Initialized
DEBUG - 2014-01-07 23:29:03 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:03 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:29:03 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Loader Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Controller Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Session Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:29:03 --> Session routines successfully run
DEBUG - 2014-01-07 23:29:03 --> Patient MX_Controller Initialized
DEBUG - 2014-01-07 23:29:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:29:03 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:29:03 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:29:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:29:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:29:03 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:29:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: image_helper
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-01-07 23:29:03 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:29:03 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Final output sent to browser
DEBUG - 2014-01-07 23:29:03 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Total execution time: 0.6062
DEBUG - 2014-01-07 23:29:03 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:29:03 --> URI Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Router Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Output Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Security Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Input Class Initialized
DEBUG - 2014-01-07 23:29:03 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:03 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:29:03 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Loader Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Controller Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Session Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:29:03 --> Session routines successfully run
DEBUG - 2014-01-07 23:29:03 --> Dashboard MX_Controller Initialized
DEBUG - 2014-01-07 23:29:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:29:03 --> Database Driver Class Initialized
ERROR - 2014-01-07 23:29:03 --> Severity: Warning  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: MySQL server has gone away D:\Hosting\11379054\html\renalemr\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:29:03 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:29:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:29:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:29:03 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:29:03 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-01-07 23:29:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:29:03 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-01-07 23:29:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:29:03 --> Final output sent to browser
DEBUG - 2014-01-07 23:29:03 --> Total execution time: 0.5491
DEBUG - 2014-01-07 23:29:19 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:29:19 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:29:19 --> URI Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Router Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Output Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Security Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Input Class Initialized
DEBUG - 2014-01-07 23:29:19 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:19 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:29:19 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Loader Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Controller Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Session Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:29:19 --> Session routines successfully run
DEBUG - 2014-01-07 23:29:19 --> Dashboard MX_Controller Initialized
DEBUG - 2014-01-07 23:29:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:29:19 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:29:19 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:29:19 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:29:19 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:29:19 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:29:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:29:19 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:29:19 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-01-07 23:29:19 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:19 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:29:19 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:29:20 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:29:20 --> URI Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Router Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Output Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Security Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Input Class Initialized
DEBUG - 2014-01-07 23:29:20 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:20 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:29:20 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Loader Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Controller Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Session Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:29:20 --> Session routines successfully run
DEBUG - 2014-01-07 23:29:20 --> Dashboard MX_Controller Initialized
DEBUG - 2014-01-07 23:29:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:29:20 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:29:20 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:29:20 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:29:20 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:29:20 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:29:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:29:20 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:29:20 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-01-07 23:29:20 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-01-07 23:29:20 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:20 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-01-07 23:29:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-01-07 23:29:20 --> Final output sent to browser
DEBUG - 2014-01-07 23:29:20 --> Total execution time: 0.4671
DEBUG - 2014-01-07 23:29:39 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:29:39 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:29:39 --> URI Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Router Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Output Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Security Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Input Class Initialized
DEBUG - 2014-01-07 23:29:39 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:39 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:29:39 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Loader Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Controller Class Initialized
DEBUG - 2014-01-07 23:29:39 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 23:29:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:29:39 --> Session Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:29:40 --> Session routines successfully run
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:29:40 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:29:40 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:29:40 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:29:40 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:29:40 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:29:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:29:40 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:29:40 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Hooks Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Utf8 Class Initialized
DEBUG - 2014-01-07 23:29:40 --> UTF-8 Support Enabled
DEBUG - 2014-01-07 23:29:40 --> URI Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Router Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Output Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Security Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Input Class Initialized
DEBUG - 2014-01-07 23:29:40 --> XSS Filtering completed
DEBUG - 2014-01-07 23:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-01-07 23:29:40 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Language Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Config Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Loader Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Controller Class Initialized
DEBUG - 2014-01-07 23:29:40 --> Sessions MX_Controller Initialized
DEBUG - 2014-01-07 23:29:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-01-07 23:29:41 --> Session Class Initialized
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: string_helper
DEBUG - 2014-01-07 23:29:41 --> A session cookie was not found.
DEBUG - 2014-01-07 23:29:41 --> Session routines successfully run
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: url_helper
DEBUG - 2014-01-07 23:29:41 --> Database Driver Class Initialized
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: form_helper
DEBUG - 2014-01-07 23:29:41 --> Form Validation Class Initialized
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: number_helper
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: pager_helper
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: invoice_helper
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: date_helper
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: redirect_helper
DEBUG - 2014-01-07 23:29:41 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-01-07 23:29:41 --> Model Class Initialized
DEBUG - 2014-01-07 23:29:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-01-07 23:29:41 --> Helper loaded: language_helper
DEBUG - 2014-01-07 23:29:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-01-07 23:29:41 --> Layout MX_Controller Initialized
DEBUG - 2014-01-07 23:29:41 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-01-07 23:29:41 --> Final output sent to browser
DEBUG - 2014-01-07 23:29:41 --> Total execution time: 0.4024
