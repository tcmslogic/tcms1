<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-22 10:24:40 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:24:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:24:40 --> URI Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Router Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Output Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Security Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Input Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:24:40 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Loader Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:24:40 --> Controller Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Session Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:24:40 --> A session cookie was not found.
DEBUG - 2014-02-22 10:24:40 --> Session routines successfully run
DEBUG - 2014-02-22 10:24:40 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:24:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:24:40 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:24:40 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:24:40 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:24:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:24:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:24:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:24:40 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:24:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:24:40 --> URI Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Router Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Output Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Security Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Input Class Initialized
DEBUG - 2014-02-22 10:24:40 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:24:40 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Loader Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:24:40 --> Controller Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-22 10:24:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:24:40 --> Session Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:24:40 --> Session routines successfully run
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:24:40 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:24:40 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:24:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:24:40 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:24:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:24:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:24:40 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-22 10:24:40 --> Final output sent to browser
DEBUG - 2014-02-22 10:24:40 --> Total execution time: 0.0334
DEBUG - 2014-02-22 10:24:49 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:24:49 --> URI Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Router Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Output Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Security Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Input Class Initialized
DEBUG - 2014-02-22 10:24:49 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:49 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:49 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:49 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:24:49 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Loader Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:24:49 --> Controller Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-22 10:24:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:24:49 --> Session Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:24:49 --> Session routines successfully run
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:24:49 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:24:49 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:24:49 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:24:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:24:49 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:24:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:24:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:24:49 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:49 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-22 10:24:49 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:24:50 --> URI Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Router Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Output Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Security Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Input Class Initialized
DEBUG - 2014-02-22 10:24:50 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:24:50 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Loader Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:24:50 --> Controller Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Session Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:24:50 --> Session routines successfully run
DEBUG - 2014-02-22 10:24:50 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 10:24:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:24:50 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:24:50 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:24:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:24:50 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:24:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:24:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:24:50 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:50 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 10:24:50 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:24:50 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:50 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 10:24:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:24:50 --> Final output sent to browser
DEBUG - 2014-02-22 10:24:50 --> Total execution time: 0.0573
DEBUG - 2014-02-22 10:24:53 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:24:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:24:53 --> URI Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Router Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Output Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Security Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Input Class Initialized
DEBUG - 2014-02-22 10:24:53 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:24:53 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Loader Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:24:53 --> Controller Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Session Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:24:53 --> Session routines successfully run
DEBUG - 2014-02-22 10:24:53 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:24:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:24:53 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:24:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:24:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:24:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:24:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:24:53 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:24:53 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:53 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:24:53 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-22 10:24:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:24:53 --> Final output sent to browser
DEBUG - 2014-02-22 10:24:53 --> Total execution time: 0.0703
DEBUG - 2014-02-22 10:24:55 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:24:55 --> URI Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Router Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Output Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Security Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Input Class Initialized
DEBUG - 2014-02-22 10:24:55 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:24:55 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Loader Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:24:55 --> Controller Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Session Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:24:55 --> Session routines successfully run
DEBUG - 2014-02-22 10:24:55 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:24:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:24:55 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:24:55 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:24:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:24:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:24:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:24:55 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:24:55 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:55 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:24:55 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 10:24:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:24:55 --> Final output sent to browser
DEBUG - 2014-02-22 10:24:55 --> Total execution time: 0.0588
DEBUG - 2014-02-22 10:24:58 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:24:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:24:58 --> URI Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Router Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Output Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Security Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Input Class Initialized
DEBUG - 2014-02-22 10:24:58 --> XSS Filtering completed
DEBUG - 2014-02-22 10:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:24:58 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Language Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Config Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Loader Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:24:58 --> Controller Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Session Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:24:58 --> Session routines successfully run
DEBUG - 2014-02-22 10:24:58 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:24:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:24:58 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:24:58 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:24:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:24:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:24:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:24:58 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:58 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:24:58 --> Model Class Initialized
DEBUG - 2014-02-22 10:24:58 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:24:58 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-22 10:24:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:24:58 --> Final output sent to browser
DEBUG - 2014-02-22 10:24:58 --> Total execution time: 0.0601
DEBUG - 2014-02-22 10:25:02 --> Config Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:25:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:25:02 --> URI Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Router Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Output Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Security Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Input Class Initialized
DEBUG - 2014-02-22 10:25:02 --> XSS Filtering completed
DEBUG - 2014-02-22 10:25:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:25:02 --> Language Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Language Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Config Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Loader Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:25:02 --> Controller Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Session Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:25:02 --> Session routines successfully run
DEBUG - 2014-02-22 10:25:02 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:25:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:25:02 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:25:02 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:25:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:25:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:25:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:25:02 --> Model Class Initialized
DEBUG - 2014-02-22 10:25:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:25:02 --> Model Class Initialized
DEBUG - 2014-02-22 10:25:02 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:25:02 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:25:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:25:02 --> Final output sent to browser
DEBUG - 2014-02-22 10:25:02 --> Total execution time: 0.0604
DEBUG - 2014-02-22 10:26:43 --> Config Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:26:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:26:43 --> URI Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Router Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Output Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Security Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Input Class Initialized
DEBUG - 2014-02-22 10:26:43 --> XSS Filtering completed
DEBUG - 2014-02-22 10:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:26:43 --> Language Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Language Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Config Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Loader Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:26:43 --> Controller Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Session Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:26:43 --> Session routines successfully run
DEBUG - 2014-02-22 10:26:43 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:26:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:26:43 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:26:43 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:26:43 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:26:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:26:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:26:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:26:43 --> Model Class Initialized
DEBUG - 2014-02-22 10:26:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:26:43 --> Model Class Initialized
DEBUG - 2014-02-22 10:26:43 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:26:43 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:26:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:26:43 --> Final output sent to browser
DEBUG - 2014-02-22 10:26:43 --> Total execution time: 0.0693
DEBUG - 2014-02-22 10:31:46 --> Config Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:31:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:31:46 --> URI Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Router Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Output Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Security Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Input Class Initialized
DEBUG - 2014-02-22 10:31:46 --> XSS Filtering completed
DEBUG - 2014-02-22 10:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:31:46 --> Language Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Language Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Config Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Loader Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:31:46 --> Controller Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Session Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:31:46 --> Session routines successfully run
DEBUG - 2014-02-22 10:31:46 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:31:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:31:46 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:31:46 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:31:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:31:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:31:46 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:31:46 --> Model Class Initialized
DEBUG - 2014-02-22 10:31:46 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:31:46 --> Model Class Initialized
DEBUG - 2014-02-22 10:31:46 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:31:46 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:31:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:31:46 --> Final output sent to browser
DEBUG - 2014-02-22 10:31:46 --> Total execution time: 0.0605
DEBUG - 2014-02-22 10:32:09 --> Config Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:32:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:32:09 --> URI Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Router Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Output Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Security Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Input Class Initialized
DEBUG - 2014-02-22 10:32:09 --> XSS Filtering completed
DEBUG - 2014-02-22 10:32:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:32:09 --> Language Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Language Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Config Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Loader Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:32:09 --> Controller Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Session Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:32:09 --> Session routines successfully run
DEBUG - 2014-02-22 10:32:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:32:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:32:09 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:32:09 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:32:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:32:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:32:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:32:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:32:09 --> Model Class Initialized
DEBUG - 2014-02-22 10:32:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:32:09 --> Model Class Initialized
DEBUG - 2014-02-22 10:32:09 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:32:09 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:32:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:32:09 --> Final output sent to browser
DEBUG - 2014-02-22 10:32:09 --> Total execution time: 0.0610
DEBUG - 2014-02-22 10:33:38 --> Config Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:33:38 --> URI Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Router Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Output Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Security Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Input Class Initialized
DEBUG - 2014-02-22 10:33:38 --> XSS Filtering completed
DEBUG - 2014-02-22 10:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:33:38 --> Language Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Language Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Config Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Loader Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:33:38 --> Controller Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Session Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:33:38 --> Session routines successfully run
DEBUG - 2014-02-22 10:33:38 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:33:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:33:38 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:33:38 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:33:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:33:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:33:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:33:38 --> Model Class Initialized
DEBUG - 2014-02-22 10:33:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:33:38 --> Model Class Initialized
DEBUG - 2014-02-22 10:33:38 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:33:38 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:33:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:33:38 --> Final output sent to browser
DEBUG - 2014-02-22 10:33:38 --> Total execution time: 0.0592
DEBUG - 2014-02-22 10:43:58 --> Config Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:43:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:43:58 --> URI Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Router Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Output Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Security Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Input Class Initialized
DEBUG - 2014-02-22 10:43:58 --> XSS Filtering completed
DEBUG - 2014-02-22 10:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:43:58 --> Language Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Language Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Config Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Loader Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:43:58 --> Controller Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Session Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:43:58 --> Session routines successfully run
DEBUG - 2014-02-22 10:43:58 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:43:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:43:58 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:43:58 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:43:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:43:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:43:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:43:58 --> Model Class Initialized
DEBUG - 2014-02-22 10:43:58 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:43:58 --> Model Class Initialized
DEBUG - 2014-02-22 10:43:58 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:43:58 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:43:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:43:58 --> Final output sent to browser
DEBUG - 2014-02-22 10:43:58 --> Total execution time: 0.0669
DEBUG - 2014-02-22 10:45:56 --> Config Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:45:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:45:56 --> URI Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Router Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Output Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Security Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Input Class Initialized
DEBUG - 2014-02-22 10:45:56 --> XSS Filtering completed
DEBUG - 2014-02-22 10:45:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:45:56 --> Language Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Language Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Config Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Loader Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:45:56 --> Controller Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Session Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:45:56 --> Session routines successfully run
DEBUG - 2014-02-22 10:45:56 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:45:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:45:56 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:45:56 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:45:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:45:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:45:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:45:56 --> Model Class Initialized
DEBUG - 2014-02-22 10:45:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:45:56 --> Model Class Initialized
DEBUG - 2014-02-22 10:45:56 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:45:56 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:45:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:45:56 --> Final output sent to browser
DEBUG - 2014-02-22 10:45:56 --> Total execution time: 0.0539
DEBUG - 2014-02-22 10:48:57 --> Config Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:48:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:48:57 --> URI Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Router Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Output Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Security Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Input Class Initialized
DEBUG - 2014-02-22 10:48:57 --> XSS Filtering completed
DEBUG - 2014-02-22 10:48:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:48:57 --> Language Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Language Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Config Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Loader Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:48:57 --> Controller Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Session Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:48:57 --> Session routines successfully run
DEBUG - 2014-02-22 10:48:57 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:48:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:48:57 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:48:57 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:48:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:48:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:48:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:48:57 --> Model Class Initialized
DEBUG - 2014-02-22 10:48:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:48:57 --> Model Class Initialized
DEBUG - 2014-02-22 10:48:57 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:48:57 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:48:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:48:57 --> Final output sent to browser
DEBUG - 2014-02-22 10:48:57 --> Total execution time: 0.0613
DEBUG - 2014-02-22 10:49:02 --> Config Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:49:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:49:02 --> URI Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Router Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Output Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Security Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Input Class Initialized
DEBUG - 2014-02-22 10:49:02 --> XSS Filtering completed
DEBUG - 2014-02-22 10:49:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:49:02 --> Language Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Language Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Config Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Loader Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:49:02 --> Controller Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Session Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:49:02 --> Session routines successfully run
DEBUG - 2014-02-22 10:49:02 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:49:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:49:02 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:49:02 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:49:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:49:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:49:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:49:02 --> Model Class Initialized
DEBUG - 2014-02-22 10:49:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:49:02 --> Model Class Initialized
DEBUG - 2014-02-22 10:49:02 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:49:02 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:49:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:49:02 --> Final output sent to browser
DEBUG - 2014-02-22 10:49:02 --> Total execution time: 0.0603
DEBUG - 2014-02-22 10:50:51 --> Config Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:50:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:50:51 --> URI Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Router Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Output Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Security Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Input Class Initialized
DEBUG - 2014-02-22 10:50:51 --> XSS Filtering completed
DEBUG - 2014-02-22 10:50:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:50:51 --> Language Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Language Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Config Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Loader Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:50:51 --> Controller Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Session Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:50:51 --> Session routines successfully run
DEBUG - 2014-02-22 10:50:51 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:50:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:50:51 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:50:51 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:50:51 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:50:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:50:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:50:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:50:51 --> Model Class Initialized
DEBUG - 2014-02-22 10:50:51 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:50:51 --> Model Class Initialized
DEBUG - 2014-02-22 10:50:51 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:50:51 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:50:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:50:51 --> Final output sent to browser
DEBUG - 2014-02-22 10:50:51 --> Total execution time: 0.0551
DEBUG - 2014-02-22 10:50:53 --> Config Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:50:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:50:53 --> URI Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Router Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Output Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Security Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Input Class Initialized
DEBUG - 2014-02-22 10:50:53 --> XSS Filtering completed
DEBUG - 2014-02-22 10:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:50:53 --> Language Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Language Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Config Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Loader Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:50:53 --> Controller Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Session Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:50:53 --> Session routines successfully run
DEBUG - 2014-02-22 10:50:53 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:50:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:50:53 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:50:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:50:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:50:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:50:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:50:53 --> Model Class Initialized
DEBUG - 2014-02-22 10:50:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:50:53 --> Model Class Initialized
DEBUG - 2014-02-22 10:50:53 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:50:53 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:50:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:50:53 --> Final output sent to browser
DEBUG - 2014-02-22 10:50:53 --> Total execution time: 0.0581
DEBUG - 2014-02-22 10:51:35 --> Config Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:51:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:51:35 --> URI Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Router Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Output Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Security Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Input Class Initialized
DEBUG - 2014-02-22 10:51:35 --> XSS Filtering completed
DEBUG - 2014-02-22 10:51:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:51:35 --> Language Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Language Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Config Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Loader Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:51:35 --> Controller Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Session Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:51:35 --> Session routines successfully run
DEBUG - 2014-02-22 10:51:35 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:51:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:51:35 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:51:35 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:51:35 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:51:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:51:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:51:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:51:35 --> Model Class Initialized
DEBUG - 2014-02-22 10:51:35 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:51:35 --> Model Class Initialized
DEBUG - 2014-02-22 10:51:35 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:51:35 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:51:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:51:35 --> Final output sent to browser
DEBUG - 2014-02-22 10:51:35 --> Total execution time: 0.0563
DEBUG - 2014-02-22 10:53:51 --> Config Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:53:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:53:51 --> URI Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Router Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Output Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Security Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Input Class Initialized
DEBUG - 2014-02-22 10:53:51 --> XSS Filtering completed
DEBUG - 2014-02-22 10:53:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:53:51 --> Language Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Language Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Config Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Loader Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:53:51 --> Controller Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Session Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:53:51 --> Session routines successfully run
DEBUG - 2014-02-22 10:53:51 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:53:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:53:51 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:53:51 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:53:51 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:53:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:53:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:53:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:53:51 --> Model Class Initialized
DEBUG - 2014-02-22 10:53:51 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:53:51 --> Model Class Initialized
DEBUG - 2014-02-22 10:53:51 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:53:51 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:53:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:53:51 --> Final output sent to browser
DEBUG - 2014-02-22 10:53:51 --> Total execution time: 0.0760
DEBUG - 2014-02-22 10:54:07 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:07 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:07 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:07 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:07 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:07 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:07 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:07 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:54:07 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:07 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:07 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:07 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:07 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:07 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:07 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:07 --> Total execution time: 0.0620
DEBUG - 2014-02-22 10:54:31 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:31 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:31 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:31 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:31 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:31 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:31 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:31 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:31 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:31 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:31 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:31 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:31 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:31 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:31 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:31 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:31 --> Total execution time: 0.0604
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:32 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:32 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:32 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:32 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:32 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:32 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:54:32 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:32 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:32 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:32 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:32 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:32 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:32 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:32 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:32 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Total execution time: 0.0576
DEBUG - 2014-02-22 10:54:32 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:32 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:32 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:32 --> Database Driver Class Initialized
ERROR - 2014-02-22 10:54:32 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:32 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:32 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:32 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:32 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:32 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:32 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:32 --> Total execution time: 0.0475
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:32 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:32 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:32 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:32 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:32 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:32 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:32 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:32 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:32 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:32 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:32 --> Total execution time: 0.0496
DEBUG - 2014-02-22 10:54:32 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:32 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:32 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:32 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:32 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:32 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:32 --> Total execution time: 0.0487
DEBUG - 2014-02-22 10:54:32 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:32 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:32 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:32 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:32 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:32 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:32 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:32 --> Total execution time: 0.0434
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:32 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:32 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:32 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:32 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:32 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:32 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:32 --> URI Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Router Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Output Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Security Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Input Class Initialized
DEBUG - 2014-02-22 10:54:32 --> XSS Filtering completed
DEBUG - 2014-02-22 10:54:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:32 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:32 --> Language Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:32 --> Config Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:32 --> Loader Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:54:32 --> Controller Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Session Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:54:32 --> Session routines successfully run
DEBUG - 2014-02-22 10:54:32 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:32 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:32 --> Total execution time: 0.0464
DEBUG - 2014-02-22 10:54:32 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:54:32 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:54:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:54:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:54:32 --> Model Class Initialized
DEBUG - 2014-02-22 10:54:32 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:54:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:54:32 --> Final output sent to browser
DEBUG - 2014-02-22 10:54:32 --> Total execution time: 0.0458
DEBUG - 2014-02-22 10:56:56 --> Config Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:56:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:56:56 --> URI Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Router Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Output Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Security Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Input Class Initialized
DEBUG - 2014-02-22 10:56:56 --> XSS Filtering completed
DEBUG - 2014-02-22 10:56:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:56:56 --> Language Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Language Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Config Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Loader Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:56:56 --> Controller Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Session Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:56:56 --> Session routines successfully run
DEBUG - 2014-02-22 10:56:56 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:56:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:56:56 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:56:56 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:56:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:56:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:56:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:56:56 --> Model Class Initialized
DEBUG - 2014-02-22 10:56:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:56:56 --> Model Class Initialized
DEBUG - 2014-02-22 10:56:56 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:56:56 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:56:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:56:56 --> Final output sent to browser
DEBUG - 2014-02-22 10:56:56 --> Total execution time: 0.0637
DEBUG - 2014-02-22 10:58:50 --> Config Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:58:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:58:50 --> URI Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Router Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Output Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Security Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Input Class Initialized
DEBUG - 2014-02-22 10:58:50 --> XSS Filtering completed
DEBUG - 2014-02-22 10:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:58:50 --> Language Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Language Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Config Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Loader Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:58:50 --> Controller Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Session Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:58:50 --> Session routines successfully run
DEBUG - 2014-02-22 10:58:50 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:58:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:58:50 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:58:50 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:58:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:58:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:58:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:58:50 --> Model Class Initialized
DEBUG - 2014-02-22 10:58:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:58:50 --> Model Class Initialized
DEBUG - 2014-02-22 10:58:50 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:58:50 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:58:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:58:50 --> Final output sent to browser
DEBUG - 2014-02-22 10:58:50 --> Total execution time: 0.0662
DEBUG - 2014-02-22 10:59:48 --> Config Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Hooks Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Utf8 Class Initialized
DEBUG - 2014-02-22 10:59:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 10:59:48 --> URI Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Router Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Output Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Security Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Input Class Initialized
DEBUG - 2014-02-22 10:59:48 --> XSS Filtering completed
DEBUG - 2014-02-22 10:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 10:59:48 --> Language Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Language Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Config Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Loader Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: text_helper
DEBUG - 2014-02-22 10:59:48 --> Controller Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Session Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: string_helper
DEBUG - 2014-02-22 10:59:48 --> Session routines successfully run
DEBUG - 2014-02-22 10:59:48 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 10:59:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: url_helper
DEBUG - 2014-02-22 10:59:48 --> Database Driver Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: form_helper
DEBUG - 2014-02-22 10:59:48 --> Form Validation Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: number_helper
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: date_helper
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 10:59:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: language_helper
DEBUG - 2014-02-22 10:59:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 10:59:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 10:59:48 --> Model Class Initialized
DEBUG - 2014-02-22 10:59:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 10:59:48 --> Model Class Initialized
DEBUG - 2014-02-22 10:59:48 --> Helper loaded: image_helper
DEBUG - 2014-02-22 10:59:48 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 10:59:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 10:59:48 --> Final output sent to browser
DEBUG - 2014-02-22 10:59:48 --> Total execution time: 0.0555
DEBUG - 2014-02-22 11:07:42 --> Config Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:07:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:07:42 --> URI Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Router Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Output Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Security Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Input Class Initialized
DEBUG - 2014-02-22 11:07:42 --> XSS Filtering completed
DEBUG - 2014-02-22 11:07:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:07:42 --> Language Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Language Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Config Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Loader Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:07:42 --> Controller Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Session Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:07:42 --> Session routines successfully run
DEBUG - 2014-02-22 11:07:42 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:07:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:07:42 --> Database Driver Class Initialized
ERROR - 2014-02-22 11:07:42 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:07:42 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:07:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:07:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:07:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:07:42 --> Model Class Initialized
DEBUG - 2014-02-22 11:07:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:07:42 --> Model Class Initialized
DEBUG - 2014-02-22 11:07:42 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:07:42 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 11:07:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:07:42 --> Final output sent to browser
DEBUG - 2014-02-22 11:07:42 --> Total execution time: 0.0636
DEBUG - 2014-02-22 11:08:40 --> Config Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:08:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:08:40 --> URI Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Router Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Output Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Security Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Input Class Initialized
DEBUG - 2014-02-22 11:08:40 --> XSS Filtering completed
DEBUG - 2014-02-22 11:08:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:08:40 --> Language Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Language Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Config Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Loader Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:08:40 --> Controller Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Session Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:08:40 --> Session routines successfully run
DEBUG - 2014-02-22 11:08:40 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:08:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:08:40 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:08:40 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:08:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:08:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:08:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:08:40 --> Model Class Initialized
DEBUG - 2014-02-22 11:08:40 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:08:40 --> Model Class Initialized
DEBUG - 2014-02-22 11:08:40 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:08:40 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 11:08:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:08:40 --> Final output sent to browser
DEBUG - 2014-02-22 11:08:40 --> Total execution time: 0.0813
DEBUG - 2014-02-22 11:21:19 --> Config Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:21:19 --> URI Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Router Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Output Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Security Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Input Class Initialized
DEBUG - 2014-02-22 11:21:19 --> XSS Filtering completed
DEBUG - 2014-02-22 11:21:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:21:19 --> Language Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Language Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Config Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Loader Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:21:19 --> Controller Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Session Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:21:19 --> Session routines successfully run
DEBUG - 2014-02-22 11:21:19 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:21:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:21:19 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:21:19 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:21:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:21:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:21:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:21:19 --> Model Class Initialized
DEBUG - 2014-02-22 11:21:19 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:21:19 --> Model Class Initialized
DEBUG - 2014-02-22 11:21:19 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:21:19 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-22 11:21:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:21:19 --> Final output sent to browser
DEBUG - 2014-02-22 11:21:19 --> Total execution time: 0.0547
DEBUG - 2014-02-22 11:21:25 --> Config Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:21:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:21:25 --> URI Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Router Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Output Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Security Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Input Class Initialized
DEBUG - 2014-02-22 11:21:25 --> XSS Filtering completed
DEBUG - 2014-02-22 11:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:21:25 --> Language Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Language Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Config Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Loader Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:21:25 --> Controller Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Session Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:21:25 --> Session routines successfully run
DEBUG - 2014-02-22 11:21:25 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:21:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:21:25 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:21:25 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:21:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:21:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:21:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:21:25 --> Model Class Initialized
DEBUG - 2014-02-22 11:21:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:21:25 --> Model Class Initialized
DEBUG - 2014-02-22 11:21:25 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:21:25 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 11:21:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:21:25 --> Final output sent to browser
DEBUG - 2014-02-22 11:21:25 --> Total execution time: 0.0619
DEBUG - 2014-02-22 11:25:53 --> Config Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:25:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:25:53 --> URI Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Router Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Output Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Security Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Input Class Initialized
DEBUG - 2014-02-22 11:25:53 --> XSS Filtering completed
DEBUG - 2014-02-22 11:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:25:53 --> Language Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Language Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Config Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Loader Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:25:53 --> Controller Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Session Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:25:53 --> A session cookie was not found.
DEBUG - 2014-02-22 11:25:53 --> Session routines successfully run
DEBUG - 2014-02-22 11:25:53 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:25:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:25:53 --> Database Driver Class Initialized
ERROR - 2014-02-22 11:25:53 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:25:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:25:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:25:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:25:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:25:53 --> Config Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:25:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:25:53 --> URI Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Router Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Output Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Security Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Input Class Initialized
DEBUG - 2014-02-22 11:25:53 --> XSS Filtering completed
DEBUG - 2014-02-22 11:25:53 --> XSS Filtering completed
DEBUG - 2014-02-22 11:25:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:25:53 --> Language Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Language Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Config Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Loader Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:25:53 --> Controller Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-22 11:25:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:25:53 --> Session Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:25:53 --> Session routines successfully run
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:25:53 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:25:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:25:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:25:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:25:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:25:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:25:53 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-22 11:25:53 --> Final output sent to browser
DEBUG - 2014-02-22 11:25:53 --> Total execution time: 0.0487
DEBUG - 2014-02-22 11:26:08 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:26:08 --> URI Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Router Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Output Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Security Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Input Class Initialized
DEBUG - 2014-02-22 11:26:08 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:08 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:08 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:08 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:08 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:26:08 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Loader Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:26:08 --> Controller Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-22 11:26:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:26:08 --> Session Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:26:08 --> Session routines successfully run
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:26:08 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:26:08 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:26:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:26:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:26:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:26:08 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:08 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-22 11:26:08 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:26:08 --> URI Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Router Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Output Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Security Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Input Class Initialized
DEBUG - 2014-02-22 11:26:08 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:08 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:26:08 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Loader Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:26:08 --> Controller Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Session Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:26:08 --> Session routines successfully run
DEBUG - 2014-02-22 11:26:08 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 11:26:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:26:08 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:26:08 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:26:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:26:08 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:26:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:26:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:26:08 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:08 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 11:26:08 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:26:08 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:08 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 11:26:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:26:08 --> Final output sent to browser
DEBUG - 2014-02-22 11:26:08 --> Total execution time: 0.0583
DEBUG - 2014-02-22 11:26:17 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:26:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:26:17 --> URI Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Router Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Output Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Security Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Input Class Initialized
DEBUG - 2014-02-22 11:26:17 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:17 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:26:17 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Loader Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:26:17 --> Controller Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Session Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:26:17 --> Session routines successfully run
DEBUG - 2014-02-22 11:26:17 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:26:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:26:17 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:26:17 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:26:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:26:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:26:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:26:17 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:26:17 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:17 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:26:17 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-22 11:26:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:26:17 --> Final output sent to browser
DEBUG - 2014-02-22 11:26:17 --> Total execution time: 0.0702
DEBUG - 2014-02-22 11:26:20 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:26:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:26:20 --> URI Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Router Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Output Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Security Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Input Class Initialized
DEBUG - 2014-02-22 11:26:20 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:20 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:26:20 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Loader Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:26:20 --> Controller Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Session Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:26:20 --> Session routines successfully run
DEBUG - 2014-02-22 11:26:20 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:26:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:26:20 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:26:20 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:26:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:26:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:26:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:26:20 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:26:20 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:20 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:26:20 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 11:26:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:26:20 --> Final output sent to browser
DEBUG - 2014-02-22 11:26:20 --> Total execution time: 0.0594
DEBUG - 2014-02-22 11:26:26 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:26:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:26:26 --> URI Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Router Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Output Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Security Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Input Class Initialized
DEBUG - 2014-02-22 11:26:26 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:26 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:26:26 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Loader Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:26:26 --> Controller Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Session Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:26:26 --> Session routines successfully run
DEBUG - 2014-02-22 11:26:26 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:26:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:26:26 --> Database Driver Class Initialized
ERROR - 2014-02-22 11:26:26 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:26:26 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:26:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:26:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:26:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:26:26 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:26:26 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:26 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:26:26 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-22 11:26:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:26:26 --> Final output sent to browser
DEBUG - 2014-02-22 11:26:26 --> Total execution time: 0.0641
DEBUG - 2014-02-22 11:26:38 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:26:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:26:38 --> URI Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Router Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Output Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Security Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Input Class Initialized
DEBUG - 2014-02-22 11:26:38 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:38 --> XSS Filtering completed
DEBUG - 2014-02-22 11:26:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:26:38 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Language Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Config Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Loader Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:26:38 --> Controller Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Session Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:26:38 --> Session routines successfully run
DEBUG - 2014-02-22 11:26:38 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:26:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:26:38 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:26:38 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:26:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:26:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:26:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:26:38 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:26:38 --> Model Class Initialized
DEBUG - 2014-02-22 11:26:38 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:26:38 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 11:26:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:26:38 --> Final output sent to browser
DEBUG - 2014-02-22 11:26:38 --> Total execution time: 0.0658
DEBUG - 2014-02-22 11:41:02 --> Config Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:41:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:41:02 --> URI Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Router Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Output Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Security Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Input Class Initialized
DEBUG - 2014-02-22 11:41:02 --> XSS Filtering completed
DEBUG - 2014-02-22 11:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:41:02 --> Language Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Language Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Config Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Loader Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:41:02 --> Controller Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Session Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:41:02 --> Session routines successfully run
DEBUG - 2014-02-22 11:41:02 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:41:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:41:02 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:41:02 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:41:02 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:41:02 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:41:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:41:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:41:03 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:41:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:41:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:41:03 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:41:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:41:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:41:03 --> Model Class Initialized
DEBUG - 2014-02-22 11:41:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:41:03 --> Model Class Initialized
DEBUG - 2014-02-22 11:41:03 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:41:03 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 11:41:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:41:03 --> Final output sent to browser
DEBUG - 2014-02-22 11:41:03 --> Total execution time: 0.0587
DEBUG - 2014-02-22 11:46:12 --> Config Class Initialized
DEBUG - 2014-02-22 11:46:12 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:46:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:46:13 --> URI Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Router Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Output Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Security Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Input Class Initialized
DEBUG - 2014-02-22 11:46:13 --> XSS Filtering completed
DEBUG - 2014-02-22 11:46:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:46:13 --> Language Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Language Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Config Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Loader Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:46:13 --> Controller Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Session Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:46:13 --> Session routines successfully run
DEBUG - 2014-02-22 11:46:13 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:46:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:46:13 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:46:13 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:46:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:46:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:46:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:46:13 --> Model Class Initialized
DEBUG - 2014-02-22 11:46:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:46:13 --> Model Class Initialized
DEBUG - 2014-02-22 11:46:13 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:46:13 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 11:46:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:46:13 --> Final output sent to browser
DEBUG - 2014-02-22 11:46:13 --> Total execution time: 0.0610
DEBUG - 2014-02-22 11:49:23 --> Config Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:49:23 --> URI Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Router Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Output Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Security Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Input Class Initialized
DEBUG - 2014-02-22 11:49:23 --> XSS Filtering completed
DEBUG - 2014-02-22 11:49:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:49:23 --> Language Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Language Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Config Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Loader Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:49:23 --> Controller Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Session Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:49:23 --> Session routines successfully run
DEBUG - 2014-02-22 11:49:23 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:49:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:49:23 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:49:23 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:49:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:49:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:49:23 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:49:23 --> Model Class Initialized
DEBUG - 2014-02-22 11:49:23 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:49:23 --> Model Class Initialized
DEBUG - 2014-02-22 11:49:23 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:49:23 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 11:49:23 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:49:23 --> Final output sent to browser
DEBUG - 2014-02-22 11:49:23 --> Total execution time: 0.0597
DEBUG - 2014-02-22 11:50:25 --> Config Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:50:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:50:25 --> URI Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Router Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Output Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Security Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Input Class Initialized
DEBUG - 2014-02-22 11:50:25 --> XSS Filtering completed
DEBUG - 2014-02-22 11:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:50:25 --> Language Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Language Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Config Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Loader Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:50:25 --> Controller Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Session Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:50:25 --> Session routines successfully run
DEBUG - 2014-02-22 11:50:25 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:50:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:50:25 --> Database Driver Class Initialized
ERROR - 2014-02-22 11:50:25 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:50:25 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:50:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:50:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:50:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:50:25 --> Model Class Initialized
DEBUG - 2014-02-22 11:50:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:50:25 --> Model Class Initialized
DEBUG - 2014-02-22 11:50:25 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:50:25 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 11:50:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:50:25 --> Final output sent to browser
DEBUG - 2014-02-22 11:50:25 --> Total execution time: 0.0679
DEBUG - 2014-02-22 11:53:06 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:53:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:53:06 --> URI Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Router Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Output Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Security Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Input Class Initialized
DEBUG - 2014-02-22 11:53:06 --> XSS Filtering completed
DEBUG - 2014-02-22 11:53:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:53:06 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Loader Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:53:06 --> Controller Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Session Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:53:06 --> Session routines successfully run
DEBUG - 2014-02-22 11:53:06 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:53:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:53:06 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:53:06 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:53:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:53:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:53:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:53:06 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:53:06 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:06 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:53:06 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-22 11:53:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:53:06 --> Final output sent to browser
DEBUG - 2014-02-22 11:53:06 --> Total execution time: 0.0626
DEBUG - 2014-02-22 11:53:09 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:53:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:53:09 --> URI Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Router Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Output Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Security Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Input Class Initialized
DEBUG - 2014-02-22 11:53:09 --> XSS Filtering completed
DEBUG - 2014-02-22 11:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:53:09 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Loader Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:53:09 --> Controller Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Session Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:53:09 --> Session routines successfully run
DEBUG - 2014-02-22 11:53:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:53:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:53:09 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:53:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:53:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:53:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:53:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:53:09 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:53:09 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:09 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:53:09 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 11:53:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:53:09 --> Final output sent to browser
DEBUG - 2014-02-22 11:53:09 --> Total execution time: 0.0600
DEBUG - 2014-02-22 11:53:11 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:53:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:53:11 --> URI Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Router Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Output Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Security Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Input Class Initialized
DEBUG - 2014-02-22 11:53:11 --> XSS Filtering completed
DEBUG - 2014-02-22 11:53:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:53:11 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Loader Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:53:11 --> Controller Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Session Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:53:11 --> Session routines successfully run
DEBUG - 2014-02-22 11:53:11 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:53:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:53:11 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:53:11 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:53:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:53:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:53:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:53:11 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:11 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:53:11 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:11 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:53:11 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 11:53:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:53:11 --> Final output sent to browser
DEBUG - 2014-02-22 11:53:11 --> Total execution time: 0.0600
DEBUG - 2014-02-22 11:53:13 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:53:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:53:13 --> URI Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Router Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Output Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Security Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Input Class Initialized
DEBUG - 2014-02-22 11:53:13 --> XSS Filtering completed
DEBUG - 2014-02-22 11:53:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:53:13 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Loader Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:53:13 --> Controller Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Session Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:53:13 --> Session routines successfully run
DEBUG - 2014-02-22 11:53:13 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:53:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:53:13 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:53:13 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:53:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:53:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:53:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:53:13 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:53:13 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:13 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:53:13 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 11:53:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:53:13 --> Final output sent to browser
DEBUG - 2014-02-22 11:53:13 --> Total execution time: 0.0604
DEBUG - 2014-02-22 11:53:14 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:53:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:53:14 --> URI Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Router Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Output Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Security Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Input Class Initialized
DEBUG - 2014-02-22 11:53:14 --> XSS Filtering completed
DEBUG - 2014-02-22 11:53:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:53:14 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Loader Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:53:14 --> Controller Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Session Class Initialized
DEBUG - 2014-02-22 11:53:14 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:53:14 --> Session routines successfully run
DEBUG - 2014-02-22 11:53:14 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:53:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:53:14 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:53:14 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:53:15 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:53:15 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:53:15 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:53:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:53:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:53:15 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:53:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:53:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:53:15 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:53:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:53:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:53:15 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:53:15 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:15 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:53:15 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 11:53:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:53:15 --> Final output sent to browser
DEBUG - 2014-02-22 11:53:15 --> Total execution time: 0.0523
DEBUG - 2014-02-22 11:53:16 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:53:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:53:16 --> URI Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Router Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Output Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Security Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Input Class Initialized
DEBUG - 2014-02-22 11:53:16 --> XSS Filtering completed
DEBUG - 2014-02-22 11:53:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:53:16 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Loader Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:53:16 --> Controller Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Session Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:53:16 --> Session routines successfully run
DEBUG - 2014-02-22 11:53:16 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:53:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:53:16 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:53:16 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:53:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:53:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:53:16 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:53:16 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:16 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:53:16 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:16 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:53:16 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 11:53:16 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:53:16 --> Final output sent to browser
DEBUG - 2014-02-22 11:53:16 --> Total execution time: 0.0579
DEBUG - 2014-02-22 11:53:39 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:53:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:53:39 --> URI Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Router Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Output Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Security Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Input Class Initialized
DEBUG - 2014-02-22 11:53:39 --> XSS Filtering completed
DEBUG - 2014-02-22 11:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:53:39 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Loader Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:53:39 --> Controller Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Session Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:53:39 --> Session routines successfully run
DEBUG - 2014-02-22 11:53:39 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:53:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:53:39 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:53:39 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:53:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:53:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:53:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:53:39 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:39 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:53:39 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:39 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:53:39 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 11:53:39 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:53:39 --> Final output sent to browser
DEBUG - 2014-02-22 11:53:39 --> Total execution time: 0.0661
DEBUG - 2014-02-22 11:53:41 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:53:41 --> URI Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Router Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Output Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Security Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Input Class Initialized
DEBUG - 2014-02-22 11:53:41 --> XSS Filtering completed
DEBUG - 2014-02-22 11:53:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:53:41 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Language Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Config Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Loader Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:53:41 --> Controller Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Session Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:53:41 --> Session routines successfully run
DEBUG - 2014-02-22 11:53:41 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:53:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:53:41 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:53:41 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:53:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:53:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:53:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:53:41 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:41 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:53:41 --> Model Class Initialized
DEBUG - 2014-02-22 11:53:41 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:53:41 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 11:53:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:53:41 --> Final output sent to browser
DEBUG - 2014-02-22 11:53:41 --> Total execution time: 0.0592
DEBUG - 2014-02-22 11:56:14 --> Config Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:56:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:56:14 --> URI Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Router Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Output Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Security Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Input Class Initialized
DEBUG - 2014-02-22 11:56:14 --> XSS Filtering completed
DEBUG - 2014-02-22 11:56:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:56:14 --> Language Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Language Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Config Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Loader Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:56:14 --> Controller Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Session Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:56:14 --> Session routines successfully run
DEBUG - 2014-02-22 11:56:14 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:56:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:56:14 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:56:14 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:56:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:56:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:56:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:56:14 --> Model Class Initialized
DEBUG - 2014-02-22 11:56:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:56:14 --> Model Class Initialized
DEBUG - 2014-02-22 11:56:14 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:56:14 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 11:56:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:56:14 --> Final output sent to browser
DEBUG - 2014-02-22 11:56:14 --> Total execution time: 0.0684
DEBUG - 2014-02-22 11:56:41 --> Config Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Hooks Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Utf8 Class Initialized
DEBUG - 2014-02-22 11:56:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 11:56:41 --> URI Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Router Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Output Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Security Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Input Class Initialized
DEBUG - 2014-02-22 11:56:41 --> XSS Filtering completed
DEBUG - 2014-02-22 11:56:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 11:56:41 --> Language Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Language Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Config Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Loader Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: text_helper
DEBUG - 2014-02-22 11:56:41 --> Controller Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Session Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: string_helper
DEBUG - 2014-02-22 11:56:41 --> Session routines successfully run
DEBUG - 2014-02-22 11:56:41 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 11:56:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: url_helper
DEBUG - 2014-02-22 11:56:41 --> Database Driver Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: form_helper
DEBUG - 2014-02-22 11:56:41 --> Form Validation Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: number_helper
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: date_helper
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 11:56:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: language_helper
DEBUG - 2014-02-22 11:56:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 11:56:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 11:56:41 --> Model Class Initialized
DEBUG - 2014-02-22 11:56:41 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 11:56:41 --> Model Class Initialized
DEBUG - 2014-02-22 11:56:41 --> Helper loaded: image_helper
DEBUG - 2014-02-22 11:56:41 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 11:56:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 11:56:41 --> Final output sent to browser
DEBUG - 2014-02-22 11:56:41 --> Total execution time: 0.0702
DEBUG - 2014-02-22 12:04:09 --> Config Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:04:09 --> URI Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Router Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Output Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Security Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Input Class Initialized
DEBUG - 2014-02-22 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:04:09 --> Language Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Language Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Config Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Loader Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:04:09 --> Controller Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Session Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:04:09 --> Session routines successfully run
DEBUG - 2014-02-22 12:04:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:04:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:04:09 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:04:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:04:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:04:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:04:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-22 12:04:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-22 12:04:09 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:04:09 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:04:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:04:09 --> Final output sent to browser
DEBUG - 2014-02-22 12:04:09 --> Total execution time: 0.0668
DEBUG - 2014-02-22 12:04:38 --> Config Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:04:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:04:38 --> URI Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Router Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Output Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Security Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Input Class Initialized
DEBUG - 2014-02-22 12:04:38 --> XSS Filtering completed
DEBUG - 2014-02-22 12:04:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:04:38 --> Language Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Language Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Config Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Loader Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:04:38 --> Controller Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Session Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:04:38 --> Session routines successfully run
DEBUG - 2014-02-22 12:04:38 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:04:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:04:38 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:04:38 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:04:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:04:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:04:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:04:38 --> Model Class Initialized
DEBUG - 2014-02-22 12:04:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:04:38 --> Model Class Initialized
DEBUG - 2014-02-22 12:04:38 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:04:38 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:04:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:04:38 --> Final output sent to browser
DEBUG - 2014-02-22 12:04:38 --> Total execution time: 0.0686
DEBUG - 2014-02-22 12:05:27 --> Config Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:05:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:05:27 --> URI Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Router Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Output Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Security Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Input Class Initialized
DEBUG - 2014-02-22 12:05:27 --> XSS Filtering completed
DEBUG - 2014-02-22 12:05:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:05:27 --> Language Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Language Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Config Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Loader Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:05:27 --> Controller Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Session Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:05:27 --> Session routines successfully run
DEBUG - 2014-02-22 12:05:27 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:05:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:05:27 --> Database Driver Class Initialized
ERROR - 2014-02-22 12:05:27 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:05:27 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:05:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:05:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:05:27 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:05:27 --> Model Class Initialized
DEBUG - 2014-02-22 12:05:27 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:05:27 --> Model Class Initialized
DEBUG - 2014-02-22 12:05:27 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:05:27 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:05:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:05:27 --> Final output sent to browser
DEBUG - 2014-02-22 12:05:27 --> Total execution time: 0.0710
DEBUG - 2014-02-22 12:06:10 --> Config Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:06:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:06:10 --> URI Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Router Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Output Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Security Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Input Class Initialized
DEBUG - 2014-02-22 12:06:10 --> XSS Filtering completed
DEBUG - 2014-02-22 12:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:06:10 --> Language Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Language Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Config Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Loader Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:06:10 --> Controller Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Session Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:06:10 --> Session routines successfully run
DEBUG - 2014-02-22 12:06:10 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:06:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:06:10 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:06:10 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:06:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:06:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:06:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:06:10 --> Model Class Initialized
DEBUG - 2014-02-22 12:06:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:06:10 --> Model Class Initialized
DEBUG - 2014-02-22 12:06:10 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:06:10 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:06:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:06:10 --> Final output sent to browser
DEBUG - 2014-02-22 12:06:10 --> Total execution time: 0.0621
DEBUG - 2014-02-22 12:06:45 --> Config Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:06:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:06:45 --> URI Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Router Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Output Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Security Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Input Class Initialized
DEBUG - 2014-02-22 12:06:45 --> XSS Filtering completed
DEBUG - 2014-02-22 12:06:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:06:45 --> Language Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Language Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Config Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Loader Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:06:45 --> Controller Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Session Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:06:45 --> Session routines successfully run
DEBUG - 2014-02-22 12:06:45 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:06:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:06:45 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:06:45 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:06:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:06:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:06:45 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:06:45 --> Model Class Initialized
DEBUG - 2014-02-22 12:06:45 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:06:45 --> Model Class Initialized
DEBUG - 2014-02-22 12:06:45 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:06:45 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:06:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:06:45 --> Final output sent to browser
DEBUG - 2014-02-22 12:06:45 --> Total execution time: 0.0646
DEBUG - 2014-02-22 12:08:50 --> Config Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:08:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:08:50 --> URI Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Router Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Output Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Security Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Input Class Initialized
DEBUG - 2014-02-22 12:08:50 --> XSS Filtering completed
DEBUG - 2014-02-22 12:08:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:08:50 --> Language Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Language Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Config Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Loader Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:08:50 --> Controller Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Session Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:08:50 --> Session routines successfully run
DEBUG - 2014-02-22 12:08:50 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:08:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:08:50 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:08:50 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:08:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:08:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:08:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:08:50 --> Model Class Initialized
DEBUG - 2014-02-22 12:08:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:08:50 --> Model Class Initialized
DEBUG - 2014-02-22 12:08:50 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:08:50 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:08:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:08:50 --> Final output sent to browser
DEBUG - 2014-02-22 12:08:50 --> Total execution time: 0.0557
DEBUG - 2014-02-22 12:12:15 --> Config Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:12:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:12:15 --> URI Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Router Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Output Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Security Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Input Class Initialized
DEBUG - 2014-02-22 12:12:15 --> XSS Filtering completed
DEBUG - 2014-02-22 12:12:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:12:15 --> Language Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Language Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Config Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Loader Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:12:15 --> Controller Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Session Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:12:15 --> Session routines successfully run
DEBUG - 2014-02-22 12:12:15 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:12:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:12:15 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:12:15 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:12:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:12:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:12:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:12:15 --> Model Class Initialized
DEBUG - 2014-02-22 12:12:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:12:15 --> Model Class Initialized
DEBUG - 2014-02-22 12:12:15 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:12:15 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:12:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:12:15 --> Final output sent to browser
DEBUG - 2014-02-22 12:12:15 --> Total execution time: 0.0747
DEBUG - 2014-02-22 12:13:36 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:13:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:13:36 --> URI Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Router Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Output Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Security Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Input Class Initialized
DEBUG - 2014-02-22 12:13:36 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:13:36 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Loader Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:13:36 --> Controller Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Session Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:13:36 --> Session routines successfully run
DEBUG - 2014-02-22 12:13:36 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:13:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:13:36 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:13:36 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:13:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:13:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:13:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:13:36 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:36 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:13:36 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:36 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:13:36 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:13:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:13:36 --> Final output sent to browser
DEBUG - 2014-02-22 12:13:36 --> Total execution time: 0.0633
DEBUG - 2014-02-22 12:13:44 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:13:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:13:44 --> URI Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Router Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Output Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Security Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Input Class Initialized
DEBUG - 2014-02-22 12:13:44 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:44 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:44 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:44 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:44 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:44 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:44 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:13:44 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Loader Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:13:44 --> Controller Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Session Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:13:44 --> Session routines successfully run
DEBUG - 2014-02-22 12:13:44 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:13:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:13:44 --> Database Driver Class Initialized
ERROR - 2014-02-22 12:13:44 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:13:44 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:13:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:13:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:13:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:13:44 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:13:44 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:44 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:13:45 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:13:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:13:45 --> URI Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Router Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Output Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Security Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Input Class Initialized
DEBUG - 2014-02-22 12:13:45 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:13:45 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Loader Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:13:45 --> Controller Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Session Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:13:45 --> Session routines successfully run
DEBUG - 2014-02-22 12:13:45 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:13:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:13:45 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:13:45 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:13:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:13:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:13:45 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:13:45 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:45 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:13:45 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:45 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:13:45 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 12:13:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:13:45 --> Final output sent to browser
DEBUG - 2014-02-22 12:13:45 --> Total execution time: 0.0547
DEBUG - 2014-02-22 12:13:49 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:13:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:13:49 --> URI Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Router Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Output Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Security Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Input Class Initialized
DEBUG - 2014-02-22 12:13:49 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:13:49 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Loader Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:13:49 --> Controller Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Session Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:13:49 --> Session routines successfully run
DEBUG - 2014-02-22 12:13:49 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:13:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:13:49 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:13:49 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:13:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:13:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:13:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:13:49 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:49 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:13:49 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:49 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:13:49 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:13:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:13:49 --> Final output sent to browser
DEBUG - 2014-02-22 12:13:49 --> Total execution time: 0.0678
DEBUG - 2014-02-22 12:13:57 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:13:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:13:57 --> URI Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Router Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Output Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Security Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Input Class Initialized
DEBUG - 2014-02-22 12:13:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:13:57 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Loader Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:13:57 --> Controller Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Session Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:13:57 --> Session routines successfully run
DEBUG - 2014-02-22 12:13:57 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:13:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:13:57 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:13:57 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:13:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:13:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:13:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:13:57 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:13:57 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:13:57 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:13:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:13:57 --> URI Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Router Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Output Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Security Class Initialized
DEBUG - 2014-02-22 12:13:57 --> Input Class Initialized
DEBUG - 2014-02-22 12:13:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:13:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:13:58 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Language Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Config Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Loader Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:13:58 --> Controller Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Session Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:13:58 --> Session routines successfully run
DEBUG - 2014-02-22 12:13:58 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:13:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:13:58 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:13:58 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:13:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:13:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:13:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:13:58 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:58 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:13:58 --> Model Class Initialized
DEBUG - 2014-02-22 12:13:58 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:13:58 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 12:13:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:13:58 --> Final output sent to browser
DEBUG - 2014-02-22 12:13:58 --> Total execution time: 0.0567
DEBUG - 2014-02-22 12:14:00 --> Config Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:14:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:14:00 --> URI Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Router Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Output Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Security Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Input Class Initialized
DEBUG - 2014-02-22 12:14:00 --> XSS Filtering completed
DEBUG - 2014-02-22 12:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:14:00 --> Language Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Language Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Config Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Loader Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:14:00 --> Controller Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Session Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:14:00 --> Session routines successfully run
DEBUG - 2014-02-22 12:14:00 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:14:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:14:00 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:14:00 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:14:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:14:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:14:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:14:00 --> Model Class Initialized
DEBUG - 2014-02-22 12:14:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:14:00 --> Model Class Initialized
DEBUG - 2014-02-22 12:14:00 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:14:00 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:14:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:14:00 --> Final output sent to browser
DEBUG - 2014-02-22 12:14:00 --> Total execution time: 0.0615
DEBUG - 2014-02-22 12:14:12 --> Config Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:14:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:14:12 --> URI Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Router Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Output Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Security Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Input Class Initialized
DEBUG - 2014-02-22 12:14:12 --> XSS Filtering completed
DEBUG - 2014-02-22 12:14:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:14:12 --> Language Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Language Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Config Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Loader Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:14:12 --> Controller Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Session Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:14:12 --> Session routines successfully run
DEBUG - 2014-02-22 12:14:12 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:14:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:14:12 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:14:12 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:14:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:14:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:14:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:14:12 --> Model Class Initialized
DEBUG - 2014-02-22 12:14:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:14:12 --> Model Class Initialized
DEBUG - 2014-02-22 12:14:12 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:14:12 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:14:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:14:12 --> Final output sent to browser
DEBUG - 2014-02-22 12:14:12 --> Total execution time: 0.0697
DEBUG - 2014-02-22 12:15:08 --> Config Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:15:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:15:08 --> URI Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Router Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Output Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Security Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Input Class Initialized
DEBUG - 2014-02-22 12:15:08 --> XSS Filtering completed
DEBUG - 2014-02-22 12:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:15:08 --> Language Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Language Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Config Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Loader Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:15:08 --> Controller Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Session Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:15:08 --> Session routines successfully run
DEBUG - 2014-02-22 12:15:08 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:15:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:15:08 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:15:08 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:15:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:15:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:15:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:15:08 --> Model Class Initialized
DEBUG - 2014-02-22 12:15:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:15:08 --> Model Class Initialized
DEBUG - 2014-02-22 12:15:08 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:15:08 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:15:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:15:08 --> Final output sent to browser
DEBUG - 2014-02-22 12:15:08 --> Total execution time: 0.0588
DEBUG - 2014-02-22 12:15:56 --> Config Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:15:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:15:56 --> URI Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Router Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Output Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Security Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Input Class Initialized
DEBUG - 2014-02-22 12:15:56 --> XSS Filtering completed
DEBUG - 2014-02-22 12:15:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:15:56 --> Language Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Language Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Config Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Loader Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:15:56 --> Controller Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Session Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:15:56 --> Session routines successfully run
DEBUG - 2014-02-22 12:15:56 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:15:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:15:56 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:15:56 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:15:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:15:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:15:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:15:56 --> Model Class Initialized
DEBUG - 2014-02-22 12:15:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:15:56 --> Model Class Initialized
DEBUG - 2014-02-22 12:15:56 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:15:56 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:15:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:15:56 --> Final output sent to browser
DEBUG - 2014-02-22 12:15:56 --> Total execution time: 0.0601
DEBUG - 2014-02-22 12:16:09 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:09 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:09 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:09 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:09 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:09 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:09 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:09 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:09 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:09 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:09 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:09 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:09 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:09 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:09 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:09 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:09 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:09 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 12:16:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:16:09 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:09 --> Total execution time: 0.0585
DEBUG - 2014-02-22 12:16:12 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:12 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:12 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:12 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:12 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:12 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:12 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:12 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:12 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:12 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:12 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:12 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:12 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:16:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:16:12 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:12 --> Total execution time: 0.0573
DEBUG - 2014-02-22 12:16:15 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:15 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:15 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:15 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:15 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:15 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:15 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:15 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:15 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:15 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:15 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:15 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:15 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 12:16:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:16:15 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:15 --> Total execution time: 0.0581
DEBUG - 2014-02-22 12:16:21 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:21 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:21 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:21 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:21 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:21 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:21 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:21 --> Database Driver Class Initialized
ERROR - 2014-02-22 12:16:21 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:21 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:21 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:21 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:21 --> Helper loaded: pdf_helper
DEBUG - 2014-02-22 12:16:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-22 12:16:21 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-22 12:16:21 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:21 --> File loaded: application/views/common/header/header.php
DEBUG - 2014-02-22 12:16:21 --> File loaded: application/views/patient_referral_templates/pdf/default.php
DEBUG - 2014-02-22 12:16:21 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:21 --> Total execution time: 0.0643
DEBUG - 2014-02-22 12:16:25 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:25 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:25 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:25 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:25 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:25 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:25 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:25 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:25 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:25 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:25 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:25 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:25 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 12:16:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:16:25 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:25 --> Total execution time: 0.0509
DEBUG - 2014-02-22 12:16:27 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:27 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:27 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:27 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:27 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:27 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:27 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:27 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:27 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:27 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:27 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:27 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:27 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: pdf_helper
DEBUG - 2014-02-22 12:16:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-22 12:16:27 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:27 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-22 12:16:27 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:27 --> File loaded: application/views/common/header/header.php
DEBUG - 2014-02-22 12:16:27 --> File loaded: application/views/patient_referral_templates/pdf/default.php
DEBUG - 2014-02-22 12:16:27 --> Helper loaded: mpdf_helper
ERROR - 2014-02-22 12:16:27 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavuserifcondensed.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:27 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavuserifcondensed.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:27 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:27 --> Severity: Notice  --> Undefined index: BODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:27 --> Severity: Notice  --> Undefined index: BODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:27 --> Severity: Notice  --> Undefined offset: -1 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14393
ERROR - 2014-02-22 12:16:27 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensed.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:27 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensed.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 17642
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensedB.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensedB.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: overflow D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24135
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: headernrows D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24824
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: headernrows D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24824
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 0 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 17642
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TBODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TBODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TBODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TBODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 0 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 1 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 2 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 4 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 5 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: css_set_height D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 5084
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27963
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 28064
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 8741
DEBUG - 2014-02-22 12:16:28 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:28 --> Total execution time: 0.4371
DEBUG - 2014-02-22 12:16:28 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:28 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:28 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:28 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:28 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:28 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:28 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:28 --> Database Driver Class Initialized
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:28 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:28 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: pdf_helper
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-22 12:16:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-22 12:16:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/views/common/header/header.php
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/views/patient_referral_templates/pdf/default.php
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: mpdf_helper
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavuserifcondensed.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavuserifcondensed.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: BODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: BODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: -1 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14393
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensed.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensed.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 17642
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensedB.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensedB.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: overflow D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24135
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: headernrows D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24824
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: headernrows D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24824
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 0 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 17642
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TBODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TBODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TBODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TBODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 0 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 1 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 2 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 4 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 5 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: css_set_height D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 5084
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27963
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 28064
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 8741
DEBUG - 2014-02-22 12:16:28 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:28 --> Total execution time: 0.4342
DEBUG - 2014-02-22 12:16:28 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:28 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:28 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:28 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:28 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:28 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:28 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:28 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:28 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:28 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: pdf_helper
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-22 12:16:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-22 12:16:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/views/common/header/header.php
DEBUG - 2014-02-22 12:16:28 --> File loaded: application/views/patient_referral_templates/pdf/default.php
DEBUG - 2014-02-22 12:16:28 --> Helper loaded: mpdf_helper
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavuserifcondensed.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavuserifcondensed.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: BODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: BODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: -1 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14393
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensed.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensed.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 17642
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include(D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensedB.mtx.php) [<a href='function.include'>function.include</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Warning  --> include() [<a href='function.include'>function.include</a>]: Failed opening 'D:/xampp/htdocs/tcms/application/helpers/mpdf/ttfontdata/dejavusanscondensedB.mtx.php' for inclusion (include_path='.;D:\xampp\php\PEAR') D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2809
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: unAGlyphs D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 2895
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: overflow D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24135
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: headernrows D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24824
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: headernrows D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 24824
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined offset: 0 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>CLASS>>CONTENT D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV>>ID>>HEADER D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: H3>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:28 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: DIV>>ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: DIV>>ID>>LE_DETAIL D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: DIV D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: DIV>>ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14252
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: DIV>>ID>>INVOICE-ITEMS D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 16447
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 17642
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14218
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TABLE>>CLASS>>TABLE-STRIPED D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14256
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TABLE>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TBODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TBODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TBODY D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TBODY>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TH>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TR D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TR>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14215
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: TD>>ID>> D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 14260
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined offset: 0 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined offset: 1 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined offset: 2 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined offset: 3 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined offset: 4 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined offset: 5 D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27065
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: direction D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 19012
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined index: css_set_height D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 5084
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 27963
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 28064
ERROR - 2014-02-22 12:16:29 --> Severity: Notice  --> Undefined property: mPDF::$hasOC D:\xampp\htdocs\tcms\application\helpers\mpdf\mpdf.php 8741
DEBUG - 2014-02-22 12:16:29 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:29 --> Total execution time: 0.4276
DEBUG - 2014-02-22 12:16:50 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:50 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:50 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:50 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:50 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:50 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:50 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:50 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:50 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:50 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:50 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:50 --> Helper loaded: pdf_helper
DEBUG - 2014-02-22 12:16:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-22 12:16:50 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:50 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-22 12:16:50 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:50 --> File loaded: application/views/common/header/header.php
DEBUG - 2014-02-22 12:16:50 --> File loaded: application/views/patient_referral_templates/pdf/default.php
DEBUG - 2014-02-22 12:16:50 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:50 --> Total execution time: 0.0618
DEBUG - 2014-02-22 12:16:57 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:16:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:16:57 --> URI Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Router Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Output Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Security Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Input Class Initialized
DEBUG - 2014-02-22 12:16:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:16:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:16:57 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Language Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Config Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Loader Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:16:57 --> Controller Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Session Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:16:57 --> Session routines successfully run
DEBUG - 2014-02-22 12:16:57 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:16:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:16:57 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:16:57 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:16:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:16:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:16:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:16:57 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:16:57 --> Model Class Initialized
DEBUG - 2014-02-22 12:16:57 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:16:57 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 12:16:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:16:57 --> Final output sent to browser
DEBUG - 2014-02-22 12:16:57 --> Total execution time: 0.0522
DEBUG - 2014-02-22 12:17:00 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:17:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:17:00 --> URI Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Router Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Output Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Security Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Input Class Initialized
DEBUG - 2014-02-22 12:17:00 --> XSS Filtering completed
DEBUG - 2014-02-22 12:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:17:00 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Loader Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:17:00 --> Controller Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Session Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:17:00 --> Session routines successfully run
DEBUG - 2014-02-22 12:17:00 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:17:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:17:00 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:17:00 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:17:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:17:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:17:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:17:00 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:17:00 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:00 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:17:00 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-22 12:17:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:17:00 --> Final output sent to browser
DEBUG - 2014-02-22 12:17:00 --> Total execution time: 0.0599
DEBUG - 2014-02-22 12:17:03 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:17:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:17:03 --> URI Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Router Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Output Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Security Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Input Class Initialized
DEBUG - 2014-02-22 12:17:03 --> XSS Filtering completed
DEBUG - 2014-02-22 12:17:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:17:03 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Loader Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:17:03 --> Controller Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Session Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:17:03 --> Session routines successfully run
DEBUG - 2014-02-22 12:17:03 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:17:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:17:03 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:17:03 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:17:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:17:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:17:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:17:03 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:17:03 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:03 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:17:03 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 12:17:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:17:03 --> Final output sent to browser
DEBUG - 2014-02-22 12:17:03 --> Total execution time: 0.0612
DEBUG - 2014-02-22 12:17:07 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:17:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:17:07 --> URI Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Router Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Output Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Security Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Input Class Initialized
DEBUG - 2014-02-22 12:17:07 --> XSS Filtering completed
DEBUG - 2014-02-22 12:17:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:17:07 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Loader Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:17:07 --> Controller Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Session Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:17:07 --> Session routines successfully run
DEBUG - 2014-02-22 12:17:07 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:17:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:17:07 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:17:07 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:17:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:17:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:17:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:17:07 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:17:07 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:07 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:17:07 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-22 12:17:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:17:07 --> Final output sent to browser
DEBUG - 2014-02-22 12:17:07 --> Total execution time: 0.0558
DEBUG - 2014-02-22 12:17:09 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:17:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:17:09 --> URI Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Router Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Output Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Security Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Input Class Initialized
DEBUG - 2014-02-22 12:17:09 --> XSS Filtering completed
DEBUG - 2014-02-22 12:17:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:17:09 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Loader Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:17:09 --> Controller Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Session Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:17:09 --> Session routines successfully run
DEBUG - 2014-02-22 12:17:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:17:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:17:09 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:17:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:17:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:17:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:17:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:17:09 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:17:09 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:09 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:17:09 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 12:17:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:17:09 --> Final output sent to browser
DEBUG - 2014-02-22 12:17:09 --> Total execution time: 0.0623
DEBUG - 2014-02-22 12:17:13 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:17:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:17:13 --> URI Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Router Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Output Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Security Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Input Class Initialized
DEBUG - 2014-02-22 12:17:13 --> XSS Filtering completed
DEBUG - 2014-02-22 12:17:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:17:13 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Loader Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:17:13 --> Controller Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Session Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:17:13 --> Session routines successfully run
DEBUG - 2014-02-22 12:17:13 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:17:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:17:13 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:17:13 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:17:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:17:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:17:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:17:13 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:17:13 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:13 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:17:13 --> File loaded: application/modules/patient/views/certificate.php
DEBUG - 2014-02-22 12:17:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:17:13 --> Final output sent to browser
DEBUG - 2014-02-22 12:17:13 --> Total execution time: 0.0661
DEBUG - 2014-02-22 12:17:15 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:17:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:17:15 --> URI Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Router Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Output Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Security Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Input Class Initialized
DEBUG - 2014-02-22 12:17:15 --> XSS Filtering completed
DEBUG - 2014-02-22 12:17:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:17:15 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Language Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Config Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Loader Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:17:15 --> Controller Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Session Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:17:15 --> Session routines successfully run
DEBUG - 2014-02-22 12:17:15 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:17:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:17:15 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:17:15 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:17:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:17:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:17:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:17:15 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:17:15 --> Model Class Initialized
DEBUG - 2014-02-22 12:17:15 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:17:15 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:17:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:17:15 --> Final output sent to browser
DEBUG - 2014-02-22 12:17:15 --> Total execution time: 0.0628
DEBUG - 2014-02-22 12:19:12 --> Config Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:19:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:19:12 --> URI Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Router Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Output Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Security Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Input Class Initialized
DEBUG - 2014-02-22 12:19:12 --> XSS Filtering completed
DEBUG - 2014-02-22 12:19:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:19:12 --> Language Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Language Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Config Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Loader Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:19:12 --> Controller Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Session Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:19:12 --> Session routines successfully run
DEBUG - 2014-02-22 12:19:12 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:19:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:19:12 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:19:12 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:19:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:19:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:19:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:19:12 --> Model Class Initialized
DEBUG - 2014-02-22 12:19:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:19:12 --> Model Class Initialized
DEBUG - 2014-02-22 12:19:12 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:19:12 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:19:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:19:12 --> Final output sent to browser
DEBUG - 2014-02-22 12:19:12 --> Total execution time: 0.0637
DEBUG - 2014-02-22 12:19:25 --> Config Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:19:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:19:25 --> URI Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Router Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Output Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Security Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Input Class Initialized
DEBUG - 2014-02-22 12:19:25 --> XSS Filtering completed
DEBUG - 2014-02-22 12:19:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:19:25 --> Language Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Language Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Config Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Loader Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:19:25 --> Controller Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Session Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:19:25 --> Session routines successfully run
DEBUG - 2014-02-22 12:19:25 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:19:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:19:25 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:19:25 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:19:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:19:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:19:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:19:25 --> Model Class Initialized
DEBUG - 2014-02-22 12:19:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:19:25 --> Model Class Initialized
DEBUG - 2014-02-22 12:19:25 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:19:25 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:19:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:19:25 --> Final output sent to browser
DEBUG - 2014-02-22 12:19:25 --> Total execution time: 0.0655
DEBUG - 2014-02-22 12:21:15 --> Config Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:21:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:21:15 --> URI Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Router Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Output Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Security Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Input Class Initialized
DEBUG - 2014-02-22 12:21:15 --> XSS Filtering completed
DEBUG - 2014-02-22 12:21:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:21:15 --> Language Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Language Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Config Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Loader Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:21:15 --> Controller Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Session Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:21:15 --> Session routines successfully run
DEBUG - 2014-02-22 12:21:15 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:21:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:21:15 --> Database Driver Class Initialized
ERROR - 2014-02-22 12:21:15 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:21:15 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:21:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:21:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:21:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:21:15 --> Model Class Initialized
DEBUG - 2014-02-22 12:21:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:21:15 --> Model Class Initialized
DEBUG - 2014-02-22 12:21:15 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:21:15 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:21:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:21:15 --> Final output sent to browser
DEBUG - 2014-02-22 12:21:15 --> Total execution time: 0.0661
DEBUG - 2014-02-22 12:22:50 --> Config Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:22:50 --> URI Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Router Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Output Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Security Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Input Class Initialized
DEBUG - 2014-02-22 12:22:50 --> XSS Filtering completed
DEBUG - 2014-02-22 12:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:22:50 --> Language Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Language Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Config Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Loader Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:22:50 --> Controller Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Session Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:22:50 --> Session routines successfully run
DEBUG - 2014-02-22 12:22:50 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:22:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:22:50 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:22:50 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:22:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:22:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:22:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:22:50 --> Model Class Initialized
DEBUG - 2014-02-22 12:22:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:22:50 --> Model Class Initialized
DEBUG - 2014-02-22 12:22:50 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:22:50 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-22 12:22:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:22:50 --> Final output sent to browser
DEBUG - 2014-02-22 12:22:50 --> Total execution time: 0.0613
DEBUG - 2014-02-22 12:22:53 --> Config Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:22:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:22:53 --> URI Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Router Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Output Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Security Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Input Class Initialized
DEBUG - 2014-02-22 12:22:53 --> XSS Filtering completed
DEBUG - 2014-02-22 12:22:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:22:53 --> Language Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Language Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Config Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Loader Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:22:53 --> Controller Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Session Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:22:53 --> Session routines successfully run
DEBUG - 2014-02-22 12:22:53 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:22:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:22:53 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:22:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:22:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:22:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:22:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:22:53 --> Model Class Initialized
DEBUG - 2014-02-22 12:22:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:22:53 --> Model Class Initialized
DEBUG - 2014-02-22 12:22:53 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:22:53 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-22 12:22:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:22:53 --> Final output sent to browser
DEBUG - 2014-02-22 12:22:53 --> Total execution time: 0.0614
DEBUG - 2014-02-22 12:22:55 --> Config Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:22:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:22:55 --> URI Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Router Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Output Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Security Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Input Class Initialized
DEBUG - 2014-02-22 12:22:55 --> XSS Filtering completed
DEBUG - 2014-02-22 12:22:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:22:55 --> Language Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Language Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Config Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Loader Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:22:55 --> Controller Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Session Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:22:55 --> Session routines successfully run
DEBUG - 2014-02-22 12:22:55 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:22:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:22:55 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:22:55 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:22:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:22:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:22:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:22:55 --> Model Class Initialized
DEBUG - 2014-02-22 12:22:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:22:55 --> Model Class Initialized
DEBUG - 2014-02-22 12:22:55 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:22:55 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 12:22:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:22:55 --> Final output sent to browser
DEBUG - 2014-02-22 12:22:55 --> Total execution time: 0.0551
DEBUG - 2014-02-22 12:23:19 --> Config Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:23:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:23:19 --> URI Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Router Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Output Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Security Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Input Class Initialized
DEBUG - 2014-02-22 12:23:19 --> XSS Filtering completed
DEBUG - 2014-02-22 12:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:23:19 --> Language Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Language Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Config Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Loader Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:23:19 --> Controller Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Session Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:23:19 --> Session routines successfully run
DEBUG - 2014-02-22 12:23:19 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:23:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:23:19 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:23:19 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:23:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:23:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:23:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:23:19 --> Model Class Initialized
DEBUG - 2014-02-22 12:23:19 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:23:19 --> Model Class Initialized
DEBUG - 2014-02-22 12:23:19 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:23:19 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:23:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:23:19 --> Final output sent to browser
DEBUG - 2014-02-22 12:23:19 --> Total execution time: 0.0653
DEBUG - 2014-02-22 12:28:05 --> Config Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:28:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:28:05 --> URI Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Router Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Output Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Security Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Input Class Initialized
DEBUG - 2014-02-22 12:28:05 --> XSS Filtering completed
DEBUG - 2014-02-22 12:28:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:28:05 --> Language Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Language Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Config Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Loader Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:28:05 --> Controller Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Session Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:28:05 --> Session routines successfully run
DEBUG - 2014-02-22 12:28:05 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:28:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:28:05 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:28:05 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:28:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:28:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:28:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:28:05 --> Model Class Initialized
DEBUG - 2014-02-22 12:28:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:28:05 --> Model Class Initialized
DEBUG - 2014-02-22 12:28:05 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:28:05 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:28:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:28:05 --> Final output sent to browser
DEBUG - 2014-02-22 12:28:05 --> Total execution time: 0.0662
DEBUG - 2014-02-22 12:31:53 --> Config Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:31:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:31:53 --> URI Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Router Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Output Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Security Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Input Class Initialized
DEBUG - 2014-02-22 12:31:53 --> XSS Filtering completed
DEBUG - 2014-02-22 12:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:31:53 --> Language Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Language Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Config Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Loader Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:31:53 --> Controller Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Session Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:31:53 --> Session routines successfully run
DEBUG - 2014-02-22 12:31:53 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:31:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:31:53 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:31:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:31:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:31:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:31:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:31:53 --> Model Class Initialized
DEBUG - 2014-02-22 12:31:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:31:53 --> Model Class Initialized
DEBUG - 2014-02-22 12:31:53 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:31:53 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:31:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:31:53 --> Final output sent to browser
DEBUG - 2014-02-22 12:31:53 --> Total execution time: 0.0654
DEBUG - 2014-02-22 12:32:03 --> Config Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:32:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:32:03 --> URI Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Router Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Output Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Security Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Input Class Initialized
DEBUG - 2014-02-22 12:32:03 --> XSS Filtering completed
DEBUG - 2014-02-22 12:32:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:32:03 --> Language Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Language Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Config Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Loader Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:32:03 --> Controller Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Session Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:32:03 --> Session routines successfully run
DEBUG - 2014-02-22 12:32:03 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:32:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:32:03 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:32:03 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:32:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:32:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:32:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:32:03 --> Model Class Initialized
DEBUG - 2014-02-22 12:32:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:32:03 --> Model Class Initialized
DEBUG - 2014-02-22 12:32:03 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:32:03 --> File loaded: application/modules/patient/views/prescription.php
DEBUG - 2014-02-22 12:32:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:32:03 --> Final output sent to browser
DEBUG - 2014-02-22 12:32:03 --> Total execution time: 0.0586
DEBUG - 2014-02-22 12:32:05 --> Config Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:32:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:32:05 --> URI Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Router Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Output Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Security Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Input Class Initialized
DEBUG - 2014-02-22 12:32:05 --> XSS Filtering completed
DEBUG - 2014-02-22 12:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:32:05 --> Language Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Language Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Config Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Loader Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:32:05 --> Controller Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Session Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:32:05 --> Session routines successfully run
DEBUG - 2014-02-22 12:32:05 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:32:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:32:05 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:32:05 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:32:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:32:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:32:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:32:05 --> Model Class Initialized
DEBUG - 2014-02-22 12:32:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:32:05 --> Model Class Initialized
DEBUG - 2014-02-22 12:32:05 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:32:05 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:32:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:32:05 --> Final output sent to browser
DEBUG - 2014-02-22 12:32:05 --> Total execution time: 0.0580
DEBUG - 2014-02-22 12:33:29 --> Config Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:33:29 --> URI Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Router Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Output Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Security Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Input Class Initialized
DEBUG - 2014-02-22 12:33:29 --> XSS Filtering completed
DEBUG - 2014-02-22 12:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:33:29 --> Language Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Language Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Config Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Loader Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:33:29 --> Controller Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Session Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:33:29 --> Session routines successfully run
DEBUG - 2014-02-22 12:33:29 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:33:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:33:29 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:33:29 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:33:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:33:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:33:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:33:29 --> Model Class Initialized
DEBUG - 2014-02-22 12:33:29 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:33:29 --> Model Class Initialized
DEBUG - 2014-02-22 12:33:29 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:33:29 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:33:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:33:29 --> Final output sent to browser
DEBUG - 2014-02-22 12:33:29 --> Total execution time: 0.0561
DEBUG - 2014-02-22 12:33:36 --> Config Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:33:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:33:36 --> URI Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Router Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Output Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Security Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Input Class Initialized
DEBUG - 2014-02-22 12:33:36 --> XSS Filtering completed
DEBUG - 2014-02-22 12:33:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:33:36 --> Language Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Language Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Config Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Loader Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:33:36 --> Controller Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Session Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:33:36 --> Session routines successfully run
DEBUG - 2014-02-22 12:33:36 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:33:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:33:36 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:33:36 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:33:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:33:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:33:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:33:36 --> Model Class Initialized
DEBUG - 2014-02-22 12:33:36 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:33:36 --> Model Class Initialized
DEBUG - 2014-02-22 12:33:36 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:33:36 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 12:33:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:33:36 --> Final output sent to browser
DEBUG - 2014-02-22 12:33:36 --> Total execution time: 0.0570
DEBUG - 2014-02-22 12:34:24 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:34:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:34:24 --> URI Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Router Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Output Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Security Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Input Class Initialized
DEBUG - 2014-02-22 12:34:24 --> XSS Filtering completed
DEBUG - 2014-02-22 12:34:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:34:24 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Loader Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:34:24 --> Controller Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Session Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:34:24 --> Session routines successfully run
DEBUG - 2014-02-22 12:34:24 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:34:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:34:24 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:34:24 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:34:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:34:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:34:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:34:24 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:34:24 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:24 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:34:24 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:34:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:34:24 --> Final output sent to browser
DEBUG - 2014-02-22 12:34:24 --> Total execution time: 0.0602
DEBUG - 2014-02-22 12:34:27 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:34:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:34:27 --> URI Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Router Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Output Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Security Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Input Class Initialized
DEBUG - 2014-02-22 12:34:27 --> XSS Filtering completed
DEBUG - 2014-02-22 12:34:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:34:27 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Loader Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:34:27 --> Controller Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Session Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:34:27 --> Session routines successfully run
DEBUG - 2014-02-22 12:34:27 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:34:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:34:27 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:34:27 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:34:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:34:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:34:27 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:34:27 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:27 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:34:27 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:27 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:34:27 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:34:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:34:27 --> Final output sent to browser
DEBUG - 2014-02-22 12:34:27 --> Total execution time: 0.0575
DEBUG - 2014-02-22 12:34:35 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:34:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:34:35 --> URI Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Router Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Output Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Security Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Input Class Initialized
DEBUG - 2014-02-22 12:34:35 --> XSS Filtering completed
DEBUG - 2014-02-22 12:34:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:34:35 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Loader Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:34:35 --> Controller Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Session Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:34:35 --> Session routines successfully run
DEBUG - 2014-02-22 12:34:35 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:34:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:34:35 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:34:35 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:34:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:34:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:34:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:34:35 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:35 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:34:35 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:35 --> Helper loaded: image_helper
ERROR - 2014-02-22 12:34:35 --> Severity: Notice  --> Undefined variable: patient_profile D:\xampp\htdocs\tcms\application\modules\patient\views\edit_prescription.php 12
ERROR - 2014-02-22 12:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\tcms\application\modules\patient\views\edit_prescription.php 12
ERROR - 2014-02-22 12:34:35 --> Severity: Notice  --> Undefined variable: patient_profile D:\xampp\htdocs\tcms\application\modules\patient\views\edit_prescription.php 12
ERROR - 2014-02-22 12:34:35 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\tcms\application\modules\patient\views\edit_prescription.php 12
DEBUG - 2014-02-22 12:34:35 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:34:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:34:35 --> Final output sent to browser
DEBUG - 2014-02-22 12:34:35 --> Total execution time: 0.0611
DEBUG - 2014-02-22 12:34:46 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:34:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:34:46 --> URI Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Router Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Output Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Security Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Input Class Initialized
DEBUG - 2014-02-22 12:34:46 --> XSS Filtering completed
DEBUG - 2014-02-22 12:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:34:46 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Loader Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:34:46 --> Controller Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Session Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:34:46 --> Session routines successfully run
DEBUG - 2014-02-22 12:34:46 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:34:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:34:46 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:34:46 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:34:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:34:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:34:46 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:34:46 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:46 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:34:46 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:46 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:34:46 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:34:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:34:46 --> Final output sent to browser
DEBUG - 2014-02-22 12:34:46 --> Total execution time: 0.0608
DEBUG - 2014-02-22 12:34:55 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:34:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:34:55 --> URI Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Router Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Output Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Security Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Input Class Initialized
DEBUG - 2014-02-22 12:34:55 --> XSS Filtering completed
DEBUG - 2014-02-22 12:34:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:34:55 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Language Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Config Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Loader Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:34:55 --> Controller Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Session Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:34:55 --> Session routines successfully run
DEBUG - 2014-02-22 12:34:55 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:34:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:34:55 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:34:55 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:34:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:34:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:34:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:34:55 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:34:55 --> Model Class Initialized
DEBUG - 2014-02-22 12:34:55 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:34:55 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:34:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:34:55 --> Final output sent to browser
DEBUG - 2014-02-22 12:34:55 --> Total execution time: 0.0583
DEBUG - 2014-02-22 12:38:41 --> Config Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:38:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:38:41 --> URI Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Router Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Output Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Security Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Input Class Initialized
DEBUG - 2014-02-22 12:38:41 --> XSS Filtering completed
DEBUG - 2014-02-22 12:38:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:38:41 --> Language Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Language Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Config Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Loader Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:38:41 --> Controller Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Session Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:38:41 --> Session routines successfully run
DEBUG - 2014-02-22 12:38:41 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:38:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:38:41 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:38:41 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:38:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:38:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:38:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:38:41 --> Model Class Initialized
DEBUG - 2014-02-22 12:38:41 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:38:41 --> Model Class Initialized
DEBUG - 2014-02-22 12:38:41 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:38:41 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:38:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:38:41 --> Final output sent to browser
DEBUG - 2014-02-22 12:38:41 --> Total execution time: 0.0568
DEBUG - 2014-02-22 12:42:23 --> Config Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:42:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:42:23 --> URI Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Router Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Output Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Security Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Input Class Initialized
DEBUG - 2014-02-22 12:42:23 --> XSS Filtering completed
DEBUG - 2014-02-22 12:42:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:42:23 --> Language Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Language Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Config Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Loader Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:42:23 --> Controller Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Session Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:42:23 --> Session routines successfully run
DEBUG - 2014-02-22 12:42:23 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:42:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:42:23 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:42:23 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:42:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:42:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:42:24 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:42:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:42:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:42:24 --> Model Class Initialized
DEBUG - 2014-02-22 12:42:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:42:24 --> Model Class Initialized
DEBUG - 2014-02-22 12:42:24 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:42:24 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:42:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:42:24 --> Final output sent to browser
DEBUG - 2014-02-22 12:42:24 --> Total execution time: 0.0664
DEBUG - 2014-02-22 12:43:06 --> Config Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:43:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:43:06 --> URI Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Router Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Output Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Security Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Input Class Initialized
DEBUG - 2014-02-22 12:43:06 --> XSS Filtering completed
DEBUG - 2014-02-22 12:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:43:06 --> Language Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Language Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Config Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Loader Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:43:06 --> Controller Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Session Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:43:06 --> Session routines successfully run
DEBUG - 2014-02-22 12:43:06 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:43:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:43:06 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:43:06 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:43:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:43:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:43:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:43:06 --> Model Class Initialized
DEBUG - 2014-02-22 12:43:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:43:06 --> Model Class Initialized
DEBUG - 2014-02-22 12:43:06 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:43:06 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:43:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:43:06 --> Final output sent to browser
DEBUG - 2014-02-22 12:43:06 --> Total execution time: 0.0652
DEBUG - 2014-02-22 12:43:31 --> Config Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:43:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:43:31 --> URI Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Router Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Output Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Security Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Input Class Initialized
DEBUG - 2014-02-22 12:43:31 --> XSS Filtering completed
DEBUG - 2014-02-22 12:43:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:43:31 --> Language Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Language Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Config Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Loader Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:43:31 --> Controller Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Session Class Initialized
DEBUG - 2014-02-22 12:43:31 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:43:32 --> Session routines successfully run
DEBUG - 2014-02-22 12:43:32 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:43:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:43:32 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:43:32 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:43:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:43:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:43:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:43:32 --> Model Class Initialized
DEBUG - 2014-02-22 12:43:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:43:32 --> Model Class Initialized
DEBUG - 2014-02-22 12:43:32 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:43:32 --> File loaded: application/modules/patient/views/edit_prescription.php
DEBUG - 2014-02-22 12:43:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:43:32 --> Final output sent to browser
DEBUG - 2014-02-22 12:43:32 --> Total execution time: 0.0596
DEBUG - 2014-02-22 12:46:41 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:46:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:46:41 --> URI Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Router Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Output Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Security Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Input Class Initialized
DEBUG - 2014-02-22 12:46:41 --> XSS Filtering completed
DEBUG - 2014-02-22 12:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:46:41 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Loader Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:46:41 --> Controller Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Session Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:46:41 --> Session routines successfully run
DEBUG - 2014-02-22 12:46:41 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:46:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:46:41 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:46:41 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:46:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:46:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:46:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:46:41 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:41 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:46:41 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:41 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:46:41 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 12:46:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:46:41 --> Final output sent to browser
DEBUG - 2014-02-22 12:46:41 --> Total execution time: 0.0678
DEBUG - 2014-02-22 12:46:43 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:46:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:46:43 --> URI Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Router Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Output Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Security Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Input Class Initialized
DEBUG - 2014-02-22 12:46:43 --> XSS Filtering completed
DEBUG - 2014-02-22 12:46:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:46:43 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Loader Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:46:43 --> Controller Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Session Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:46:43 --> Session routines successfully run
DEBUG - 2014-02-22 12:46:43 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:46:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:46:43 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:46:43 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:46:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:46:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:46:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:46:43 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:46:43 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:43 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:46:43 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 12:46:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:46:43 --> Final output sent to browser
DEBUG - 2014-02-22 12:46:43 --> Total execution time: 0.0582
DEBUG - 2014-02-22 12:46:53 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:46:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:46:53 --> URI Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Router Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Output Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Security Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Input Class Initialized
DEBUG - 2014-02-22 12:46:53 --> XSS Filtering completed
DEBUG - 2014-02-22 12:46:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:46:53 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Loader Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:46:53 --> Controller Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Session Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:46:53 --> Session routines successfully run
DEBUG - 2014-02-22 12:46:53 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:46:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:46:53 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:46:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:46:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:46:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:46:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:46:53 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:46:53 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:53 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:46:53 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-22 12:46:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:46:53 --> Final output sent to browser
DEBUG - 2014-02-22 12:46:53 --> Total execution time: 0.0533
DEBUG - 2014-02-22 12:46:55 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:46:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:46:55 --> URI Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Router Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Output Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Security Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Input Class Initialized
DEBUG - 2014-02-22 12:46:55 --> XSS Filtering completed
DEBUG - 2014-02-22 12:46:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:46:55 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Loader Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:46:55 --> Controller Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Session Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:46:55 --> Session routines successfully run
DEBUG - 2014-02-22 12:46:55 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:46:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:46:55 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:46:55 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:46:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:46:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:46:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:46:55 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:46:55 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:55 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:46:55 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-22 12:46:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:46:55 --> Final output sent to browser
DEBUG - 2014-02-22 12:46:55 --> Total execution time: 0.0564
DEBUG - 2014-02-22 12:46:57 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:46:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:46:57 --> URI Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Router Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Output Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Security Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Input Class Initialized
DEBUG - 2014-02-22 12:46:57 --> XSS Filtering completed
DEBUG - 2014-02-22 12:46:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:46:57 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Language Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Config Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Loader Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:46:57 --> Controller Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Session Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:46:57 --> Session routines successfully run
DEBUG - 2014-02-22 12:46:57 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:46:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:46:57 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:46:57 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:46:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:46:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:46:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:46:57 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:46:57 --> Model Class Initialized
DEBUG - 2014-02-22 12:46:57 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:46:57 --> File loaded: application/modules/patient/views/edit_note.php
DEBUG - 2014-02-22 12:46:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:46:57 --> Final output sent to browser
DEBUG - 2014-02-22 12:46:57 --> Total execution time: 0.0584
DEBUG - 2014-02-22 12:47:00 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:47:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:47:00 --> URI Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Router Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Output Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Security Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Input Class Initialized
DEBUG - 2014-02-22 12:47:00 --> XSS Filtering completed
DEBUG - 2014-02-22 12:47:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:47:00 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Loader Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:47:00 --> Controller Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Session Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:47:00 --> Session routines successfully run
DEBUG - 2014-02-22 12:47:00 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:47:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:47:00 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:47:00 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:47:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:47:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:47:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:47:00 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:47:00 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:00 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:47:00 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 12:47:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:47:00 --> Final output sent to browser
DEBUG - 2014-02-22 12:47:00 --> Total execution time: 0.0557
DEBUG - 2014-02-22 12:47:03 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:47:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:47:03 --> URI Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Router Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Output Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Security Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Input Class Initialized
DEBUG - 2014-02-22 12:47:03 --> XSS Filtering completed
DEBUG - 2014-02-22 12:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:47:03 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Loader Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:47:03 --> Controller Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Session Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:47:03 --> Session routines successfully run
DEBUG - 2014-02-22 12:47:03 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:47:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:47:03 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:47:03 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:47:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:47:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:47:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:47:03 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:47:03 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:03 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:47:03 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:47:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:47:03 --> Final output sent to browser
DEBUG - 2014-02-22 12:47:03 --> Total execution time: 0.0679
DEBUG - 2014-02-22 12:47:08 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:47:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:47:08 --> URI Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Router Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Output Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Security Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Input Class Initialized
DEBUG - 2014-02-22 12:47:08 --> XSS Filtering completed
DEBUG - 2014-02-22 12:47:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:47:08 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Loader Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:47:08 --> Controller Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Session Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:47:08 --> Session routines successfully run
DEBUG - 2014-02-22 12:47:08 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:47:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:47:08 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:47:08 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:47:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:47:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:47:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:47:08 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:47:08 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:08 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:47:08 --> File loaded: application/modules/patient/views/certificate.php
DEBUG - 2014-02-22 12:47:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:47:08 --> Final output sent to browser
DEBUG - 2014-02-22 12:47:08 --> Total execution time: 0.0523
DEBUG - 2014-02-22 12:47:21 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:47:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:47:21 --> URI Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Router Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Output Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Security Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Input Class Initialized
DEBUG - 2014-02-22 12:47:21 --> XSS Filtering completed
DEBUG - 2014-02-22 12:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:47:21 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Loader Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:47:21 --> Controller Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Session Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:47:21 --> Session routines successfully run
DEBUG - 2014-02-22 12:47:21 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:47:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:47:21 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:47:21 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:47:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:47:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:47:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:47:21 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:47:21 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:21 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:47:21 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:47:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:47:21 --> Final output sent to browser
DEBUG - 2014-02-22 12:47:21 --> Total execution time: 0.0596
DEBUG - 2014-02-22 12:47:59 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:47:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:47:59 --> URI Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Router Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Output Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Security Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Input Class Initialized
DEBUG - 2014-02-22 12:47:59 --> XSS Filtering completed
DEBUG - 2014-02-22 12:47:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:47:59 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Language Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Config Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Loader Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:47:59 --> Controller Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Session Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:47:59 --> Session routines successfully run
DEBUG - 2014-02-22 12:47:59 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:47:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:47:59 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:47:59 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:47:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:47:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:47:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:47:59 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:47:59 --> Model Class Initialized
DEBUG - 2014-02-22 12:47:59 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:47:59 --> File loaded: application/modules/patient/views/edit_certificate.php
DEBUG - 2014-02-22 12:47:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:47:59 --> Final output sent to browser
DEBUG - 2014-02-22 12:47:59 --> Total execution time: 0.0647
DEBUG - 2014-02-22 12:48:04 --> Config Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:48:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:48:04 --> URI Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Router Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Output Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Security Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Input Class Initialized
DEBUG - 2014-02-22 12:48:04 --> XSS Filtering completed
DEBUG - 2014-02-22 12:48:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:48:04 --> Language Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Language Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Config Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Loader Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:48:04 --> Controller Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Session Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:48:04 --> Session routines successfully run
DEBUG - 2014-02-22 12:48:04 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:48:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:48:04 --> Database Driver Class Initialized
ERROR - 2014-02-22 12:48:04 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:48:04 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:48:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:48:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:48:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:48:04 --> Model Class Initialized
DEBUG - 2014-02-22 12:48:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:48:04 --> Model Class Initialized
DEBUG - 2014-02-22 12:48:04 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:48:04 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-22 12:48:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:48:04 --> Final output sent to browser
DEBUG - 2014-02-22 12:48:04 --> Total execution time: 0.0720
DEBUG - 2014-02-22 12:48:06 --> Config Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:48:06 --> URI Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Router Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Output Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Security Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Input Class Initialized
DEBUG - 2014-02-22 12:48:06 --> XSS Filtering completed
DEBUG - 2014-02-22 12:48:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:48:06 --> Language Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Language Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Config Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Loader Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:48:06 --> Controller Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Session Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:48:06 --> Session routines successfully run
DEBUG - 2014-02-22 12:48:06 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:48:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:48:06 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:48:06 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:48:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:48:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:48:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:48:06 --> Model Class Initialized
DEBUG - 2014-02-22 12:48:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:48:06 --> Model Class Initialized
DEBUG - 2014-02-22 12:48:06 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:48:06 --> File loaded: application/modules/patient/views/edit_referral.php
DEBUG - 2014-02-22 12:48:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:48:06 --> Final output sent to browser
DEBUG - 2014-02-22 12:48:06 --> Total execution time: 0.0617
DEBUG - 2014-02-22 12:59:24 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:24 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:59:24 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:59:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:59:24 --> URI Class Initialized
DEBUG - 2014-02-22 12:59:24 --> Router Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Output Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Security Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Input Class Initialized
DEBUG - 2014-02-22 12:59:25 --> XSS Filtering completed
DEBUG - 2014-02-22 12:59:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:59:25 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Loader Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:59:25 --> Controller Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Session Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:59:25 --> Session routines successfully run
DEBUG - 2014-02-22 12:59:25 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:59:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:59:25 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:59:25 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:59:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:59:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:59:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:59:25 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:59:25 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:25 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:59:25 --> File loaded: application/modules/patient/views/certificate.php
DEBUG - 2014-02-22 12:59:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:59:25 --> Final output sent to browser
DEBUG - 2014-02-22 12:59:25 --> Total execution time: 0.0540
DEBUG - 2014-02-22 12:59:28 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:59:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:59:28 --> URI Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Router Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Output Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Security Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Input Class Initialized
DEBUG - 2014-02-22 12:59:28 --> XSS Filtering completed
DEBUG - 2014-02-22 12:59:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:59:28 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Loader Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:59:28 --> Controller Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Session Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:59:28 --> Session routines successfully run
DEBUG - 2014-02-22 12:59:28 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:59:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:59:28 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:59:28 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:59:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:59:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:59:28 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:59:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:28 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:59:28 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:28 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:59:28 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 12:59:28 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:59:28 --> Final output sent to browser
DEBUG - 2014-02-22 12:59:28 --> Total execution time: 0.0630
DEBUG - 2014-02-22 12:59:30 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:59:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:59:30 --> URI Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Router Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Output Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Security Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Input Class Initialized
DEBUG - 2014-02-22 12:59:30 --> XSS Filtering completed
DEBUG - 2014-02-22 12:59:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:59:30 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Loader Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:59:30 --> Controller Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Session Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:59:30 --> Session routines successfully run
DEBUG - 2014-02-22 12:59:30 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:59:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:59:30 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:59:30 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:59:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:59:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:59:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:59:30 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:59:30 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:30 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:59:30 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-22 12:59:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:59:30 --> Final output sent to browser
DEBUG - 2014-02-22 12:59:30 --> Total execution time: 0.0676
DEBUG - 2014-02-22 12:59:33 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:59:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:59:33 --> URI Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Router Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Output Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Security Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Input Class Initialized
DEBUG - 2014-02-22 12:59:33 --> XSS Filtering completed
DEBUG - 2014-02-22 12:59:33 --> XSS Filtering completed
DEBUG - 2014-02-22 12:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:59:33 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Loader Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:59:33 --> Controller Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Session Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:59:33 --> Session routines successfully run
DEBUG - 2014-02-22 12:59:33 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:59:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:59:33 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:59:33 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:59:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:59:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:59:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:59:33 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:59:33 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:33 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:59:33 --> Final output sent to browser
DEBUG - 2014-02-22 12:59:33 --> Total execution time: 0.0667
DEBUG - 2014-02-22 12:59:37 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:59:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:59:37 --> URI Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Router Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Output Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Security Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Input Class Initialized
DEBUG - 2014-02-22 12:59:37 --> XSS Filtering completed
DEBUG - 2014-02-22 12:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:59:37 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Loader Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:59:37 --> Controller Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Session Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:59:37 --> Session routines successfully run
DEBUG - 2014-02-22 12:59:37 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:59:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:59:37 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:59:37 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:59:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:59:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:59:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:59:37 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:37 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:59:37 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:37 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:59:37 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 12:59:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:59:37 --> Final output sent to browser
DEBUG - 2014-02-22 12:59:37 --> Total execution time: 0.0583
DEBUG - 2014-02-22 12:59:48 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Hooks Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Utf8 Class Initialized
DEBUG - 2014-02-22 12:59:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 12:59:48 --> URI Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Router Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Output Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Security Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Input Class Initialized
DEBUG - 2014-02-22 12:59:48 --> XSS Filtering completed
DEBUG - 2014-02-22 12:59:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 12:59:48 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Language Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Config Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Loader Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: text_helper
DEBUG - 2014-02-22 12:59:48 --> Controller Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Session Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: string_helper
DEBUG - 2014-02-22 12:59:48 --> Session routines successfully run
DEBUG - 2014-02-22 12:59:48 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 12:59:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: url_helper
DEBUG - 2014-02-22 12:59:48 --> Database Driver Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: form_helper
DEBUG - 2014-02-22 12:59:48 --> Form Validation Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: number_helper
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: date_helper
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 12:59:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: language_helper
DEBUG - 2014-02-22 12:59:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 12:59:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 12:59:48 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 12:59:48 --> Model Class Initialized
DEBUG - 2014-02-22 12:59:48 --> Helper loaded: image_helper
DEBUG - 2014-02-22 12:59:48 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 12:59:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 12:59:48 --> Final output sent to browser
DEBUG - 2014-02-22 12:59:48 --> Total execution time: 0.0587
DEBUG - 2014-02-22 14:05:09 --> Config Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:05:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:05:09 --> URI Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Router Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Output Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Security Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Input Class Initialized
DEBUG - 2014-02-22 14:05:09 --> XSS Filtering completed
DEBUG - 2014-02-22 14:05:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:05:09 --> Language Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Language Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Config Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Loader Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:05:09 --> Controller Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Session Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:05:09 --> Session routines successfully run
DEBUG - 2014-02-22 14:05:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:05:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:05:09 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:05:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:05:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:05:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:05:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:05:09 --> Model Class Initialized
DEBUG - 2014-02-22 14:05:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:05:09 --> Model Class Initialized
DEBUG - 2014-02-22 14:05:09 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:05:09 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:05:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:05:09 --> Final output sent to browser
DEBUG - 2014-02-22 14:05:09 --> Total execution time: 0.0563
DEBUG - 2014-02-22 14:05:14 --> Config Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:05:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:05:14 --> URI Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Router Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Output Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Security Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Input Class Initialized
DEBUG - 2014-02-22 14:05:14 --> XSS Filtering completed
DEBUG - 2014-02-22 14:05:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:05:14 --> Language Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Language Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Config Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Loader Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:05:14 --> Controller Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Session Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:05:14 --> Session routines successfully run
DEBUG - 2014-02-22 14:05:14 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:05:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:05:14 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:05:14 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:05:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:05:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:05:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:05:14 --> Model Class Initialized
DEBUG - 2014-02-22 14:05:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:05:14 --> Model Class Initialized
DEBUG - 2014-02-22 14:05:14 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:05:14 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:05:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:05:14 --> Final output sent to browser
DEBUG - 2014-02-22 14:05:14 --> Total execution time: 0.0677
DEBUG - 2014-02-22 14:05:52 --> Config Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:05:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:05:52 --> URI Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Router Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Output Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Security Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Input Class Initialized
DEBUG - 2014-02-22 14:05:52 --> XSS Filtering completed
DEBUG - 2014-02-22 14:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:05:52 --> Language Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Language Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Config Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Loader Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:05:52 --> Controller Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Session Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:05:52 --> Session routines successfully run
DEBUG - 2014-02-22 14:05:52 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:05:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:05:52 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:05:52 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:05:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:05:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:05:52 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:05:52 --> Model Class Initialized
DEBUG - 2014-02-22 14:05:52 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:05:52 --> Model Class Initialized
DEBUG - 2014-02-22 14:05:52 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:05:52 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:05:52 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:05:52 --> Final output sent to browser
DEBUG - 2014-02-22 14:05:52 --> Total execution time: 0.0673
DEBUG - 2014-02-22 14:06:33 --> Config Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:06:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:06:33 --> URI Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Router Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Output Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Security Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Input Class Initialized
DEBUG - 2014-02-22 14:06:33 --> XSS Filtering completed
DEBUG - 2014-02-22 14:06:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:06:33 --> Language Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Language Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Config Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Loader Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:06:33 --> Controller Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Session Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:06:33 --> Session routines successfully run
DEBUG - 2014-02-22 14:06:33 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:06:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:06:33 --> Database Driver Class Initialized
ERROR - 2014-02-22 14:06:33 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:06:33 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:06:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:06:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:06:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:06:33 --> Model Class Initialized
DEBUG - 2014-02-22 14:06:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:06:33 --> Model Class Initialized
DEBUG - 2014-02-22 14:06:33 --> Helper loaded: image_helper
ERROR - 2014-02-22 14:06:33 --> Severity: Notice  --> Undefined variable: prescription_details D:\xampp\htdocs\tcms\application\modules\patient\views\edit_patient.php 95
ERROR - 2014-02-22 14:06:33 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\tcms\application\modules\patient\views\edit_patient.php 95
DEBUG - 2014-02-22 14:06:33 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:06:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:06:33 --> Final output sent to browser
DEBUG - 2014-02-22 14:06:33 --> Total execution time: 0.0565
DEBUG - 2014-02-22 14:06:50 --> Config Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:06:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:06:50 --> URI Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Router Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Output Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Security Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Input Class Initialized
DEBUG - 2014-02-22 14:06:50 --> XSS Filtering completed
DEBUG - 2014-02-22 14:06:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:06:50 --> Language Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Language Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Config Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Loader Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:06:50 --> Controller Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Session Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:06:50 --> Session routines successfully run
DEBUG - 2014-02-22 14:06:50 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:06:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:06:50 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:06:50 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:06:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:06:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:06:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:06:50 --> Model Class Initialized
DEBUG - 2014-02-22 14:06:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:06:50 --> Model Class Initialized
DEBUG - 2014-02-22 14:06:50 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:06:50 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:06:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:06:50 --> Final output sent to browser
DEBUG - 2014-02-22 14:06:50 --> Total execution time: 0.0530
DEBUG - 2014-02-22 14:07:21 --> Config Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:07:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:07:21 --> URI Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Router Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Output Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Security Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Input Class Initialized
DEBUG - 2014-02-22 14:07:21 --> XSS Filtering completed
DEBUG - 2014-02-22 14:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:07:21 --> Language Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Language Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Config Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Loader Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:07:21 --> Controller Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Session Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:07:21 --> Session routines successfully run
DEBUG - 2014-02-22 14:07:21 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:07:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:07:21 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:07:21 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:07:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:07:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:07:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:07:21 --> Model Class Initialized
DEBUG - 2014-02-22 14:07:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:07:21 --> Model Class Initialized
DEBUG - 2014-02-22 14:07:21 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:07:21 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:07:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:07:21 --> Final output sent to browser
DEBUG - 2014-02-22 14:07:21 --> Total execution time: 0.0561
DEBUG - 2014-02-22 14:10:30 --> Config Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:10:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:10:30 --> URI Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Router Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Output Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Security Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Input Class Initialized
DEBUG - 2014-02-22 14:10:30 --> XSS Filtering completed
DEBUG - 2014-02-22 14:10:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:10:30 --> Language Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Language Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Config Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Loader Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:10:30 --> Controller Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Session Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:10:30 --> Session routines successfully run
DEBUG - 2014-02-22 14:10:30 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:10:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:10:30 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:10:30 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:10:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:10:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:10:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:10:30 --> Model Class Initialized
DEBUG - 2014-02-22 14:10:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:10:30 --> Model Class Initialized
DEBUG - 2014-02-22 14:10:30 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:10:30 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:10:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:10:30 --> Final output sent to browser
DEBUG - 2014-02-22 14:10:30 --> Total execution time: 0.0660
DEBUG - 2014-02-22 14:16:26 --> Config Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:16:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:16:26 --> URI Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Router Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Output Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Security Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Input Class Initialized
DEBUG - 2014-02-22 14:16:26 --> XSS Filtering completed
DEBUG - 2014-02-22 14:16:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:16:26 --> Language Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Language Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Config Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Loader Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:16:26 --> Controller Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Session Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:16:26 --> Session routines successfully run
DEBUG - 2014-02-22 14:16:26 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:16:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:16:26 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:16:26 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:16:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:16:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:16:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:16:26 --> Model Class Initialized
DEBUG - 2014-02-22 14:16:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:16:26 --> Model Class Initialized
DEBUG - 2014-02-22 14:16:26 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:16:26 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:16:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:16:26 --> Final output sent to browser
DEBUG - 2014-02-22 14:16:26 --> Total execution time: 0.0692
DEBUG - 2014-02-22 14:17:55 --> Config Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:17:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:17:55 --> URI Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Router Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Output Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Security Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Input Class Initialized
DEBUG - 2014-02-22 14:17:55 --> XSS Filtering completed
DEBUG - 2014-02-22 14:17:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:17:55 --> Language Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Language Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Config Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Loader Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:17:55 --> Controller Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Session Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:17:55 --> Session routines successfully run
DEBUG - 2014-02-22 14:17:55 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:17:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:17:55 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:17:55 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:17:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:17:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:17:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:17:55 --> Model Class Initialized
DEBUG - 2014-02-22 14:17:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:17:55 --> Model Class Initialized
DEBUG - 2014-02-22 14:17:55 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:17:55 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:17:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:17:55 --> Final output sent to browser
DEBUG - 2014-02-22 14:17:55 --> Total execution time: 0.0542
DEBUG - 2014-02-22 14:44:41 --> Config Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:44:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:44:41 --> URI Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Router Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Output Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Security Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Input Class Initialized
DEBUG - 2014-02-22 14:44:41 --> XSS Filtering completed
DEBUG - 2014-02-22 14:44:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:44:41 --> Language Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Language Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Config Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Loader Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:44:41 --> Controller Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Session Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:44:41 --> Session routines successfully run
DEBUG - 2014-02-22 14:44:41 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:44:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:44:41 --> Database Driver Class Initialized
ERROR - 2014-02-22 14:44:41 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:44:41 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:44:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:44:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:44:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:44:41 --> Model Class Initialized
DEBUG - 2014-02-22 14:44:41 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:44:41 --> Model Class Initialized
DEBUG - 2014-02-22 14:44:41 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:44:41 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:44:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:44:41 --> Final output sent to browser
DEBUG - 2014-02-22 14:44:41 --> Total execution time: 0.0633
DEBUG - 2014-02-22 14:45:05 --> Config Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:45:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:45:05 --> URI Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Router Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Output Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Security Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Input Class Initialized
DEBUG - 2014-02-22 14:45:05 --> XSS Filtering completed
DEBUG - 2014-02-22 14:45:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:45:05 --> Language Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Language Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Config Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Loader Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:45:05 --> Controller Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Session Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:45:05 --> Session routines successfully run
DEBUG - 2014-02-22 14:45:05 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:45:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:45:05 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:45:05 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:45:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:45:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:45:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:45:05 --> Model Class Initialized
DEBUG - 2014-02-22 14:45:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:45:05 --> Model Class Initialized
DEBUG - 2014-02-22 14:45:05 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:45:05 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:45:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:45:05 --> Final output sent to browser
DEBUG - 2014-02-22 14:45:05 --> Total execution time: 0.0561
DEBUG - 2014-02-22 14:45:07 --> Config Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Hooks Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Utf8 Class Initialized
DEBUG - 2014-02-22 14:45:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 14:45:07 --> URI Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Router Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Output Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Security Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Input Class Initialized
DEBUG - 2014-02-22 14:45:07 --> XSS Filtering completed
DEBUG - 2014-02-22 14:45:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 14:45:07 --> Language Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Language Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Config Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Loader Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: text_helper
DEBUG - 2014-02-22 14:45:07 --> Controller Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Session Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: string_helper
DEBUG - 2014-02-22 14:45:07 --> Session routines successfully run
DEBUG - 2014-02-22 14:45:07 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 14:45:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: url_helper
DEBUG - 2014-02-22 14:45:07 --> Database Driver Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: form_helper
DEBUG - 2014-02-22 14:45:07 --> Form Validation Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: number_helper
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: date_helper
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 14:45:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: language_helper
DEBUG - 2014-02-22 14:45:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 14:45:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 14:45:07 --> Model Class Initialized
DEBUG - 2014-02-22 14:45:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 14:45:07 --> Model Class Initialized
DEBUG - 2014-02-22 14:45:07 --> Helper loaded: image_helper
DEBUG - 2014-02-22 14:45:07 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 14:45:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 14:45:07 --> Final output sent to browser
DEBUG - 2014-02-22 14:45:07 --> Total execution time: 0.0576
DEBUG - 2014-02-22 15:04:07 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Hooks Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Utf8 Class Initialized
DEBUG - 2014-02-22 15:04:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 15:04:07 --> URI Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Router Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Output Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Security Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Input Class Initialized
DEBUG - 2014-02-22 15:04:07 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 15:04:07 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Loader Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: text_helper
DEBUG - 2014-02-22 15:04:07 --> Controller Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Session Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: string_helper
DEBUG - 2014-02-22 15:04:07 --> A session cookie was not found.
DEBUG - 2014-02-22 15:04:07 --> Session routines successfully run
DEBUG - 2014-02-22 15:04:07 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 15:04:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: url_helper
DEBUG - 2014-02-22 15:04:07 --> Database Driver Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: form_helper
DEBUG - 2014-02-22 15:04:07 --> Form Validation Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: number_helper
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: date_helper
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 15:04:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: language_helper
DEBUG - 2014-02-22 15:04:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 15:04:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 15:04:07 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Hooks Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Utf8 Class Initialized
DEBUG - 2014-02-22 15:04:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 15:04:07 --> URI Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Router Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Output Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Security Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Input Class Initialized
DEBUG - 2014-02-22 15:04:07 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:07 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 15:04:07 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Loader Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: text_helper
DEBUG - 2014-02-22 15:04:07 --> Controller Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-22 15:04:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 15:04:07 --> Session Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: string_helper
DEBUG - 2014-02-22 15:04:07 --> Session routines successfully run
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: url_helper
DEBUG - 2014-02-22 15:04:07 --> Database Driver Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: form_helper
DEBUG - 2014-02-22 15:04:07 --> Form Validation Class Initialized
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: number_helper
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: date_helper
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 15:04:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 15:04:07 --> Helper loaded: language_helper
DEBUG - 2014-02-22 15:04:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 15:04:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 15:04:07 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-22 15:04:07 --> Final output sent to browser
DEBUG - 2014-02-22 15:04:07 --> Total execution time: 0.0577
DEBUG - 2014-02-22 15:04:26 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Hooks Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Utf8 Class Initialized
DEBUG - 2014-02-22 15:04:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 15:04:26 --> URI Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Router Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Output Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Security Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Input Class Initialized
DEBUG - 2014-02-22 15:04:26 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:26 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:26 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:26 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:26 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 15:04:26 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Loader Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: text_helper
DEBUG - 2014-02-22 15:04:26 --> Controller Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-22 15:04:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 15:04:26 --> Session Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: string_helper
DEBUG - 2014-02-22 15:04:26 --> Session routines successfully run
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: url_helper
DEBUG - 2014-02-22 15:04:26 --> Database Driver Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: form_helper
DEBUG - 2014-02-22 15:04:26 --> Form Validation Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: number_helper
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: date_helper
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 15:04:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: language_helper
DEBUG - 2014-02-22 15:04:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 15:04:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 15:04:26 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:26 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-22 15:04:26 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Hooks Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Utf8 Class Initialized
DEBUG - 2014-02-22 15:04:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 15:04:26 --> URI Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Router Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Output Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Security Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Input Class Initialized
DEBUG - 2014-02-22 15:04:26 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:26 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 15:04:26 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Loader Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: text_helper
DEBUG - 2014-02-22 15:04:26 --> Controller Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Session Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: string_helper
DEBUG - 2014-02-22 15:04:26 --> Session routines successfully run
DEBUG - 2014-02-22 15:04:26 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 15:04:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: url_helper
DEBUG - 2014-02-22 15:04:26 --> Database Driver Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: form_helper
DEBUG - 2014-02-22 15:04:26 --> Form Validation Class Initialized
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: number_helper
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: date_helper
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 15:04:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 15:04:26 --> Helper loaded: language_helper
DEBUG - 2014-02-22 15:04:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 15:04:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 15:04:26 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:26 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 15:04:26 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 15:04:26 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:26 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 15:04:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 15:04:26 --> Final output sent to browser
DEBUG - 2014-02-22 15:04:26 --> Total execution time: 0.0615
DEBUG - 2014-02-22 15:04:37 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Hooks Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Utf8 Class Initialized
DEBUG - 2014-02-22 15:04:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 15:04:37 --> URI Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Router Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Output Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Security Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Input Class Initialized
DEBUG - 2014-02-22 15:04:37 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:37 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 15:04:37 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Loader Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: text_helper
DEBUG - 2014-02-22 15:04:37 --> Controller Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Session Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: string_helper
DEBUG - 2014-02-22 15:04:37 --> Session routines successfully run
DEBUG - 2014-02-22 15:04:37 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 15:04:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: url_helper
DEBUG - 2014-02-22 15:04:37 --> Database Driver Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: form_helper
DEBUG - 2014-02-22 15:04:37 --> Form Validation Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: number_helper
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: date_helper
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 15:04:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: language_helper
DEBUG - 2014-02-22 15:04:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 15:04:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 15:04:37 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:37 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 15:04:37 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:37 --> Helper loaded: image_helper
DEBUG - 2014-02-22 15:04:37 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-22 15:04:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 15:04:37 --> Final output sent to browser
DEBUG - 2014-02-22 15:04:37 --> Total execution time: 0.0611
DEBUG - 2014-02-22 15:04:42 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Hooks Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Utf8 Class Initialized
DEBUG - 2014-02-22 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 15:04:42 --> URI Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Router Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Output Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Security Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Input Class Initialized
DEBUG - 2014-02-22 15:04:42 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:42 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 15:04:42 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Loader Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: text_helper
DEBUG - 2014-02-22 15:04:42 --> Controller Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Session Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: string_helper
DEBUG - 2014-02-22 15:04:42 --> Session routines successfully run
DEBUG - 2014-02-22 15:04:42 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 15:04:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: url_helper
DEBUG - 2014-02-22 15:04:42 --> Database Driver Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: form_helper
DEBUG - 2014-02-22 15:04:42 --> Form Validation Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: number_helper
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: date_helper
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 15:04:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: language_helper
DEBUG - 2014-02-22 15:04:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 15:04:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 15:04:42 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 15:04:42 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:42 --> Helper loaded: image_helper
DEBUG - 2014-02-22 15:04:42 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 15:04:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 15:04:42 --> Final output sent to browser
DEBUG - 2014-02-22 15:04:42 --> Total execution time: 0.0630
DEBUG - 2014-02-22 15:04:48 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Hooks Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Utf8 Class Initialized
DEBUG - 2014-02-22 15:04:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 15:04:48 --> URI Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Router Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Output Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Security Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Input Class Initialized
DEBUG - 2014-02-22 15:04:48 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:48 --> XSS Filtering completed
DEBUG - 2014-02-22 15:04:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 15:04:48 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Language Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Config Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Loader Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: text_helper
DEBUG - 2014-02-22 15:04:48 --> Controller Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Session Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: string_helper
DEBUG - 2014-02-22 15:04:48 --> Session routines successfully run
DEBUG - 2014-02-22 15:04:48 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 15:04:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: url_helper
DEBUG - 2014-02-22 15:04:48 --> Database Driver Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: form_helper
DEBUG - 2014-02-22 15:04:48 --> Form Validation Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: number_helper
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: date_helper
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 15:04:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: language_helper
DEBUG - 2014-02-22 15:04:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 15:04:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 15:04:48 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 15:04:48 --> Model Class Initialized
DEBUG - 2014-02-22 15:04:48 --> Helper loaded: image_helper
DEBUG - 2014-02-22 15:04:48 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 15:04:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 15:04:48 --> Final output sent to browser
DEBUG - 2014-02-22 15:04:48 --> Total execution time: 0.0666
DEBUG - 2014-02-22 15:25:30 --> Config Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Hooks Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Utf8 Class Initialized
DEBUG - 2014-02-22 15:25:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 15:25:30 --> URI Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Router Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Output Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Security Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Input Class Initialized
DEBUG - 2014-02-22 15:25:30 --> XSS Filtering completed
DEBUG - 2014-02-22 15:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 15:25:30 --> Language Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Language Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Config Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Loader Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: text_helper
DEBUG - 2014-02-22 15:25:30 --> Controller Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Session Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: string_helper
DEBUG - 2014-02-22 15:25:30 --> Session routines successfully run
DEBUG - 2014-02-22 15:25:30 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 15:25:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: url_helper
DEBUG - 2014-02-22 15:25:30 --> Database Driver Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: form_helper
DEBUG - 2014-02-22 15:25:30 --> Form Validation Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: number_helper
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: date_helper
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 15:25:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: language_helper
DEBUG - 2014-02-22 15:25:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 15:25:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 15:25:30 --> Model Class Initialized
DEBUG - 2014-02-22 15:25:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 15:25:30 --> Model Class Initialized
DEBUG - 2014-02-22 15:25:30 --> Helper loaded: image_helper
DEBUG - 2014-02-22 15:25:30 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 15:25:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 15:25:30 --> Final output sent to browser
DEBUG - 2014-02-22 15:25:30 --> Total execution time: 0.0534
DEBUG - 2014-02-22 17:12:56 --> Config Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:12:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:12:56 --> URI Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Router Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Output Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Security Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Input Class Initialized
DEBUG - 2014-02-22 17:12:56 --> XSS Filtering completed
DEBUG - 2014-02-22 17:12:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:12:56 --> Language Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Language Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Config Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Loader Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:12:56 --> Controller Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Session Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:12:56 --> Session routines successfully run
DEBUG - 2014-02-22 17:12:56 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:12:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:12:56 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:12:56 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:12:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:12:56 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:12:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:12:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:12:56 --> Model Class Initialized
DEBUG - 2014-02-22 17:12:56 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:12:56 --> Model Class Initialized
DEBUG - 2014-02-22 17:12:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:12:56 --> Model Class Initialized
DEBUG - 2014-02-22 17:12:56 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:12:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:12:56 --> Final output sent to browser
DEBUG - 2014-02-22 17:12:56 --> Total execution time: 0.0551
DEBUG - 2014-02-22 17:47:20 --> Config Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:47:20 --> URI Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Router Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Output Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Security Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Input Class Initialized
DEBUG - 2014-02-22 17:47:20 --> XSS Filtering completed
DEBUG - 2014-02-22 17:47:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:47:20 --> Language Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Language Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Config Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Loader Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:47:20 --> Controller Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Session Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:47:20 --> Session routines successfully run
DEBUG - 2014-02-22 17:47:20 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:47:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:47:20 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:47:20 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:47:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:47:20 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:47:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:47:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:47:20 --> Model Class Initialized
DEBUG - 2014-02-22 17:47:20 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:47:20 --> Model Class Initialized
DEBUG - 2014-02-22 17:47:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:47:20 --> Model Class Initialized
DEBUG - 2014-02-22 17:47:20 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:47:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:47:20 --> Final output sent to browser
DEBUG - 2014-02-22 17:47:20 --> Total execution time: 0.0679
DEBUG - 2014-02-22 17:48:45 --> Config Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:48:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:48:45 --> URI Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Router Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Output Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Security Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Input Class Initialized
DEBUG - 2014-02-22 17:48:45 --> XSS Filtering completed
DEBUG - 2014-02-22 17:48:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:48:45 --> Language Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Language Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Config Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Loader Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:48:45 --> Controller Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Session Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:48:45 --> Session routines successfully run
DEBUG - 2014-02-22 17:48:45 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:48:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:48:45 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:48:45 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:48:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:48:45 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:48:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:48:45 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:48:45 --> Model Class Initialized
DEBUG - 2014-02-22 17:48:45 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:48:45 --> Model Class Initialized
DEBUG - 2014-02-22 17:48:45 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:48:45 --> Model Class Initialized
DEBUG - 2014-02-22 17:48:45 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:48:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:48:45 --> Final output sent to browser
DEBUG - 2014-02-22 17:48:45 --> Total execution time: 0.0570
DEBUG - 2014-02-22 17:49:47 --> Config Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:49:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:49:47 --> URI Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Router Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Output Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Security Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Input Class Initialized
DEBUG - 2014-02-22 17:49:47 --> XSS Filtering completed
DEBUG - 2014-02-22 17:49:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:49:47 --> Language Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Language Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Config Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Loader Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:49:47 --> Controller Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Session Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:49:47 --> Session routines successfully run
DEBUG - 2014-02-22 17:49:47 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:49:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:49:47 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:49:47 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:49:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:49:47 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:49:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:49:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:49:47 --> Model Class Initialized
DEBUG - 2014-02-22 17:49:47 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:49:47 --> Model Class Initialized
DEBUG - 2014-02-22 17:49:47 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:49:47 --> Model Class Initialized
DEBUG - 2014-02-22 17:49:47 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:49:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:49:47 --> Final output sent to browser
DEBUG - 2014-02-22 17:49:47 --> Total execution time: 0.0593
DEBUG - 2014-02-22 17:50:46 --> Config Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:50:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:50:46 --> URI Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Router Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Output Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Security Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Input Class Initialized
DEBUG - 2014-02-22 17:50:46 --> XSS Filtering completed
DEBUG - 2014-02-22 17:50:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:50:46 --> Language Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Language Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Config Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Loader Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:50:46 --> Controller Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Session Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:50:46 --> Session routines successfully run
DEBUG - 2014-02-22 17:50:46 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:50:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:50:46 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:50:46 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:50:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:50:46 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:50:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:50:46 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:50:46 --> Model Class Initialized
DEBUG - 2014-02-22 17:50:46 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:50:46 --> Model Class Initialized
DEBUG - 2014-02-22 17:50:46 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:50:46 --> Model Class Initialized
DEBUG - 2014-02-22 17:50:46 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:50:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:50:46 --> Final output sent to browser
DEBUG - 2014-02-22 17:50:46 --> Total execution time: 0.0549
DEBUG - 2014-02-22 17:51:31 --> Config Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:51:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:51:31 --> URI Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Router Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Output Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Security Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Input Class Initialized
DEBUG - 2014-02-22 17:51:31 --> XSS Filtering completed
DEBUG - 2014-02-22 17:51:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:51:31 --> Language Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Language Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Config Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Loader Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:51:31 --> Controller Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Session Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:51:31 --> Session routines successfully run
DEBUG - 2014-02-22 17:51:31 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:51:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:51:31 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:51:31 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:51:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:51:31 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:51:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:51:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:51:31 --> Model Class Initialized
DEBUG - 2014-02-22 17:51:31 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:51:31 --> Model Class Initialized
DEBUG - 2014-02-22 17:51:31 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:51:31 --> Model Class Initialized
DEBUG - 2014-02-22 17:51:31 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:51:31 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:51:31 --> Final output sent to browser
DEBUG - 2014-02-22 17:51:31 --> Total execution time: 0.0602
DEBUG - 2014-02-22 17:51:34 --> Config Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:51:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:51:34 --> URI Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Router Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Output Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Security Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Input Class Initialized
DEBUG - 2014-02-22 17:51:34 --> XSS Filtering completed
DEBUG - 2014-02-22 17:51:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:51:34 --> Language Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Language Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Config Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Loader Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:51:34 --> Controller Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Session Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:51:34 --> Session routines successfully run
DEBUG - 2014-02-22 17:51:34 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:51:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:51:34 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:51:34 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:51:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:51:34 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:51:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:51:34 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:51:34 --> Model Class Initialized
DEBUG - 2014-02-22 17:51:34 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:51:34 --> Model Class Initialized
DEBUG - 2014-02-22 17:51:34 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:51:34 --> Model Class Initialized
DEBUG - 2014-02-22 17:51:34 --> File loaded: application/modules/dashboard/views/add_notice.php
DEBUG - 2014-02-22 17:51:34 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:51:34 --> Final output sent to browser
DEBUG - 2014-02-22 17:51:34 --> Total execution time: 0.0576
DEBUG - 2014-02-22 17:53:09 --> Config Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:53:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:53:09 --> URI Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Router Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Output Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Security Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Input Class Initialized
DEBUG - 2014-02-22 17:53:09 --> XSS Filtering completed
DEBUG - 2014-02-22 17:53:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:53:09 --> Language Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Language Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Config Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Loader Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:53:09 --> Controller Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Session Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:53:09 --> Session routines successfully run
DEBUG - 2014-02-22 17:53:09 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:53:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:53:09 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:53:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:53:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:53:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:53:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:53:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:53:09 --> Model Class Initialized
DEBUG - 2014-02-22 17:53:09 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:53:09 --> Model Class Initialized
DEBUG - 2014-02-22 17:53:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:53:09 --> Model Class Initialized
DEBUG - 2014-02-22 17:53:09 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:53:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:53:09 --> Final output sent to browser
DEBUG - 2014-02-22 17:53:09 --> Total execution time: 0.0551
DEBUG - 2014-02-22 17:54:31 --> Config Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:54:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:54:31 --> URI Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Router Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Output Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Security Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Input Class Initialized
DEBUG - 2014-02-22 17:54:31 --> XSS Filtering completed
DEBUG - 2014-02-22 17:54:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:54:31 --> Language Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Language Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Config Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Loader Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:54:31 --> Controller Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Session Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:54:31 --> Session routines successfully run
DEBUG - 2014-02-22 17:54:31 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:54:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:54:31 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:54:31 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:54:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:54:31 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:54:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:54:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:54:31 --> Model Class Initialized
DEBUG - 2014-02-22 17:54:31 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:54:31 --> Model Class Initialized
DEBUG - 2014-02-22 17:54:31 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:54:31 --> Model Class Initialized
DEBUG - 2014-02-22 17:54:31 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:54:31 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:54:31 --> Final output sent to browser
DEBUG - 2014-02-22 17:54:31 --> Total execution time: 0.0574
DEBUG - 2014-02-22 17:56:02 --> Config Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:56:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:56:02 --> URI Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Router Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Output Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Security Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Input Class Initialized
DEBUG - 2014-02-22 17:56:02 --> XSS Filtering completed
DEBUG - 2014-02-22 17:56:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:56:02 --> Language Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Language Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Config Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Loader Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:56:02 --> Controller Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Session Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:56:02 --> Session routines successfully run
DEBUG - 2014-02-22 17:56:02 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:56:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:56:02 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:56:02 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:56:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:56:02 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:56:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:56:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:56:02 --> Model Class Initialized
DEBUG - 2014-02-22 17:56:02 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:56:02 --> Model Class Initialized
DEBUG - 2014-02-22 17:56:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:56:02 --> Model Class Initialized
DEBUG - 2014-02-22 17:56:02 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:56:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:56:02 --> Final output sent to browser
DEBUG - 2014-02-22 17:56:02 --> Total execution time: 0.0420
DEBUG - 2014-02-22 17:56:02 --> Config Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:56:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:56:02 --> URI Class Initialized
DEBUG - 2014-02-22 17:56:02 --> Router Class Initialized
ERROR - 2014-02-22 17:56:02 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 17:56:03 --> Config Class Initialized
DEBUG - 2014-02-22 17:56:03 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:56:03 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:56:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:56:03 --> URI Class Initialized
DEBUG - 2014-02-22 17:56:03 --> Router Class Initialized
ERROR - 2014-02-22 17:56:03 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 17:57:14 --> Config Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:57:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:57:14 --> URI Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Router Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Output Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Security Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Input Class Initialized
DEBUG - 2014-02-22 17:57:14 --> XSS Filtering completed
DEBUG - 2014-02-22 17:57:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:57:14 --> Language Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Language Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Config Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Loader Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:57:14 --> Controller Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Session Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:57:14 --> Session routines successfully run
DEBUG - 2014-02-22 17:57:14 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:57:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:57:14 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:57:14 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:57:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:57:14 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:57:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:57:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:57:14 --> Model Class Initialized
DEBUG - 2014-02-22 17:57:14 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:57:14 --> Model Class Initialized
DEBUG - 2014-02-22 17:57:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:57:14 --> Model Class Initialized
DEBUG - 2014-02-22 17:57:14 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:57:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:57:14 --> Final output sent to browser
DEBUG - 2014-02-22 17:57:14 --> Total execution time: 0.0537
DEBUG - 2014-02-22 17:57:58 --> Config Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:57:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:57:58 --> URI Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Router Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Output Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Security Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Input Class Initialized
DEBUG - 2014-02-22 17:57:58 --> XSS Filtering completed
DEBUG - 2014-02-22 17:57:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:57:58 --> Language Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Language Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Config Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Loader Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:57:58 --> Controller Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Session Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:57:58 --> Session routines successfully run
DEBUG - 2014-02-22 17:57:58 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:57:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:57:58 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:57:58 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:57:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:57:58 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:57:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:57:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:57:58 --> Model Class Initialized
DEBUG - 2014-02-22 17:57:58 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:57:58 --> Model Class Initialized
DEBUG - 2014-02-22 17:57:58 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:57:58 --> Model Class Initialized
DEBUG - 2014-02-22 17:57:58 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:57:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:57:58 --> Final output sent to browser
DEBUG - 2014-02-22 17:57:58 --> Total execution time: 0.0604
DEBUG - 2014-02-22 17:57:59 --> Config Class Initialized
DEBUG - 2014-02-22 17:57:59 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:57:59 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:57:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:57:59 --> URI Class Initialized
DEBUG - 2014-02-22 17:57:59 --> Router Class Initialized
ERROR - 2014-02-22 17:57:59 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 17:58:00 --> Config Class Initialized
DEBUG - 2014-02-22 17:58:00 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:58:00 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:58:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:58:00 --> URI Class Initialized
DEBUG - 2014-02-22 17:58:00 --> Router Class Initialized
ERROR - 2014-02-22 17:58:00 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 17:59:40 --> Config Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:59:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:59:40 --> URI Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Router Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Output Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Security Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Input Class Initialized
DEBUG - 2014-02-22 17:59:40 --> XSS Filtering completed
DEBUG - 2014-02-22 17:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 17:59:40 --> Language Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Language Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Config Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Loader Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: text_helper
DEBUG - 2014-02-22 17:59:40 --> Controller Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Session Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: string_helper
DEBUG - 2014-02-22 17:59:40 --> Session routines successfully run
DEBUG - 2014-02-22 17:59:40 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 17:59:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: url_helper
DEBUG - 2014-02-22 17:59:40 --> Database Driver Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: form_helper
DEBUG - 2014-02-22 17:59:40 --> Form Validation Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: number_helper
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: date_helper
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 17:59:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 17:59:40 --> Helper loaded: language_helper
DEBUG - 2014-02-22 17:59:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 17:59:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 17:59:40 --> Model Class Initialized
DEBUG - 2014-02-22 17:59:40 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 17:59:40 --> Model Class Initialized
DEBUG - 2014-02-22 17:59:40 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 17:59:40 --> Model Class Initialized
DEBUG - 2014-02-22 17:59:40 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 17:59:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 17:59:40 --> Final output sent to browser
DEBUG - 2014-02-22 17:59:40 --> Total execution time: 0.0649
DEBUG - 2014-02-22 17:59:40 --> Config Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:59:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:59:40 --> URI Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Router Class Initialized
ERROR - 2014-02-22 17:59:40 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 17:59:40 --> Config Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Hooks Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Utf8 Class Initialized
DEBUG - 2014-02-22 17:59:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 17:59:40 --> URI Class Initialized
DEBUG - 2014-02-22 17:59:40 --> Router Class Initialized
ERROR - 2014-02-22 17:59:40 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 18:00:01 --> Config Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:00:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:00:01 --> URI Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Router Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Output Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Security Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Input Class Initialized
DEBUG - 2014-02-22 18:00:01 --> XSS Filtering completed
DEBUG - 2014-02-22 18:00:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:00:01 --> Language Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Language Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Config Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Loader Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:00:01 --> Controller Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Session Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:00:01 --> Session routines successfully run
DEBUG - 2014-02-22 18:00:01 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:00:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:00:01 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:00:01 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:00:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:00:01 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:00:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:00:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:00:01 --> Model Class Initialized
DEBUG - 2014-02-22 18:00:01 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:00:01 --> Model Class Initialized
DEBUG - 2014-02-22 18:00:01 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:00:01 --> Model Class Initialized
DEBUG - 2014-02-22 18:00:01 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:00:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:00:01 --> Final output sent to browser
DEBUG - 2014-02-22 18:00:01 --> Total execution time: 0.0580
DEBUG - 2014-02-22 18:00:01 --> Config Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:00:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:00:01 --> URI Class Initialized
DEBUG - 2014-02-22 18:00:01 --> Router Class Initialized
ERROR - 2014-02-22 18:00:01 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 18:00:02 --> Config Class Initialized
DEBUG - 2014-02-22 18:00:02 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:00:02 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:00:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:00:02 --> URI Class Initialized
DEBUG - 2014-02-22 18:00:02 --> Router Class Initialized
ERROR - 2014-02-22 18:00:02 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 18:01:06 --> Config Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:01:06 --> URI Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Router Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Output Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Security Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Input Class Initialized
DEBUG - 2014-02-22 18:01:06 --> XSS Filtering completed
DEBUG - 2014-02-22 18:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:01:06 --> Language Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Language Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Config Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Loader Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:01:06 --> Controller Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Session Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:01:06 --> Session routines successfully run
DEBUG - 2014-02-22 18:01:06 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:01:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:01:06 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:01:06 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:01:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:01:06 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:01:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:01:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:01:06 --> Model Class Initialized
DEBUG - 2014-02-22 18:01:06 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:01:06 --> Model Class Initialized
DEBUG - 2014-02-22 18:01:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:01:06 --> Model Class Initialized
DEBUG - 2014-02-22 18:01:06 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:01:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:01:06 --> Final output sent to browser
DEBUG - 2014-02-22 18:01:06 --> Total execution time: 0.0510
DEBUG - 2014-02-22 18:01:06 --> Config Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:01:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:01:06 --> URI Class Initialized
DEBUG - 2014-02-22 18:01:06 --> Router Class Initialized
ERROR - 2014-02-22 18:01:06 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 18:01:07 --> Config Class Initialized
DEBUG - 2014-02-22 18:01:07 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:01:07 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:01:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:01:07 --> URI Class Initialized
DEBUG - 2014-02-22 18:01:07 --> Router Class Initialized
ERROR - 2014-02-22 18:01:07 --> 404 Page Not Found --> 
DEBUG - 2014-02-22 18:02:12 --> Config Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:02:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:02:12 --> URI Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Router Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Output Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Security Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Input Class Initialized
DEBUG - 2014-02-22 18:02:12 --> XSS Filtering completed
DEBUG - 2014-02-22 18:02:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:02:12 --> Language Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Language Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Config Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Loader Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:02:12 --> Controller Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Session Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:02:12 --> Session routines successfully run
DEBUG - 2014-02-22 18:02:12 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:02:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:02:12 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:02:12 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:02:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:02:12 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:02:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:02:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:02:12 --> Model Class Initialized
DEBUG - 2014-02-22 18:02:12 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:02:12 --> Model Class Initialized
DEBUG - 2014-02-22 18:02:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:02:12 --> Model Class Initialized
DEBUG - 2014-02-22 18:02:12 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:02:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:02:12 --> Final output sent to browser
DEBUG - 2014-02-22 18:02:12 --> Total execution time: 0.0560
DEBUG - 2014-02-22 18:04:22 --> Config Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:04:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:04:22 --> URI Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Router Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Output Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Security Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Input Class Initialized
DEBUG - 2014-02-22 18:04:22 --> XSS Filtering completed
DEBUG - 2014-02-22 18:04:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:04:22 --> Language Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Language Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Config Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Loader Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:04:22 --> Controller Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Session Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:04:22 --> Session routines successfully run
DEBUG - 2014-02-22 18:04:22 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:04:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:04:22 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:04:22 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:04:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:04:22 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:04:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:04:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:04:22 --> Model Class Initialized
DEBUG - 2014-02-22 18:04:22 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:04:22 --> Model Class Initialized
DEBUG - 2014-02-22 18:04:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:04:22 --> Model Class Initialized
DEBUG - 2014-02-22 18:04:22 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:04:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:04:22 --> Final output sent to browser
DEBUG - 2014-02-22 18:04:22 --> Total execution time: 0.0629
DEBUG - 2014-02-22 18:14:53 --> Config Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:14:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:14:53 --> URI Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Router Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Output Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Security Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Input Class Initialized
DEBUG - 2014-02-22 18:14:53 --> XSS Filtering completed
DEBUG - 2014-02-22 18:14:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:14:53 --> Language Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Language Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Config Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Loader Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:14:53 --> Controller Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Session Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:14:53 --> Session routines successfully run
DEBUG - 2014-02-22 18:14:53 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:14:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:14:53 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:14:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:14:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:14:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:14:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:14:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:14:53 --> Model Class Initialized
DEBUG - 2014-02-22 18:14:53 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:14:53 --> Model Class Initialized
DEBUG - 2014-02-22 18:14:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:14:53 --> Model Class Initialized
DEBUG - 2014-02-22 18:14:53 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:14:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:14:53 --> Final output sent to browser
DEBUG - 2014-02-22 18:14:53 --> Total execution time: 0.0536
DEBUG - 2014-02-22 18:15:47 --> Config Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:15:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:15:47 --> URI Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Router Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Output Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Security Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Input Class Initialized
DEBUG - 2014-02-22 18:15:47 --> XSS Filtering completed
DEBUG - 2014-02-22 18:15:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:15:47 --> Language Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Language Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Config Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Loader Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:15:47 --> Controller Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Session Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:15:47 --> Session routines successfully run
DEBUG - 2014-02-22 18:15:47 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:15:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:15:47 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:15:47 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:15:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:15:47 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:15:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:15:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:15:47 --> Model Class Initialized
DEBUG - 2014-02-22 18:15:47 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:15:47 --> Model Class Initialized
DEBUG - 2014-02-22 18:15:47 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:15:47 --> Model Class Initialized
DEBUG - 2014-02-22 18:15:47 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:15:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:15:47 --> Final output sent to browser
DEBUG - 2014-02-22 18:15:47 --> Total execution time: 0.0530
DEBUG - 2014-02-22 18:16:18 --> Config Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:16:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:16:18 --> URI Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Router Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Output Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Security Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Input Class Initialized
DEBUG - 2014-02-22 18:16:18 --> XSS Filtering completed
DEBUG - 2014-02-22 18:16:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:16:18 --> Language Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Language Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Config Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Loader Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:16:18 --> Controller Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Session Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:16:18 --> Session routines successfully run
DEBUG - 2014-02-22 18:16:18 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:16:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:16:18 --> Database Driver Class Initialized
ERROR - 2014-02-22 18:16:18 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:16:18 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:16:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:16:18 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:16:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:16:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:16:18 --> Model Class Initialized
DEBUG - 2014-02-22 18:16:18 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:16:18 --> Model Class Initialized
DEBUG - 2014-02-22 18:16:18 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:16:18 --> Model Class Initialized
DEBUG - 2014-02-22 18:16:18 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:16:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:16:18 --> Final output sent to browser
DEBUG - 2014-02-22 18:16:18 --> Total execution time: 0.0645
DEBUG - 2014-02-22 18:17:10 --> Config Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:17:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:17:10 --> URI Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Router Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Output Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Security Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Input Class Initialized
DEBUG - 2014-02-22 18:17:10 --> XSS Filtering completed
DEBUG - 2014-02-22 18:17:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:17:10 --> Language Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Language Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Config Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Loader Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:17:10 --> Controller Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Session Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:17:10 --> Session routines successfully run
DEBUG - 2014-02-22 18:17:10 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:17:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:17:10 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:17:10 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:17:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:17:10 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:17:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:17:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:17:10 --> Model Class Initialized
DEBUG - 2014-02-22 18:17:10 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:17:10 --> Model Class Initialized
DEBUG - 2014-02-22 18:17:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:17:10 --> Model Class Initialized
DEBUG - 2014-02-22 18:17:10 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:17:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:17:10 --> Final output sent to browser
DEBUG - 2014-02-22 18:17:10 --> Total execution time: 0.0539
DEBUG - 2014-02-22 18:18:15 --> Config Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:18:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:18:15 --> URI Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Router Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Output Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Security Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Input Class Initialized
DEBUG - 2014-02-22 18:18:15 --> XSS Filtering completed
DEBUG - 2014-02-22 18:18:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:18:15 --> Language Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Language Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Config Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Loader Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:18:15 --> Controller Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Session Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:18:15 --> Session routines successfully run
DEBUG - 2014-02-22 18:18:15 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:18:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:18:15 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:18:15 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:18:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:18:15 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:18:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:18:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:18:15 --> Model Class Initialized
DEBUG - 2014-02-22 18:18:15 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:18:15 --> Model Class Initialized
DEBUG - 2014-02-22 18:18:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:18:15 --> Model Class Initialized
DEBUG - 2014-02-22 18:18:15 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:18:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:18:15 --> Final output sent to browser
DEBUG - 2014-02-22 18:18:15 --> Total execution time: 0.0597
DEBUG - 2014-02-22 18:21:25 --> Config Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:21:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:21:25 --> URI Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Router Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Output Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Security Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Input Class Initialized
DEBUG - 2014-02-22 18:21:25 --> XSS Filtering completed
DEBUG - 2014-02-22 18:21:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:21:25 --> Language Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Language Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Config Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Loader Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:21:25 --> Controller Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Session Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:21:25 --> Session routines successfully run
DEBUG - 2014-02-22 18:21:25 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:21:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:21:25 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:21:25 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:21:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:21:25 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:21:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:21:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:21:25 --> Model Class Initialized
DEBUG - 2014-02-22 18:21:25 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:21:25 --> Model Class Initialized
DEBUG - 2014-02-22 18:21:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:21:25 --> Model Class Initialized
DEBUG - 2014-02-22 18:21:25 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:21:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:21:25 --> Final output sent to browser
DEBUG - 2014-02-22 18:21:25 --> Total execution time: 0.0528
DEBUG - 2014-02-22 18:24:12 --> Config Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:24:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:24:12 --> URI Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Router Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Output Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Security Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Input Class Initialized
DEBUG - 2014-02-22 18:24:12 --> XSS Filtering completed
DEBUG - 2014-02-22 18:24:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:24:12 --> Language Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Language Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Config Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Loader Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:24:12 --> Controller Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Session Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:24:12 --> Session routines successfully run
DEBUG - 2014-02-22 18:24:12 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:24:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:24:12 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:24:12 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:24:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:24:12 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:24:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:24:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:24:12 --> Model Class Initialized
DEBUG - 2014-02-22 18:24:12 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:24:12 --> Model Class Initialized
DEBUG - 2014-02-22 18:24:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:24:12 --> Model Class Initialized
DEBUG - 2014-02-22 18:24:12 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:24:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:24:12 --> Final output sent to browser
DEBUG - 2014-02-22 18:24:12 --> Total execution time: 0.0574
DEBUG - 2014-02-22 18:24:58 --> Config Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:24:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:24:58 --> URI Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Router Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Output Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Security Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Input Class Initialized
DEBUG - 2014-02-22 18:24:58 --> XSS Filtering completed
DEBUG - 2014-02-22 18:24:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:24:58 --> Language Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Language Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Config Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Loader Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:24:58 --> Controller Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Session Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:24:58 --> Session routines successfully run
DEBUG - 2014-02-22 18:24:58 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:24:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:24:58 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:24:58 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:24:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:24:58 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:24:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:24:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:24:58 --> Model Class Initialized
DEBUG - 2014-02-22 18:24:58 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:24:58 --> Model Class Initialized
DEBUG - 2014-02-22 18:24:58 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:24:58 --> Model Class Initialized
DEBUG - 2014-02-22 18:24:58 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:24:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:24:58 --> Final output sent to browser
DEBUG - 2014-02-22 18:24:58 --> Total execution time: 0.0547
DEBUG - 2014-02-22 18:26:04 --> Config Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:26:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:26:04 --> URI Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Router Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Output Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Security Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Input Class Initialized
DEBUG - 2014-02-22 18:26:04 --> XSS Filtering completed
DEBUG - 2014-02-22 18:26:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:26:04 --> Language Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Language Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Config Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Loader Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:26:04 --> Controller Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Session Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:26:04 --> Session routines successfully run
DEBUG - 2014-02-22 18:26:04 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:26:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:26:04 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:26:04 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:26:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:26:04 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:26:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:26:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:26:04 --> Model Class Initialized
DEBUG - 2014-02-22 18:26:04 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:26:04 --> Model Class Initialized
DEBUG - 2014-02-22 18:26:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:26:04 --> Model Class Initialized
DEBUG - 2014-02-22 18:26:04 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:26:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:26:04 --> Final output sent to browser
DEBUG - 2014-02-22 18:26:04 --> Total execution time: 0.0701
DEBUG - 2014-02-22 18:26:39 --> Config Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:26:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:26:39 --> URI Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Router Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Output Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Security Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Input Class Initialized
DEBUG - 2014-02-22 18:26:39 --> XSS Filtering completed
DEBUG - 2014-02-22 18:26:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:26:39 --> Language Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Language Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Config Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Loader Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:26:39 --> Controller Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Session Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:26:39 --> Session routines successfully run
DEBUG - 2014-02-22 18:26:39 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:26:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:26:39 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:26:39 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:26:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:26:39 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:26:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:26:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:26:39 --> Model Class Initialized
DEBUG - 2014-02-22 18:26:39 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:26:39 --> Model Class Initialized
DEBUG - 2014-02-22 18:26:39 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:26:39 --> Model Class Initialized
DEBUG - 2014-02-22 18:26:39 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:26:39 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:26:39 --> Final output sent to browser
DEBUG - 2014-02-22 18:26:39 --> Total execution time: 0.0538
DEBUG - 2014-02-22 18:28:33 --> Config Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:28:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:28:33 --> URI Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Router Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Output Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Security Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Input Class Initialized
DEBUG - 2014-02-22 18:28:33 --> XSS Filtering completed
DEBUG - 2014-02-22 18:28:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:28:33 --> Language Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Language Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Config Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Loader Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:28:33 --> Controller Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Session Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:28:33 --> Session routines successfully run
DEBUG - 2014-02-22 18:28:33 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:28:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:28:33 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:28:33 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:28:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:28:33 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:28:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:28:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:28:33 --> Model Class Initialized
DEBUG - 2014-02-22 18:28:33 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:28:33 --> Model Class Initialized
DEBUG - 2014-02-22 18:28:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:28:33 --> Model Class Initialized
DEBUG - 2014-02-22 18:28:33 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:28:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:28:33 --> Final output sent to browser
DEBUG - 2014-02-22 18:28:33 --> Total execution time: 0.0606
DEBUG - 2014-02-22 18:29:40 --> Config Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:29:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:29:40 --> URI Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Router Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Output Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Security Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Input Class Initialized
DEBUG - 2014-02-22 18:29:40 --> XSS Filtering completed
DEBUG - 2014-02-22 18:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:29:40 --> Language Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Language Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Config Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Loader Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:29:40 --> Controller Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Session Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:29:40 --> Session routines successfully run
DEBUG - 2014-02-22 18:29:40 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:29:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:29:40 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:29:40 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:29:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:29:40 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:29:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:29:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:29:40 --> Model Class Initialized
DEBUG - 2014-02-22 18:29:40 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:29:40 --> Model Class Initialized
DEBUG - 2014-02-22 18:29:40 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:29:40 --> Model Class Initialized
DEBUG - 2014-02-22 18:29:40 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:29:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:29:40 --> Final output sent to browser
DEBUG - 2014-02-22 18:29:40 --> Total execution time: 0.0635
DEBUG - 2014-02-22 18:31:53 --> Config Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:31:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:31:53 --> URI Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Router Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Output Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Security Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Input Class Initialized
DEBUG - 2014-02-22 18:31:53 --> XSS Filtering completed
DEBUG - 2014-02-22 18:31:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:31:53 --> Language Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Language Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Config Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Loader Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:31:53 --> Controller Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Session Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:31:53 --> Session routines successfully run
DEBUG - 2014-02-22 18:31:53 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:31:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:31:53 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:31:53 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:31:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:31:53 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:31:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:31:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:31:53 --> Model Class Initialized
DEBUG - 2014-02-22 18:31:53 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:31:53 --> Model Class Initialized
DEBUG - 2014-02-22 18:31:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:31:53 --> Model Class Initialized
DEBUG - 2014-02-22 18:31:53 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:31:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:31:53 --> Final output sent to browser
DEBUG - 2014-02-22 18:31:53 --> Total execution time: 0.0541
DEBUG - 2014-02-22 18:33:05 --> Config Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:33:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:33:05 --> URI Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Router Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Output Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Security Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Input Class Initialized
DEBUG - 2014-02-22 18:33:05 --> XSS Filtering completed
DEBUG - 2014-02-22 18:33:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:33:05 --> Language Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Language Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Config Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Loader Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:33:05 --> Controller Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Session Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:33:05 --> Session routines successfully run
DEBUG - 2014-02-22 18:33:05 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:33:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:33:05 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:33:05 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:33:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:33:05 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:33:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:33:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:33:05 --> Model Class Initialized
DEBUG - 2014-02-22 18:33:05 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:33:05 --> Model Class Initialized
DEBUG - 2014-02-22 18:33:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:33:05 --> Model Class Initialized
DEBUG - 2014-02-22 18:33:05 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:33:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:33:05 --> Final output sent to browser
DEBUG - 2014-02-22 18:33:05 --> Total execution time: 0.0538
DEBUG - 2014-02-22 18:34:05 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:05 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:34:05 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:34:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:34:05 --> URI Class Initialized
DEBUG - 2014-02-22 18:34:05 --> Router Class Initialized
DEBUG - 2014-02-22 18:34:05 --> Output Class Initialized
DEBUG - 2014-02-22 18:34:05 --> Security Class Initialized
DEBUG - 2014-02-22 18:34:05 --> Input Class Initialized
DEBUG - 2014-02-22 18:34:05 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:34:05 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Loader Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:34:06 --> Controller Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Session Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:34:06 --> A session cookie was not found.
DEBUG - 2014-02-22 18:34:06 --> Session routines successfully run
DEBUG - 2014-02-22 18:34:06 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 18:34:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:34:06 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:34:06 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:34:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:34:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:34:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:34:06 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:34:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:34:06 --> URI Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Router Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Output Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Security Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Input Class Initialized
DEBUG - 2014-02-22 18:34:06 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:06 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:34:06 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Loader Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:34:06 --> Controller Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-22 18:34:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:34:06 --> Session Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:34:06 --> Session routines successfully run
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:34:06 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:34:06 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:34:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:34:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:34:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:34:06 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-22 18:34:06 --> Final output sent to browser
DEBUG - 2014-02-22 18:34:06 --> Total execution time: 0.0391
DEBUG - 2014-02-22 18:34:06 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:34:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:34:06 --> URI Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Router Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Output Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Security Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Input Class Initialized
DEBUG - 2014-02-22 18:34:06 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:34:06 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Loader Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:34:06 --> Controller Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Session Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:34:06 --> Session routines successfully run
DEBUG - 2014-02-22 18:34:06 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:34:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:34:06 --> Database Driver Class Initialized
ERROR - 2014-02-22 18:34:06 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:34:06 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:34:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:34:06 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:34:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:34:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:34:06 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:06 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:34:06 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:34:06 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:06 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:34:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:34:06 --> Final output sent to browser
DEBUG - 2014-02-22 18:34:06 --> Total execution time: 0.0588
DEBUG - 2014-02-22 18:34:20 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:34:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:34:20 --> URI Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Router Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Output Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Security Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Input Class Initialized
DEBUG - 2014-02-22 18:34:20 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:20 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:20 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:20 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:20 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:34:20 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Loader Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:34:20 --> Controller Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-22 18:34:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:34:20 --> Session Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:34:20 --> Session routines successfully run
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:34:20 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:34:20 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:34:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:34:20 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:34:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:34:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:34:20 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:20 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-22 18:34:20 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:34:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:34:21 --> URI Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Router Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Output Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Security Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Input Class Initialized
DEBUG - 2014-02-22 18:34:21 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:21 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:34:21 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Loader Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:34:21 --> Controller Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Session Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:34:21 --> Session routines successfully run
DEBUG - 2014-02-22 18:34:21 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:34:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:34:21 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:34:21 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:34:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:34:21 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:34:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:34:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:34:21 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:21 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:34:21 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:34:21 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:21 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:34:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:34:21 --> Final output sent to browser
DEBUG - 2014-02-22 18:34:21 --> Total execution time: 0.0567
DEBUG - 2014-02-22 18:34:38 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:34:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:34:38 --> URI Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Router Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Output Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Security Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Input Class Initialized
DEBUG - 2014-02-22 18:34:38 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:38 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:34:38 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Loader Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:34:38 --> Controller Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Session Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:34:38 --> Session routines successfully run
DEBUG - 2014-02-22 18:34:38 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:34:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:34:38 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:34:38 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:34:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:34:38 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:34:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:34:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:34:38 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:38 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:34:38 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:34:38 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:38 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:34:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:34:38 --> Final output sent to browser
DEBUG - 2014-02-22 18:34:38 --> Total execution time: 0.0644
DEBUG - 2014-02-22 18:34:56 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:34:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:34:56 --> URI Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Router Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Output Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Security Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Input Class Initialized
DEBUG - 2014-02-22 18:34:56 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:56 --> XSS Filtering completed
DEBUG - 2014-02-22 18:34:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:34:56 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Language Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Config Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Loader Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:34:56 --> Controller Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Session Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:34:56 --> Session routines successfully run
DEBUG - 2014-02-22 18:34:56 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 18:34:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:34:56 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:34:56 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:34:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:34:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:34:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:34:56 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:34:56 --> Model Class Initialized
DEBUG - 2014-02-22 18:34:56 --> Helper loaded: image_helper
DEBUG - 2014-02-22 18:34:56 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-22 18:34:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:34:56 --> Final output sent to browser
DEBUG - 2014-02-22 18:34:56 --> Total execution time: 0.0683
DEBUG - 2014-02-22 18:35:00 --> Config Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:35:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:35:00 --> URI Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Router Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Output Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Security Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Input Class Initialized
DEBUG - 2014-02-22 18:35:00 --> XSS Filtering completed
DEBUG - 2014-02-22 18:35:00 --> XSS Filtering completed
DEBUG - 2014-02-22 18:35:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:35:00 --> Language Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Language Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Config Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Loader Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:35:00 --> Controller Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Session Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:35:00 --> Session routines successfully run
DEBUG - 2014-02-22 18:35:00 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 18:35:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:35:00 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:35:00 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:35:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:35:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:35:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:35:00 --> Model Class Initialized
DEBUG - 2014-02-22 18:35:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:35:00 --> Model Class Initialized
DEBUG - 2014-02-22 18:35:00 --> Helper loaded: image_helper
DEBUG - 2014-02-22 18:35:00 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-22 18:35:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:35:00 --> Final output sent to browser
DEBUG - 2014-02-22 18:35:00 --> Total execution time: 0.0565
DEBUG - 2014-02-22 18:35:09 --> Config Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:35:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:35:09 --> URI Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Router Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Output Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Security Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Input Class Initialized
DEBUG - 2014-02-22 18:35:09 --> XSS Filtering completed
DEBUG - 2014-02-22 18:35:09 --> XSS Filtering completed
DEBUG - 2014-02-22 18:35:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:35:09 --> Language Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Language Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Config Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Loader Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:35:09 --> Controller Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Session Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:35:09 --> Session routines successfully run
DEBUG - 2014-02-22 18:35:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-22 18:35:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:35:09 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:35:09 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:35:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:35:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:35:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:35:09 --> Model Class Initialized
DEBUG - 2014-02-22 18:35:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:35:09 --> Model Class Initialized
DEBUG - 2014-02-22 18:35:09 --> Helper loaded: image_helper
DEBUG - 2014-02-22 18:35:09 --> File loaded: application/modules/patient/views/edit_patient.php
DEBUG - 2014-02-22 18:35:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:35:09 --> Final output sent to browser
DEBUG - 2014-02-22 18:35:09 --> Total execution time: 0.0571
DEBUG - 2014-02-22 18:47:22 --> Config Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:47:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:47:22 --> URI Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Router Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Output Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Security Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Input Class Initialized
DEBUG - 2014-02-22 18:47:22 --> XSS Filtering completed
DEBUG - 2014-02-22 18:47:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:47:22 --> Language Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Language Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Config Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Loader Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:47:22 --> Controller Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Session Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:47:22 --> Session routines successfully run
DEBUG - 2014-02-22 18:47:22 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:47:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:47:22 --> Database Driver Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:47:22 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:47:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:47:22 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:47:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:47:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:47:22 --> Model Class Initialized
DEBUG - 2014-02-22 18:47:22 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:47:22 --> Model Class Initialized
DEBUG - 2014-02-22 18:47:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:47:22 --> Model Class Initialized
DEBUG - 2014-02-22 18:47:22 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:47:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:47:22 --> Final output sent to browser
DEBUG - 2014-02-22 18:47:22 --> Total execution time: 0.0625
DEBUG - 2014-02-22 18:57:50 --> Config Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Hooks Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Utf8 Class Initialized
DEBUG - 2014-02-22 18:57:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-22 18:57:50 --> URI Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Router Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Output Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Security Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Input Class Initialized
DEBUG - 2014-02-22 18:57:50 --> XSS Filtering completed
DEBUG - 2014-02-22 18:57:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-22 18:57:50 --> Language Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Language Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Config Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Loader Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: text_helper
DEBUG - 2014-02-22 18:57:50 --> Controller Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Session Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: string_helper
DEBUG - 2014-02-22 18:57:50 --> Session routines successfully run
DEBUG - 2014-02-22 18:57:50 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-22 18:57:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: url_helper
DEBUG - 2014-02-22 18:57:50 --> Database Driver Class Initialized
ERROR - 2014-02-22 18:57:50 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: form_helper
DEBUG - 2014-02-22 18:57:50 --> Form Validation Class Initialized
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: number_helper
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: date_helper
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-22 18:57:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-22 18:57:50 --> Helper loaded: language_helper
DEBUG - 2014-02-22 18:57:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-22 18:57:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-22 18:57:50 --> Model Class Initialized
DEBUG - 2014-02-22 18:57:50 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-22 18:57:50 --> Model Class Initialized
DEBUG - 2014-02-22 18:57:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-22 18:57:50 --> Model Class Initialized
DEBUG - 2014-02-22 18:57:50 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-22 18:57:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-22 18:57:50 --> Final output sent to browser
DEBUG - 2014-02-22 18:57:50 --> Total execution time: 0.0555
