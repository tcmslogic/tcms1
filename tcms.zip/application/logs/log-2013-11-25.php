<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-11-25 06:32:07 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:32:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:32:07 --> URI Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Router Class Initialized
DEBUG - 2013-11-25 06:32:07 --> No URI present. Default controller set.
DEBUG - 2013-11-25 06:32:07 --> Output Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Security Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Input Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:32:07 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Loader Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Controller Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-25 06:32:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:32:07 --> Session Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:32:07 --> A session cookie was not found.
DEBUG - 2013-11-25 06:32:07 --> Session routines successfully run
DEBUG - 2013-11-25 06:32:07 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:32:07 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:32:07 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:32:07 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:32:07 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:32:07 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:32:07 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:32:07 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:32:08 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:32:08 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:32:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:32:08 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:32:08 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:32:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:32:08 --> URI Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Router Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Output Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Security Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Input Class Initialized
DEBUG - 2013-11-25 06:32:08 --> XSS Filtering completed
DEBUG - 2013-11-25 06:32:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:32:08 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Loader Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Controller Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-25 06:32:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:32:08 --> Session Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:32:08 --> Session routines successfully run
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:32:08 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:32:08 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:32:08 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:32:08 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:32:08 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:32:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:32:08 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:32:08 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-25 06:32:08 --> Final output sent to browser
DEBUG - 2013-11-25 06:32:08 --> Total execution time: 0.0958
DEBUG - 2013-11-25 06:32:12 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:32:12 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:32:12 --> URI Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Router Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Output Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Security Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Input Class Initialized
DEBUG - 2013-11-25 06:32:12 --> XSS Filtering completed
DEBUG - 2013-11-25 06:32:12 --> XSS Filtering completed
DEBUG - 2013-11-25 06:32:12 --> XSS Filtering completed
DEBUG - 2013-11-25 06:32:12 --> XSS Filtering completed
DEBUG - 2013-11-25 06:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:32:12 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Loader Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Controller Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-25 06:32:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:32:12 --> Session Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:32:12 --> Session routines successfully run
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:32:12 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:32:12 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:32:12 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:32:12 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:32:12 --> URI Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Router Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Output Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Security Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Input Class Initialized
DEBUG - 2013-11-25 06:32:12 --> XSS Filtering completed
DEBUG - 2013-11-25 06:32:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:32:12 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Loader Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Controller Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-25 06:32:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:32:12 --> Session Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:32:12 --> Session routines successfully run
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:32:12 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:32:12 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:32:12 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:32:12 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/modules/invoices/models/mdl_invoice_amounts.php
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/modules/quotes/models/mdl_quote_amounts.php
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/modules/quotes/models/mdl_quotes.php
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:12 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:32:12 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:13 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:32:13 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-11-25 06:32:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:32:13 --> Final output sent to browser
DEBUG - 2013-11-25 06:32:13 --> Total execution time: 0.9583
DEBUG - 2013-11-25 06:32:15 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:32:15 --> URI Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Router Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Output Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Security Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Input Class Initialized
DEBUG - 2013-11-25 06:32:15 --> XSS Filtering completed
DEBUG - 2013-11-25 06:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:32:15 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:32:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:32:15 --> URI Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Router Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Output Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Security Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Input Class Initialized
DEBUG - 2013-11-25 06:32:15 --> XSS Filtering completed
DEBUG - 2013-11-25 06:32:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:32:15 --> Loader Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Controller Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-25 06:32:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:32:15 --> Language Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Config Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Session Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:32:15 --> Session routines successfully run
DEBUG - 2013-11-25 06:32:15 --> Loader Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:32:15 --> Controller Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-25 06:32:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:32:15 --> Session Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:32:15 --> Session routines successfully run
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:32:15 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:32:15 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:32:15 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:32:15 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:32:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:32:15 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:32:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:32:15 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:32:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:32:15 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:32:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:32:15 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:32:15 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:32:15 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:32:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:32:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:32:15 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:32:15 --> Model Class Initialized
DEBUG - 2013-11-25 06:32:15 --> Final output sent to browser
DEBUG - 2013-11-25 06:32:15 --> Total execution time: 0.1567
DEBUG - 2013-11-25 06:32:15 --> Final output sent to browser
DEBUG - 2013-11-25 06:32:15 --> Total execution time: 0.1551
DEBUG - 2013-11-25 06:33:46 --> Config Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:33:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:33:46 --> URI Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Router Class Initialized
DEBUG - 2013-11-25 06:33:46 --> No URI present. Default controller set.
DEBUG - 2013-11-25 06:33:46 --> Output Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Security Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Input Class Initialized
DEBUG - 2013-11-25 06:33:46 --> XSS Filtering completed
DEBUG - 2013-11-25 06:33:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:33:46 --> Language Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Language Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Config Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Loader Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Controller Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-25 06:33:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:33:46 --> Session Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:33:46 --> Session routines successfully run
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:33:46 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:33:46 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:33:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:33:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:33:46 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:33:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/invoices/models/mdl_invoice_amounts.php
DEBUG - 2013-11-25 06:33:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/quotes/models/mdl_quote_amounts.php
DEBUG - 2013-11-25 06:33:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 06:33:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/quotes/models/mdl_quotes.php
DEBUG - 2013-11-25 06:33:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:33:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-11-25 06:33:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:33:46 --> Final output sent to browser
DEBUG - 2013-11-25 06:33:46 --> Total execution time: 0.0690
DEBUG - 2013-11-25 06:33:47 --> Config Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:33:47 --> URI Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Router Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Output Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Security Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Input Class Initialized
DEBUG - 2013-11-25 06:33:47 --> XSS Filtering completed
DEBUG - 2013-11-25 06:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:33:47 --> Language Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Language Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Config Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Loader Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Controller Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-25 06:33:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:33:47 --> Session Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:33:47 --> Session routines successfully run
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:33:47 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:33:47 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:33:47 --> Config Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:33:47 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:33:47 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:47 --> URI Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:33:47 --> Router Class Initialized
DEBUG - 2013-11-25 06:33:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:33:47 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:33:47 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:33:47 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Output Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Security Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Final output sent to browser
DEBUG - 2013-11-25 06:33:47 --> Total execution time: 0.0489
DEBUG - 2013-11-25 06:33:47 --> Input Class Initialized
DEBUG - 2013-11-25 06:33:47 --> XSS Filtering completed
DEBUG - 2013-11-25 06:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:33:47 --> Language Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Language Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Config Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Loader Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Controller Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-25 06:33:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:33:47 --> Session Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:33:47 --> Session routines successfully run
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:33:47 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:33:47 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:33:47 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:33:47 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:33:47 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:33:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:33:47 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:33:47 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:33:47 --> Model Class Initialized
DEBUG - 2013-11-25 06:33:47 --> Final output sent to browser
DEBUG - 2013-11-25 06:33:47 --> Total execution time: 0.0596
DEBUG - 2013-11-25 06:41:57 --> Config Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:41:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:41:57 --> URI Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Router Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Output Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Security Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Input Class Initialized
DEBUG - 2013-11-25 06:41:57 --> XSS Filtering completed
DEBUG - 2013-11-25 06:41:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:41:57 --> Language Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Language Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Config Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Loader Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Controller Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:41:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:41:57 --> Session Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:41:57 --> Session routines successfully run
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:41:57 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:41:57 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:41:57 --> Model Class Initialized
DEBUG - 2013-11-25 06:41:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:41:57 --> Model Class Initialized
DEBUG - 2013-11-25 06:41:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:41:57 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:41:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:41:57 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:41:57 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:41:57 --> Model Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Config Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:41:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:41:58 --> URI Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Router Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Output Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Security Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Input Class Initialized
DEBUG - 2013-11-25 06:41:58 --> XSS Filtering completed
DEBUG - 2013-11-25 06:41:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:41:58 --> Language Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Language Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Config Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Loader Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Controller Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:41:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:41:58 --> Session Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:41:58 --> Session routines successfully run
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:41:58 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:41:58 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:41:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:41:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:41:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:41:58 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:41:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:41:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:41:58 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:41:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:41:58 --> Pagination Class Initialized
DEBUG - 2013-11-25 06:41:58 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:41:58 --> File loaded: application/modules/clients/views/partial_client_table.php
DEBUG - 2013-11-25 06:41:58 --> File loaded: application/modules/clients/views/index.php
DEBUG - 2013-11-25 06:41:58 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-25 06:41:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:41:58 --> Final output sent to browser
DEBUG - 2013-11-25 06:41:58 --> Total execution time: 0.0864
DEBUG - 2013-11-25 06:47:46 --> Config Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:47:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:47:46 --> URI Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Router Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Output Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Security Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Input Class Initialized
DEBUG - 2013-11-25 06:47:46 --> XSS Filtering completed
DEBUG - 2013-11-25 06:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:47:46 --> Language Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Language Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Config Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Loader Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Controller Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:47:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:47:46 --> Session Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:47:46 --> Session routines successfully run
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:47:46 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:47:46 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:47:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:47:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:47:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:47:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Config Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:47:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:47:46 --> URI Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Router Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Output Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Security Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Input Class Initialized
DEBUG - 2013-11-25 06:47:46 --> XSS Filtering completed
DEBUG - 2013-11-25 06:47:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:47:46 --> Language Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Language Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Config Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Loader Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Controller Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:47:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:47:46 --> Session Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:47:46 --> Session routines successfully run
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:47:46 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:47:46 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:47:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:47:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:47:46 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:47:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:47:46 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:46 --> Pagination Class Initialized
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/clients/views/partial_client_table.php
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/clients/views/index.php
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-25 06:47:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:47:46 --> Final output sent to browser
DEBUG - 2013-11-25 06:47:46 --> Total execution time: 0.0571
DEBUG - 2013-11-25 06:47:49 --> Config Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:47:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:47:49 --> URI Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Router Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Output Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Security Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Input Class Initialized
DEBUG - 2013-11-25 06:47:49 --> XSS Filtering completed
DEBUG - 2013-11-25 06:47:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:47:49 --> Language Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Language Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Config Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Loader Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Controller Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:47:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:47:49 --> Session Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:47:49 --> Session routines successfully run
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:47:49 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:47:49 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:47:49 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:47:49 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:47:49 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:47:49 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:47:49 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/modules/custom_fields/models/mdl_client_custom.php
DEBUG - 2013-11-25 06:47:49 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 06:47:49 --> Model Class Initialized
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 06:47:49 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/modules/clients/views/form.php
DEBUG - 2013-11-25 06:47:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:47:49 --> Final output sent to browser
DEBUG - 2013-11-25 06:47:49 --> Total execution time: 0.1061
DEBUG - 2013-11-25 06:48:31 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:48:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:48:31 --> URI Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Router Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Output Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Security Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Input Class Initialized
DEBUG - 2013-11-25 06:48:31 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:48:31 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Loader Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Controller Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 06:48:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:48:31 --> Session Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:48:31 --> Session routines successfully run
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:48:31 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:48:31 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:48:31 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:48:31 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:48:31 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:48:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:48:31 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:48:31 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 06:48:31 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:31 --> Pagination Class Initialized
DEBUG - 2013-11-25 06:48:31 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:48:31 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 06:48:31 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:48:31 --> Final output sent to browser
DEBUG - 2013-11-25 06:48:31 --> Total execution time: 0.0752
DEBUG - 2013-11-25 06:48:33 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:48:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:48:33 --> URI Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Router Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Output Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Security Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Input Class Initialized
DEBUG - 2013-11-25 06:48:33 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:48:33 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Loader Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Controller Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 06:48:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:48:33 --> Session Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:48:33 --> Session routines successfully run
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:48:33 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:48:33 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:48:33 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:48:33 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:48:33 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:48:33 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 06:48:33 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 06:48:33 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:48:33 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 06:48:33 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 06:48:33 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 06:48:33 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 06:48:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:48:33 --> Final output sent to browser
DEBUG - 2013-11-25 06:48:33 --> Total execution time: 0.0923
DEBUG - 2013-11-25 06:48:52 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:48:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:48:52 --> URI Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Router Class Initialized
DEBUG - 2013-11-25 06:48:52 --> No URI present. Default controller set.
DEBUG - 2013-11-25 06:48:52 --> Output Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Security Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Input Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:48:52 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Loader Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Controller Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-25 06:48:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:48:52 --> Session Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:48:52 --> A session cookie was not found.
DEBUG - 2013-11-25 06:48:52 --> Session routines successfully run
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:48:52 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:48:52 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:48:52 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:48:52 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:48:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:48:52 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:48:52 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:48:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:48:52 --> URI Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Router Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Output Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Security Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Input Class Initialized
DEBUG - 2013-11-25 06:48:52 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:48:52 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Loader Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Controller Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-25 06:48:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:48:52 --> Session Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:48:52 --> Session routines successfully run
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:48:52 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:48:52 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:48:52 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:48:52 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:48:52 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:48:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:48:52 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:48:52 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-25 06:48:52 --> Final output sent to browser
DEBUG - 2013-11-25 06:48:52 --> Total execution time: 0.0385
DEBUG - 2013-11-25 06:48:55 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:48:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:48:55 --> URI Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Router Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Output Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Security Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Input Class Initialized
DEBUG - 2013-11-25 06:48:55 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:48:55 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Loader Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Controller Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 06:48:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:48:55 --> Session Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:48:55 --> Session routines successfully run
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:48:55 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:48:55 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:48:55 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:48:55 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:48:55 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:48:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:48:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:48:55 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 06:48:55 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:55 --> Pagination Class Initialized
DEBUG - 2013-11-25 06:48:55 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:48:55 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 06:48:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:48:55 --> Final output sent to browser
DEBUG - 2013-11-25 06:48:55 --> Total execution time: 0.0524
DEBUG - 2013-11-25 06:48:58 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:48:58 --> URI Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Router Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Output Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Security Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Input Class Initialized
DEBUG - 2013-11-25 06:48:58 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:58 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:58 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:58 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:48:58 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Loader Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Controller Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-25 06:48:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:48:58 --> Session Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:48:58 --> Session routines successfully run
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:48:58 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:48:58 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:48:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:48:58 --> URI Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Router Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Output Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Security Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Input Class Initialized
DEBUG - 2013-11-25 06:48:58 --> XSS Filtering completed
DEBUG - 2013-11-25 06:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:48:58 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Language Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Config Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Loader Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Controller Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-25 06:48:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:48:58 --> Session Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:48:58 --> Session routines successfully run
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:48:58 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:48:58 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:48:58 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:48:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/invoices/models/mdl_invoice_amounts.php
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/quotes/models/mdl_quote_amounts.php
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/quotes/models/mdl_quotes.php
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:48:58 --> Model Class Initialized
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-11-25 06:48:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:48:58 --> Final output sent to browser
DEBUG - 2013-11-25 06:48:58 --> Total execution time: 0.0546
DEBUG - 2013-11-25 06:49:00 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:49:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:49:00 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:49:00 --> URI Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:49:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:49:00 --> URI Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Router Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Router Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Output Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Security Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Output Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Input Class Initialized
DEBUG - 2013-11-25 06:49:00 --> XSS Filtering completed
DEBUG - 2013-11-25 06:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:49:00 --> Security Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Input Class Initialized
DEBUG - 2013-11-25 06:49:00 --> XSS Filtering completed
DEBUG - 2013-11-25 06:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:49:00 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Loader Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Controller Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-25 06:49:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:49:00 --> Loader Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Session Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Controller Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:49:00 --> Session routines successfully run
DEBUG - 2013-11-25 06:49:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:49:00 --> Session Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:49:00 --> Session routines successfully run
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:49:00 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:49:00 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:49:00 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:49:00 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:49:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:49:00 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:49:00 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:49:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:49:00 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:49:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:49:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:49:00 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:49:00 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:49:00 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:49:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:49:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:49:00 --> Final output sent to browser
DEBUG - 2013-11-25 06:49:00 --> Total execution time: 0.0586
DEBUG - 2013-11-25 06:49:00 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-25 06:49:00 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:00 --> Final output sent to browser
DEBUG - 2013-11-25 06:49:00 --> Total execution time: 0.0591
DEBUG - 2013-11-25 06:49:18 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:49:18 --> URI Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Router Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Output Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Security Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Input Class Initialized
DEBUG - 2013-11-25 06:49:18 --> XSS Filtering completed
DEBUG - 2013-11-25 06:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:49:18 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Loader Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Controller Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:49:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:49:18 --> Session Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:49:18 --> Session routines successfully run
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:49:18 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:49:18 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:49:18 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:49:18 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:49:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:49:18 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:49:18 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:49:18 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:49:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:49:18 --> URI Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Router Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Output Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Security Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Input Class Initialized
DEBUG - 2013-11-25 06:49:18 --> XSS Filtering completed
DEBUG - 2013-11-25 06:49:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:49:18 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Loader Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Controller Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:49:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:49:18 --> Session Class Initialized
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:49:18 --> Session routines successfully run
DEBUG - 2013-11-25 06:49:18 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:49:19 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:49:19 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:49:19 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:49:19 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:49:19 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:49:19 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:49:19 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:49:19 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:49:19 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:49:19 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:49:19 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:49:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:49:19 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:49:19 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:49:19 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:19 --> Pagination Class Initialized
DEBUG - 2013-11-25 06:49:19 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:49:19 --> File loaded: application/modules/clients/views/partial_client_table.php
DEBUG - 2013-11-25 06:49:19 --> File loaded: application/modules/clients/views/index.php
DEBUG - 2013-11-25 06:49:19 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-25 06:49:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:49:19 --> Final output sent to browser
DEBUG - 2013-11-25 06:49:19 --> Total execution time: 0.0769
DEBUG - 2013-11-25 06:49:24 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:24 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:49:24 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:49:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:49:24 --> URI Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Router Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Output Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Security Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Input Class Initialized
DEBUG - 2013-11-25 06:49:25 --> XSS Filtering completed
DEBUG - 2013-11-25 06:49:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:49:25 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Language Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Config Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Loader Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Controller Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:49:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:49:25 --> Session Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:49:25 --> Session routines successfully run
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:49:25 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:49:25 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:49:25 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:49:25 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:49:25 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:49:25 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:49:25 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/modules/custom_fields/models/mdl_client_custom.php
DEBUG - 2013-11-25 06:49:25 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 06:49:25 --> Model Class Initialized
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 06:49:25 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/modules/clients/views/form.php
DEBUG - 2013-11-25 06:49:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:49:25 --> Final output sent to browser
DEBUG - 2013-11-25 06:49:25 --> Total execution time: 0.0490
DEBUG - 2013-11-25 06:50:27 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:50:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:50:27 --> URI Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Router Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Output Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Security Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Input Class Initialized
DEBUG - 2013-11-25 06:50:27 --> XSS Filtering completed
DEBUG - 2013-11-25 06:50:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:50:27 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Loader Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Controller Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 06:50:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:50:27 --> Session Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:50:27 --> Session routines successfully run
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:50:27 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:50:27 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:50:27 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:50:27 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:50:27 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:50:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:50:27 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:50:27 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 06:50:27 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:27 --> Pagination Class Initialized
DEBUG - 2013-11-25 06:50:27 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:50:27 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 06:50:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:50:27 --> Final output sent to browser
DEBUG - 2013-11-25 06:50:27 --> Total execution time: 0.0607
DEBUG - 2013-11-25 06:50:30 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:50:30 --> URI Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Router Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Output Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Security Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Input Class Initialized
DEBUG - 2013-11-25 06:50:30 --> XSS Filtering completed
DEBUG - 2013-11-25 06:50:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:50:30 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Loader Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Controller Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 06:50:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:50:30 --> Session Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:50:30 --> Session routines successfully run
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:50:30 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:50:30 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:50:30 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:50:30 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:50:30 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:50:30 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 06:50:30 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 06:50:30 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 06:50:30 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:50:30 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 06:50:30 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 06:50:30 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 06:50:30 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 06:50:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:50:30 --> Final output sent to browser
DEBUG - 2013-11-25 06:50:30 --> Total execution time: 0.0920
DEBUG - 2013-11-25 06:50:39 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:50:39 --> URI Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Router Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Output Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Security Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Input Class Initialized
DEBUG - 2013-11-25 06:50:39 --> XSS Filtering completed
DEBUG - 2013-11-25 06:50:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:50:39 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Loader Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Controller Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 06:50:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:50:39 --> Session Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:50:39 --> Session routines successfully run
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:50:39 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:50:39 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:50:39 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:50:39 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:50:39 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:50:39 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 06:50:39 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 06:50:39 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 06:50:39 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:50:39 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 06:50:39 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 06:50:39 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 06:50:39 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 06:50:39 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:50:39 --> Final output sent to browser
DEBUG - 2013-11-25 06:50:39 --> Total execution time: 0.0668
DEBUG - 2013-11-25 06:50:53 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:50:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:50:53 --> URI Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Router Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Output Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Security Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Input Class Initialized
DEBUG - 2013-11-25 06:50:53 --> XSS Filtering completed
DEBUG - 2013-11-25 06:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:50:53 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Loader Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Controller Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:50:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:50:53 --> Session Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:50:53 --> Session routines successfully run
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:50:53 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:50:53 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:50:53 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:50:53 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:50:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:50:53 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:50:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:50:53 --> URI Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Router Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Output Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Security Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Input Class Initialized
DEBUG - 2013-11-25 06:50:53 --> XSS Filtering completed
DEBUG - 2013-11-25 06:50:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:50:53 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Loader Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Controller Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:50:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:50:53 --> Session Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:50:53 --> Session routines successfully run
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:50:53 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:50:53 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:50:53 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:50:53 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:50:53 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:50:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:50:53 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:53 --> Pagination Class Initialized
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/clients/views/partial_client_table.php
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/clients/views/index.php
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-25 06:50:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:50:53 --> Final output sent to browser
DEBUG - 2013-11-25 06:50:53 --> Total execution time: 0.0465
DEBUG - 2013-11-25 06:50:56 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:50:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:50:56 --> URI Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Router Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Output Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Security Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Input Class Initialized
DEBUG - 2013-11-25 06:50:56 --> XSS Filtering completed
DEBUG - 2013-11-25 06:50:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:50:56 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Language Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Config Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Loader Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Controller Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Clients MX_Controller Initialized
DEBUG - 2013-11-25 06:50:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:50:56 --> Session Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:50:56 --> Session routines successfully run
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:50:56 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:50:56 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:50:56 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:50:56 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:50:56 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:50:56 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:50:56 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/modules/custom_fields/models/mdl_client_custom.php
DEBUG - 2013-11-25 06:50:56 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 06:50:56 --> Model Class Initialized
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 06:50:56 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/modules/clients/views/form.php
DEBUG - 2013-11-25 06:50:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:50:56 --> Final output sent to browser
DEBUG - 2013-11-25 06:50:56 --> Total execution time: 0.0669
DEBUG - 2013-11-25 06:57:42 --> Config Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Hooks Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Utf8 Class Initialized
DEBUG - 2013-11-25 06:57:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 06:57:42 --> URI Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Router Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Output Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Security Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Input Class Initialized
DEBUG - 2013-11-25 06:57:42 --> XSS Filtering completed
DEBUG - 2013-11-25 06:57:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 06:57:42 --> Language Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Language Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Config Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Loader Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Controller Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 06:57:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 06:57:42 --> Session Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: string_helper
DEBUG - 2013-11-25 06:57:42 --> Session routines successfully run
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: url_helper
DEBUG - 2013-11-25 06:57:42 --> Database Driver Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: form_helper
DEBUG - 2013-11-25 06:57:42 --> Form Validation Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: number_helper
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: date_helper
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 06:57:42 --> Model Class Initialized
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 06:57:42 --> Model Class Initialized
DEBUG - 2013-11-25 06:57:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 06:57:42 --> Helper loaded: language_helper
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 06:57:42 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 06:57:42 --> Model Class Initialized
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 06:57:42 --> Model Class Initialized
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 06:57:42 --> Model Class Initialized
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 06:57:42 --> Model Class Initialized
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 06:57:42 --> Model Class Initialized
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 06:57:42 --> Model Class Initialized
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 06:57:42 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 06:57:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 06:57:42 --> Final output sent to browser
DEBUG - 2013-11-25 06:57:42 --> Total execution time: 0.0590
DEBUG - 2013-11-25 07:00:13 --> Config Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:00:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:00:13 --> URI Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Router Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Output Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Security Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Input Class Initialized
DEBUG - 2013-11-25 07:00:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:00:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:00:13 --> Language Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Language Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Config Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Loader Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Controller Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:00:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:00:13 --> Session Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:00:13 --> Session routines successfully run
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:00:13 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:00:13 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:00:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:00:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:00:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:00:13 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:00:13 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:00:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:00:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:00:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:00:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:00:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:00:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:00:13 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:00:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:00:13 --> Final output sent to browser
DEBUG - 2013-11-25 07:00:13 --> Total execution time: 0.0652
DEBUG - 2013-11-25 07:01:57 --> Config Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:01:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:01:57 --> URI Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Router Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Output Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Security Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Input Class Initialized
DEBUG - 2013-11-25 07:01:57 --> XSS Filtering completed
DEBUG - 2013-11-25 07:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:01:57 --> Language Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Language Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Config Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Loader Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Controller Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:01:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:01:57 --> Session Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:01:57 --> Session routines successfully run
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:01:57 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:01:57 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:01:57 --> Model Class Initialized
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:01:57 --> Model Class Initialized
DEBUG - 2013-11-25 07:01:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:01:57 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:01:57 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:01:57 --> Model Class Initialized
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:01:57 --> Model Class Initialized
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:01:57 --> Model Class Initialized
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:01:57 --> Model Class Initialized
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:01:57 --> Model Class Initialized
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:01:57 --> Model Class Initialized
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:01:57 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:01:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:01:57 --> Final output sent to browser
DEBUG - 2013-11-25 07:01:57 --> Total execution time: 0.0646
DEBUG - 2013-11-25 07:06:34 --> Config Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:06:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:06:34 --> URI Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Router Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Output Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Security Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Input Class Initialized
DEBUG - 2013-11-25 07:06:34 --> XSS Filtering completed
DEBUG - 2013-11-25 07:06:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:06:34 --> Language Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Language Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Config Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Loader Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Controller Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:06:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:06:34 --> Session Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:06:34 --> Session routines successfully run
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:06:34 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:06:34 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:06:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:06:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:06:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:06:34 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:06:34 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:06:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:06:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:06:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:06:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:06:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:06:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:06:34 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:06:34 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:06:34 --> Final output sent to browser
DEBUG - 2013-11-25 07:06:34 --> Total execution time: 0.0643
DEBUG - 2013-11-25 07:07:25 --> Config Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:07:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:07:25 --> URI Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Router Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Output Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Security Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Input Class Initialized
DEBUG - 2013-11-25 07:07:25 --> XSS Filtering completed
DEBUG - 2013-11-25 07:07:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:07:25 --> Language Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Language Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Config Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Loader Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Controller Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:07:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:07:25 --> Session Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:07:25 --> Session routines successfully run
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:07:25 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:07:25 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:07:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:07:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:07:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:07:25 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:07:25 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:07:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:07:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:07:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:07:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:07:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:07:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:07:25 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:07:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:07:25 --> Final output sent to browser
DEBUG - 2013-11-25 07:07:25 --> Total execution time: 0.0911
DEBUG - 2013-11-25 07:26:10 --> Config Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:26:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:26:10 --> URI Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Router Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Output Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Security Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Input Class Initialized
DEBUG - 2013-11-25 07:26:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:26:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:26:10 --> Language Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Language Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Config Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Loader Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Controller Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:26:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:26:10 --> Session Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:26:10 --> Session routines successfully run
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:26:10 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:26:10 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:26:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:26:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:26:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:26:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:26:10 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:26:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:26:10 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:26:10 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:26:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:26:10 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:26:10 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 07:26:10 --> File loaded: application/modules/users/views/form_change_password.php
DEBUG - 2013-11-25 07:26:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:26:10 --> Final output sent to browser
DEBUG - 2013-11-25 07:26:10 --> Total execution time: 0.0709
DEBUG - 2013-11-25 07:29:49 --> Config Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:29:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:29:49 --> URI Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Router Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Output Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Security Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Input Class Initialized
DEBUG - 2013-11-25 07:29:49 --> XSS Filtering completed
DEBUG - 2013-11-25 07:29:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:29:49 --> Language Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Language Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Config Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Loader Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Controller Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:29:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:29:49 --> Session Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:29:49 --> Session routines successfully run
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:29:49 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:29:49 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:29:49 --> Model Class Initialized
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:29:49 --> Model Class Initialized
DEBUG - 2013-11-25 07:29:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:29:49 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:29:49 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:29:49 --> Model Class Initialized
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:29:49 --> Model Class Initialized
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:29:49 --> Model Class Initialized
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:29:49 --> Model Class Initialized
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:29:49 --> Model Class Initialized
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:29:49 --> Model Class Initialized
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:29:49 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:29:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:29:49 --> Final output sent to browser
DEBUG - 2013-11-25 07:29:49 --> Total execution time: 0.0630
DEBUG - 2013-11-25 07:30:43 --> Config Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:30:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:30:43 --> URI Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Router Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Output Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Security Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Input Class Initialized
DEBUG - 2013-11-25 07:30:43 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:30:43 --> Language Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Language Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Config Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Loader Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Controller Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:30:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:30:43 --> Session Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:30:43 --> Session routines successfully run
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:30:43 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:30:43 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:30:43 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:30:43 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:30:43 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:30:43 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:30:43 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:30:43 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:30:43 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:30:43 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:30:43 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:30:43 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:30:43 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:30:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:30:43 --> Final output sent to browser
DEBUG - 2013-11-25 07:30:43 --> Total execution time: 0.0773
DEBUG - 2013-11-25 07:30:58 --> Config Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:30:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:30:58 --> URI Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Router Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Output Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Security Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Input Class Initialized
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> XSS Filtering completed
DEBUG - 2013-11-25 07:30:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:30:58 --> Language Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Language Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Config Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Loader Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Controller Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:30:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:30:58 --> Session Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:30:58 --> Session routines successfully run
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:30:58 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:30:58 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:30:58 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:30:58 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:30:58 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:30:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:30:58 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:58 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:30:58 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:30:58 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:30:58 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:30:58 --> Model Class Initialized
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:30:58 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:30:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:30:58 --> Final output sent to browser
DEBUG - 2013-11-25 07:30:58 --> Total execution time: 0.0756
DEBUG - 2013-11-25 07:31:06 --> Config Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:31:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:31:06 --> URI Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Router Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Output Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Security Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Input Class Initialized
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:31:06 --> Language Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Language Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Config Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Loader Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Controller Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:31:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:31:06 --> Session Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:31:06 --> Session routines successfully run
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:31:06 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:31:06 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:31:06 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:31:06 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:31:06 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:31:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:31:06 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:31:06 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:31:06 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:31:56 --> Config Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:31:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:31:56 --> URI Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Router Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Output Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Security Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Input Class Initialized
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:31:56 --> Language Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Language Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Config Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Loader Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Controller Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:31:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:31:56 --> Session Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:31:56 --> Session routines successfully run
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:31:56 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:31:56 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:31:56 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:31:56 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:31:56 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:31:56 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:31:56 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Config Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:31:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:31:56 --> URI Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Router Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Output Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Security Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Input Class Initialized
DEBUG - 2013-11-25 07:31:56 --> XSS Filtering completed
DEBUG - 2013-11-25 07:31:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:31:56 --> Language Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Language Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Config Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Loader Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Controller Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:31:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:31:56 --> Session Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:31:56 --> Session routines successfully run
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:31:56 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:31:56 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:31:56 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:31:56 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:31:56 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:31:56 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:31:56 --> Model Class Initialized
DEBUG - 2013-11-25 07:31:56 --> Pagination Class Initialized
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 07:31:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:31:56 --> Final output sent to browser
DEBUG - 2013-11-25 07:31:56 --> Total execution time: 0.0491
DEBUG - 2013-11-25 07:32:05 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:32:05 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:32:05 --> URI Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Router Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Output Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Security Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Input Class Initialized
DEBUG - 2013-11-25 07:32:05 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:32:05 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Loader Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Controller Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:32:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:32:05 --> Session Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:32:05 --> Session routines successfully run
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:32:05 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:32:05 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:32:05 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:32:05 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:32:05 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:32:05 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:32:05 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:32:05 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:32:05 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:32:05 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:32:05 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:32:05 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:32:05 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:32:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:32:05 --> Final output sent to browser
DEBUG - 2013-11-25 07:32:05 --> Total execution time: 0.0722
DEBUG - 2013-11-25 07:32:10 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:32:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:32:10 --> URI Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Router Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Output Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Security Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Input Class Initialized
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:32:10 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Loader Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Controller Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:32:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:32:10 --> Session Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:32:10 --> Session routines successfully run
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:32:10 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:32:10 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:32:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:32:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:32:10 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:32:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:32:10 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:32:10 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:32:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:32:10 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:32:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:32:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:32:11 --> URI Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Router Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Output Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Security Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Input Class Initialized
DEBUG - 2013-11-25 07:32:11 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:32:11 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Loader Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Controller Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:32:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:32:11 --> Session Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:32:11 --> Session routines successfully run
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:32:11 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:32:11 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:32:11 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:32:11 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:32:11 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:32:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:32:11 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:32:11 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:32:11 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:11 --> Pagination Class Initialized
DEBUG - 2013-11-25 07:32:11 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 07:32:11 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 07:32:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:32:11 --> Final output sent to browser
DEBUG - 2013-11-25 07:32:11 --> Total execution time: 0.0487
DEBUG - 2013-11-25 07:32:30 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:32:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:32:30 --> URI Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Router Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Output Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Security Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Input Class Initialized
DEBUG - 2013-11-25 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:32:30 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Loader Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Controller Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:32:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:32:30 --> Session Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:32:30 --> Session routines successfully run
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:32:30 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:32:30 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:32:30 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:32:30 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:32:30 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:32:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:32:30 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:32:30 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:32:30 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:30 --> Pagination Class Initialized
DEBUG - 2013-11-25 07:32:30 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 07:32:30 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 07:32:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:32:30 --> Final output sent to browser
DEBUG - 2013-11-25 07:32:30 --> Total execution time: 0.0547
DEBUG - 2013-11-25 07:32:33 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:32:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:32:33 --> URI Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Router Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Output Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Security Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Input Class Initialized
DEBUG - 2013-11-25 07:32:33 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:32:33 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Loader Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Controller Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:32:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:32:33 --> Session Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:32:33 --> Session routines successfully run
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:32:33 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:32:33 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:32:33 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:32:33 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:32:33 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:32:33 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:32:33 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:32:33 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:32:33 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:32:33 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:32:33 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:32:33 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:32:33 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:32:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:32:33 --> Final output sent to browser
DEBUG - 2013-11-25 07:32:33 --> Total execution time: 0.0628
DEBUG - 2013-11-25 07:32:39 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:32:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:32:39 --> URI Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Router Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Output Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Security Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Input Class Initialized
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> XSS Filtering completed
DEBUG - 2013-11-25 07:32:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:32:39 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Language Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Config Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Loader Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Controller Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:32:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:32:39 --> Session Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:32:39 --> Session routines successfully run
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:32:39 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:32:39 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:32:39 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:32:39 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:32:39 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:32:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:32:39 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:32:39 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:32:39 --> Model Class Initialized
DEBUG - 2013-11-25 07:32:39 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:34:14 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:34:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:34:14 --> URI Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Router Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Output Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Security Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Input Class Initialized
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:34:14 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Loader Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Controller Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:34:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:34:14 --> Session Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:34:14 --> Session routines successfully run
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:34:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:34:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:34:14 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:34:14 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:34:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:34:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:34:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:34:14 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:34:14 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:34:19 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:34:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:34:19 --> URI Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Router Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Output Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Security Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Input Class Initialized
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:34:19 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Loader Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Controller Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:34:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:34:19 --> Session Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:34:19 --> Session routines successfully run
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:34:19 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:34:19 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:34:19 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:34:19 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:34:19 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:34:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:34:19 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:34:19 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:34:19 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:19 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:34:21 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:34:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:34:21 --> URI Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Router Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Output Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Security Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Input Class Initialized
DEBUG - 2013-11-25 07:34:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:34:21 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Loader Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Controller Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:34:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:34:21 --> Session Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:34:21 --> Session routines successfully run
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:34:21 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:34:21 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:34:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:34:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:34:21 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:34:21 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:34:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:34:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:34:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:34:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:34:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:34:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:34:21 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:34:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:34:21 --> Final output sent to browser
DEBUG - 2013-11-25 07:34:21 --> Total execution time: 0.0763
DEBUG - 2013-11-25 07:34:28 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:28 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:34:28 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:34:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:34:28 --> URI Class Initialized
DEBUG - 2013-11-25 07:34:28 --> Router Class Initialized
DEBUG - 2013-11-25 07:34:28 --> Output Class Initialized
DEBUG - 2013-11-25 07:34:28 --> Security Class Initialized
DEBUG - 2013-11-25 07:34:28 --> Input Class Initialized
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:38 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:34:38 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:34:38 --> URI Class Initialized
DEBUG - 2013-11-25 07:34:38 --> Router Class Initialized
DEBUG - 2013-11-25 07:34:38 --> Output Class Initialized
DEBUG - 2013-11-25 07:34:38 --> Security Class Initialized
DEBUG - 2013-11-25 07:34:38 --> Input Class Initialized
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:38 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:40 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:34:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:34:40 --> URI Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Router Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Output Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Security Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Input Class Initialized
DEBUG - 2013-11-25 07:34:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:34:40 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Loader Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Controller Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:34:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:34:40 --> Session Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:34:40 --> Session routines successfully run
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:34:40 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:34:40 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:34:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:34:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:34:40 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:34:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:34:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:34:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:34:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:34:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:34:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:34:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:34:40 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:34:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:34:40 --> Final output sent to browser
DEBUG - 2013-11-25 07:34:40 --> Total execution time: 0.0696
DEBUG - 2013-11-25 07:34:46 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:34:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:34:46 --> URI Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Router Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Output Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Security Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Input Class Initialized
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> XSS Filtering completed
DEBUG - 2013-11-25 07:34:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:34:46 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Language Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Config Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Loader Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Controller Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:34:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:34:46 --> Session Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:34:46 --> Session routines successfully run
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:34:46 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:34:46 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:34:46 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:34:46 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:34:46 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:34:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:34:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:34:46 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:34:46 --> Model Class Initialized
DEBUG - 2013-11-25 07:34:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:35:13 --> Config Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:35:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:35:13 --> URI Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Router Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Output Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Security Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Input Class Initialized
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:35:13 --> Language Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Language Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Config Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Loader Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Controller Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:35:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:35:13 --> Session Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:35:13 --> Session routines successfully run
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:35:13 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:35:13 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:35:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:35:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:35:13 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:35:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:35:13 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:35:13 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:35:13 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:35:14 --> Config Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:35:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:35:14 --> URI Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Router Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Output Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Security Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Input Class Initialized
DEBUG - 2013-11-25 07:35:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:35:14 --> Language Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Language Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Config Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Loader Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Controller Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:35:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:35:14 --> Session Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:35:14 --> Session routines successfully run
DEBUG - 2013-11-25 07:35:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:35:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:35:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:35:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:35:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:35:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:35:15 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:35:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:35:15 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:35:15 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:35:15 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:35:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:35:15 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:35:15 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:35:15 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:35:15 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:35:15 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:35:15 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:35:15 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:35:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:35:15 --> Final output sent to browser
DEBUG - 2013-11-25 07:35:15 --> Total execution time: 0.0661
DEBUG - 2013-11-25 07:35:21 --> Config Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:35:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:35:21 --> URI Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Router Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Output Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Security Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Input Class Initialized
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> XSS Filtering completed
DEBUG - 2013-11-25 07:35:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:35:21 --> Language Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Language Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Config Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Loader Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Controller Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:35:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:35:21 --> Session Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:35:21 --> Session routines successfully run
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:35:21 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:35:21 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:35:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:35:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:35:21 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:35:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:35:21 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:35:21 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:35:21 --> Model Class Initialized
DEBUG - 2013-11-25 07:35:21 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:36:03 --> Config Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:36:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:36:03 --> URI Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Router Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Output Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Security Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Input Class Initialized
DEBUG - 2013-11-25 07:36:03 --> XSS Filtering completed
DEBUG - 2013-11-25 07:36:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:36:03 --> Language Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Language Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Config Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Loader Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Controller Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:36:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:36:03 --> Session Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:36:03 --> Session routines successfully run
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:36:03 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:36:03 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:36:03 --> Model Class Initialized
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:36:03 --> Model Class Initialized
DEBUG - 2013-11-25 07:36:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:36:03 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:36:03 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:36:03 --> Model Class Initialized
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:36:03 --> Model Class Initialized
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:36:03 --> Model Class Initialized
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:36:03 --> Model Class Initialized
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:36:03 --> Model Class Initialized
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:36:03 --> Model Class Initialized
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:36:03 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:36:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:36:03 --> Final output sent to browser
DEBUG - 2013-11-25 07:36:03 --> Total execution time: 0.0672
DEBUG - 2013-11-25 07:38:40 --> Config Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:38:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:38:40 --> URI Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Router Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Output Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Security Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Input Class Initialized
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> XSS Filtering completed
DEBUG - 2013-11-25 07:38:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:38:40 --> Language Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Language Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Config Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Loader Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Controller Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:38:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:38:40 --> Session Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:38:40 --> Session routines successfully run
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:38:40 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:38:40 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:38:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:38:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:38:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:38:40 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:38:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:38:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:38:40 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:38:40 --> Model Class Initialized
DEBUG - 2013-11-25 07:38:40 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:39:23 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:39:23 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:39:23 --> URI Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Router Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Output Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Security Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Input Class Initialized
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:39:23 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Loader Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Controller Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:39:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:39:23 --> Session Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:39:23 --> Session routines successfully run
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:39:23 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:39:23 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:39:23 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:39:23 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:39:23 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:39:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:39:23 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:39:23 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:39:23 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:23 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:39:24 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:39:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:39:24 --> URI Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Router Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Output Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Security Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Input Class Initialized
DEBUG - 2013-11-25 07:39:24 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:39:24 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Loader Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Controller Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:39:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:39:24 --> Session Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:39:24 --> Session routines successfully run
DEBUG - 2013-11-25 07:39:24 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:39:24 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:39:24 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:39:24 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:39:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:39:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:39:24 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:39:25 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:39:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:39:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:39:25 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:39:25 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:39:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:39:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:39:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:39:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:39:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:39:25 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:39:25 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:39:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:39:25 --> Final output sent to browser
DEBUG - 2013-11-25 07:39:25 --> Total execution time: 0.0637
DEBUG - 2013-11-25 07:39:28 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:39:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:39:28 --> URI Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Router Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Output Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Security Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Input Class Initialized
DEBUG - 2013-11-25 07:39:28 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:39:28 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Loader Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Controller Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:39:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:39:28 --> Session Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:39:28 --> Session routines successfully run
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:39:28 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:39:28 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:39:28 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:39:28 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:39:28 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:39:28 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:39:28 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:39:28 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:39:28 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:39:28 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:39:28 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:39:28 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:39:28 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:39:28 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:39:28 --> Final output sent to browser
DEBUG - 2013-11-25 07:39:28 --> Total execution time: 0.0753
DEBUG - 2013-11-25 07:39:29 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:39:29 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:39:29 --> URI Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Router Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Output Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Security Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Input Class Initialized
DEBUG - 2013-11-25 07:39:29 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:39:29 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Loader Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Controller Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:39:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:39:29 --> Session Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:39:29 --> Session routines successfully run
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:39:29 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:39:29 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:39:29 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:39:29 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:39:29 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:39:29 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:39:29 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:39:29 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:39:29 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:39:29 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:39:29 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:39:29 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:39:29 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:39:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:39:29 --> Final output sent to browser
DEBUG - 2013-11-25 07:39:29 --> Total execution time: 0.0571
DEBUG - 2013-11-25 07:39:34 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:39:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:39:34 --> URI Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Router Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Output Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Security Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Input Class Initialized
DEBUG - 2013-11-25 07:39:34 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:39:34 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Loader Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Controller Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:39:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:39:34 --> Session Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:39:34 --> Session routines successfully run
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:39:34 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:39:34 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:39:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:39:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:39:34 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:39:34 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:39:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:39:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:39:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:39:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:39:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:39:34 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:39:34 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:39:34 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:39:34 --> Final output sent to browser
DEBUG - 2013-11-25 07:39:34 --> Total execution time: 0.0589
DEBUG - 2013-11-25 07:39:41 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:39:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:39:41 --> URI Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Router Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Output Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Security Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Input Class Initialized
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> XSS Filtering completed
DEBUG - 2013-11-25 07:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:39:41 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Language Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Config Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Loader Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Controller Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:39:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:39:41 --> Session Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:39:41 --> Session routines successfully run
DEBUG - 2013-11-25 07:39:41 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:39:41 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:39:41 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:39:41 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:39:42 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:39:42 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:39:42 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:39:42 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:39:42 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:39:42 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:39:42 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:39:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:39:42 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:39:42 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:39:42 --> Model Class Initialized
DEBUG - 2013-11-25 07:39:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:41:27 --> Config Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:41:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:41:27 --> URI Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Router Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Output Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Security Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Input Class Initialized
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:41:27 --> Language Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Language Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Config Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Loader Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Controller Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:41:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:41:27 --> Session Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:41:27 --> Session routines successfully run
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:41:27 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:41:27 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:41:27 --> Model Class Initialized
DEBUG - 2013-11-25 07:41:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:41:27 --> Model Class Initialized
DEBUG - 2013-11-25 07:41:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:41:27 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:41:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:41:27 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:41:36 --> Config Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:41:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:41:36 --> URI Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Router Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Output Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Security Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Input Class Initialized
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> XSS Filtering completed
DEBUG - 2013-11-25 07:41:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:41:36 --> Language Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Language Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Config Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Loader Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Controller Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:41:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:41:36 --> Session Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:41:36 --> Session routines successfully run
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:41:36 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:41:36 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:41:36 --> Model Class Initialized
DEBUG - 2013-11-25 07:41:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:41:36 --> Model Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:41:36 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:41:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:41:36 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:41:36 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:41:36 --> Model Class Initialized
DEBUG - 2013-11-25 07:41:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:42:50 --> Config Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:42:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:42:50 --> URI Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Router Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Output Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Security Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Input Class Initialized
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:42:50 --> Language Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Language Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Config Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Loader Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Controller Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:42:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:42:50 --> Session Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:42:50 --> Session routines successfully run
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:42:50 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:42:50 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:42:50 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:42:50 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:42:50 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:42:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:42:50 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:42:50 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:42:50 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:42:53 --> Config Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:42:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:42:53 --> URI Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Router Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Output Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Security Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Input Class Initialized
DEBUG - 2013-11-25 07:42:53 --> XSS Filtering completed
DEBUG - 2013-11-25 07:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:42:53 --> Language Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Language Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Config Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Loader Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Controller Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:42:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:42:53 --> Session Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:42:53 --> Session routines successfully run
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:42:53 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:42:53 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:42:53 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:42:53 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:42:53 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:42:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:42:53 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 07:42:53 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 07:42:53 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 07:42:53 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 07:42:53 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 07:42:53 --> Model Class Initialized
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 07:42:53 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 07:42:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 07:42:53 --> Final output sent to browser
DEBUG - 2013-11-25 07:42:53 --> Total execution time: 0.0593
DEBUG - 2013-11-25 07:43:06 --> Config Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:43:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:43:06 --> URI Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Router Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Output Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Security Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Input Class Initialized
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> XSS Filtering completed
DEBUG - 2013-11-25 07:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:43:06 --> Language Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Language Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Config Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Loader Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Controller Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:43:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:43:06 --> Session Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:43:06 --> Session routines successfully run
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:43:06 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:43:06 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:43:06 --> Model Class Initialized
DEBUG - 2013-11-25 07:43:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:43:06 --> Model Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:43:06 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:43:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:43:06 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:43:06 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:43:06 --> Model Class Initialized
DEBUG - 2013-11-25 07:43:06 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:44:09 --> Config Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:44:09 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:44:09 --> URI Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Router Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Output Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Security Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Input Class Initialized
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:44:09 --> Language Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Language Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Config Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Loader Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Controller Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:44:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:44:09 --> Session Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:44:09 --> Session routines successfully run
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:44:09 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:44:09 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:44:09 --> Model Class Initialized
DEBUG - 2013-11-25 07:44:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:44:09 --> Model Class Initialized
DEBUG - 2013-11-25 07:44:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:44:09 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:44:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:44:09 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:44:42 --> Config Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:44:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:44:42 --> URI Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Router Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Output Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Security Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Input Class Initialized
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> XSS Filtering completed
DEBUG - 2013-11-25 07:44:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:44:42 --> Language Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Language Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Config Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Loader Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Controller Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:44:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:44:42 --> Session Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:44:42 --> Session routines successfully run
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:44:42 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:44:42 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:44:42 --> Model Class Initialized
DEBUG - 2013-11-25 07:44:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:44:42 --> Model Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:44:42 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:44:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:44:42 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:44:42 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:44:42 --> Model Class Initialized
DEBUG - 2013-11-25 07:44:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:51:37 --> Config Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:51:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:51:37 --> URI Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Router Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Output Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Security Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Input Class Initialized
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:51:37 --> Language Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Language Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Config Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Loader Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Controller Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:51:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:51:37 --> Session Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:51:37 --> Session routines successfully run
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:51:37 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:51:37 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:51:37 --> Model Class Initialized
DEBUG - 2013-11-25 07:51:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:51:37 --> Model Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:51:37 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:51:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:51:37 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:51:37 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:51:37 --> Model Class Initialized
DEBUG - 2013-11-25 07:51:37 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:51:51 --> Config Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:51:51 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:51:51 --> URI Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Router Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Output Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Security Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Input Class Initialized
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> XSS Filtering completed
DEBUG - 2013-11-25 07:51:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:51:51 --> Language Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Language Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Config Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Loader Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Controller Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:51:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:51:51 --> Session Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:51:51 --> Session routines successfully run
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:51:51 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:51:51 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:51:51 --> Model Class Initialized
DEBUG - 2013-11-25 07:51:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:51:51 --> Model Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:51:51 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:51:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:51:51 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:51:51 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:51:51 --> Model Class Initialized
DEBUG - 2013-11-25 07:51:51 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:58:10 --> Config Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:58:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:58:10 --> URI Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Router Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Output Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Security Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Input Class Initialized
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:58:10 --> Language Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Language Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Config Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Loader Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Controller Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:58:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:58:10 --> Session Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:58:10 --> Session routines successfully run
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:58:10 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:58:10 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:58:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:58:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:58:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:58:10 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:58:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:58:10 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:58:10 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:58:10 --> Model Class Initialized
DEBUG - 2013-11-25 07:58:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:58:48 --> Config Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:58:48 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:58:48 --> URI Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Router Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Output Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Security Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Input Class Initialized
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> XSS Filtering completed
DEBUG - 2013-11-25 07:58:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:58:48 --> Language Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Language Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Config Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Loader Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Controller Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:58:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:58:48 --> Session Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:58:48 --> Session routines successfully run
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:58:48 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:58:48 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:58:48 --> Model Class Initialized
DEBUG - 2013-11-25 07:58:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:58:48 --> Model Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:58:48 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:58:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:58:48 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:58:48 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:58:48 --> Model Class Initialized
DEBUG - 2013-11-25 07:58:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 07:58:48 --> DB Transaction Failure
ERROR - 2013-11-25 07:58:48 --> Query error: Unknown column 'c_details' in 'field list'
DEBUG - 2013-11-25 07:58:48 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 07:59:14 --> Config Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 07:59:14 --> URI Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Router Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Output Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Security Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Input Class Initialized
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> XSS Filtering completed
DEBUG - 2013-11-25 07:59:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 07:59:14 --> Language Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Language Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Config Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Loader Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Controller Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 07:59:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 07:59:14 --> Session Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 07:59:14 --> Session routines successfully run
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 07:59:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 07:59:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 07:59:14 --> Model Class Initialized
DEBUG - 2013-11-25 07:59:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 07:59:14 --> Model Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 07:59:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 07:59:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 07:59:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 07:59:14 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 07:59:14 --> Model Class Initialized
DEBUG - 2013-11-25 07:59:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:02:01 --> Config Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:02:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:02:01 --> URI Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Router Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Output Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Security Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Input Class Initialized
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:02:01 --> Language Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Language Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Config Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Loader Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Controller Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:02:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:02:01 --> Session Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:02:01 --> Session routines successfully run
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:02:01 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:02:01 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:02:01 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:02:01 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:02:01 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:02:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:02:01 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:02:01 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:02:01 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:02:53 --> Config Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:02:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:02:53 --> URI Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Router Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Output Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Security Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Input Class Initialized
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:02:53 --> Language Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Language Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Config Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Loader Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Controller Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:02:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:02:53 --> Session Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:02:53 --> Session routines successfully run
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:02:53 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:02:53 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:02:53 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:02:53 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:02:53 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:02:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:02:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:02:53 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:02:53 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:02:56 --> Config Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:02:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:02:56 --> URI Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Router Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Output Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Security Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Input Class Initialized
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:02:56 --> Language Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Language Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Config Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Loader Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Controller Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:02:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:02:56 --> Session Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:02:56 --> Session routines successfully run
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:02:56 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:02:56 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:02:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:02:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:02:56 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:02:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:02:56 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:02:56 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:02:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:02:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:05:04 --> Config Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:05:04 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:05:04 --> URI Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Router Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Output Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Security Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Input Class Initialized
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:05:04 --> Language Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Language Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Config Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Loader Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Controller Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:05:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:05:04 --> Session Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:05:04 --> Session routines successfully run
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:05:04 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:05:04 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:05:04 --> Model Class Initialized
DEBUG - 2013-11-25 08:05:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:05:04 --> Model Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:05:04 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:05:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:05:04 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:05:04 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:05:04 --> Model Class Initialized
DEBUG - 2013-11-25 08:05:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:05:52 --> Config Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:05:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:05:52 --> URI Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Router Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Output Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Security Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Input Class Initialized
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:05:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:05:52 --> Language Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Language Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Config Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Loader Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Controller Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:05:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:05:52 --> Session Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:05:52 --> Session routines successfully run
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:05:52 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:05:52 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:05:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:05:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:05:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:05:52 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:05:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:05:52 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:05:52 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:05:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:05:52 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:06:53 --> Config Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:06:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:06:53 --> URI Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Router Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Output Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Security Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Input Class Initialized
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> XSS Filtering completed
DEBUG - 2013-11-25 08:06:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:06:53 --> Language Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Language Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Config Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Loader Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Controller Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:06:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:06:53 --> Session Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:06:53 --> Session routines successfully run
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:06:53 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:06:53 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:06:53 --> Model Class Initialized
DEBUG - 2013-11-25 08:06:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:06:53 --> Model Class Initialized
DEBUG - 2013-11-25 08:06:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:06:53 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:06:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:06:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:14:33 --> Config Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:14:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:14:33 --> URI Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Router Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Output Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Security Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Input Class Initialized
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:14:33 --> Language Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Language Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Config Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Loader Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Controller Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:14:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:14:33 --> Session Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:14:33 --> Session routines successfully run
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:14:33 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:14:33 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:14:33 --> Model Class Initialized
DEBUG - 2013-11-25 08:14:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:14:33 --> Model Class Initialized
DEBUG - 2013-11-25 08:14:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:14:33 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:14:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:14:33 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:14:35 --> Config Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:14:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:14:35 --> URI Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Router Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Output Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Security Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Input Class Initialized
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:14:35 --> Language Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Language Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Config Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Loader Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Controller Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:14:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:14:35 --> Session Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:14:35 --> Session routines successfully run
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:14:35 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:14:35 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:14:35 --> Model Class Initialized
DEBUG - 2013-11-25 08:14:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:14:35 --> Model Class Initialized
DEBUG - 2013-11-25 08:14:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:14:35 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:14:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:14:35 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:14:55 --> Config Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:14:55 --> URI Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Router Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Output Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Security Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Input Class Initialized
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:14:55 --> Language Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Language Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Config Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Loader Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Controller Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:14:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:14:55 --> Session Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:14:55 --> Session routines successfully run
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:14:55 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:14:55 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:14:55 --> Model Class Initialized
DEBUG - 2013-11-25 08:14:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:14:55 --> Model Class Initialized
DEBUG - 2013-11-25 08:14:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:14:55 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:14:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:14:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:15:14 --> Config Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:15:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:15:14 --> URI Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Router Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Output Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Security Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Input Class Initialized
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:15:14 --> Language Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Language Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Config Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Loader Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Controller Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:15:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:15:14 --> Session Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:15:14 --> Session routines successfully run
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:15:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:15:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:15:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:15:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:15:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:15:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:15:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:15:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:15:14 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:15:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:15:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:15:22 --> Config Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:15:22 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:15:22 --> URI Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Router Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Output Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Security Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Input Class Initialized
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> XSS Filtering completed
DEBUG - 2013-11-25 08:15:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:15:22 --> Language Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Language Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Config Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Loader Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Controller Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:15:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:15:22 --> Session Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:15:22 --> Session routines successfully run
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:15:22 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:15:22 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:15:22 --> Model Class Initialized
DEBUG - 2013-11-25 08:15:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:15:22 --> Model Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:15:22 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:15:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:15:22 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:15:22 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:15:22 --> Model Class Initialized
DEBUG - 2013-11-25 08:15:22 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:16:58 --> Config Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:16:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:16:58 --> URI Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Router Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Output Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Security Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Input Class Initialized
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> XSS Filtering completed
DEBUG - 2013-11-25 08:16:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:16:58 --> Language Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Language Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Config Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Loader Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Controller Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:16:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:16:58 --> Session Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:16:58 --> Session routines successfully run
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:16:58 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:16:58 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:16:58 --> Model Class Initialized
DEBUG - 2013-11-25 08:16:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:16:58 --> Model Class Initialized
DEBUG - 2013-11-25 08:16:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:16:58 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:16:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:16:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:17:11 --> Config Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:17:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:17:11 --> URI Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Router Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Output Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Security Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Input Class Initialized
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:17:11 --> Language Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Language Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Config Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Loader Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Controller Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:17:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:17:11 --> Session Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:17:11 --> Session routines successfully run
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:17:11 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:17:11 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:17:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:17:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:17:11 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:17:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:17:11 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:17:11 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:17:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-11-25 08:17:11 --> Severity: Warning  --> array_pop() expects parameter 1 to be array, null given D:\xampp\htdocs\rentalportal\FusionInvoice\application\modules\users\models\mdl_users.php 266
DEBUG - 2013-11-25 08:17:49 --> Config Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:17:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:17:49 --> URI Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Router Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Output Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Security Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Input Class Initialized
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:17:49 --> Language Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Language Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Config Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Loader Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Controller Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:17:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:17:49 --> Session Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:17:49 --> Session routines successfully run
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:17:49 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:17:49 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:17:49 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:17:49 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:17:49 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:17:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:17:49 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:17:49 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:17:49 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:49 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-11-25 08:17:49 --> Severity: Warning  --> array_pop() expects parameter 1 to be array, null given D:\xampp\htdocs\rentalportal\FusionInvoice\application\modules\users\models\mdl_users.php 266
DEBUG - 2013-11-25 08:17:57 --> Config Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:17:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:17:57 --> URI Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Router Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Output Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Security Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Input Class Initialized
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> XSS Filtering completed
DEBUG - 2013-11-25 08:17:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:17:57 --> Language Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Language Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Config Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Loader Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Controller Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:17:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:17:57 --> Session Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:17:57 --> Session routines successfully run
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:17:57 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:17:57 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:17:57 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:17:57 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:17:57 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:17:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:17:57 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:17:57 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:17:57 --> Model Class Initialized
DEBUG - 2013-11-25 08:17:57 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:18:17 --> Config Class Initialized
DEBUG - 2013-11-25 08:18:17 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:18:17 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:18:17 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:18:17 --> URI Class Initialized
DEBUG - 2013-11-25 08:18:17 --> Router Class Initialized
DEBUG - 2013-11-25 08:18:17 --> Output Class Initialized
DEBUG - 2013-11-25 08:18:17 --> Security Class Initialized
DEBUG - 2013-11-25 08:18:17 --> Input Class Initialized
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:17 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:18:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:18:18 --> Language Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Language Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Config Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Loader Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Controller Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:18:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:18:18 --> Session Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:18:18 --> Session routines successfully run
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:18:18 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:18:18 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:18:18 --> Model Class Initialized
DEBUG - 2013-11-25 08:18:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:18:18 --> Model Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:18:18 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:18:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:18:18 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:18:18 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:18:18 --> Model Class Initialized
DEBUG - 2013-11-25 08:18:18 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-11-25 08:18:18 --> Severity: Warning  --> array_pop() expects parameter 1 to be array, null given D:\xampp\htdocs\rentalportal\FusionInvoice\application\modules\users\models\mdl_users.php 266
DEBUG - 2013-11-25 08:19:07 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:19:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:19:07 --> URI Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Router Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Output Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Security Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Input Class Initialized
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:19:07 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Loader Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Controller Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:19:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:19:07 --> Session Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:19:07 --> Session routines successfully run
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:19:07 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:19:07 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:19:07 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:19:07 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:19:07 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:19:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:19:07 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:19:07 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:19:07 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:19:11 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:19:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:19:11 --> URI Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Router Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Output Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Security Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Input Class Initialized
DEBUG - 2013-11-25 08:19:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:19:11 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Loader Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Controller Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:19:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:19:11 --> Session Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:19:11 --> Session routines successfully run
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:19:11 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:19:11 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:19:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:19:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:19:11 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:19:11 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:19:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 08:19:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 08:19:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 08:19:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 08:19:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 08:19:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 08:19:11 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 08:19:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 08:19:11 --> Final output sent to browser
DEBUG - 2013-11-25 08:19:11 --> Total execution time: 0.0875
DEBUG - 2013-11-25 08:19:15 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:19:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:19:15 --> URI Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Router Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Output Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Security Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Input Class Initialized
DEBUG - 2013-11-25 08:19:15 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:19:15 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Loader Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Controller Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:19:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:19:15 --> Session Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:19:15 --> Session routines successfully run
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:19:15 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:19:15 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:19:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:19:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:19:15 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:19:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:19:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 08:19:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 08:19:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 08:19:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 08:19:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 08:19:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 08:19:15 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 08:19:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 08:19:15 --> Final output sent to browser
DEBUG - 2013-11-25 08:19:15 --> Total execution time: 0.0704
DEBUG - 2013-11-25 08:19:18 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:19:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:19:18 --> URI Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Router Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Output Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Security Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Input Class Initialized
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:19:18 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Loader Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Controller Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:19:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:19:18 --> Session Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:19:18 --> Session routines successfully run
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:19:18 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:19:18 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:19:18 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:19:18 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:19:18 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:19:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:19:18 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:19:18 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:19:18 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:18 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:19:44 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:19:44 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:19:44 --> URI Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Router Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Output Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Security Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Input Class Initialized
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> XSS Filtering completed
DEBUG - 2013-11-25 08:19:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:19:44 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Language Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Config Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Loader Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Controller Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:19:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:19:44 --> Session Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:19:44 --> Session routines successfully run
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:19:44 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:19:44 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:19:44 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:19:44 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:19:44 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:19:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:19:44 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:19:44 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:19:44 --> Model Class Initialized
DEBUG - 2013-11-25 08:19:44 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:20:00 --> Config Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:20:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:20:00 --> URI Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Router Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Output Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Security Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Input Class Initialized
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:20:00 --> Language Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Language Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Config Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Loader Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Controller Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:20:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:20:00 --> Session Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:20:00 --> Session routines successfully run
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:20:00 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:20:00 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:20:00 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:20:00 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:20:00 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:20:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:20:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:20:00 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:20:00 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:00 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:20:10 --> Config Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:20:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:20:10 --> URI Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Router Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Output Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Security Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Input Class Initialized
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:20:10 --> Language Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Language Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Config Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Loader Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Controller Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:20:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:20:10 --> Session Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:20:10 --> Session routines successfully run
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:20:10 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:20:10 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:20:10 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:20:10 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:20:10 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:20:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:20:10 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:20:10 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:20:10 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:20:29 --> Config Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:20:29 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:20:29 --> URI Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Router Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Output Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Security Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Input Class Initialized
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:20:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:20:29 --> Language Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Language Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Config Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Loader Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Controller Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:20:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:20:29 --> Session Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:20:29 --> Session routines successfully run
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:20:29 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:20:29 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:20:29 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:20:29 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:20:29 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:20:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:20:29 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:20:29 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:20:29 --> Model Class Initialized
DEBUG - 2013-11-25 08:20:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:21:14 --> Config Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:21:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:21:14 --> URI Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Router Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Output Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Security Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Input Class Initialized
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:21:14 --> Language Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Language Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Config Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Loader Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Controller Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:21:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:21:14 --> Session Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:21:14 --> Session routines successfully run
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:21:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:21:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:21:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:21:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:21:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:21:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:21:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:21:14 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:21:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:14 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:21:26 --> Config Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:21:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:21:26 --> URI Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Router Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Output Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Security Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Input Class Initialized
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:21:26 --> Language Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Language Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Config Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Loader Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Controller Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:21:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:21:26 --> Session Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:21:26 --> Session routines successfully run
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:21:26 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:21:26 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:21:26 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:21:26 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:21:26 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:21:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:21:26 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:21:26 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:21:26 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:26 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:21:26 --> DB Transaction Failure
ERROR - 2013-11-25 08:21:26 --> Query error: Unknown column '0' in 'field list'
DEBUG - 2013-11-25 08:21:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:21:42 --> Config Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:21:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:21:42 --> URI Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Router Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Output Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Security Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Input Class Initialized
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> XSS Filtering completed
DEBUG - 2013-11-25 08:21:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:21:42 --> Language Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Language Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Config Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Loader Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Controller Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:21:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:21:42 --> Session Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:21:42 --> Session routines successfully run
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:21:42 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:21:42 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:21:42 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:21:42 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:21:42 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:21:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:21:42 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:21:42 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:21:42 --> Model Class Initialized
DEBUG - 2013-11-25 08:21:42 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:21:42 --> DB Transaction Failure
ERROR - 2013-11-25 08:21:42 --> Query error: Unknown column 'btn_submit' in 'field list'
DEBUG - 2013-11-25 08:21:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:23:13 --> Config Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:23:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:23:13 --> URI Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Router Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Output Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Security Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Input Class Initialized
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> XSS Filtering completed
DEBUG - 2013-11-25 08:23:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:23:13 --> Language Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Language Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Config Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Loader Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Controller Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:23:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:23:13 --> Session Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:23:13 --> Session routines successfully run
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:23:13 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:23:13 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:23:13 --> Model Class Initialized
DEBUG - 2013-11-25 08:23:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:23:13 --> Model Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:23:13 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:23:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:23:13 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:23:13 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:23:13 --> Model Class Initialized
DEBUG - 2013-11-25 08:23:13 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:29:29 --> Config Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:29:29 --> URI Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Router Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Output Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Security Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Input Class Initialized
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> XSS Filtering completed
DEBUG - 2013-11-25 08:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:29:29 --> Language Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Language Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Config Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Loader Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Controller Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:29:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:29:29 --> Session Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:29:29 --> Session routines successfully run
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:29:29 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:29:29 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:29:29 --> Model Class Initialized
DEBUG - 2013-11-25 08:29:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:29:29 --> Model Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:29:29 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:29:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:29:29 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:29:29 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:29:29 --> Model Class Initialized
DEBUG - 2013-11-25 08:29:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:29:29 --> DB Transaction Failure
ERROR - 2013-11-25 08:29:29 --> Query error: Unknown column 'fi_users.user_id' in 'where clause'
DEBUG - 2013-11-25 08:29:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:30:09 --> Config Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:30:09 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:30:09 --> URI Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Router Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Output Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Security Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Input Class Initialized
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:30:09 --> Language Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Language Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Config Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Loader Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Controller Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:30:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:30:09 --> Session Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:30:09 --> Session routines successfully run
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:30:09 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:30:09 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:30:09 --> Model Class Initialized
DEBUG - 2013-11-25 08:30:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:30:09 --> Model Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:30:09 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:30:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:30:09 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:30:09 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:30:09 --> Model Class Initialized
DEBUG - 2013-11-25 08:30:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:30:24 --> Config Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:30:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:30:24 --> URI Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Router Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Output Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Security Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Input Class Initialized
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:30:24 --> Language Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Language Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Config Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Loader Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Controller Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:30:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:30:24 --> Session Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:30:24 --> Session routines successfully run
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:30:24 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:30:24 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:30:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:30:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:30:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:30:24 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:30:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:30:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:30:24 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:30:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:30:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:30:24 --> DB Transaction Failure
ERROR - 2013-11-25 08:30:24 --> Query error: Unknown column 'fi_users.user_id' in 'where clause'
DEBUG - 2013-11-25 08:30:24 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:32:02 --> Config Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:32:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:32:02 --> URI Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Router Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Output Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Security Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Input Class Initialized
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> XSS Filtering completed
DEBUG - 2013-11-25 08:32:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:32:02 --> Language Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Language Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Config Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Loader Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Controller Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:32:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:32:02 --> Session Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:32:02 --> Session routines successfully run
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:32:02 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:32:02 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:32:02 --> Model Class Initialized
DEBUG - 2013-11-25 08:32:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:32:02 --> Model Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:32:02 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:32:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:32:02 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:32:02 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:32:02 --> Model Class Initialized
DEBUG - 2013-11-25 08:32:02 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:32:02 --> DB Transaction Failure
ERROR - 2013-11-25 08:32:02 --> Query error: Unknown column 'fi_company_details.vandor_id' in 'where clause'
DEBUG - 2013-11-25 08:32:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:33:55 --> Config Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:33:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:33:55 --> URI Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Router Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Output Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Security Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Input Class Initialized
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:33:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:33:55 --> Language Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Language Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Config Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Loader Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Controller Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:33:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:33:55 --> Session Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:33:55 --> Session routines successfully run
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:33:55 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:33:55 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:33:55 --> Model Class Initialized
DEBUG - 2013-11-25 08:33:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:33:55 --> Model Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:33:55 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:33:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:33:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:33:55 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:33:55 --> Model Class Initialized
DEBUG - 2013-11-25 08:33:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:33:55 --> DB Transaction Failure
ERROR - 2013-11-25 08:33:55 --> Query error: Unknown column 'fi_company_details.vandor_id' in 'where clause'
DEBUG - 2013-11-25 08:33:55 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:35:07 --> Config Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:35:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:35:07 --> URI Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Router Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Output Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Security Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Input Class Initialized
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:35:07 --> Language Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Language Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Config Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Loader Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Controller Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:35:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:35:07 --> Session Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:35:07 --> Session routines successfully run
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:35:07 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:35:07 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:35:07 --> Model Class Initialized
DEBUG - 2013-11-25 08:35:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:35:07 --> Model Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:35:07 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:35:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:35:07 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:35:07 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:35:07 --> Model Class Initialized
DEBUG - 2013-11-25 08:35:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:35:07 --> DB Transaction Failure
ERROR - 2013-11-25 08:35:07 --> Query error: Unknown column 'fi_company_details.vandor_id' in 'where clause'
DEBUG - 2013-11-25 08:35:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:35:56 --> Config Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:35:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:35:56 --> URI Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Router Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Output Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Security Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Input Class Initialized
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> XSS Filtering completed
DEBUG - 2013-11-25 08:35:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:35:56 --> Language Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Language Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Config Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Loader Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Controller Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:35:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:35:56 --> Session Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:35:56 --> Session routines successfully run
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:35:56 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:35:56 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:35:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:35:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:35:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:35:56 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:35:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:35:56 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:35:56 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:35:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:35:56 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:36:11 --> Config Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:36:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:36:11 --> URI Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Router Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Output Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Security Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Input Class Initialized
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:36:11 --> Language Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Language Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Config Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Loader Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Controller Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:36:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:36:11 --> Session Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:36:11 --> Session routines successfully run
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:36:11 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:36:11 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:36:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:36:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:36:11 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:36:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 08:36:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Config Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:36:11 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:36:11 --> URI Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Router Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Output Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Security Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Input Class Initialized
DEBUG - 2013-11-25 08:36:11 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:36:11 --> Language Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Language Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Config Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Loader Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Controller Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:36:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:36:11 --> Session Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:36:11 --> Session routines successfully run
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:36:11 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:36:11 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:36:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:36:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:36:11 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:36:11 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:36:11 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:11 --> Pagination Class Initialized
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 08:36:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 08:36:11 --> Final output sent to browser
DEBUG - 2013-11-25 08:36:11 --> Total execution time: 0.0526
DEBUG - 2013-11-25 08:36:14 --> Config Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:36:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:36:14 --> URI Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Router Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Output Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Security Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Input Class Initialized
DEBUG - 2013-11-25 08:36:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:36:14 --> Language Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Language Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Config Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Loader Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Controller Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:36:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:36:14 --> Session Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:36:14 --> Session routines successfully run
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:36:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:36:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:36:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:36:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:36:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:36:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:36:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 08:36:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 08:36:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 08:36:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 08:36:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 08:36:14 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 08:36:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 08:36:14 --> Final output sent to browser
DEBUG - 2013-11-25 08:36:14 --> Total execution time: 0.0743
DEBUG - 2013-11-25 08:37:04 --> Config Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:37:04 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:37:04 --> URI Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Router Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Output Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Security Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Input Class Initialized
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> XSS Filtering completed
DEBUG - 2013-11-25 08:37:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:37:04 --> Language Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Language Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Config Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Loader Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Controller Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:37:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:37:04 --> Session Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:37:04 --> Session routines successfully run
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:37:04 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:37:04 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:37:04 --> Model Class Initialized
DEBUG - 2013-11-25 08:37:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:37:04 --> Model Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:37:04 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:37:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:37:04 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:37:04 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:37:04 --> Model Class Initialized
DEBUG - 2013-11-25 08:37:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:37:04 --> DB Transaction Failure
ERROR - 2013-11-25 08:37:04 --> Query error: Unknown column 'user_passwordv' in 'field list'
DEBUG - 2013-11-25 08:37:04 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:40:46 --> Config Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:40:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:40:46 --> URI Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Router Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Output Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Security Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Input Class Initialized
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 08:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:40:46 --> Language Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Language Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Config Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Loader Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Controller Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:40:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:40:46 --> Session Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:40:46 --> Session routines successfully run
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:40:46 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:40:46 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 08:40:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:40:46 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:40:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:40:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:40:46 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 08:40:46 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:40:47 --> DB Transaction Failure
ERROR - 2013-11-25 08:40:47 --> Query error: Unknown column 'user_date_created' in 'field list'
DEBUG - 2013-11-25 08:40:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 08:41:14 --> Config Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:41:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:41:14 --> URI Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Router Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Output Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Security Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Input Class Initialized
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:41:14 --> Language Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Language Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Config Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Loader Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Controller Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:41:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:41:14 --> Session Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:41:14 --> Session routines successfully run
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:41:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:41:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:41:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:41:14 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:41:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:41:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:41:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:41:15 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:41:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 08:41:15 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 08:41:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Config Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:41:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:41:15 --> URI Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Router Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Output Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Security Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Input Class Initialized
DEBUG - 2013-11-25 08:41:15 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:41:15 --> Language Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Language Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Config Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Loader Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Controller Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:41:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:41:15 --> Session Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:41:15 --> Session routines successfully run
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:41:15 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:41:15 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:41:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:41:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:41:15 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:41:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:41:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:41:15 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:41:15 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:15 --> Pagination Class Initialized
DEBUG - 2013-11-25 08:41:15 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 08:41:15 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 08:41:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 08:41:15 --> Final output sent to browser
DEBUG - 2013-11-25 08:41:15 --> Total execution time: 0.0670
DEBUG - 2013-11-25 08:41:23 --> Config Class Initialized
DEBUG - 2013-11-25 08:41:23 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:41:23 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:41:23 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:41:24 --> URI Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Router Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Output Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Security Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Input Class Initialized
DEBUG - 2013-11-25 08:41:24 --> XSS Filtering completed
DEBUG - 2013-11-25 08:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:41:24 --> Language Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Language Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Config Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Loader Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Controller Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:41:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:41:24 --> Session Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:41:24 --> Session routines successfully run
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:41:24 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:41:24 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:41:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:41:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:41:24 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:41:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:41:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 08:41:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 08:41:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 08:41:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 08:41:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 08:41:24 --> Model Class Initialized
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 08:41:24 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 08:41:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 08:41:24 --> Final output sent to browser
DEBUG - 2013-11-25 08:41:24 --> Total execution time: 0.0890
DEBUG - 2013-11-25 08:44:52 --> Config Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:44:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:44:52 --> URI Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Router Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Output Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Security Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Input Class Initialized
DEBUG - 2013-11-25 08:44:52 --> XSS Filtering completed
DEBUG - 2013-11-25 08:44:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:44:52 --> Language Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Language Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Config Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Loader Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Controller Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:44:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:44:52 --> Session Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:44:52 --> Session routines successfully run
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:44:52 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:44:52 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:44:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:44:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:44:52 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:44:52 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:44:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 08:44:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 08:44:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 08:44:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 08:44:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 08:44:52 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 08:44:52 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 08:44:52 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 08:44:52 --> Final output sent to browser
DEBUG - 2013-11-25 08:44:52 --> Total execution time: 0.0826
DEBUG - 2013-11-25 08:44:55 --> Config Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Hooks Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Utf8 Class Initialized
DEBUG - 2013-11-25 08:44:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 08:44:55 --> URI Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Router Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Output Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Security Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Input Class Initialized
DEBUG - 2013-11-25 08:44:55 --> XSS Filtering completed
DEBUG - 2013-11-25 08:44:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 08:44:55 --> Language Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Language Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Config Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Loader Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Controller Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 08:44:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 08:44:55 --> Session Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: string_helper
DEBUG - 2013-11-25 08:44:55 --> Session routines successfully run
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: url_helper
DEBUG - 2013-11-25 08:44:55 --> Database Driver Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: form_helper
DEBUG - 2013-11-25 08:44:55 --> Form Validation Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: number_helper
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: date_helper
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 08:44:55 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 08:44:55 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 08:44:55 --> Helper loaded: language_helper
DEBUG - 2013-11-25 08:44:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 08:44:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 08:44:55 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 08:44:55 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:55 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 08:44:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 08:44:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 08:44:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 08:44:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 08:44:56 --> Model Class Initialized
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 08:44:56 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 08:44:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 08:44:56 --> Final output sent to browser
DEBUG - 2013-11-25 08:44:56 --> Total execution time: 0.0683
DEBUG - 2013-11-25 09:38:52 --> Config Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:38:52 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:38:52 --> URI Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Router Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Output Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Security Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Input Class Initialized
DEBUG - 2013-11-25 09:38:52 --> XSS Filtering completed
DEBUG - 2013-11-25 09:38:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:38:52 --> Language Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Language Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Config Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Loader Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Controller Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:38:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:38:52 --> Session Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:38:52 --> Session routines successfully run
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:38:52 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:38:52 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:38:52 --> Model Class Initialized
DEBUG - 2013-11-25 09:38:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:38:52 --> Model Class Initialized
DEBUG - 2013-11-25 09:38:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:38:52 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:38:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:38:52 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:38:52 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:38:52 --> Model Class Initialized
DEBUG - 2013-11-25 09:38:52 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:38:52 --> Model Class Initialized
DEBUG - 2013-11-25 09:38:52 --> DB Transaction Failure
ERROR - 2013-11-25 09:38:52 --> Query error: Unknown column 'vandor_id' in 'where clause'
DEBUG - 2013-11-25 09:38:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 09:39:02 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:39:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:39:02 --> URI Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Router Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Output Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Security Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Input Class Initialized
DEBUG - 2013-11-25 09:39:02 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:39:02 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Loader Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Controller Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:39:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:39:02 --> Session Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:39:02 --> Session routines successfully run
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:39:02 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:39:02 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:39:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:39:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:39:02 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:39:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:39:02 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:39:02 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:39:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:02 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:39:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:02 --> DB Transaction Failure
ERROR - 2013-11-25 09:39:02 --> Query error: Unknown column 'vandor_id' in 'where clause'
DEBUG - 2013-11-25 09:39:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 09:39:12 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:39:12 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:39:12 --> URI Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Router Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Output Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Security Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Input Class Initialized
DEBUG - 2013-11-25 09:39:12 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:39:12 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Loader Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Controller Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:39:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:39:12 --> Session Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:39:12 --> Session routines successfully run
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:39:12 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:39:12 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:39:12 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:39:12 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:39:12 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:39:12 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:39:12 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:39:12 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:39:12 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:39:12 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:39:12 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 09:39:12 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 09:39:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:39:12 --> Final output sent to browser
DEBUG - 2013-11-25 09:39:12 --> Total execution time: 0.0691
DEBUG - 2013-11-25 09:39:48 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:39:48 --> URI Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Router Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Output Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Security Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Input Class Initialized
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:39:48 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Loader Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Controller Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:39:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:39:48 --> Session Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:39:48 --> Session routines successfully run
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:39:48 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:39:48 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:39:48 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:39:48 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:39:48 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:39:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:39:48 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:39:48 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:39:48 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 09:39:48 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:39:48 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:39:48 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:39:48 --> URI Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Router Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Output Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Security Class Initialized
DEBUG - 2013-11-25 09:39:48 --> Input Class Initialized
DEBUG - 2013-11-25 09:39:48 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:39:48 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Loader Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Controller Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:39:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:39:49 --> Session Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:39:49 --> Session routines successfully run
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:39:49 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:39:49 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:39:49 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:39:49 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:39:49 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:39:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:39:49 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:39:49 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:39:49 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:49 --> Pagination Class Initialized
DEBUG - 2013-11-25 09:39:49 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 09:39:49 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 09:39:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:39:49 --> Final output sent to browser
DEBUG - 2013-11-25 09:39:49 --> Total execution time: 0.0499
DEBUG - 2013-11-25 09:39:54 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:39:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:39:54 --> URI Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Router Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Output Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Security Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Input Class Initialized
DEBUG - 2013-11-25 09:39:54 --> XSS Filtering completed
DEBUG - 2013-11-25 09:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:39:54 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Language Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Config Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Loader Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Controller Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:39:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:39:54 --> Session Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:39:54 --> Session routines successfully run
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:39:54 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:39:54 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:39:54 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:39:54 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:39:54 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:39:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:39:54 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:39:54 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:39:54 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:54 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:39:54 --> Model Class Initialized
DEBUG - 2013-11-25 09:39:54 --> DB Transaction Failure
ERROR - 2013-11-25 09:39:54 --> Query error: Unknown column 'vandor_id' in 'where clause'
DEBUG - 2013-11-25 09:39:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 09:40:42 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:40:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:40:42 --> URI Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Router Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Output Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Security Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Input Class Initialized
DEBUG - 2013-11-25 09:40:42 --> XSS Filtering completed
DEBUG - 2013-11-25 09:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:40:42 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Loader Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Controller Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:40:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:40:42 --> Session Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:40:42 --> Session routines successfully run
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:40:42 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:40:42 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:40:42 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:40:42 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:40:42 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:40:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:40:42 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:40:42 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:40:42 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:42 --> Pagination Class Initialized
DEBUG - 2013-11-25 09:40:42 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 09:40:42 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 09:40:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:40:42 --> Final output sent to browser
DEBUG - 2013-11-25 09:40:42 --> Total execution time: 0.0835
DEBUG - 2013-11-25 09:40:46 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:40:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:40:46 --> URI Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Router Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Output Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Security Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Input Class Initialized
DEBUG - 2013-11-25 09:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 09:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:40:46 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Loader Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Controller Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:40:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:40:46 --> Session Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:40:46 --> Session routines successfully run
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:40:46 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:40:46 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:40:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: orphan_helper
DEBUG - 2013-11-25 09:40:46 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:40:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:40:46 --> URI Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Router Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Output Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Security Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Input Class Initialized
DEBUG - 2013-11-25 09:40:46 --> XSS Filtering completed
DEBUG - 2013-11-25 09:40:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:40:46 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Loader Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Controller Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:40:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:40:46 --> Session Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:40:46 --> Session routines successfully run
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:40:46 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:40:46 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:40:46 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:40:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:40:46 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:46 --> Pagination Class Initialized
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 09:40:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:40:46 --> Final output sent to browser
DEBUG - 2013-11-25 09:40:46 --> Total execution time: 0.0907
DEBUG - 2013-11-25 09:40:51 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:40:51 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:40:51 --> URI Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Router Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Output Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Security Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Input Class Initialized
DEBUG - 2013-11-25 09:40:51 --> XSS Filtering completed
DEBUG - 2013-11-25 09:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:40:51 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Loader Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Controller Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:40:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:40:51 --> Session Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:40:51 --> Session routines successfully run
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:40:51 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:40:51 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:40:51 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:40:51 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:40:51 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:40:51 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: orphan_helper
DEBUG - 2013-11-25 09:40:51 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:40:51 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:40:51 --> URI Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Router Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Output Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Security Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Input Class Initialized
DEBUG - 2013-11-25 09:40:51 --> XSS Filtering completed
DEBUG - 2013-11-25 09:40:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:40:51 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Loader Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Controller Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:40:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:40:51 --> Session Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:40:51 --> Session routines successfully run
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:40:51 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:40:51 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:40:51 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:40:51 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:40:51 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:40:51 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:40:51 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:51 --> Pagination Class Initialized
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 09:40:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:40:51 --> Final output sent to browser
DEBUG - 2013-11-25 09:40:51 --> Total execution time: 0.0642
DEBUG - 2013-11-25 09:40:55 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:40:55 --> URI Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Router Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Output Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Security Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Input Class Initialized
DEBUG - 2013-11-25 09:40:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:40:55 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Loader Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Controller Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:40:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:40:55 --> Session Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:40:55 --> Session routines successfully run
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:40:55 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:40:55 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:40:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:40:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:40:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:40:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: orphan_helper
DEBUG - 2013-11-25 09:40:55 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:40:55 --> URI Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Router Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Output Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Security Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Input Class Initialized
DEBUG - 2013-11-25 09:40:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:40:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:40:55 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Language Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Config Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Loader Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Controller Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:40:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:40:55 --> Session Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:40:55 --> Session routines successfully run
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:40:55 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:40:55 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:40:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:40:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:40:55 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:40:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:40:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:40:55 --> Pagination Class Initialized
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 09:40:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:40:55 --> Final output sent to browser
DEBUG - 2013-11-25 09:40:55 --> Total execution time: 0.0541
DEBUG - 2013-11-25 09:41:00 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:41:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:41:00 --> URI Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Router Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Output Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Security Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Input Class Initialized
DEBUG - 2013-11-25 09:41:00 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:41:00 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Loader Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Controller Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:41:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:41:00 --> Session Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:41:00 --> Session routines successfully run
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:41:00 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:41:00 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:41:00 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:41:00 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:41:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:41:00 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: orphan_helper
DEBUG - 2013-11-25 09:41:00 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:41:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:41:00 --> URI Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Router Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Output Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Security Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Input Class Initialized
DEBUG - 2013-11-25 09:41:00 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:41:00 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Loader Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Controller Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:41:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:41:00 --> Session Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:41:00 --> Session routines successfully run
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:41:00 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:41:00 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:41:00 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:41:00 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:41:00 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:41:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:41:00 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:00 --> Pagination Class Initialized
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 09:41:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:41:00 --> Final output sent to browser
DEBUG - 2013-11-25 09:41:00 --> Total execution time: 0.0906
DEBUG - 2013-11-25 09:41:02 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:41:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:41:02 --> URI Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Router Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Output Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Security Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Input Class Initialized
DEBUG - 2013-11-25 09:41:02 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:41:02 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Loader Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Controller Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:41:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:41:02 --> Session Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:41:02 --> Session routines successfully run
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:41:02 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:41:02 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:41:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:41:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:41:02 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:41:02 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:41:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:41:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:41:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:41:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:41:02 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 09:41:02 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 09:41:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:41:02 --> Final output sent to browser
DEBUG - 2013-11-25 09:41:02 --> Total execution time: 0.0668
DEBUG - 2013-11-25 09:41:50 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:41:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:41:50 --> URI Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Router Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Output Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Security Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Input Class Initialized
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:41:50 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Loader Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Controller Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:41:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:41:50 --> Session Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:41:50 --> Session routines successfully run
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:41:50 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:41:50 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:41:50 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:41:50 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:41:50 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:41:50 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:41:50 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:41:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:41:50 --> URI Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Router Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Output Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Security Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Input Class Initialized
DEBUG - 2013-11-25 09:41:50 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:41:50 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Loader Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Controller Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:41:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:41:50 --> Session Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:41:50 --> Session routines successfully run
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:41:50 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:41:50 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:41:50 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:41:50 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:41:50 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:41:50 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:41:50 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:50 --> Pagination Class Initialized
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 09:41:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:41:50 --> Final output sent to browser
DEBUG - 2013-11-25 09:41:50 --> Total execution time: 0.0485
DEBUG - 2013-11-25 09:41:54 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:41:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:41:54 --> URI Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Router Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Output Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Security Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Input Class Initialized
DEBUG - 2013-11-25 09:41:54 --> XSS Filtering completed
DEBUG - 2013-11-25 09:41:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:41:54 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Language Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Config Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Loader Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Controller Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:41:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:41:54 --> Session Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:41:54 --> Session routines successfully run
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:41:54 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:41:54 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:41:54 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:41:54 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:41:54 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:41:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:41:54 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:41:54 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:41:54 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:54 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:41:54 --> Model Class Initialized
DEBUG - 2013-11-25 09:41:54 --> DB Transaction Failure
ERROR - 2013-11-25 09:41:54 --> Query error: Unknown column 'vandor_id' in 'where clause'
DEBUG - 2013-11-25 09:41:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-25 09:42:24 --> Config Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:42:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:42:24 --> URI Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Router Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Output Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Security Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Input Class Initialized
DEBUG - 2013-11-25 09:42:24 --> XSS Filtering completed
DEBUG - 2013-11-25 09:42:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:42:24 --> Language Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Language Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Config Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Loader Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Controller Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:42:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:42:24 --> Session Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:42:24 --> Session routines successfully run
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:42:24 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:42:24 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:42:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:42:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:42:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:42:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:42:24 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:42:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:42:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:42:24 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:42:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:42:24 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:42:24 --> Model Class Initialized
ERROR - 2013-11-25 09:42:24 --> Severity: Notice  --> Undefined variable: user_custom D:\xampp\htdocs\rentalportal\FusionInvoice\application\modules\custom_fields\models\mdl_user_custom.php 49
DEBUG - 2013-11-25 09:42:36 --> Config Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:42:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:42:36 --> URI Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Router Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Output Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Security Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Input Class Initialized
DEBUG - 2013-11-25 09:42:36 --> XSS Filtering completed
DEBUG - 2013-11-25 09:42:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:42:36 --> Language Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Language Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Config Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Loader Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Controller Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:42:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:42:36 --> Session Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:42:36 --> Session routines successfully run
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:42:36 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:42:36 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:42:36 --> Model Class Initialized
DEBUG - 2013-11-25 09:42:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:42:36 --> Model Class Initialized
DEBUG - 2013-11-25 09:42:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:42:36 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:42:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:42:36 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:42:36 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:42:36 --> Model Class Initialized
DEBUG - 2013-11-25 09:42:36 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:42:36 --> Model Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Config Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:43:59 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:43:59 --> URI Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Router Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Output Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Security Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Input Class Initialized
DEBUG - 2013-11-25 09:43:59 --> XSS Filtering completed
DEBUG - 2013-11-25 09:43:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:43:59 --> Language Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Language Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Config Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Loader Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Controller Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:43:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:43:59 --> Session Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:43:59 --> Session routines successfully run
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:43:59 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:43:59 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:43:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:43:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:43:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:43:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:43:59 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:43:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:43:59 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:43:59 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:43:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:43:59 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:43:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Config Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:44:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:44:18 --> URI Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Router Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Output Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Security Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Input Class Initialized
DEBUG - 2013-11-25 09:44:18 --> XSS Filtering completed
DEBUG - 2013-11-25 09:44:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:44:18 --> Language Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Language Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Config Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Loader Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Controller Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:44:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:44:18 --> Session Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:44:18 --> Session routines successfully run
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:44:18 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:44:18 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:44:18 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:44:18 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:44:18 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:44:18 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:44:18 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:44:18 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:44:18 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:44:18 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:44:18 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:44:18 --> Model Class Initialized
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 09:44:18 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 09:44:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:44:18 --> Final output sent to browser
DEBUG - 2013-11-25 09:44:18 --> Total execution time: 0.0587
DEBUG - 2013-11-25 09:45:14 --> Config Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:45:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:45:14 --> URI Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Router Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Output Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Security Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Input Class Initialized
DEBUG - 2013-11-25 09:45:14 --> XSS Filtering completed
DEBUG - 2013-11-25 09:45:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:45:14 --> Language Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Language Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Config Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Loader Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Controller Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:45:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:45:14 --> Session Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:45:14 --> Session routines successfully run
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:45:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:45:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:45:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:45:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:45:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:45:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:45:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:45:14 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:45:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:14 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:45:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:14 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:45:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:14 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:45:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:14 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:45:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:14 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:45:14 --> Model Class Initialized
ERROR - 2013-11-25 09:45:14 --> Severity: Notice  --> Undefined property: CI::$form_value D:\xampp\htdocs\rentalportal\FusionInvoice\system\core\Model.php 51
DEBUG - 2013-11-25 09:45:19 --> Config Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:45:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:45:19 --> URI Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Router Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Output Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Security Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Input Class Initialized
DEBUG - 2013-11-25 09:45:19 --> XSS Filtering completed
DEBUG - 2013-11-25 09:45:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:45:19 --> Language Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Language Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Config Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Loader Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Controller Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:45:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:45:19 --> Session Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:45:19 --> Session routines successfully run
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:45:19 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:45:19 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:45:19 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:45:19 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:45:19 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:45:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:45:19 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:45:19 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:45:19 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:19 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:45:19 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:19 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:45:19 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:19 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:45:19 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:19 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:45:19 --> Model Class Initialized
DEBUG - 2013-11-25 09:45:19 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:45:19 --> Model Class Initialized
ERROR - 2013-11-25 09:45:19 --> Severity: Warning  --> Missing argument 1 for MY_Model::form_value(), called in D:\xampp\htdocs\rentalportal\FusionInvoice\application\modules\users\controllers\users.php on line 125 and defined D:\xampp\htdocs\rentalportal\FusionInvoice\application\core\MY_Model.php 402
ERROR - 2013-11-25 09:45:19 --> Severity: Notice  --> Undefined variable: key D:\xampp\htdocs\rentalportal\FusionInvoice\application\core\MY_Model.php 404
DEBUG - 2013-11-25 09:46:07 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:46:07 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:46:07 --> URI Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Router Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Output Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Security Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Input Class Initialized
DEBUG - 2013-11-25 09:46:07 --> XSS Filtering completed
DEBUG - 2013-11-25 09:46:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:46:07 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Loader Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Controller Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:46:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:46:07 --> Session Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:46:07 --> Session routines successfully run
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:46:07 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:46:07 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:46:07 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:46:07 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:46:07 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:46:07 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:46:07 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:46:07 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:46:07 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:46:07 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:46:07 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:46:07 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:46:07 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:46:14 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:46:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:46:14 --> URI Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Router Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Output Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Security Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Input Class Initialized
DEBUG - 2013-11-25 09:46:14 --> XSS Filtering completed
DEBUG - 2013-11-25 09:46:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:46:14 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Loader Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Controller Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:46:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:46:14 --> Session Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:46:14 --> Session routines successfully run
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:46:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:46:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:46:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:46:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:46:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:46:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:46:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:46:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:46:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:46:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:46:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:46:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:46:14 --> File loaded: application/modules/users/views/modal_user_client.php
ERROR - 2013-11-25 09:46:14 --> Severity: Warning  --> Missing argument 1 for MY_Model::form_value(), called in D:\xampp\htdocs\rentalportal\FusionInvoice\application\modules\users\views\form.php on line 8 and defined D:\xampp\htdocs\rentalportal\FusionInvoice\application\core\MY_Model.php 402
ERROR - 2013-11-25 09:46:14 --> Severity: Notice  --> Undefined variable: key D:\xampp\htdocs\rentalportal\FusionInvoice\application\core\MY_Model.php 404
DEBUG - 2013-11-25 09:46:27 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:46:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:46:27 --> URI Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Router Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Output Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Security Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Input Class Initialized
DEBUG - 2013-11-25 09:46:27 --> XSS Filtering completed
DEBUG - 2013-11-25 09:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:46:27 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Loader Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Controller Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:46:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:46:27 --> Session Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:46:27 --> Session routines successfully run
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:46:27 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:46:27 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:46:27 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:46:27 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:46:27 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:46:27 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:46:27 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:46:27 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:46:27 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:46:27 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:46:27 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:46:27 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:46:27 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:46:27 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:46:27 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:46:27 --> URI Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Router Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Output Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Security Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Input Class Initialized
DEBUG - 2013-11-25 09:46:27 --> XSS Filtering completed
DEBUG - 2013-11-25 09:46:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:46:27 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Loader Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Controller Class Initialized
DEBUG - 2013-11-25 09:46:27 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:46:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:46:28 --> Session Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:46:28 --> Session routines successfully run
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:46:28 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:46:28 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:46:28 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:46:28 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:46:28 --> URI Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Router Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Output Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Security Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Input Class Initialized
DEBUG - 2013-11-25 09:46:28 --> XSS Filtering completed
DEBUG - 2013-11-25 09:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:46:28 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Loader Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Controller Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:46:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:46:28 --> Session Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:46:28 --> Session routines successfully run
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:46:28 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:46:28 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:46:28 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:46:28 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:46:28 --> URI Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Router Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Output Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Security Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Input Class Initialized
DEBUG - 2013-11-25 09:46:28 --> XSS Filtering completed
DEBUG - 2013-11-25 09:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:46:28 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Loader Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Controller Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:46:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:46:28 --> Session Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:46:28 --> Session routines successfully run
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:46:28 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:46:28 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:46:28 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:46:28 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:46:28 --> URI Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Router Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Output Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Security Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Input Class Initialized
DEBUG - 2013-11-25 09:46:28 --> XSS Filtering completed
DEBUG - 2013-11-25 09:46:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:46:28 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Loader Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Controller Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:46:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:46:28 --> Session Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:46:28 --> Session routines successfully run
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:46:28 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:46:28 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:46:28 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:46:28 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:46:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:46:28 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:46:46 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:46:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:46:46 --> URI Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Router Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Output Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Security Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Input Class Initialized
DEBUG - 2013-11-25 09:46:46 --> XSS Filtering completed
DEBUG - 2013-11-25 09:46:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:46:46 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Language Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Config Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Loader Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Controller Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:46:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:46:46 --> Session Class Initialized
DEBUG - 2013-11-25 09:46:46 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:46:46 --> Session routines successfully run
DEBUG - 2013-11-25 09:46:46 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:46:46 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:46:47 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:46:47 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:46:47 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:46:47 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:46:47 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:46:47 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:46:47 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:46:47 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:46:47 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:46:47 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:46:47 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:46:47 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:46:47 --> Model Class Initialized
ERROR - 2013-11-25 09:46:47 --> Severity: Notice  --> Undefined variable: company_fields D:\xampp\htdocs\rentalportal\FusionInvoice\application\modules\users\controllers\users.php 75
ERROR - 2013-11-25 09:46:47 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\rentalportal\FusionInvoice\application\modules\users\controllers\users.php 75
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:46:47 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:46:47 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:46:47 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:46:47 --> Model Class Initialized
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:46:47 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:47:03 --> Config Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:47:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:47:03 --> URI Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Router Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Output Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Security Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Input Class Initialized
DEBUG - 2013-11-25 09:47:03 --> XSS Filtering completed
DEBUG - 2013-11-25 09:47:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:47:03 --> Language Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Language Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Config Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Loader Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Controller Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:47:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:47:03 --> Session Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:47:03 --> Session routines successfully run
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:47:03 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:47:03 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:47:03 --> Model Class Initialized
DEBUG - 2013-11-25 09:47:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:47:03 --> Model Class Initialized
DEBUG - 2013-11-25 09:47:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:47:03 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:47:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:47:03 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:47:03 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:47:03 --> Model Class Initialized
DEBUG - 2013-11-25 09:47:03 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:47:03 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Config Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:48:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:48:14 --> URI Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Router Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Output Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Security Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Input Class Initialized
DEBUG - 2013-11-25 09:48:14 --> XSS Filtering completed
DEBUG - 2013-11-25 09:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:48:14 --> Language Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Language Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Config Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Loader Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Controller Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:48:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:48:14 --> Session Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:48:14 --> Session routines successfully run
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:48:14 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:48:14 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:48:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:48:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:48:14 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:48:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:48:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:48:14 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:48:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:14 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:48:14 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Config Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:48:26 --> URI Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Router Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Output Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Security Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Input Class Initialized
DEBUG - 2013-11-25 09:48:26 --> XSS Filtering completed
DEBUG - 2013-11-25 09:48:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:48:26 --> Language Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Language Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Config Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Loader Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Controller Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:48:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:48:26 --> Session Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:48:26 --> Session routines successfully run
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:48:26 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:48:26 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:48:26 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:48:26 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:48:26 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:48:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:48:26 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:48:26 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:48:26 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:26 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:48:26 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Config Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:48:44 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:48:44 --> URI Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Router Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Output Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Security Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Input Class Initialized
DEBUG - 2013-11-25 09:48:44 --> XSS Filtering completed
DEBUG - 2013-11-25 09:48:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:48:44 --> Language Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Language Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Config Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Loader Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Controller Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:48:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:48:44 --> Session Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:48:44 --> Session routines successfully run
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:48:44 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:48:44 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:48:44 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:48:44 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:48:44 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:48:44 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:48:44 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:48:44 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:48:44 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:48:44 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:48:44 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:48:44 --> Model Class Initialized
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:48:44 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:49:28 --> Config Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:49:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:49:28 --> URI Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Router Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Output Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Security Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Input Class Initialized
DEBUG - 2013-11-25 09:49:28 --> XSS Filtering completed
DEBUG - 2013-11-25 09:49:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:49:28 --> Language Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Language Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Config Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Loader Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Controller Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:49:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:49:28 --> Session Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:49:28 --> Session routines successfully run
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:49:28 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:49:28 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:49:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:49:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:49:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:49:28 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:49:28 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:49:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:49:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:49:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:49:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:49:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:49:28 --> Model Class Initialized
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:49:28 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:50:24 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:50:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:50:24 --> URI Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Router Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Output Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Security Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Input Class Initialized
DEBUG - 2013-11-25 09:50:24 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:50:24 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Loader Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Controller Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:50:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:50:24 --> Session Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:50:24 --> Session routines successfully run
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:50:24 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:50:24 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:50:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:50:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:50:24 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:50:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:50:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:50:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:50:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:50:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:50:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:50:24 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:50:24 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:50:25 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:50:25 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:50:25 --> URI Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Router Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Output Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Security Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Input Class Initialized
DEBUG - 2013-11-25 09:50:25 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:50:25 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Loader Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Controller Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:50:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:50:25 --> Session Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:50:25 --> Session routines successfully run
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:50:25 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:50:25 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:50:25 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:50:25 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:50:25 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:50:25 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:50:25 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:50:25 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:50:25 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:50:25 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:50:25 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:50:25 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:50:25 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:50:31 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:50:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:50:31 --> URI Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Router Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Output Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Security Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Input Class Initialized
DEBUG - 2013-11-25 09:50:31 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:50:31 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Loader Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Controller Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:50:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:50:31 --> Session Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:50:31 --> Session routines successfully run
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:50:31 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:50:31 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:50:31 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:50:31 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:50:31 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:50:31 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:50:31 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:50:31 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:50:31 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:50:31 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:50:31 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:50:31 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:50:31 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:50:41 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:50:41 --> URI Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Router Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Output Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Security Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Input Class Initialized
DEBUG - 2013-11-25 09:50:41 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:50:41 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Loader Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Controller Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:50:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:50:41 --> Session Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:50:41 --> Session routines successfully run
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:50:41 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:50:41 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:50:41 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:50:41 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:50:41 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:50:41 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:50:41 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:50:41 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:50:41 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:50:41 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:50:41 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:50:41 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 09:50:41 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 09:50:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:50:41 --> Final output sent to browser
DEBUG - 2013-11-25 09:50:41 --> Total execution time: 0.0698
DEBUG - 2013-11-25 09:50:55 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:50:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:50:55 --> URI Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Router Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Output Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Security Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Input Class Initialized
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:50:55 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Loader Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Controller Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:50:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:50:55 --> Session Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:50:55 --> Session routines successfully run
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:50:55 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:50:55 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:50:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:50:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:50:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:50:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:50:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:50:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:50:55 --> URI Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Router Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Output Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Security Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Input Class Initialized
DEBUG - 2013-11-25 09:50:55 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:50:55 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Loader Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Controller Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:50:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:50:55 --> Session Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:50:55 --> Session routines successfully run
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:50:55 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:50:55 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:50:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:50:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:50:55 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:50:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:50:55 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:55 --> Pagination Class Initialized
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-25 09:50:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:50:55 --> Final output sent to browser
DEBUG - 2013-11-25 09:50:55 --> Total execution time: 0.0540
DEBUG - 2013-11-25 09:50:59 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Hooks Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Utf8 Class Initialized
DEBUG - 2013-11-25 09:50:59 --> UTF-8 Support Enabled
DEBUG - 2013-11-25 09:50:59 --> URI Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Router Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Output Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Security Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Input Class Initialized
DEBUG - 2013-11-25 09:50:59 --> XSS Filtering completed
DEBUG - 2013-11-25 09:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-25 09:50:59 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Language Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Config Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Loader Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Controller Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Users MX_Controller Initialized
DEBUG - 2013-11-25 09:50:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-25 09:50:59 --> Session Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: string_helper
DEBUG - 2013-11-25 09:50:59 --> Session routines successfully run
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: url_helper
DEBUG - 2013-11-25 09:50:59 --> Database Driver Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: form_helper
DEBUG - 2013-11-25 09:50:59 --> Form Validation Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: number_helper
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: pager_helper
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: invoice_helper
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: date_helper
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: redirect_helper
DEBUG - 2013-11-25 09:50:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-25 09:50:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-25 09:50:59 --> Helper loaded: language_helper
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-25 09:50:59 --> Layout MX_Controller Initialized
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-25 09:50:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-25 09:50:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-25 09:50:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-25 09:50:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-25 09:50:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-25 09:50:59 --> Model Class Initialized
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-25 09:50:59 --> Could not find the language line "product_img"
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-25 09:50:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-25 09:50:59 --> Final output sent to browser
DEBUG - 2013-11-25 09:50:59 --> Total execution time: 0.0610
