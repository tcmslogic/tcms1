<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-11-26 06:48:30 --> Config Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Hooks Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Utf8 Class Initialized
DEBUG - 2013-11-26 06:48:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-26 06:48:30 --> URI Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Router Class Initialized
DEBUG - 2013-11-26 06:48:30 --> No URI present. Default controller set.
DEBUG - 2013-11-26 06:48:30 --> Output Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Security Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Input Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-26 06:48:30 --> Language Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Language Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Config Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Loader Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Controller Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-26 06:48:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-26 06:48:30 --> Session Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: string_helper
DEBUG - 2013-11-26 06:48:30 --> A session cookie was not found.
DEBUG - 2013-11-26 06:48:30 --> Session routines successfully run
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: url_helper
DEBUG - 2013-11-26 06:48:30 --> Database Driver Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: form_helper
DEBUG - 2013-11-26 06:48:30 --> Form Validation Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: number_helper
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: pager_helper
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: invoice_helper
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: date_helper
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: redirect_helper
DEBUG - 2013-11-26 06:48:30 --> Model Class Initialized
DEBUG - 2013-11-26 06:48:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-26 06:48:30 --> Model Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: language_helper
DEBUG - 2013-11-26 06:48:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-26 06:48:30 --> Layout MX_Controller Initialized
DEBUG - 2013-11-26 06:48:30 --> Config Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Hooks Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Utf8 Class Initialized
DEBUG - 2013-11-26 06:48:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-26 06:48:30 --> URI Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Router Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Output Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Security Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Input Class Initialized
DEBUG - 2013-11-26 06:48:30 --> XSS Filtering completed
DEBUG - 2013-11-26 06:48:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-26 06:48:30 --> Language Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Language Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Config Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Loader Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Controller Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-26 06:48:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-26 06:48:30 --> Session Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: string_helper
DEBUG - 2013-11-26 06:48:30 --> Session routines successfully run
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: url_helper
DEBUG - 2013-11-26 06:48:30 --> Database Driver Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: form_helper
DEBUG - 2013-11-26 06:48:30 --> Form Validation Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: number_helper
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: pager_helper
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: invoice_helper
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: date_helper
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: redirect_helper
DEBUG - 2013-11-26 06:48:30 --> Model Class Initialized
DEBUG - 2013-11-26 06:48:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-26 06:48:30 --> Model Class Initialized
DEBUG - 2013-11-26 06:48:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-26 06:48:30 --> Helper loaded: language_helper
DEBUG - 2013-11-26 06:48:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-26 06:48:30 --> Layout MX_Controller Initialized
DEBUG - 2013-11-26 06:48:30 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-26 06:48:30 --> Final output sent to browser
DEBUG - 2013-11-26 06:48:30 --> Total execution time: 0.0560
DEBUG - 2013-11-26 06:48:35 --> Config Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Hooks Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Utf8 Class Initialized
DEBUG - 2013-11-26 06:48:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-26 06:48:35 --> URI Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Router Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Output Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Security Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Input Class Initialized
DEBUG - 2013-11-26 06:48:35 --> XSS Filtering completed
DEBUG - 2013-11-26 06:48:35 --> XSS Filtering completed
DEBUG - 2013-11-26 06:48:35 --> XSS Filtering completed
DEBUG - 2013-11-26 06:48:35 --> XSS Filtering completed
DEBUG - 2013-11-26 06:48:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-26 06:48:35 --> Language Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Language Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Config Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Loader Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Controller Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-26 06:48:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-26 06:48:35 --> Session Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: string_helper
DEBUG - 2013-11-26 06:48:35 --> Session routines successfully run
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: url_helper
DEBUG - 2013-11-26 06:48:35 --> Database Driver Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: form_helper
DEBUG - 2013-11-26 06:48:35 --> Form Validation Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: number_helper
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: pager_helper
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: invoice_helper
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: date_helper
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: redirect_helper
DEBUG - 2013-11-26 06:48:35 --> Model Class Initialized
DEBUG - 2013-11-26 06:48:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-26 06:48:35 --> Model Class Initialized
DEBUG - 2013-11-26 06:48:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-26 06:48:35 --> Helper loaded: language_helper
DEBUG - 2013-11-26 06:48:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-26 06:48:35 --> Layout MX_Controller Initialized
DEBUG - 2013-11-26 06:48:35 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-26 06:48:35 --> Model Class Initialized
DEBUG - 2013-11-26 06:48:35 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-26 06:48:35 --> Final output sent to browser
DEBUG - 2013-11-26 06:48:35 --> Total execution time: 0.1574
