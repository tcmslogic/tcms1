<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-04 15:43:09 --> Config Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:43:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:43:09 --> URI Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Router Class Initialized
DEBUG - 2014-02-04 15:43:09 --> No URI present. Default controller set.
DEBUG - 2014-02-04 15:43:09 --> Output Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Security Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Input Class Initialized
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:43:09 --> Language Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Language Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Config Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Loader Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Controller Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Session Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:43:09 --> Session routines successfully run
DEBUG - 2014-02-04 15:43:09 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-04 15:43:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:43:09 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:43:09 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:43:09 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:43:09 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:43:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:43:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:43:09 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:43:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:43:09 --> Model Class Initialized
DEBUG - 2014-02-04 15:43:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:43:09 --> Model Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:43:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:43:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:43:10 --> Config Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:43:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:43:10 --> URI Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Router Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Output Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Security Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Input Class Initialized
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 15:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:43:10 --> Language Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Language Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Config Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Loader Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Controller Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-04 15:43:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:43:10 --> Session Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:43:10 --> Session routines successfully run
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:43:10 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:43:10 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:43:10 --> Model Class Initialized
DEBUG - 2014-02-04 15:43:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:43:10 --> Model Class Initialized
DEBUG - 2014-02-04 15:43:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:43:10 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:43:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:43:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:43:10 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-04 15:43:10 --> Final output sent to browser
DEBUG - 2014-02-04 15:43:10 --> Total execution time: 0.1067
DEBUG - 2014-02-04 15:51:39 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:51:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:51:39 --> URI Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Router Class Initialized
DEBUG - 2014-02-04 15:51:39 --> No URI present. Default controller set.
DEBUG - 2014-02-04 15:51:39 --> Output Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Security Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Input Class Initialized
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:51:39 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Loader Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Controller Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Session Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:51:39 --> Session routines successfully run
DEBUG - 2014-02-04 15:51:39 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-04 15:51:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:51:39 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:51:39 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:51:39 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:51:39 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:51:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:51:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:51:39 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:51:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:51:39 --> URI Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Router Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Output Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Security Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Input Class Initialized
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:51:39 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Loader Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Controller Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-04 15:51:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:51:39 --> Session Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:51:39 --> Session routines successfully run
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:51:39 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:51:39 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:51:39 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:51:39 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:51:39 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:51:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:51:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:51:39 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-04 15:51:39 --> Final output sent to browser
DEBUG - 2014-02-04 15:51:39 --> Total execution time: 0.0462
DEBUG - 2014-02-04 15:51:48 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:51:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:51:48 --> URI Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Router Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Output Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Security Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Input Class Initialized
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:51:48 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Loader Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Controller Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-04 15:51:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:51:48 --> Session Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:51:48 --> Session routines successfully run
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:51:48 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:51:48 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:51:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:51:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:51:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-04 15:51:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:51:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:51:48 --> URI Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Router Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Output Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Security Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Input Class Initialized
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:51:48 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Loader Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Controller Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Session Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:51:48 --> Session routines successfully run
DEBUG - 2014-02-04 15:51:48 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-04 15:51:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:51:48 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:51:48 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:51:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:51:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:51:48 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:51:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-04 15:51:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 15:51:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-04 15:51:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 15:51:49 --> Final output sent to browser
DEBUG - 2014-02-04 15:51:49 --> Total execution time: 0.0975
DEBUG - 2014-02-04 15:51:57 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:51:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:51:57 --> URI Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Router Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Output Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Security Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Input Class Initialized
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> XSS Filtering completed
DEBUG - 2014-02-04 15:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:51:57 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Language Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Config Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Loader Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Controller Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Session Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:51:57 --> Session routines successfully run
DEBUG - 2014-02-04 15:51:57 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 15:51:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:51:57 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:51:57 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:51:57 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:51:57 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:51:57 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:51:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:51:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:51:57 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 15:51:57 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 15:51:57 --> Model Class Initialized
DEBUG - 2014-02-04 15:51:57 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 15:51:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 15:51:57 --> Final output sent to browser
DEBUG - 2014-02-04 15:51:57 --> Total execution time: 0.1220
DEBUG - 2014-02-04 15:52:48 --> Config Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:52:48 --> URI Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Router Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Output Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Security Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Input Class Initialized
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:52:48 --> Language Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Language Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Config Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Loader Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Controller Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Session Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:52:48 --> Session routines successfully run
DEBUG - 2014-02-04 15:52:48 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 15:52:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:52:48 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:52:48 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:52:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:52:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:52:48 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:52:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:52:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:52:48 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 15:52:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 15:52:48 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Config Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:52:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:52:51 --> URI Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Router Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Output Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Security Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Input Class Initialized
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:52:51 --> Language Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Language Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Config Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Loader Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Controller Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Session Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:52:51 --> Session routines successfully run
DEBUG - 2014-02-04 15:52:51 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 15:52:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:52:51 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:52:51 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:52:51 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:52:51 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:52:51 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:52:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:52:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:52:51 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 15:52:51 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:51 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 15:52:51 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:51 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 15:52:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 15:52:51 --> Final output sent to browser
DEBUG - 2014-02-04 15:52:51 --> Total execution time: 0.0953
DEBUG - 2014-02-04 15:52:55 --> Config Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Hooks Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Utf8 Class Initialized
DEBUG - 2014-02-04 15:52:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 15:52:55 --> URI Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Router Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Output Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Security Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Input Class Initialized
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> XSS Filtering completed
DEBUG - 2014-02-04 15:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 15:52:55 --> Language Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Language Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Config Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Loader Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Controller Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Session Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: string_helper
DEBUG - 2014-02-04 15:52:55 --> Session routines successfully run
DEBUG - 2014-02-04 15:52:55 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 15:52:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: url_helper
DEBUG - 2014-02-04 15:52:55 --> Database Driver Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: form_helper
DEBUG - 2014-02-04 15:52:55 --> Form Validation Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: number_helper
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: date_helper
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 15:52:55 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 15:52:55 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 15:52:55 --> Helper loaded: language_helper
DEBUG - 2014-02-04 15:52:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 15:52:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 15:52:55 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 15:52:55 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 15:52:55 --> Model Class Initialized
DEBUG - 2014-02-04 15:52:55 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 15:52:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 15:52:55 --> Final output sent to browser
DEBUG - 2014-02-04 15:52:55 --> Total execution time: 0.0854
DEBUG - 2014-02-04 17:04:54 --> Config Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:04:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:04:54 --> URI Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Router Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Output Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Security Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Input Class Initialized
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:04:54 --> Language Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Language Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Config Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Loader Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Controller Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Session Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:04:54 --> Session routines successfully run
DEBUG - 2014-02-04 17:04:54 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:04:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:04:54 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:04:54 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:04:54 --> Model Class Initialized
DEBUG - 2014-02-04 17:04:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:04:54 --> Model Class Initialized
DEBUG - 2014-02-04 17:04:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:04:54 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:04:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:04:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:04:54 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:04:54 --> Model Class Initialized
DEBUG - 2014-02-04 17:04:54 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:04:54 --> Model Class Initialized
DEBUG - 2014-02-04 17:04:54 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 17:04:54 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:04:54 --> Final output sent to browser
DEBUG - 2014-02-04 17:04:54 --> Total execution time: 0.0547
DEBUG - 2014-02-04 17:04:57 --> Config Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:04:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:04:57 --> URI Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Router Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Output Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Security Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Input Class Initialized
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> XSS Filtering completed
DEBUG - 2014-02-04 17:04:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:04:57 --> Language Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Language Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Config Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Loader Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Controller Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Session Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:04:57 --> Session routines successfully run
DEBUG - 2014-02-04 17:04:57 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:04:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:04:57 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:04:57 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:04:57 --> Model Class Initialized
DEBUG - 2014-02-04 17:04:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:04:57 --> Model Class Initialized
DEBUG - 2014-02-04 17:04:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:04:57 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:04:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:04:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:04:57 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:04:57 --> Model Class Initialized
DEBUG - 2014-02-04 17:04:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:04:57 --> Model Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Config Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:05:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:05:38 --> URI Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Router Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Output Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Security Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Input Class Initialized
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:05:38 --> Language Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Language Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Config Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Loader Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Controller Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Session Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:05:38 --> Session routines successfully run
DEBUG - 2014-02-04 17:05:38 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:05:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:05:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:05:38 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:05:38 --> Model Class Initialized
DEBUG - 2014-02-04 17:05:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:05:38 --> Model Class Initialized
DEBUG - 2014-02-04 17:05:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:05:38 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:05:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:05:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:05:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:05:38 --> Model Class Initialized
DEBUG - 2014-02-04 17:05:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:05:38 --> Model Class Initialized
DEBUG - 2014-02-04 17:05:38 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 17:05:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:05:38 --> Final output sent to browser
DEBUG - 2014-02-04 17:05:38 --> Total execution time: 0.0637
DEBUG - 2014-02-04 17:05:45 --> Config Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:05:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:05:45 --> URI Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Router Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Output Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Security Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Input Class Initialized
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:05:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:05:45 --> Language Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Language Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Config Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Loader Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Controller Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Session Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:05:45 --> Session routines successfully run
DEBUG - 2014-02-04 17:05:45 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:05:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:05:45 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:05:45 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:05:45 --> Model Class Initialized
DEBUG - 2014-02-04 17:05:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:05:45 --> Model Class Initialized
DEBUG - 2014-02-04 17:05:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:05:45 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:05:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:05:45 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:05:45 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:05:45 --> Model Class Initialized
DEBUG - 2014-02-04 17:05:45 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:05:45 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Config Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:14:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:14:45 --> URI Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Router Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Output Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Security Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Input Class Initialized
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:14:45 --> Language Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Language Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Config Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Loader Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Controller Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Session Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:14:45 --> Session routines successfully run
DEBUG - 2014-02-04 17:14:45 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:14:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:14:45 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:14:45 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:14:45 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:14:45 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:14:45 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:14:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:14:45 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:14:45 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:14:45 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:45 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:14:45 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:45 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:14:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:14:45 --> Final output sent to browser
DEBUG - 2014-02-04 17:14:45 --> Total execution time: 0.0823
DEBUG - 2014-02-04 17:14:51 --> Config Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:14:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:14:51 --> URI Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Router Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Output Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Security Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Input Class Initialized
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> XSS Filtering completed
DEBUG - 2014-02-04 17:14:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:14:51 --> Language Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Language Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Config Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Loader Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Controller Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Session Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:14:51 --> Session routines successfully run
DEBUG - 2014-02-04 17:14:51 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:14:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:14:51 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:14:51 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:14:51 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:14:51 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:14:51 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:14:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:14:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:14:51 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:14:51 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:51 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:14:51 --> Model Class Initialized
DEBUG - 2014-02-04 17:14:51 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:14:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:14:51 --> Final output sent to browser
DEBUG - 2014-02-04 17:14:51 --> Total execution time: 0.0842
DEBUG - 2014-02-04 17:15:53 --> Config Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:15:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:15:53 --> URI Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Router Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Output Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Security Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Input Class Initialized
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:15:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:15:53 --> Language Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Language Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Config Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Loader Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Controller Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Session Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:15:53 --> Session routines successfully run
DEBUG - 2014-02-04 17:15:53 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:15:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:15:53 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:15:53 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:15:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:15:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:15:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:15:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:15:53 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:15:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:15:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:15:53 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:15:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:15:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:15:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:15:53 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:15:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:15:53 --> Final output sent to browser
DEBUG - 2014-02-04 17:15:53 --> Total execution time: 0.0763
DEBUG - 2014-02-04 17:19:22 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:19:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:19:22 --> URI Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Router Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Output Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Security Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Input Class Initialized
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:19:22 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Loader Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Controller Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Session Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:19:22 --> Session routines successfully run
DEBUG - 2014-02-04 17:19:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:19:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:19:22 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:19:22 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:19:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:19:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:19:22 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:19:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:19:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:19:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:19:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:19:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:22 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:19:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:19:22 --> Final output sent to browser
DEBUG - 2014-02-04 17:19:22 --> Total execution time: 0.0562
DEBUG - 2014-02-04 17:19:26 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:19:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:19:26 --> URI Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Router Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Output Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Security Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Input Class Initialized
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:19:26 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Loader Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Controller Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Session Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:19:26 --> Session routines successfully run
DEBUG - 2014-02-04 17:19:26 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:19:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:19:26 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:19:26 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:19:26 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:19:26 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:19:26 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:19:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:19:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:19:26 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:19:26 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:19:26 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:26 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 17:19:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:19:26 --> Final output sent to browser
DEBUG - 2014-02-04 17:19:26 --> Total execution time: 0.0572
DEBUG - 2014-02-04 17:19:29 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:19:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:19:29 --> URI Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Router Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Output Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Security Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Input Class Initialized
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:19:29 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Loader Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Controller Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Session Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:19:29 --> Session routines successfully run
DEBUG - 2014-02-04 17:19:29 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:19:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:19:29 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:19:29 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:19:29 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:19:29 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:19:29 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:19:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:19:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:19:29 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:19:29 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:29 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:19:29 --> Model Class Initialized
ERROR - 2014-02-04 17:19:29 --> Severity: Notice  --> Undefined variable: end_year D:\xampp\htdocs\renalemr\application\modules\billing\controllers\billing.php 47
ERROR - 2014-02-04 17:19:29 --> Severity: Notice  --> Undefined variable: end_month D:\xampp\htdocs\renalemr\application\modules\billing\controllers\billing.php 47
DEBUG - 2014-02-04 17:19:53 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:19:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:19:53 --> URI Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Router Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Output Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Security Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Input Class Initialized
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:19:53 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Loader Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Controller Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Session Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:19:53 --> Session routines successfully run
DEBUG - 2014-02-04 17:19:53 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:19:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:19:53 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:19:53 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:19:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:19:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:19:53 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:19:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:19:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:19:53 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:19:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:19:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:53 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 17:19:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:19:53 --> Final output sent to browser
DEBUG - 2014-02-04 17:19:53 --> Total execution time: 0.0692
DEBUG - 2014-02-04 17:19:59 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:19:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:19:59 --> URI Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Router Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Output Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Security Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Input Class Initialized
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> XSS Filtering completed
DEBUG - 2014-02-04 17:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:19:59 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Language Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Config Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Loader Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Controller Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Session Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:19:59 --> Session routines successfully run
DEBUG - 2014-02-04 17:19:59 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:19:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:19:59 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:19:59 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:19:59 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:19:59 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:19:59 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:19:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:19:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:19:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:19:59 --> Model Class Initialized
DEBUG - 2014-02-04 17:19:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:19:59 --> Model Class Initialized
ERROR - 2014-02-04 17:19:59 --> Severity: Notice  --> Undefined variable: end_year D:\xampp\htdocs\renalemr\application\modules\billing\controllers\billing.php 47
ERROR - 2014-02-04 17:19:59 --> Severity: Notice  --> Undefined variable: end_month D:\xampp\htdocs\renalemr\application\modules\billing\controllers\billing.php 47
DEBUG - 2014-02-04 17:21:13 --> Config Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:21:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:21:13 --> URI Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Router Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Output Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Security Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Input Class Initialized
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:21:13 --> Language Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Language Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Config Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Loader Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Controller Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Session Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:21:13 --> Session routines successfully run
DEBUG - 2014-02-04 17:21:13 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:21:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:21:13 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:21:13 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:21:13 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:21:13 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:21:13 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:21:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:21:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:21:13 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:21:13 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:21:13 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:13 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 17:21:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:21:13 --> Final output sent to browser
DEBUG - 2014-02-04 17:21:13 --> Total execution time: 0.0707
DEBUG - 2014-02-04 17:21:16 --> Config Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:21:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:21:16 --> URI Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Router Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Output Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Security Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Input Class Initialized
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:21:16 --> Language Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Language Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Config Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Loader Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Controller Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Session Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:21:16 --> Session routines successfully run
DEBUG - 2014-02-04 17:21:16 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:21:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:21:16 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:21:16 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:21:16 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:21:16 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:21:16 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:21:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:21:16 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:21:16 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:21:16 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:16 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:21:16 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Config Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:21:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:21:22 --> URI Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Router Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Output Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Security Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Input Class Initialized
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:21:22 --> Language Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Language Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Config Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Loader Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Controller Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Session Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:21:22 --> Session routines successfully run
DEBUG - 2014-02-04 17:21:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:21:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:21:22 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:21:22 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:21:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:21:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:21:22 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:21:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:21:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:21:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:21:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:21:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:22 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:21:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:21:22 --> Final output sent to browser
DEBUG - 2014-02-04 17:21:22 --> Total execution time: 0.0905
DEBUG - 2014-02-04 17:21:39 --> Config Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:21:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:21:39 --> URI Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Router Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Output Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Security Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Input Class Initialized
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> XSS Filtering completed
DEBUG - 2014-02-04 17:21:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:21:39 --> Language Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Language Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Config Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Loader Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Controller Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Session Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:21:39 --> Session routines successfully run
DEBUG - 2014-02-04 17:21:39 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:21:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:21:39 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:21:39 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:21:39 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:21:39 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:21:39 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:21:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:21:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:21:39 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:21:39 --> Model Class Initialized
DEBUG - 2014-02-04 17:21:39 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:21:39 --> Model Class Initialized
ERROR - 2014-02-04 17:21:39 --> Severity: Notice  --> Undefined variable: result_arr D:\xampp\htdocs\renalemr\application\modules\billing\models\mdl_billing.php 368
ERROR - 2014-02-04 17:21:39 --> Severity: Notice  --> Undefined index: invoice_no D:\xampp\htdocs\renalemr\application\modules\billing\views\monthly_details.php 31
DEBUG - 2014-02-04 17:21:39 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:21:39 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:21:39 --> Final output sent to browser
DEBUG - 2014-02-04 17:21:39 --> Total execution time: 0.0895
DEBUG - 2014-02-04 17:22:01 --> Config Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:22:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:22:01 --> URI Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Router Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Output Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Security Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Input Class Initialized
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:22:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:22:01 --> Language Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Language Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Config Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Loader Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Controller Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Session Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:22:01 --> Session routines successfully run
DEBUG - 2014-02-04 17:22:01 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:22:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:22:01 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:22:01 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:22:01 --> Model Class Initialized
DEBUG - 2014-02-04 17:22:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:22:01 --> Model Class Initialized
DEBUG - 2014-02-04 17:22:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:22:01 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:22:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:22:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:22:01 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:22:01 --> Model Class Initialized
DEBUG - 2014-02-04 17:22:01 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:22:01 --> Model Class Initialized
ERROR - 2014-02-04 17:22:01 --> Severity: Notice  --> Undefined variable: result_arr D:\xampp\htdocs\renalemr\application\modules\billing\models\mdl_billing.php 368
ERROR - 2014-02-04 17:22:01 --> Severity: Notice  --> Undefined index: invoice_no D:\xampp\htdocs\renalemr\application\modules\billing\views\monthly_details.php 31
DEBUG - 2014-02-04 17:22:01 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:22:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:22:01 --> Final output sent to browser
DEBUG - 2014-02-04 17:22:01 --> Total execution time: 0.0871
DEBUG - 2014-02-04 17:28:50 --> Config Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:28:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:28:50 --> URI Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Router Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Output Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Security Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Input Class Initialized
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:28:50 --> Language Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Language Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Config Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Loader Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Controller Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Session Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:28:50 --> Session routines successfully run
DEBUG - 2014-02-04 17:28:50 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:28:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:28:50 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:28:50 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:28:50 --> Model Class Initialized
DEBUG - 2014-02-04 17:28:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:28:50 --> Model Class Initialized
DEBUG - 2014-02-04 17:28:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:28:50 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:28:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:28:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:28:50 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:28:50 --> Model Class Initialized
DEBUG - 2014-02-04 17:28:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:28:50 --> Model Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Config Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:28:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:28:55 --> URI Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Router Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Output Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Security Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Input Class Initialized
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:28:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:28:55 --> Language Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Language Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Config Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Loader Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Controller Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Session Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:28:55 --> Session routines successfully run
DEBUG - 2014-02-04 17:28:55 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:28:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:28:55 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:28:55 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:28:55 --> Model Class Initialized
DEBUG - 2014-02-04 17:28:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:28:55 --> Model Class Initialized
DEBUG - 2014-02-04 17:28:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:28:55 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:28:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:28:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:28:55 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:28:55 --> Model Class Initialized
DEBUG - 2014-02-04 17:28:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:28:55 --> Model Class Initialized
DEBUG - 2014-02-04 17:28:55 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:28:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:28:55 --> Final output sent to browser
DEBUG - 2014-02-04 17:28:55 --> Total execution time: 0.0830
DEBUG - 2014-02-04 17:29:41 --> Config Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:29:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:29:41 --> URI Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Router Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Output Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Security Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Input Class Initialized
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:29:41 --> Language Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Language Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Config Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Loader Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Controller Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Session Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:29:41 --> Session routines successfully run
DEBUG - 2014-02-04 17:29:41 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:29:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:29:41 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:29:41 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:29:41 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:29:41 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:29:41 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:29:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:29:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:29:41 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:29:41 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:41 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:29:41 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:41 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 17:29:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:29:41 --> Final output sent to browser
DEBUG - 2014-02-04 17:29:41 --> Total execution time: 0.0571
DEBUG - 2014-02-04 17:29:43 --> Config Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:29:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:29:43 --> URI Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Router Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Output Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Security Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Input Class Initialized
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:29:43 --> Language Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Language Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Config Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Loader Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Controller Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Session Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:29:43 --> Session routines successfully run
DEBUG - 2014-02-04 17:29:43 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:29:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:29:43 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:29:43 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:29:43 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:29:43 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:29:43 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:29:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:29:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:29:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:29:43 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:29:43 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Config Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:29:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:29:58 --> URI Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Router Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Output Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Security Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Input Class Initialized
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 17:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:29:58 --> Language Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Language Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Config Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Loader Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Controller Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Session Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:29:58 --> Session routines successfully run
DEBUG - 2014-02-04 17:29:58 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:29:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:29:58 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:29:58 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:29:58 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:29:58 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:29:58 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:29:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:29:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:29:58 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:29:58 --> Model Class Initialized
DEBUG - 2014-02-04 17:29:58 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:29:58 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:30:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:30:15 --> URI Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Router Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Output Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Security Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Input Class Initialized
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:30:15 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Loader Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Controller Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Session Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:30:15 --> Session routines successfully run
DEBUG - 2014-02-04 17:30:15 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:30:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:30:15 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:30:15 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:30:15 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:30:15 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:30:15 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:30:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:30:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:30:15 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:30:15 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:30:15 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:15 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 17:30:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:30:15 --> Final output sent to browser
DEBUG - 2014-02-04 17:30:15 --> Total execution time: 0.0585
DEBUG - 2014-02-04 17:30:17 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:30:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:30:17 --> URI Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Router Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Output Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Security Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Input Class Initialized
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:30:17 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Loader Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Controller Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Session Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:30:17 --> Session routines successfully run
DEBUG - 2014-02-04 17:30:17 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:30:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:30:17 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:30:17 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:30:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:30:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:30:17 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:30:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:30:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:30:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:30:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:30:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:30:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:30:23 --> URI Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Router Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Output Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Security Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Input Class Initialized
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:30:23 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Loader Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Controller Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Session Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:30:23 --> Session routines successfully run
DEBUG - 2014-02-04 17:30:23 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:30:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:30:23 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:30:23 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:30:23 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:30:23 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:30:23 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:30:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:30:23 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:30:23 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:30:23 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:23 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:30:23 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:23 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:30:23 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:30:23 --> Final output sent to browser
DEBUG - 2014-02-04 17:30:23 --> Total execution time: 0.0836
DEBUG - 2014-02-04 17:30:35 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:30:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:30:35 --> URI Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Router Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Output Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Security Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Input Class Initialized
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:30:35 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Loader Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Controller Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Session Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:30:35 --> Session routines successfully run
DEBUG - 2014-02-04 17:30:35 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:30:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:30:35 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:30:35 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:30:35 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:30:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:30:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:30:35 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:35 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:35 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:30:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:30:35 --> Final output sent to browser
DEBUG - 2014-02-04 17:30:35 --> Total execution time: 0.0636
DEBUG - 2014-02-04 17:30:36 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:30:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:30:36 --> URI Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Router Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Output Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Security Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Input Class Initialized
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> XSS Filtering completed
DEBUG - 2014-02-04 17:30:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:30:36 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Language Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Config Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Loader Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Controller Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Session Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:30:36 --> Session routines successfully run
DEBUG - 2014-02-04 17:30:36 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:30:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:30:36 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:30:36 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:30:36 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:30:36 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:30:36 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:30:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:30:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:30:36 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:30:36 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:36 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:30:36 --> Model Class Initialized
DEBUG - 2014-02-04 17:30:36 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 17:30:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:30:36 --> Final output sent to browser
DEBUG - 2014-02-04 17:30:36 --> Total execution time: 0.0685
DEBUG - 2014-02-04 17:36:50 --> Config Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:36:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:36:50 --> URI Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Router Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Output Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Security Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Input Class Initialized
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:36:50 --> Language Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Language Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Config Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Loader Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Controller Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Session Class Initialized
DEBUG - 2014-02-04 17:36:50 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:36:50 --> Session routines successfully run
DEBUG - 2014-02-04 17:36:50 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:36:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:36:50 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:36:50 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:36:51 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:36:51 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:36:51 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:36:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:36:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:36:51 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:36:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:36:51 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:36:51 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:36:51 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:36:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:36:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:36:51 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:36:51 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:51 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:36:51 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:51 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 17:36:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:36:51 --> Final output sent to browser
DEBUG - 2014-02-04 17:36:51 --> Total execution time: 0.0581
DEBUG - 2014-02-04 17:36:52 --> Config Class Initialized
DEBUG - 2014-02-04 17:36:52 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:36:52 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:36:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:36:52 --> URI Class Initialized
DEBUG - 2014-02-04 17:36:52 --> Router Class Initialized
DEBUG - 2014-02-04 17:36:52 --> Output Class Initialized
DEBUG - 2014-02-04 17:36:52 --> Security Class Initialized
DEBUG - 2014-02-04 17:36:52 --> Input Class Initialized
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:36:52 --> Language Class Initialized
DEBUG - 2014-02-04 17:36:52 --> Language Class Initialized
DEBUG - 2014-02-04 17:36:52 --> Config Class Initialized
DEBUG - 2014-02-04 17:36:53 --> Loader Class Initialized
DEBUG - 2014-02-04 17:36:53 --> Controller Class Initialized
DEBUG - 2014-02-04 17:36:53 --> Session Class Initialized
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:36:53 --> Session routines successfully run
DEBUG - 2014-02-04 17:36:53 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:36:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:36:53 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:36:53 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:36:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:36:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:36:53 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:36:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:36:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:36:53 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:36:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:36:53 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:53 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 17:36:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:36:53 --> Final output sent to browser
DEBUG - 2014-02-04 17:36:53 --> Total execution time: 0.0705
DEBUG - 2014-02-04 17:36:56 --> Config Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:36:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:36:56 --> URI Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Router Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Output Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Security Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Input Class Initialized
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:36:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:36:56 --> Language Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Language Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Config Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Loader Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Controller Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Session Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:36:56 --> Session routines successfully run
DEBUG - 2014-02-04 17:36:56 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:36:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:36:56 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:36:56 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:36:56 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:36:56 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:36:56 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:36:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:36:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:36:56 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:36:56 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:36:56 --> Model Class Initialized
DEBUG - 2014-02-04 17:36:56 --> Final output sent to browser
DEBUG - 2014-02-04 17:36:56 --> Total execution time: 0.0507
DEBUG - 2014-02-04 17:45:04 --> Config Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:45:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:45:04 --> URI Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Router Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Output Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Security Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Input Class Initialized
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:45:04 --> Language Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Language Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Config Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Loader Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Controller Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Session Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:45:04 --> Session routines successfully run
DEBUG - 2014-02-04 17:45:04 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:45:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:45:04 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:45:04 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:45:04 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:45:04 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:45:04 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:45:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:45:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:45:04 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:45:04 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:45:04 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:04 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 17:45:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:45:04 --> Final output sent to browser
DEBUG - 2014-02-04 17:45:04 --> Total execution time: 0.0599
DEBUG - 2014-02-04 17:45:17 --> Config Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:45:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:45:17 --> URI Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Router Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Output Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Security Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Input Class Initialized
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:45:17 --> Language Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Language Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Config Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Loader Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Controller Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Session Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:45:17 --> Session routines successfully run
DEBUG - 2014-02-04 17:45:17 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:45:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:45:17 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:45:17 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:45:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:45:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:45:17 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:45:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:45:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:45:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:45:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:45:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:17 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 17:45:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:45:17 --> Final output sent to browser
DEBUG - 2014-02-04 17:45:17 --> Total execution time: 0.0708
DEBUG - 2014-02-04 17:45:20 --> Config Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:45:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:45:20 --> URI Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Router Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Output Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Security Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Input Class Initialized
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:45:20 --> Language Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Language Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Config Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Loader Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Controller Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Session Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:45:20 --> Session routines successfully run
DEBUG - 2014-02-04 17:45:20 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:45:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:45:20 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:45:20 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:45:20 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:45:20 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:45:20 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:45:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:45:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:45:20 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:45:20 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:45:20 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:20 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 17:45:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:45:20 --> Final output sent to browser
DEBUG - 2014-02-04 17:45:20 --> Total execution time: 0.0553
DEBUG - 2014-02-04 17:45:24 --> Config Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:45:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:45:24 --> URI Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Router Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Output Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Security Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Input Class Initialized
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:45:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:45:24 --> Language Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Language Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Config Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Loader Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Controller Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Session Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:45:24 --> Session routines successfully run
DEBUG - 2014-02-04 17:45:24 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:45:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:45:24 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:45:24 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:45:24 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:45:24 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:45:24 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:45:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:45:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:45:24 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:45:24 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:45:24 --> Model Class Initialized
DEBUG - 2014-02-04 17:45:24 --> Final output sent to browser
DEBUG - 2014-02-04 17:45:24 --> Total execution time: 0.0493
DEBUG - 2014-02-04 17:46:22 --> Config Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:46:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:46:22 --> URI Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Router Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Output Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Security Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Input Class Initialized
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:46:22 --> Language Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Language Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Config Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Loader Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Controller Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Session Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:46:22 --> Session routines successfully run
DEBUG - 2014-02-04 17:46:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:46:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:46:22 --> Database Driver Class Initialized
ERROR - 2014-02-04 17:46:22 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\renalemr\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:46:22 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:46:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:46:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:46:22 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:46:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:46:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:46:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:46:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:46:22 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:22 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 17:46:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:46:22 --> Final output sent to browser
DEBUG - 2014-02-04 17:46:22 --> Total execution time: 0.0626
DEBUG - 2014-02-04 17:46:23 --> Config Class Initialized
DEBUG - 2014-02-04 17:46:23 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:46:23 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:46:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:46:23 --> URI Class Initialized
DEBUG - 2014-02-04 17:46:23 --> Router Class Initialized
DEBUG - 2014-02-04 17:46:23 --> Output Class Initialized
DEBUG - 2014-02-04 17:46:23 --> Security Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Input Class Initialized
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:46:24 --> Language Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Language Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Config Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Loader Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Controller Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Session Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:46:24 --> Session routines successfully run
DEBUG - 2014-02-04 17:46:24 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:46:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:46:24 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:46:24 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:46:24 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:46:24 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:46:24 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:46:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:46:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:46:24 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:46:24 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:46:24 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:24 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 17:46:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:46:24 --> Final output sent to browser
DEBUG - 2014-02-04 17:46:24 --> Total execution time: 0.0633
DEBUG - 2014-02-04 17:46:26 --> Config Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:46:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:46:26 --> URI Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Router Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Output Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Security Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Input Class Initialized
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> XSS Filtering completed
DEBUG - 2014-02-04 17:46:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:46:26 --> Language Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Language Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Config Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Loader Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Controller Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Session Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:46:26 --> Session routines successfully run
DEBUG - 2014-02-04 17:46:26 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:46:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:46:26 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:46:26 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:46:26 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:46:26 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:46:26 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:46:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:46:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:46:26 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:46:26 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:46:26 --> Model Class Initialized
DEBUG - 2014-02-04 17:46:26 --> Final output sent to browser
DEBUG - 2014-02-04 17:46:26 --> Total execution time: 0.0494
DEBUG - 2014-02-04 17:47:17 --> Config Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:47:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:47:17 --> URI Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Router Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Output Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Security Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Input Class Initialized
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:47:17 --> Language Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Language Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Config Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Loader Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Controller Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Session Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:47:17 --> Session routines successfully run
DEBUG - 2014-02-04 17:47:17 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:47:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:47:17 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:47:17 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:47:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:47:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:47:17 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:47:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:47:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:47:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:47:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:47:17 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:17 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 17:47:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:47:17 --> Final output sent to browser
DEBUG - 2014-02-04 17:47:17 --> Total execution time: 0.0607
DEBUG - 2014-02-04 17:47:19 --> Config Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:47:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:47:19 --> URI Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Router Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Output Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Security Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Input Class Initialized
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:47:19 --> Language Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Language Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Config Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Loader Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Controller Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Session Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:47:19 --> Session routines successfully run
DEBUG - 2014-02-04 17:47:19 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:47:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:47:19 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:47:19 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:47:19 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:47:19 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:47:19 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:47:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:47:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:47:19 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:47:19 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:19 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:47:19 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:19 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 17:47:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:47:19 --> Final output sent to browser
DEBUG - 2014-02-04 17:47:19 --> Total execution time: 0.0553
DEBUG - 2014-02-04 17:47:21 --> Config Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:47:21 --> URI Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Router Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Output Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Security Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Input Class Initialized
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> XSS Filtering completed
DEBUG - 2014-02-04 17:47:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:47:21 --> Language Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Language Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Config Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Loader Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Controller Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Session Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:47:21 --> Session routines successfully run
DEBUG - 2014-02-04 17:47:21 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:47:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:47:21 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:47:21 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:47:21 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:47:21 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:47:21 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:47:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:47:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:47:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:47:21 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:47:21 --> Model Class Initialized
DEBUG - 2014-02-04 17:47:21 --> Final output sent to browser
DEBUG - 2014-02-04 17:47:21 --> Total execution time: 0.0558
DEBUG - 2014-02-04 17:48:23 --> Config Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:48:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:48:23 --> URI Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Router Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Output Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Security Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Input Class Initialized
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:48:23 --> Language Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Language Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Config Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Loader Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Controller Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Session Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:48:23 --> Session routines successfully run
DEBUG - 2014-02-04 17:48:23 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:48:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:48:23 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:48:23 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:48:23 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:48:23 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:48:23 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:48:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:48:23 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:48:23 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:48:23 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:23 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:48:23 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:23 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 17:48:23 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:48:23 --> Final output sent to browser
DEBUG - 2014-02-04 17:48:23 --> Total execution time: 0.0662
DEBUG - 2014-02-04 17:48:25 --> Config Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:48:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:48:25 --> URI Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Router Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Output Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Security Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Input Class Initialized
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:48:25 --> Language Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Language Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Config Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Loader Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Controller Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Session Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:48:25 --> Session routines successfully run
DEBUG - 2014-02-04 17:48:25 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:48:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:48:25 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:48:25 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:48:25 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:48:25 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:48:25 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:48:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:48:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:48:25 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:48:25 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:48:25 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:25 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 17:48:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:48:25 --> Final output sent to browser
DEBUG - 2014-02-04 17:48:25 --> Total execution time: 0.0536
DEBUG - 2014-02-04 17:48:29 --> Config Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:48:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:48:29 --> URI Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Router Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Output Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Security Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Input Class Initialized
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> XSS Filtering completed
DEBUG - 2014-02-04 17:48:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:48:29 --> Language Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Language Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Config Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Loader Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Controller Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Session Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:48:29 --> Session routines successfully run
DEBUG - 2014-02-04 17:48:29 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:48:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:48:29 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:48:29 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:48:29 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:48:29 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:48:29 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:48:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:48:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:48:29 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:48:29 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:29 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:48:29 --> Model Class Initialized
DEBUG - 2014-02-04 17:48:29 --> Final output sent to browser
DEBUG - 2014-02-04 17:48:29 --> Total execution time: 0.0547
DEBUG - 2014-02-04 17:49:55 --> Config Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:49:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:49:55 --> URI Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Router Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Output Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Security Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Input Class Initialized
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:49:55 --> Language Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Language Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Config Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Loader Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Controller Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Session Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:49:55 --> Session routines successfully run
DEBUG - 2014-02-04 17:49:55 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:49:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:49:55 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:49:55 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:49:55 --> Model Class Initialized
DEBUG - 2014-02-04 17:49:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:49:55 --> Model Class Initialized
DEBUG - 2014-02-04 17:49:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:49:55 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:49:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:49:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:49:55 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:49:55 --> Model Class Initialized
DEBUG - 2014-02-04 17:49:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:49:55 --> Model Class Initialized
DEBUG - 2014-02-04 17:49:55 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 17:49:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:49:55 --> Final output sent to browser
DEBUG - 2014-02-04 17:49:55 --> Total execution time: 0.0683
DEBUG - 2014-02-04 17:49:56 --> Config Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:49:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:49:56 --> URI Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Router Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Output Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Security Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Input Class Initialized
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> XSS Filtering completed
DEBUG - 2014-02-04 17:49:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:49:56 --> Language Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Language Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Config Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Loader Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Controller Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Session Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:49:56 --> Session routines successfully run
DEBUG - 2014-02-04 17:49:56 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:49:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:49:56 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:49:56 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:49:56 --> Model Class Initialized
DEBUG - 2014-02-04 17:49:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:49:56 --> Model Class Initialized
DEBUG - 2014-02-04 17:49:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:49:56 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:49:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:49:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:49:56 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:49:56 --> Model Class Initialized
DEBUG - 2014-02-04 17:49:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:49:56 --> Model Class Initialized
DEBUG - 2014-02-04 17:49:56 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 17:49:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 17:49:56 --> Final output sent to browser
DEBUG - 2014-02-04 17:49:56 --> Total execution time: 0.0677
DEBUG - 2014-02-04 17:50:01 --> Config Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Hooks Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Utf8 Class Initialized
DEBUG - 2014-02-04 17:50:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 17:50:01 --> URI Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Router Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Output Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Security Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Input Class Initialized
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> XSS Filtering completed
DEBUG - 2014-02-04 17:50:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 17:50:01 --> Language Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Language Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Config Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Loader Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Controller Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Session Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: string_helper
DEBUG - 2014-02-04 17:50:01 --> Session routines successfully run
DEBUG - 2014-02-04 17:50:01 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 17:50:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: url_helper
DEBUG - 2014-02-04 17:50:01 --> Database Driver Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: form_helper
DEBUG - 2014-02-04 17:50:01 --> Form Validation Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: number_helper
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: date_helper
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 17:50:01 --> Model Class Initialized
DEBUG - 2014-02-04 17:50:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 17:50:01 --> Model Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 17:50:01 --> Helper loaded: language_helper
DEBUG - 2014-02-04 17:50:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 17:50:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 17:50:01 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 17:50:01 --> Model Class Initialized
DEBUG - 2014-02-04 17:50:01 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 17:50:01 --> Model Class Initialized
DEBUG - 2014-02-04 17:50:01 --> Final output sent to browser
DEBUG - 2014-02-04 17:50:01 --> Total execution time: 0.0601
DEBUG - 2014-02-04 18:10:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:10:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:10:04 --> URI Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Router Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Output Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Security Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Input Class Initialized
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:10:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Loader Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Controller Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Session Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:10:04 --> Session routines successfully run
DEBUG - 2014-02-04 18:10:04 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:10:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:10:04 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:10:04 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:10:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:10:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:10:04 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:10:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:10:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:10:04 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:10:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:10:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:04 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:10:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:10:04 --> Final output sent to browser
DEBUG - 2014-02-04 18:10:04 --> Total execution time: 0.0583
DEBUG - 2014-02-04 18:10:10 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:10:10 --> URI Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Router Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Output Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Security Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Input Class Initialized
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:10:10 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Loader Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Controller Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Session Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:10:10 --> Session routines successfully run
DEBUG - 2014-02-04 18:10:10 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:10:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:10:10 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:10:10 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:10:10 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:10:10 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:10:10 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:10:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:10:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:10:10 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:10:10 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:10:10 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:10 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 18:10:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:10:10 --> Final output sent to browser
DEBUG - 2014-02-04 18:10:10 --> Total execution time: 0.0631
DEBUG - 2014-02-04 18:10:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:10:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:10:12 --> URI Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Router Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Output Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Security Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Input Class Initialized
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:10:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Loader Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Controller Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Session Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:10:12 --> Session routines successfully run
DEBUG - 2014-02-04 18:10:12 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:10:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:10:12 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:10:12 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:10:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:10:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:10:12 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:10:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:10:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:10:12 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:10:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:10:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:12 --> Final output sent to browser
DEBUG - 2014-02-04 18:10:12 --> Total execution time: 0.0516
DEBUG - 2014-02-04 18:10:20 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:10:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:10:20 --> URI Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Router Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Output Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Security Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Input Class Initialized
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:10:20 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Loader Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Controller Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Session Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:10:20 --> Session routines successfully run
DEBUG - 2014-02-04 18:10:20 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:10:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:10:20 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:10:20 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:10:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:10:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:10:20 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:10:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:10:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:10:20 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:10:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:10:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:20 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 18:10:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:10:20 --> Final output sent to browser
DEBUG - 2014-02-04 18:10:20 --> Total execution time: 0.0691
DEBUG - 2014-02-04 18:10:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:10:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:10:24 --> URI Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Router Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Output Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Security Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Input Class Initialized
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:10:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Loader Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Controller Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Session Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:10:24 --> Session routines successfully run
DEBUG - 2014-02-04 18:10:24 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:10:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:10:24 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:10:24 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:10:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:10:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:10:24 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:10:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:10:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:10:24 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:10:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:10:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:24 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:10:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:10:24 --> Final output sent to browser
DEBUG - 2014-02-04 18:10:24 --> Total execution time: 0.0670
DEBUG - 2014-02-04 18:10:26 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:10:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:10:26 --> URI Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Router Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Output Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Security Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Input Class Initialized
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:10:26 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Loader Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Controller Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Session Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:10:26 --> Session routines successfully run
DEBUG - 2014-02-04 18:10:26 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:10:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:10:26 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:10:26 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:10:26 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:10:26 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:10:26 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:10:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:10:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:10:26 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:10:26 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:10:26 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:26 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 18:10:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:10:26 --> Final output sent to browser
DEBUG - 2014-02-04 18:10:26 --> Total execution time: 0.0635
DEBUG - 2014-02-04 18:10:28 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:10:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:10:28 --> URI Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Router Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Output Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Security Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Input Class Initialized
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:10:28 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Loader Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Controller Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Session Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:10:28 --> Session routines successfully run
DEBUG - 2014-02-04 18:10:28 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:10:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:10:28 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:10:28 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:10:28 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:10:28 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:10:28 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:10:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:10:28 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:10:28 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:10:28 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:28 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:10:28 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:28 --> Final output sent to browser
DEBUG - 2014-02-04 18:10:28 --> Total execution time: 0.0481
DEBUG - 2014-02-04 18:10:55 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:10:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:10:55 --> URI Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Router Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Output Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Security Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Input Class Initialized
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> XSS Filtering completed
DEBUG - 2014-02-04 18:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:10:55 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Language Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Config Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Loader Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Controller Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Session Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:10:55 --> Session routines successfully run
DEBUG - 2014-02-04 18:10:55 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:10:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:10:55 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:10:55 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:10:55 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:10:55 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:10:55 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:10:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:10:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:10:55 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:10:55 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:10:55 --> Model Class Initialized
DEBUG - 2014-02-04 18:10:55 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:10:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:10:55 --> Final output sent to browser
DEBUG - 2014-02-04 18:10:55 --> Total execution time: 0.0796
DEBUG - 2014-02-04 18:11:01 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:01 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:01 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:01 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:01 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:01 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:01 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:01 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:01 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:01 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:01 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:01 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:01 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:01 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:01 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:01 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:01 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:11:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:11:01 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:01 --> Total execution time: 0.1881
DEBUG - 2014-02-04 18:11:05 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:05 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:05 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:05 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:05 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:05 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:05 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:05 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:05 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:05 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:05 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:05 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:05 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:05 --> Total execution time: 0.0722
DEBUG - 2014-02-04 18:11:11 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:11 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:11 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:11 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:11 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:11 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:11 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:11 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:11 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:11 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:11 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:11 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:11 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:11 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:11 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:11 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:11 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:11 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:11 --> Total execution time: 0.0539
DEBUG - 2014-02-04 18:11:16 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:16 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:16 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:16 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:16 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:16 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:16 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:16 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:16 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:16 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:16 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:16 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:16 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:16 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:16 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:16 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:16 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:16 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:16 --> Total execution time: 0.0542
DEBUG - 2014-02-04 18:11:20 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:20 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:20 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:20 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:20 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:20 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:20 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:20 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:20 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:20 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:20 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:20 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:20 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:20 --> Total execution time: 0.0543
DEBUG - 2014-02-04 18:11:25 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:25 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:25 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:25 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:25 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:25 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:25 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:25 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:25 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:25 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:25 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:25 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:25 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:25 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:25 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:25 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:25 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:25 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:25 --> Total execution time: 0.0540
DEBUG - 2014-02-04 18:11:31 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:31 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:31 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:31 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:31 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:31 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:31 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:31 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:31 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:31 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:31 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:31 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:31 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:31 --> Total execution time: 0.0560
DEBUG - 2014-02-04 18:11:34 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:34 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:34 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:34 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:34 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:34 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:34 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:34 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:34 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:34 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:34 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:34 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:34 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:35 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:35 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:35 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:35 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:35 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:35 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:35 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:35 --> Total execution time: 0.0553
DEBUG - 2014-02-04 18:11:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:38 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:38 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:38 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:38 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:38 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:38 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:38 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:38 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:38 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:38 --> Total execution time: 0.0553
DEBUG - 2014-02-04 18:11:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:43 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:43 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:43 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:43 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:43 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:43 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:43 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:43 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:43 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:43 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:43 --> Total execution time: 0.0579
DEBUG - 2014-02-04 18:11:52 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:52 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:52 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:52 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:52 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:52 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:52 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:52 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:52 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:52 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:52 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:52 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:52 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:52 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:52 --> Total execution time: 0.0533
DEBUG - 2014-02-04 18:11:57 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:11:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:11:57 --> URI Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Router Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Output Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Security Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Input Class Initialized
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:11:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:11:57 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Language Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Config Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Loader Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Controller Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Session Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:11:57 --> Session routines successfully run
DEBUG - 2014-02-04 18:11:57 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:11:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:11:57 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:11:57 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:11:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:11:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:11:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:11:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:11:57 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:11:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:57 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:11:57 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:11:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:57 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:11:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:11:57 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:11:57 --> Final output sent to browser
DEBUG - 2014-02-04 18:11:57 --> Total execution time: 0.0544
DEBUG - 2014-02-04 18:12:00 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:12:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:12:00 --> URI Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Router Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Output Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Security Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Input Class Initialized
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:12:00 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Loader Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Controller Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Session Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:12:00 --> Session routines successfully run
DEBUG - 2014-02-04 18:12:00 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:12:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:12:00 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:12:00 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:12:00 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:12:00 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:12:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:12:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:12:00 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:12:00 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:00 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:12:01 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:12:01 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:01 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:12:01 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:01 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:12:01 --> Final output sent to browser
DEBUG - 2014-02-04 18:12:01 --> Total execution time: 0.0648
DEBUG - 2014-02-04 18:12:07 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:12:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:12:07 --> URI Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Router Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Output Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Security Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Input Class Initialized
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:12:07 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Loader Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Controller Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Session Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:12:07 --> Session routines successfully run
DEBUG - 2014-02-04 18:12:07 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:12:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:12:07 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:12:07 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:12:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:12:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:12:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:12:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:12:07 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:12:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:07 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:12:07 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:12:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:07 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:12:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:07 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:12:07 --> Final output sent to browser
DEBUG - 2014-02-04 18:12:07 --> Total execution time: 0.0550
DEBUG - 2014-02-04 18:12:13 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:12:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:12:13 --> URI Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Router Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Output Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Security Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Input Class Initialized
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:12:13 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Loader Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Controller Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Session Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:12:13 --> Session routines successfully run
DEBUG - 2014-02-04 18:12:13 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:12:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:12:13 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:12:13 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:12:13 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:12:13 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:12:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:12:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:12:13 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:12:13 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:13 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:12:13 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:12:13 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:13 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:12:13 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:13 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:12:13 --> Final output sent to browser
DEBUG - 2014-02-04 18:12:13 --> Total execution time: 0.0528
DEBUG - 2014-02-04 18:12:17 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:12:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:12:17 --> URI Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Router Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Output Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Security Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Input Class Initialized
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:12:17 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Loader Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Controller Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Session Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:12:17 --> Session routines successfully run
DEBUG - 2014-02-04 18:12:17 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:12:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:12:17 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:12:17 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:12:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:12:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:12:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:12:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:12:17 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:12:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:17 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:12:17 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:12:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:12:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:17 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:12:17 --> Final output sent to browser
DEBUG - 2014-02-04 18:12:17 --> Total execution time: 0.0537
DEBUG - 2014-02-04 18:12:23 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:12:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:12:23 --> URI Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Router Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Output Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Security Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Input Class Initialized
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> XSS Filtering completed
DEBUG - 2014-02-04 18:12:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:12:23 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Language Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Config Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Loader Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Controller Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Session Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:12:23 --> Session routines successfully run
DEBUG - 2014-02-04 18:12:23 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:12:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:12:23 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:12:23 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:12:23 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:12:23 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:12:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:12:23 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:12:23 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:12:23 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:23 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:12:23 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:12:23 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:23 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:12:23 --> Model Class Initialized
DEBUG - 2014-02-04 18:12:23 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:12:23 --> Final output sent to browser
DEBUG - 2014-02-04 18:12:23 --> Total execution time: 0.0548
DEBUG - 2014-02-04 18:18:21 --> Config Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:18:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:18:21 --> URI Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Router Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Output Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Security Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Input Class Initialized
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:18:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:18:21 --> Language Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Language Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Config Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Loader Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Controller Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Session Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:18:21 --> Session routines successfully run
DEBUG - 2014-02-04 18:18:21 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:18:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:18:21 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:18:21 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:18:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:18:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:18:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:18:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:18:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:18:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:18:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:18:21 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:18:21 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-04 18:18:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:18:21 --> Final output sent to browser
DEBUG - 2014-02-04 18:18:21 --> Total execution time: 0.0744
DEBUG - 2014-02-04 18:26:06 --> Config Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:26:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:26:06 --> URI Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Router Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Output Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Security Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Input Class Initialized
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:26:06 --> Language Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Language Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Config Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Loader Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Controller Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Session Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:26:06 --> Session routines successfully run
DEBUG - 2014-02-04 18:26:06 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:26:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:26:06 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:26:06 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:26:06 --> Model Class Initialized
DEBUG - 2014-02-04 18:26:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:26:06 --> Model Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:26:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:26:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:26:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:26:06 --> Model Class Initialized
DEBUG - 2014-02-04 18:26:06 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:26:06 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-04 18:26:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:26:06 --> Final output sent to browser
DEBUG - 2014-02-04 18:26:06 --> Total execution time: 0.0599
DEBUG - 2014-02-04 18:26:08 --> Config Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:26:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:26:08 --> URI Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Router Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Output Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Security Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Input Class Initialized
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> XSS Filtering completed
DEBUG - 2014-02-04 18:26:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:26:08 --> Language Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Language Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Config Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Loader Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Controller Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Session Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:26:08 --> Session routines successfully run
DEBUG - 2014-02-04 18:26:08 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:26:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:26:08 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:26:08 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:26:08 --> Model Class Initialized
DEBUG - 2014-02-04 18:26:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:26:08 --> Model Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:26:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:26:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:26:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:26:08 --> Model Class Initialized
DEBUG - 2014-02-04 18:26:08 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:26:08 --> File loaded: application/modules/patient/views/add_patient.php
DEBUG - 2014-02-04 18:26:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:26:08 --> Final output sent to browser
DEBUG - 2014-02-04 18:26:08 --> Total execution time: 0.0764
DEBUG - 2014-02-04 18:27:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:27:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:27:24 --> URI Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Router Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Output Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Security Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Input Class Initialized
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:27:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Loader Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Controller Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Session Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:27:24 --> Session routines successfully run
DEBUG - 2014-02-04 18:27:24 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:27:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:27:24 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:27:24 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:27:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:27:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:27:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:27:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:27:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:27:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:27:24 --> Image Lib Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Language file loaded: language/english/imglib_lang.php
ERROR - 2014-02-04 18:27:24 --> The path to the image is not correct.
ERROR - 2014-02-04 18:27:24 --> Your server does not support the GD function required to process this type of image.
DEBUG - 2014-02-04 18:27:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:27:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:27:24 --> URI Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Router Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Output Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Security Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Input Class Initialized
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:27:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Loader Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Controller Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Session Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:27:24 --> Session routines successfully run
DEBUG - 2014-02-04 18:27:24 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:27:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:27:24 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:27:24 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:27:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:27:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:27:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:27:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:27:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:27:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:24 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:27:24 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-04 18:27:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:27:24 --> Final output sent to browser
DEBUG - 2014-02-04 18:27:24 --> Total execution time: 0.0722
DEBUG - 2014-02-04 18:27:31 --> Config Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:27:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:27:31 --> URI Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Router Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Output Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Security Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Input Class Initialized
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:27:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:27:31 --> Language Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Language Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Config Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Loader Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Controller Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Session Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:27:31 --> Session routines successfully run
DEBUG - 2014-02-04 18:27:31 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:27:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:27:31 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:27:31 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:27:31 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:27:31 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:27:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:27:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:27:31 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:27:31 --> Model Class Initialized
DEBUG - 2014-02-04 18:27:31 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:27:31 --> File loaded: application/modules/patient/views/edit_patient_financial_profile.php
DEBUG - 2014-02-04 18:27:31 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:27:31 --> Final output sent to browser
DEBUG - 2014-02-04 18:27:31 --> Total execution time: 0.1031
DEBUG - 2014-02-04 18:28:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:28:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:28:04 --> URI Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Router Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Output Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Security Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Input Class Initialized
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:28:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Loader Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Controller Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Session Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:28:04 --> Session routines successfully run
DEBUG - 2014-02-04 18:28:04 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:28:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:28:04 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:28:04 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:28:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:28:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:28:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:28:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:28:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:28:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: image_helper
ERROR - 2014-02-04 18:28:04 --> Severity: Notice  --> Undefined index: letter_upload D:\xampp\htdocs\renalemr\application\modules\patient\controllers\patient.php 168
DEBUG - 2014-02-04 18:28:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:28:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:28:04 --> URI Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Router Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Output Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Security Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Input Class Initialized
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:28:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Loader Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Controller Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Session Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:28:04 --> Session routines successfully run
DEBUG - 2014-02-04 18:28:04 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:28:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:28:04 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:28:04 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:28:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:28:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:28:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:28:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:28:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:28:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:04 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:28:04 --> File loaded: application/modules/patient/views/patient_financial_profile.php
DEBUG - 2014-02-04 18:28:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:28:04 --> Final output sent to browser
DEBUG - 2014-02-04 18:28:04 --> Total execution time: 0.0783
DEBUG - 2014-02-04 18:28:09 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:28:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:28:09 --> URI Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Router Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Output Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Security Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Input Class Initialized
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:28:09 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Loader Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Controller Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Session Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:28:09 --> Session routines successfully run
DEBUG - 2014-02-04 18:28:09 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:28:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:28:09 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:28:09 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:28:09 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:28:09 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:28:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:28:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:28:09 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:28:09 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:09 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:28:09 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:28:09 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:09 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:28:09 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:09 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:28:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:28:09 --> Final output sent to browser
DEBUG - 2014-02-04 18:28:09 --> Total execution time: 0.0627
DEBUG - 2014-02-04 18:28:31 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:31 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:28:31 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:28:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:28:31 --> URI Class Initialized
DEBUG - 2014-02-04 18:28:31 --> Router Class Initialized
DEBUG - 2014-02-04 18:28:31 --> Output Class Initialized
DEBUG - 2014-02-04 18:28:31 --> Security Class Initialized
DEBUG - 2014-02-04 18:28:31 --> Input Class Initialized
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:28:31 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Loader Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Controller Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Session Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:28:32 --> Session routines successfully run
DEBUG - 2014-02-04 18:28:32 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:28:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:28:32 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:28:32 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:28:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:28:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:28:32 --> URI Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Router Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Output Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Security Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Input Class Initialized
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:28:32 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Loader Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Controller Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Session Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:28:32 --> Session routines successfully run
DEBUG - 2014-02-04 18:28:32 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:28:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:28:32 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:28:32 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:28:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:28:32 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:28:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:28:32 --> Final output sent to browser
DEBUG - 2014-02-04 18:28:32 --> Total execution time: 0.0756
DEBUG - 2014-02-04 18:28:49 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:28:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:28:49 --> URI Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Router Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Output Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Security Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Input Class Initialized
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:28:49 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Loader Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Controller Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Session Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:28:49 --> Session routines successfully run
DEBUG - 2014-02-04 18:28:49 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:28:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:28:49 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:28:49 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:28:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:28:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:28:49 --> URI Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Router Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Output Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Security Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Input Class Initialized
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:28:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:28:49 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Language Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Config Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Loader Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Controller Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Session Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:28:49 --> Session routines successfully run
DEBUG - 2014-02-04 18:28:49 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:28:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:28:49 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:28:49 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:28:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:28:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:28:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:28:49 --> Final output sent to browser
DEBUG - 2014-02-04 18:28:49 --> Total execution time: 0.0761
DEBUG - 2014-02-04 18:29:02 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:02 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:02 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:02 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:02 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:29:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:02 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:02 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:02 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:29:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:02 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:29:02 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:29:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:02 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:03 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:03 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:03 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:29:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:03 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:03 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:03 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:29:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:03 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:29:03 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:29:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:03 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:03 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:29:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:29:03 --> Final output sent to browser
DEBUG - 2014-02-04 18:29:03 --> Total execution time: 0.0835
DEBUG - 2014-02-04 18:29:22 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:22 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:22 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:22 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:22 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:29:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:22 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:22 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:22 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:22 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:22 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:22 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:29:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:22 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:22 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:29:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:29:22 --> Final output sent to browser
DEBUG - 2014-02-04 18:29:22 --> Total execution time: 0.0808
DEBUG - 2014-02-04 18:29:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:38 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:38 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:38 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:29:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:38 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:38 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:38 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:38 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:29:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:38 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:29:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:29:38 --> Final output sent to browser
DEBUG - 2014-02-04 18:29:38 --> Total execution time: 0.0804
DEBUG - 2014-02-04 18:29:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:43 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:43 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:43 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:29:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:43 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:43 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:43 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:29:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:43 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 18:29:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:29:43 --> Final output sent to browser
DEBUG - 2014-02-04 18:29:43 --> Total execution time: 0.0584
DEBUG - 2014-02-04 18:29:50 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:50 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:50 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:50 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:50 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:29:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:50 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:50 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:50 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:50 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:50 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:50 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:50 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:29:50 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:57 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:57 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:57 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:57 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:29:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:57 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:57 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:57 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:57 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:29:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:57 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:29:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:29:57 --> Final output sent to browser
DEBUG - 2014-02-04 18:29:57 --> Total execution time: 0.0778
DEBUG - 2014-02-04 18:29:58 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:29:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:29:58 --> URI Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Router Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Output Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Security Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Input Class Initialized
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> XSS Filtering completed
DEBUG - 2014-02-04 18:29:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:29:58 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Language Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Config Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Loader Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Controller Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Session Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:29:58 --> Session routines successfully run
DEBUG - 2014-02-04 18:29:58 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:29:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:29:58 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:29:58 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:29:58 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:29:58 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:29:58 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:29:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:29:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:29:58 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:29:58 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:58 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:29:58 --> Model Class Initialized
DEBUG - 2014-02-04 18:29:58 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:29:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:29:58 --> Final output sent to browser
DEBUG - 2014-02-04 18:29:58 --> Total execution time: 0.0846
DEBUG - 2014-02-04 18:30:20 --> Config Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:30:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:30:20 --> URI Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Router Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Output Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Security Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Input Class Initialized
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:30:20 --> Language Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Language Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Config Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Loader Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Controller Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Session Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:30:20 --> Session routines successfully run
DEBUG - 2014-02-04 18:30:20 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:30:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:30:20 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:30:20 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:30:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:30:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:30:20 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:30:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:30:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:30:20 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:30:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:30:20 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:20 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:30:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:30:20 --> Final output sent to browser
DEBUG - 2014-02-04 18:30:20 --> Total execution time: 0.0697
DEBUG - 2014-02-04 18:30:35 --> Config Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:30:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:30:35 --> URI Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Router Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Output Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Security Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Input Class Initialized
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:30:35 --> Language Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Language Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Config Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Loader Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Controller Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Session Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:30:35 --> Session routines successfully run
DEBUG - 2014-02-04 18:30:35 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:30:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:30:35 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:30:35 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:30:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:30:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:30:35 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:35 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:30:35 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:35 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:30:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:35 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:30:35 --> Final output sent to browser
DEBUG - 2014-02-04 18:30:35 --> Total execution time: 0.0532
DEBUG - 2014-02-04 18:30:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:30:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:30:43 --> URI Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Router Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Output Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Security Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Input Class Initialized
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:30:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Loader Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Controller Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Session Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:30:43 --> Session routines successfully run
DEBUG - 2014-02-04 18:30:43 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:30:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:30:43 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:30:43 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:30:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:30:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:30:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:30:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:30:43 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:30:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:43 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:30:43 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:30:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:30:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:30:43 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:30:43 --> Final output sent to browser
DEBUG - 2014-02-04 18:30:43 --> Total execution time: 0.0545
DEBUG - 2014-02-04 18:31:02 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:31:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:31:02 --> URI Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Router Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Output Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Security Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Input Class Initialized
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:31:02 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Loader Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Controller Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Session Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:31:02 --> Session routines successfully run
DEBUG - 2014-02-04 18:31:02 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:31:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:31:02 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:31:02 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:31:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:31:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:31:02 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:31:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:31:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:31:02 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:31:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:31:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:02 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:31:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:31:02 --> Final output sent to browser
DEBUG - 2014-02-04 18:31:02 --> Total execution time: 0.0833
DEBUG - 2014-02-04 18:31:21 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:31:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:31:21 --> URI Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Router Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Output Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Security Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Input Class Initialized
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:31:21 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Loader Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Controller Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Session Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:31:21 --> Session routines successfully run
DEBUG - 2014-02-04 18:31:21 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:31:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:31:21 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:31:21 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:31:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:31:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:31:21 --> URI Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Router Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Output Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Security Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Input Class Initialized
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:31:21 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Loader Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Controller Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Session Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:31:21 --> Session routines successfully run
DEBUG - 2014-02-04 18:31:21 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:31:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:31:21 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:31:21 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:31:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:31:21 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:31:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:31:21 --> Final output sent to browser
DEBUG - 2014-02-04 18:31:21 --> Total execution time: 0.0729
DEBUG - 2014-02-04 18:31:33 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:31:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:31:33 --> URI Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Router Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Output Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Security Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Input Class Initialized
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:31:33 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Loader Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Controller Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Session Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:31:33 --> Session routines successfully run
DEBUG - 2014-02-04 18:31:33 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:31:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:31:33 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:31:33 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:31:33 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:31:33 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:31:33 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:31:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:31:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:31:33 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:31:33 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:31:33 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:31:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:31:36 --> URI Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Router Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Output Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Security Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Input Class Initialized
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:31:36 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Loader Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Controller Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Session Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:31:36 --> Session routines successfully run
DEBUG - 2014-02-04 18:31:36 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:31:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:31:36 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:31:36 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:31:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:31:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:31:36 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:31:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:31:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:31:36 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:31:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:36 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:31:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:31:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:31:38 --> URI Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Router Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Output Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Security Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Input Class Initialized
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:31:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Loader Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Controller Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Session Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:31:38 --> Session routines successfully run
DEBUG - 2014-02-04 18:31:38 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:31:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:31:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:31:38 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:31:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:31:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:31:38 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:31:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:31:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:31:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:31:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:31:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:38 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 18:31:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:31:38 --> Final output sent to browser
DEBUG - 2014-02-04 18:31:38 --> Total execution time: 0.0737
DEBUG - 2014-02-04 18:31:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:31:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:31:43 --> URI Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Router Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Output Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Security Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Input Class Initialized
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:31:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:31:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Loader Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Controller Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Session Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:31:43 --> Session routines successfully run
DEBUG - 2014-02-04 18:31:43 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:31:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:31:43 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:31:43 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:31:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:31:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:31:43 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:31:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:31:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:31:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:31:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:31:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:31:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:33:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:33:12 --> URI Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Router Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Output Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Security Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Input Class Initialized
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:33:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Loader Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Controller Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Session Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:33:12 --> Session routines successfully run
DEBUG - 2014-02-04 18:33:12 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:33:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:33:12 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:33:12 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:33:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:33:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:33:12 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:33:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:33:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:33:12 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:33:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:33:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:33:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:33:14 --> URI Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Router Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Output Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Security Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Input Class Initialized
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:33:14 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Loader Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Controller Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Session Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:33:14 --> Session routines successfully run
DEBUG - 2014-02-04 18:33:14 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:33:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:33:14 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:33:14 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:33:14 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:33:14 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:33:14 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:33:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:33:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:33:14 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:33:14 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:33:14 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:14 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:33:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:33:14 --> Final output sent to browser
DEBUG - 2014-02-04 18:33:14 --> Total execution time: 0.0686
DEBUG - 2014-02-04 18:33:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:33:38 --> URI Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Router Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Output Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Security Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Input Class Initialized
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:33:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Loader Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Controller Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Session Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:33:38 --> Session routines successfully run
DEBUG - 2014-02-04 18:33:38 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:33:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:33:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:33:38 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:33:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:33:38 --> URI Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Router Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Output Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Security Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Input Class Initialized
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:33:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Loader Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Controller Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Session Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:33:38 --> Session routines successfully run
DEBUG - 2014-02-04 18:33:38 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:33:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:33:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:33:38 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:33:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:33:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:33:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:33:38 --> Final output sent to browser
DEBUG - 2014-02-04 18:33:38 --> Total execution time: 0.0673
DEBUG - 2014-02-04 18:33:44 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:33:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:33:44 --> URI Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Router Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Output Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Security Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Input Class Initialized
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:33:44 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Loader Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Controller Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Session Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:33:44 --> Session routines successfully run
DEBUG - 2014-02-04 18:33:44 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:33:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:33:44 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:33:44 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:33:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:33:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:33:44 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:33:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:33:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:33:44 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:33:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:33:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:33:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:33:51 --> URI Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Router Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Output Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Security Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Input Class Initialized
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> XSS Filtering completed
DEBUG - 2014-02-04 18:33:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:33:51 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Language Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Config Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Loader Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Controller Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Session Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:33:51 --> Session routines successfully run
DEBUG - 2014-02-04 18:33:51 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:33:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:33:51 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:33:51 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:33:51 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:33:51 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:33:51 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:33:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:33:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:33:51 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:33:51 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:51 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:33:51 --> Model Class Initialized
DEBUG - 2014-02-04 18:33:51 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:33:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:33:51 --> Final output sent to browser
DEBUG - 2014-02-04 18:33:51 --> Total execution time: 0.0795
DEBUG - 2014-02-04 18:34:59 --> Config Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:34:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:34:59 --> URI Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Router Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Output Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Security Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Input Class Initialized
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> XSS Filtering completed
DEBUG - 2014-02-04 18:34:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:34:59 --> Language Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Language Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Config Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Loader Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Controller Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Session Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:34:59 --> Session routines successfully run
DEBUG - 2014-02-04 18:34:59 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:34:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:34:59 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:34:59 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:34:59 --> Model Class Initialized
DEBUG - 2014-02-04 18:34:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:34:59 --> Model Class Initialized
DEBUG - 2014-02-04 18:34:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:34:59 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:34:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:34:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:34:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:34:59 --> Model Class Initialized
DEBUG - 2014-02-04 18:34:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:34:59 --> Model Class Initialized
DEBUG - 2014-02-04 18:34:59 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:34:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:34:59 --> Final output sent to browser
DEBUG - 2014-02-04 18:34:59 --> Total execution time: 0.0847
DEBUG - 2014-02-04 18:35:02 --> Config Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:35:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:35:02 --> URI Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Router Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Output Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Security Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Input Class Initialized
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:35:02 --> Language Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Language Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Config Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Loader Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Controller Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Session Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:35:02 --> Session routines successfully run
DEBUG - 2014-02-04 18:35:02 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:35:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:35:02 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:35:02 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:35:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:35:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:35:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:35:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:35:02 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:35:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:35:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:35:02 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:35:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:35:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:35:02 --> Model Class Initialized
DEBUG - 2014-02-04 18:35:02 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 18:35:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:35:02 --> Final output sent to browser
DEBUG - 2014-02-04 18:35:02 --> Total execution time: 0.0606
DEBUG - 2014-02-04 18:35:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:35:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:35:04 --> URI Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Router Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Output Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Security Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Input Class Initialized
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:35:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:35:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Loader Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Controller Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Session Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:35:04 --> Session routines successfully run
DEBUG - 2014-02-04 18:35:04 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:35:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:35:04 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:35:04 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:35:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:35:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:35:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:35:04 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:35:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:35:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:35:04 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:35:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:35:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:35:04 --> Model Class Initialized
DEBUG - 2014-02-04 18:35:04 --> Final output sent to browser
DEBUG - 2014-02-04 18:35:04 --> Total execution time: 0.0521
DEBUG - 2014-02-04 18:37:57 --> Config Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:37:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:37:57 --> URI Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Router Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Output Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Security Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Input Class Initialized
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> XSS Filtering completed
DEBUG - 2014-02-04 18:37:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:37:57 --> Language Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Language Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Config Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Loader Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Controller Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Session Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:37:57 --> Session routines successfully run
DEBUG - 2014-02-04 18:37:57 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:37:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:37:57 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:37:57 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:37:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:37:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:37:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:37:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:37:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:37:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:37:57 --> Model Class Initialized
DEBUG - 2014-02-04 18:37:57 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:37:57 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-04 18:37:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:37:57 --> Final output sent to browser
DEBUG - 2014-02-04 18:37:57 --> Total execution time: 0.0564
DEBUG - 2014-02-04 18:38:03 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:38:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:38:03 --> URI Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Router Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Output Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Security Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Input Class Initialized
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:38:03 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Loader Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Controller Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Session Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:38:03 --> Session routines successfully run
DEBUG - 2014-02-04 18:38:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:38:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:38:03 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:38:03 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:38:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:38:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:38:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:38:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:38:03 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:38:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:03 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:38:03 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:38:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:03 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:38:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:03 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:38:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:38:03 --> Final output sent to browser
DEBUG - 2014-02-04 18:38:03 --> Total execution time: 0.0855
DEBUG - 2014-02-04 18:38:18 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:38:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:38:18 --> URI Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Router Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Output Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Security Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Input Class Initialized
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:38:18 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Loader Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Controller Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Session Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:38:18 --> Session routines successfully run
DEBUG - 2014-02-04 18:38:18 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:38:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:38:18 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:38:18 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:38:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:38:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:38:18 --> URI Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Router Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Output Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Security Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Input Class Initialized
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:38:18 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Loader Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Controller Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Session Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:38:18 --> Session routines successfully run
DEBUG - 2014-02-04 18:38:18 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:38:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:38:18 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:38:18 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:38:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:38:18 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:38:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:38:18 --> Final output sent to browser
DEBUG - 2014-02-04 18:38:18 --> Total execution time: 0.0638
DEBUG - 2014-02-04 18:38:48 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:48 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:38:48 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:38:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:38:48 --> URI Class Initialized
DEBUG - 2014-02-04 18:38:48 --> Router Class Initialized
DEBUG - 2014-02-04 18:38:48 --> Output Class Initialized
DEBUG - 2014-02-04 18:38:48 --> Security Class Initialized
DEBUG - 2014-02-04 18:38:48 --> Input Class Initialized
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:38:49 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Loader Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Controller Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Session Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:38:49 --> Session routines successfully run
DEBUG - 2014-02-04 18:38:49 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:38:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:38:49 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:38:49 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:38:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:38:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:38:49 --> URI Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Router Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Output Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Security Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Input Class Initialized
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> XSS Filtering completed
DEBUG - 2014-02-04 18:38:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:38:49 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Language Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Config Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Loader Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Controller Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Session Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:38:49 --> Session routines successfully run
DEBUG - 2014-02-04 18:38:49 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:38:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:38:49 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:38:49 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:38:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:38:49 --> Model Class Initialized
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:38:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:38:49 --> Final output sent to browser
DEBUG - 2014-02-04 18:38:49 --> Total execution time: 0.0683
DEBUG - 2014-02-04 18:39:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:39:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:39:12 --> URI Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Router Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Output Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Security Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Input Class Initialized
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:39:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Loader Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Controller Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Session Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:39:12 --> Session routines successfully run
DEBUG - 2014-02-04 18:39:12 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:39:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:39:12 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:39:12 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:39:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:39:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:39:12 --> URI Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Router Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Output Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Security Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Input Class Initialized
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:39:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Loader Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Controller Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Session Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:39:12 --> Session routines successfully run
DEBUG - 2014-02-04 18:39:12 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:39:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:39:12 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:39:12 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:39:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:39:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:39:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:39:12 --> Final output sent to browser
DEBUG - 2014-02-04 18:39:12 --> Total execution time: 0.0696
DEBUG - 2014-02-04 18:39:36 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:39:36 --> URI Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Router Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Output Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Security Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Input Class Initialized
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:39:36 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Loader Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Controller Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Session Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:39:36 --> Session routines successfully run
DEBUG - 2014-02-04 18:39:36 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:39:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:39:36 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:39:36 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:39:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:39:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:39:36 --> URI Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Router Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Output Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Security Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Input Class Initialized
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:39:36 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Loader Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Controller Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Session Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:39:36 --> Session routines successfully run
DEBUG - 2014-02-04 18:39:36 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:39:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:39:36 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:39:36 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:39:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:39:36 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:39:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:39:36 --> Final output sent to browser
DEBUG - 2014-02-04 18:39:36 --> Total execution time: 0.0661
DEBUG - 2014-02-04 18:39:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:39:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:39:43 --> URI Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Router Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Output Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Security Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Input Class Initialized
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:39:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Loader Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Controller Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Session Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:39:43 --> Session routines successfully run
DEBUG - 2014-02-04 18:39:43 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:39:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:39:43 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:39:43 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:39:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:39:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:39:43 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:39:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:39:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:39:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:39:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:39:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:43 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 18:39:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:39:43 --> Final output sent to browser
DEBUG - 2014-02-04 18:39:43 --> Total execution time: 0.0550
DEBUG - 2014-02-04 18:39:52 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:39:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:39:52 --> URI Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Router Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Output Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Security Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Input Class Initialized
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:39:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:39:52 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Language Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Config Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Loader Class Initialized
DEBUG - 2014-02-04 18:39:52 --> Controller Class Initialized
DEBUG - 2014-02-04 18:39:53 --> Session Class Initialized
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:39:53 --> Session routines successfully run
DEBUG - 2014-02-04 18:39:53 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:39:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:39:53 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:39:53 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:39:53 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:39:53 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:39:53 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:39:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:39:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:39:53 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:39:53 --> Model Class Initialized
DEBUG - 2014-02-04 18:39:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:39:53 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:40:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:40:00 --> URI Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Router Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Output Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Security Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Input Class Initialized
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:40:00 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Loader Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Controller Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Session Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:40:00 --> Session routines successfully run
DEBUG - 2014-02-04 18:40:00 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:40:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:40:00 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:40:00 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:40:00 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:40:00 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:40:00 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:40:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:40:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:40:00 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:40:00 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:40:00 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:00 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:40:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:40:00 --> Final output sent to browser
DEBUG - 2014-02-04 18:40:00 --> Total execution time: 0.0600
DEBUG - 2014-02-04 18:40:35 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:40:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:40:35 --> URI Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Router Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Output Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Security Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Input Class Initialized
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:40:35 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Loader Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Controller Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Session Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:40:35 --> Session routines successfully run
DEBUG - 2014-02-04 18:40:35 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:40:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:40:35 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:40:35 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:40:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:40:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:40:35 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:40:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:40:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:40:35 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:40:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:35 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:40:35 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:35 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:40:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:40:35 --> Final output sent to browser
DEBUG - 2014-02-04 18:40:35 --> Total execution time: 0.0583
DEBUG - 2014-02-04 18:40:42 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:40:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:40:42 --> URI Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Router Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Output Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Security Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Input Class Initialized
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:40:42 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Loader Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Controller Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Session Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:40:42 --> Session routines successfully run
DEBUG - 2014-02-04 18:40:42 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:40:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:40:42 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:40:42 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:40:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:40:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:40:42 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:40:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:40:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:40:42 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:40:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:40:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:42 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:40:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:40:42 --> Final output sent to browser
DEBUG - 2014-02-04 18:40:42 --> Total execution time: 0.0510
DEBUG - 2014-02-04 18:40:44 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:40:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:40:44 --> URI Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Router Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Output Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Security Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Input Class Initialized
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:40:44 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Loader Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Controller Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Session Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:40:44 --> Session routines successfully run
DEBUG - 2014-02-04 18:40:44 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:40:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:40:44 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:40:44 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:40:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:40:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:40:44 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:40:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:40:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:40:44 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:40:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:40:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:44 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 18:40:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:40:44 --> Final output sent to browser
DEBUG - 2014-02-04 18:40:44 --> Total execution time: 0.0540
DEBUG - 2014-02-04 18:40:47 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:40:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:40:47 --> URI Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Router Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Output Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Security Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Input Class Initialized
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> XSS Filtering completed
DEBUG - 2014-02-04 18:40:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:40:47 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Language Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Config Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Loader Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Controller Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Session Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:40:47 --> Session routines successfully run
DEBUG - 2014-02-04 18:40:47 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:40:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:40:47 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:40:47 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:40:47 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:40:47 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:40:47 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:40:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:40:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:40:47 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:40:47 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:47 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:40:47 --> Model Class Initialized
DEBUG - 2014-02-04 18:40:47 --> Final output sent to browser
DEBUG - 2014-02-04 18:40:47 --> Total execution time: 0.0573
DEBUG - 2014-02-04 18:41:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:41:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:41:24 --> URI Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Router Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Output Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Security Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Input Class Initialized
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:41:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Loader Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Controller Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Session Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:41:24 --> Session routines successfully run
DEBUG - 2014-02-04 18:41:24 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:41:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:41:24 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:41:24 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:41:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:41:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:41:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:41:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:41:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:41:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:41:24 --> URI Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Router Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Output Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Security Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Input Class Initialized
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:41:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Loader Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Controller Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Session Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:41:24 --> Session routines successfully run
DEBUG - 2014-02-04 18:41:24 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:41:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:41:24 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:41:24 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:41:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:41:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:41:24 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:41:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:41:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:41:24 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:41:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:41:24 --> Final output sent to browser
DEBUG - 2014-02-04 18:41:24 --> Total execution time: 0.0587
DEBUG - 2014-02-04 18:41:27 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:41:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:41:27 --> URI Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Router Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Output Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Security Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Input Class Initialized
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:41:27 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Loader Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Controller Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Session Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:41:27 --> Session routines successfully run
DEBUG - 2014-02-04 18:41:27 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:41:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:41:27 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:41:27 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:41:27 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:41:27 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:41:27 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:41:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:41:27 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:41:27 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:41:27 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:27 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:41:27 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:27 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 18:41:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:41:27 --> Final output sent to browser
DEBUG - 2014-02-04 18:41:27 --> Total execution time: 0.0545
DEBUG - 2014-02-04 18:41:29 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:29 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:41:29 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:41:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:41:29 --> URI Class Initialized
DEBUG - 2014-02-04 18:41:29 --> Router Class Initialized
DEBUG - 2014-02-04 18:41:29 --> Output Class Initialized
DEBUG - 2014-02-04 18:41:29 --> Security Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Input Class Initialized
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:41:30 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Loader Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Controller Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Session Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:41:30 --> Session routines successfully run
DEBUG - 2014-02-04 18:41:30 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:41:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:41:30 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:41:30 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:41:30 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:41:30 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:41:30 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:41:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:41:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:41:30 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:41:30 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:41:30 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:30 --> Final output sent to browser
DEBUG - 2014-02-04 18:41:30 --> Total execution time: 0.0513
DEBUG - 2014-02-04 18:41:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:41:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:41:38 --> URI Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Router Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Output Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Security Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Input Class Initialized
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:41:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Loader Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Controller Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Session Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:41:38 --> Session routines successfully run
DEBUG - 2014-02-04 18:41:38 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:41:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:41:38 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:41:38 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:41:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:41:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:41:38 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:41:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:41:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:41:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:41:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:41:38 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:38 --> File loaded: application/modules/billing/views/amount.php
DEBUG - 2014-02-04 18:41:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:41:38 --> Final output sent to browser
DEBUG - 2014-02-04 18:41:38 --> Total execution time: 0.0533
DEBUG - 2014-02-04 18:41:42 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:41:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:41:42 --> URI Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Router Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Output Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Security Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Input Class Initialized
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:41:42 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Language Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Config Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Loader Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Controller Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Session Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:41:42 --> Session routines successfully run
DEBUG - 2014-02-04 18:41:42 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:41:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:41:42 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:41:42 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:41:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:41:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:41:42 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:41:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:41:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:41:42 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:41:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:41:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:41:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:02 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:02 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:02 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:02 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:02 --> Patient MX_Controller Initialized
DEBUG - 2014-02-04 18:42:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:02 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:03 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:03 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:03 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:03 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:03 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:03 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:42:03 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:03 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:42:03 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-04 18:42:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:42:03 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:03 --> Total execution time: 0.0765
DEBUG - 2014-02-04 18:42:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:04 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:04 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:04 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:42:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:04 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:04 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:04 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:04 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:04 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:05 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:05 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:42:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:05 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:42:05 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:42:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:05 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:05 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:42:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:42:05 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:05 --> Total execution time: 0.0842
DEBUG - 2014-02-04 18:42:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:12 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:12 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:12 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:42:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:12 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:12 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:12 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:42:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:12 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:42:12 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:42:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:12 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:12 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-04 18:42:12 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:12 --> Total execution time: 0.0542
DEBUG - 2014-02-04 18:42:17 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:17 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:17 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:17 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:17 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:42:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:17 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:17 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:17 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:42:17 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:17 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 18:42:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:42:17 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:17 --> Total execution time: 0.0540
DEBUG - 2014-02-04 18:42:22 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:22 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:22 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:22 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:42:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:22 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:22 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:22 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:42:22 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:26 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:26 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:26 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:26 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:42:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:26 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:26 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:26 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:26 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:26 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:26 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:26 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:42:26 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:26 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:42:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:42:26 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:26 --> Total execution time: 0.0771
DEBUG - 2014-02-04 18:42:34 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:34 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:34 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:34 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:34 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:42:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:34 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:34 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:34 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:34 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:34 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:34 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:34 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:34 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:34 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:42:34 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:34 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-04 18:42:34 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:42:34 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:34 --> Total execution time: 0.0750
DEBUG - 2014-02-04 18:42:42 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:42 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:42 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:42 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:42 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:42:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:42 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:42 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:42 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:42 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:42:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:42 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:42:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:42:42 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:42 --> Total execution time: 0.0569
DEBUG - 2014-02-04 18:42:44 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:44 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:44 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:44 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:44 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:42:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:44 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:44 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:44 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:44 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:42:44 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:44 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 18:42:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:42:44 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:44 --> Total execution time: 0.0646
DEBUG - 2014-02-04 18:42:48 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:42:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:42:48 --> URI Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Router Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Output Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Security Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Input Class Initialized
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> XSS Filtering completed
DEBUG - 2014-02-04 18:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:42:48 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Language Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Config Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Loader Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Controller Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Session Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:42:48 --> Session routines successfully run
DEBUG - 2014-02-04 18:42:48 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:42:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:42:48 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:42:48 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:42:48 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:42:48 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:42:48 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:42:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:42:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:42:48 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:42:48 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:42:48 --> Model Class Initialized
DEBUG - 2014-02-04 18:42:48 --> Final output sent to browser
DEBUG - 2014-02-04 18:42:48 --> Total execution time: 0.0507
DEBUG - 2014-02-04 18:43:07 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:43:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:43:07 --> URI Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Router Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Output Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Security Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Input Class Initialized
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:43:07 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Loader Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Controller Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Session Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:43:07 --> Session routines successfully run
DEBUG - 2014-02-04 18:43:07 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:43:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:43:07 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:43:07 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:43:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:43:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:43:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:43:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:43:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:43:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:43:07 --> URI Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Router Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Output Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Security Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Input Class Initialized
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:43:07 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Loader Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Controller Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Session Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:43:07 --> Session routines successfully run
DEBUG - 2014-02-04 18:43:07 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:43:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:43:07 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:43:07 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:43:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:43:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:43:07 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:43:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:43:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:43:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:43:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:43:07 --> Final output sent to browser
DEBUG - 2014-02-04 18:43:07 --> Total execution time: 0.0568
DEBUG - 2014-02-04 18:43:10 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:43:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:43:10 --> URI Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Router Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Output Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Security Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Input Class Initialized
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:43:10 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Loader Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Controller Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Session Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:43:10 --> Session routines successfully run
DEBUG - 2014-02-04 18:43:10 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:43:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:43:10 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:43:10 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:43:10 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:43:10 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:43:10 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:43:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:43:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:43:10 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:43:10 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:43:10 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:10 --> File loaded: application/modules/billing/views/amount.php
DEBUG - 2014-02-04 18:43:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:43:10 --> Final output sent to browser
DEBUG - 2014-02-04 18:43:10 --> Total execution time: 0.0528
DEBUG - 2014-02-04 18:43:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:43:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:43:12 --> URI Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Router Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Output Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Security Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Input Class Initialized
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:43:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Loader Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Controller Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Session Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:43:12 --> Session routines successfully run
DEBUG - 2014-02-04 18:43:12 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:43:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:43:12 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:43:12 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:43:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:43:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:43:12 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:43:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:43:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:43:12 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:43:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:43:12 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:12 --> File loaded: application/modules/billing/views/reciept.php
DEBUG - 2014-02-04 18:43:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:43:12 --> Final output sent to browser
DEBUG - 2014-02-04 18:43:12 --> Total execution time: 0.0544
DEBUG - 2014-02-04 18:43:52 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:43:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:43:52 --> URI Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Router Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Output Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Security Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Input Class Initialized
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:43:52 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Loader Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Controller Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Session Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:43:52 --> Session routines successfully run
DEBUG - 2014-02-04 18:43:52 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:43:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:43:52 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:43:52 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:43:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:43:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:43:52 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:43:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:43:52 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:43:52 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:43:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:52 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:43:52 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:52 --> File loaded: application/modules/billing/views/amount.php
DEBUG - 2014-02-04 18:43:52 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:43:52 --> Final output sent to browser
DEBUG - 2014-02-04 18:43:52 --> Total execution time: 0.0837
DEBUG - 2014-02-04 18:43:56 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:43:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:43:56 --> URI Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Router Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Output Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Security Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Input Class Initialized
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> XSS Filtering completed
DEBUG - 2014-02-04 18:43:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:43:56 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Language Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Config Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Loader Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Controller Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Session Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:43:56 --> Session routines successfully run
DEBUG - 2014-02-04 18:43:56 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:43:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:43:56 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:43:56 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:43:56 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:43:56 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:43:56 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:43:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:43:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:43:56 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:43:56 --> Model Class Initialized
DEBUG - 2014-02-04 18:43:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:43:56 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Config Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:44:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:44:05 --> URI Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Router Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Output Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Security Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Input Class Initialized
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:44:05 --> Language Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Language Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Config Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Loader Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Controller Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Session Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:44:05 --> Session routines successfully run
DEBUG - 2014-02-04 18:44:05 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:44:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:44:05 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:44:05 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:44:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:44:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:44:05 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:44:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:44:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:44:05 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:44:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:44:05 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:05 --> File loaded: application/modules/billing/views/add_reciept.php
DEBUG - 2014-02-04 18:44:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:44:05 --> Final output sent to browser
DEBUG - 2014-02-04 18:44:05 --> Total execution time: 0.0625
DEBUG - 2014-02-04 18:44:07 --> Config Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:44:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:44:07 --> URI Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Router Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Output Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Security Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Input Class Initialized
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:44:07 --> Language Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Language Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Config Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Loader Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Controller Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Session Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:44:07 --> Session routines successfully run
DEBUG - 2014-02-04 18:44:07 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 18:44:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:44:07 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:44:07 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:44:07 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:44:07 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:44:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:44:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:44:07 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:44:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:44:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:44:07 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:44:08 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:44:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:44:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:44:08 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:44:08 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 18:44:08 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:08 --> Final output sent to browser
DEBUG - 2014-02-04 18:44:08 --> Total execution time: 0.0498
DEBUG - 2014-02-04 18:44:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:44:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:44:43 --> URI Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Router Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Output Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Security Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Input Class Initialized
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> XSS Filtering completed
DEBUG - 2014-02-04 18:44:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:44:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Language Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Config Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Loader Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Controller Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Session Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:44:43 --> Session routines successfully run
DEBUG - 2014-02-04 18:44:43 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:44:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:44:43 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:44:43 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:44:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:44:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:44:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:44:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:44:43 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:44:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:43 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:44:43 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:44:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:44:43 --> Model Class Initialized
DEBUG - 2014-02-04 18:44:43 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:44:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:44:43 --> Final output sent to browser
DEBUG - 2014-02-04 18:44:43 --> Total execution time: 0.0649
DEBUG - 2014-02-04 18:45:42 --> Config Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Hooks Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Utf8 Class Initialized
DEBUG - 2014-02-04 18:45:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 18:45:42 --> URI Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Router Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Output Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Security Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Input Class Initialized
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> XSS Filtering completed
DEBUG - 2014-02-04 18:45:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 18:45:42 --> Language Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Language Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Config Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Loader Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Controller Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Session Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: string_helper
DEBUG - 2014-02-04 18:45:42 --> Session routines successfully run
DEBUG - 2014-02-04 18:45:42 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 18:45:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: url_helper
DEBUG - 2014-02-04 18:45:42 --> Database Driver Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: form_helper
DEBUG - 2014-02-04 18:45:42 --> Form Validation Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: number_helper
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: date_helper
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 18:45:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:45:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 18:45:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: language_helper
DEBUG - 2014-02-04 18:45:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 18:45:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 18:45:42 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 18:45:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:45:42 --> Helper loaded: image_helper
DEBUG - 2014-02-04 18:45:42 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 18:45:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:45:42 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 18:45:42 --> Model Class Initialized
DEBUG - 2014-02-04 18:45:42 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 18:45:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 18:45:42 --> Final output sent to browser
DEBUG - 2014-02-04 18:45:42 --> Total execution time: 0.0711
DEBUG - 2014-02-04 20:14:02 --> Config Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:14:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:14:02 --> URI Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Router Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Output Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Security Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Input Class Initialized
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:14:02 --> Language Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Language Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Config Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Loader Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Controller Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Session Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:14:02 --> Session routines successfully run
DEBUG - 2014-02-04 20:14:02 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:14:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:14:02 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:14:02 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:14:02 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:14:02 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:14:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:14:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:14:02 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:14:02 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:02 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:14:02 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:14:02 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:02 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:14:02 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:02 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 20:14:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:14:02 --> Final output sent to browser
DEBUG - 2014-02-04 20:14:02 --> Total execution time: 0.0737
DEBUG - 2014-02-04 20:14:15 --> Config Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:14:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:14:15 --> URI Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Router Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Output Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Security Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Input Class Initialized
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:14:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:14:15 --> Language Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Language Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Config Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Loader Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Controller Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Session Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:14:15 --> Session routines successfully run
DEBUG - 2014-02-04 20:14:15 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:14:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:14:15 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:14:15 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:14:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:14:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:14:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:14:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:14:15 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:14:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:15 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:14:15 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:14:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:15 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:14:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:14:15 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 20:14:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:14:15 --> Final output sent to browser
DEBUG - 2014-02-04 20:14:15 --> Total execution time: 0.0586
DEBUG - 2014-02-04 20:15:31 --> Config Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:15:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:15:31 --> URI Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Router Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Output Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Security Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Input Class Initialized
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:15:31 --> Language Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Language Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Config Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Loader Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Controller Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Session Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:15:31 --> Session routines successfully run
DEBUG - 2014-02-04 20:15:31 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:15:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:15:31 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:15:31 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:15:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Config Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:15:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:15:31 --> URI Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Router Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Output Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Security Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Input Class Initialized
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:15:31 --> Language Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Language Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Config Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Loader Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Controller Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Session Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:15:31 --> Session routines successfully run
DEBUG - 2014-02-04 20:15:31 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:15:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:15:31 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:15:31 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:15:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:15:31 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 20:15:31 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:15:31 --> Final output sent to browser
DEBUG - 2014-02-04 20:15:31 --> Total execution time: 0.0793
DEBUG - 2014-02-04 20:15:44 --> Config Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:15:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:15:44 --> URI Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Router Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Output Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Security Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Input Class Initialized
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:15:44 --> Language Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Language Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Config Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Loader Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Controller Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Session Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:15:44 --> Session routines successfully run
DEBUG - 2014-02-04 20:15:44 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:15:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:15:44 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:15:44 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:15:44 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:15:44 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:15:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:15:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:15:44 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:15:44 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:44 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:15:44 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:15:44 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:44 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:15:44 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Config Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:15:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:15:45 --> URI Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Router Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Output Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Security Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Input Class Initialized
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> XSS Filtering completed
DEBUG - 2014-02-04 20:15:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:15:45 --> Language Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Language Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Config Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Loader Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Controller Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Session Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:15:45 --> Session routines successfully run
DEBUG - 2014-02-04 20:15:45 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:15:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:15:45 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:15:45 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:15:45 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:15:45 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:15:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:15:45 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:15:45 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:15:45 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:45 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:15:45 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:15:45 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:45 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:15:45 --> Model Class Initialized
DEBUG - 2014-02-04 20:15:45 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 20:15:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:15:45 --> Final output sent to browser
DEBUG - 2014-02-04 20:15:45 --> Total execution time: 0.0741
DEBUG - 2014-02-04 20:16:00 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:16:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:16:00 --> URI Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Router Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Output Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Security Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Input Class Initialized
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:16:00 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Loader Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Controller Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Session Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:16:00 --> Session routines successfully run
DEBUG - 2014-02-04 20:16:00 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:16:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:16:00 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:16:00 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:16:00 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:16:00 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:16:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:16:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:16:00 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:16:00 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:16:00 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:16:00 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:00 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:16:00 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:16:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:16:00 --> URI Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Router Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Output Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Security Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Input Class Initialized
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:16:00 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Loader Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Controller Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Session Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:16:00 --> Session routines successfully run
DEBUG - 2014-02-04 20:16:00 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:16:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:16:00 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:16:00 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:16:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:16:00 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:16:01 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:16:01 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:16:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:16:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:16:01 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:16:01 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:01 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:16:01 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:16:01 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:01 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:16:01 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:01 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 20:16:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:16:01 --> Final output sent to browser
DEBUG - 2014-02-04 20:16:01 --> Total execution time: 0.0781
DEBUG - 2014-02-04 20:16:11 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:16:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:16:11 --> URI Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Router Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Output Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Security Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Input Class Initialized
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:16:11 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Loader Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Controller Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Session Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:16:11 --> Session routines successfully run
DEBUG - 2014-02-04 20:16:11 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 20:16:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:16:11 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:16:11 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:16:11 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:16:11 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:16:11 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:16:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:16:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:16:11 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:16:11 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:11 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 20:16:11 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:11 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 20:16:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:16:11 --> Final output sent to browser
DEBUG - 2014-02-04 20:16:11 --> Total execution time: 0.0769
DEBUG - 2014-02-04 20:16:15 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:16:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:16:15 --> URI Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Router Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Output Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Security Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Input Class Initialized
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:16:15 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Loader Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Controller Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Session Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:16:15 --> Session routines successfully run
DEBUG - 2014-02-04 20:16:15 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 20:16:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:16:15 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:16:15 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:16:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:16:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:16:15 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:16:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:16:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:16:15 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:16:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 20:16:15 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:16:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:16:25 --> URI Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Router Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Output Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Security Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Input Class Initialized
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:16:25 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Loader Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Controller Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Session Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:16:25 --> Session routines successfully run
DEBUG - 2014-02-04 20:16:25 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:16:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:16:25 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:16:25 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:16:25 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:16:25 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:16:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:16:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:16:25 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:16:25 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:25 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:16:25 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:16:25 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:25 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:16:25 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:25 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 20:16:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:16:25 --> Final output sent to browser
DEBUG - 2014-02-04 20:16:25 --> Total execution time: 0.0929
DEBUG - 2014-02-04 20:16:37 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:16:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:16:37 --> URI Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Router Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Output Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Security Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Input Class Initialized
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:16:37 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Loader Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Controller Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Session Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:16:37 --> Session routines successfully run
DEBUG - 2014-02-04 20:16:37 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 20:16:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:16:37 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:16:37 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:16:37 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:16:37 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:16:37 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:16:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:16:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:16:37 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:16:37 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:37 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 20:16:37 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:37 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-04 20:16:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:16:37 --> Final output sent to browser
DEBUG - 2014-02-04 20:16:37 --> Total execution time: 0.0543
DEBUG - 2014-02-04 20:16:42 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:16:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:16:42 --> URI Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Router Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Output Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Security Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Input Class Initialized
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:16:42 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Loader Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Controller Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Session Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:16:42 --> Session routines successfully run
DEBUG - 2014-02-04 20:16:42 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 20:16:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:16:42 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:16:42 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:16:42 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:16:42 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:16:42 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:16:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:16:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:16:42 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:16:42 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 20:16:42 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:16:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:16:59 --> URI Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Router Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Output Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Security Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Input Class Initialized
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> XSS Filtering completed
DEBUG - 2014-02-04 20:16:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:16:59 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Language Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Config Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Loader Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Controller Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Session Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:16:59 --> Session routines successfully run
DEBUG - 2014-02-04 20:16:59 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 20:16:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:16:59 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:16:59 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:16:59 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:16:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:16:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:16:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 20:16:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 20:16:59 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Config Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:17:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:17:16 --> URI Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Router Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Output Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Security Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Input Class Initialized
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:17:16 --> Language Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Language Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Config Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Loader Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Controller Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Session Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:17:16 --> Session routines successfully run
DEBUG - 2014-02-04 20:17:16 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:17:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:17:16 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:17:16 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:17:16 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:17:16 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:17:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:17:16 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:17:16 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:17:16 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:16 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:17:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:17:16 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:16 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:17:16 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Config Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:17:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:17:17 --> URI Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Router Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Output Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Security Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Input Class Initialized
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:17:17 --> Language Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Language Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Config Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Loader Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Controller Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Session Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:17:17 --> Session routines successfully run
DEBUG - 2014-02-04 20:17:17 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:17:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:17:17 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:17:17 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:17:17 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:17:17 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:17:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:17:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:17:17 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:17:17 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:17 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:17:17 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:17:17 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:17:17 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:17 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 20:17:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:17:17 --> Final output sent to browser
DEBUG - 2014-02-04 20:17:17 --> Total execution time: 0.0717
DEBUG - 2014-02-04 20:17:22 --> Config Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:17:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:17:22 --> URI Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Router Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Output Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Security Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Input Class Initialized
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> XSS Filtering completed
DEBUG - 2014-02-04 20:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:17:22 --> Language Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Language Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Config Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Loader Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Controller Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Session Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:17:22 --> Session routines successfully run
DEBUG - 2014-02-04 20:17:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 20:17:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:17:22 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:17:22 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:17:22 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:17:22 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:17:22 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:17:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:17:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:17:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:17:22 --> Model Class Initialized
DEBUG - 2014-02-04 20:17:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 20:17:22 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Config Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:23:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:23:21 --> URI Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Router Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Output Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Security Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Input Class Initialized
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:23:21 --> Language Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Language Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Config Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Loader Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Controller Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Session Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:23:21 --> Session routines successfully run
DEBUG - 2014-02-04 20:23:21 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-04 20:23:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:23:21 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:23:21 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:23:21 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:23:21 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:23:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:23:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:23:21 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-04 20:23:21 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:21 --> Helper loaded: image_helper
DEBUG - 2014-02-04 20:23:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-04 20:23:21 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:23:21 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:21 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-04 20:23:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-04 20:23:21 --> Final output sent to browser
DEBUG - 2014-02-04 20:23:21 --> Total execution time: 0.0661
DEBUG - 2014-02-04 20:23:44 --> Config Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Hooks Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Utf8 Class Initialized
DEBUG - 2014-02-04 20:23:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-04 20:23:44 --> URI Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Router Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Output Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Security Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Input Class Initialized
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> XSS Filtering completed
DEBUG - 2014-02-04 20:23:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-04 20:23:44 --> Language Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Language Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Config Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Loader Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Controller Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Session Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: string_helper
DEBUG - 2014-02-04 20:23:44 --> Session routines successfully run
DEBUG - 2014-02-04 20:23:44 --> Billing MX_Controller Initialized
DEBUG - 2014-02-04 20:23:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: url_helper
DEBUG - 2014-02-04 20:23:44 --> Database Driver Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: form_helper
DEBUG - 2014-02-04 20:23:44 --> Form Validation Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: number_helper
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: date_helper
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-04 20:23:44 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-04 20:23:44 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-04 20:23:44 --> Helper loaded: language_helper
DEBUG - 2014-02-04 20:23:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-04 20:23:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-04 20:23:44 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-04 20:23:44 --> Model Class Initialized
DEBUG - 2014-02-04 20:23:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-04 20:23:44 --> Model Class Initialized
