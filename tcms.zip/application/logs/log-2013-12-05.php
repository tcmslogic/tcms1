<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-12-05 06:21:28 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:28 --> Hooks Class Initialized
DEBUG - 2013-12-05 06:21:28 --> Utf8 Class Initialized
DEBUG - 2013-12-05 06:21:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-05 06:21:28 --> URI Class Initialized
DEBUG - 2013-12-05 06:21:28 --> Router Class Initialized
DEBUG - 2013-12-05 06:21:28 --> No URI present. Default controller set.
DEBUG - 2013-12-05 06:21:28 --> Output Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Security Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Input Class Initialized
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-05 06:21:29 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Loader Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Controller Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-05 06:21:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-05 06:21:29 --> Session Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: string_helper
DEBUG - 2013-12-05 06:21:29 --> A session cookie was not found.
DEBUG - 2013-12-05 06:21:29 --> Session routines successfully run
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: url_helper
DEBUG - 2013-12-05 06:21:29 --> Database Driver Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: form_helper
DEBUG - 2013-12-05 06:21:29 --> Form Validation Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: number_helper
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: pager_helper
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: invoice_helper
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: date_helper
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: redirect_helper
DEBUG - 2013-12-05 06:21:29 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-05 06:21:29 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: language_helper
DEBUG - 2013-12-05 06:21:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-05 06:21:29 --> Layout MX_Controller Initialized
DEBUG - 2013-12-05 06:21:29 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Hooks Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Utf8 Class Initialized
DEBUG - 2013-12-05 06:21:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-05 06:21:29 --> URI Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Router Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Output Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Security Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Input Class Initialized
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-05 06:21:29 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Loader Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Controller Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-05 06:21:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-05 06:21:29 --> Session Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: string_helper
DEBUG - 2013-12-05 06:21:29 --> Session routines successfully run
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: url_helper
DEBUG - 2013-12-05 06:21:29 --> Database Driver Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: form_helper
DEBUG - 2013-12-05 06:21:29 --> Form Validation Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: number_helper
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: pager_helper
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: invoice_helper
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: date_helper
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: redirect_helper
DEBUG - 2013-12-05 06:21:29 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-05 06:21:29 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-05 06:21:29 --> Helper loaded: language_helper
DEBUG - 2013-12-05 06:21:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-05 06:21:29 --> Layout MX_Controller Initialized
DEBUG - 2013-12-05 06:21:29 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-05 06:21:29 --> Final output sent to browser
DEBUG - 2013-12-05 06:21:29 --> Total execution time: 0.1434
DEBUG - 2013-12-05 06:21:34 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Hooks Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Utf8 Class Initialized
DEBUG - 2013-12-05 06:21:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-05 06:21:34 --> URI Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Router Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Output Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Security Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Input Class Initialized
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-05 06:21:34 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Loader Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Controller Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-05 06:21:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-05 06:21:34 --> Session Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: string_helper
DEBUG - 2013-12-05 06:21:34 --> Session routines successfully run
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: url_helper
DEBUG - 2013-12-05 06:21:34 --> Database Driver Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: form_helper
DEBUG - 2013-12-05 06:21:34 --> Form Validation Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: number_helper
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: pager_helper
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: invoice_helper
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: date_helper
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: redirect_helper
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: language_helper
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-05 06:21:34 --> Layout MX_Controller Initialized
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Hooks Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Utf8 Class Initialized
DEBUG - 2013-12-05 06:21:34 --> UTF-8 Support Enabled
DEBUG - 2013-12-05 06:21:34 --> URI Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Router Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Output Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Security Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Input Class Initialized
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-05 06:21:34 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Loader Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Controller Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-05 06:21:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-05 06:21:34 --> Session Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: string_helper
DEBUG - 2013-12-05 06:21:34 --> Session routines successfully run
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: url_helper
DEBUG - 2013-12-05 06:21:34 --> Database Driver Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: form_helper
DEBUG - 2013-12-05 06:21:34 --> Form Validation Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: number_helper
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: pager_helper
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: invoice_helper
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: date_helper
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: redirect_helper
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-05 06:21:34 --> Helper loaded: language_helper
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-05 06:21:34 --> Layout MX_Controller Initialized
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/modules/invoices/models/mdl_invoice_amounts.php
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/modules/quotes/models/mdl_quote_amounts.php
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/modules/quotes/models/mdl_quotes.php
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:34 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-05 06:21:34 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:35 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-12-05 06:21:35 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-05 06:21:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-05 06:21:35 --> Final output sent to browser
DEBUG - 2013-12-05 06:21:35 --> Total execution time: 0.5581
DEBUG - 2013-12-05 06:21:37 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Hooks Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Utf8 Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Hooks Class Initialized
DEBUG - 2013-12-05 06:21:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-05 06:21:37 --> Utf8 Class Initialized
DEBUG - 2013-12-05 06:21:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-05 06:21:37 --> URI Class Initialized
DEBUG - 2013-12-05 06:21:37 --> URI Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Router Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Router Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Output Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Output Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Security Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Security Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Input Class Initialized
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> Input Class Initialized
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-05 06:21:37 --> XSS Filtering completed
DEBUG - 2013-12-05 06:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-05 06:21:37 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Language Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Config Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Loader Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Loader Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Controller Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Ajax MX_Controller Initialized
DEBUG - 2013-12-05 06:21:37 --> Controller Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Ajax MX_Controller Initialized
DEBUG - 2013-12-05 06:21:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-05 06:21:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-05 06:21:37 --> Session Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Session Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: string_helper
DEBUG - 2013-12-05 06:21:37 --> Session routines successfully run
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: string_helper
DEBUG - 2013-12-05 06:21:37 --> Session routines successfully run
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: url_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: url_helper
DEBUG - 2013-12-05 06:21:37 --> Database Driver Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Database Driver Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: form_helper
DEBUG - 2013-12-05 06:21:37 --> Form Validation Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: number_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: date_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-05 06:21:37 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-05 06:21:37 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: form_helper
DEBUG - 2013-12-05 06:21:37 --> Form Validation Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: number_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-05 06:21:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: date_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: language_helper
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-05 06:21:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-05 06:21:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-05 06:21:37 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-05 06:21:37 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:37 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-05 06:21:37 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Final output sent to browser
DEBUG - 2013-12-05 06:21:37 --> Total execution time: 0.0738
DEBUG - 2013-12-05 06:21:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-05 06:21:37 --> Helper loaded: language_helper
DEBUG - 2013-12-05 06:21:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-05 06:21:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-05 06:21:37 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-05 06:21:37 --> Model Class Initialized
DEBUG - 2013-12-05 06:21:37 --> Final output sent to browser
DEBUG - 2013-12-05 06:21:37 --> Total execution time: 0.1170
DEBUG - 2013-12-05 07:28:50 --> Config Class Initialized
DEBUG - 2013-12-05 07:28:50 --> Hooks Class Initialized
DEBUG - 2013-12-05 07:28:50 --> Utf8 Class Initialized
DEBUG - 2013-12-05 07:28:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-05 07:28:50 --> URI Class Initialized
DEBUG - 2013-12-05 07:28:50 --> Router Class Initialized
DEBUG - 2013-12-05 07:28:50 --> Output Class Initialized
DEBUG - 2013-12-05 07:28:50 --> Security Class Initialized
DEBUG - 2013-12-05 07:28:50 --> Input Class Initialized
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-05 07:28:50 --> Language Class Initialized
DEBUG - 2013-12-05 07:28:50 --> Language Class Initialized
DEBUG - 2013-12-05 07:28:50 --> Config Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Loader Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Controller Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Useraccess MX_Controller Initialized
DEBUG - 2013-12-05 07:28:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-05 07:28:51 --> Session Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: string_helper
DEBUG - 2013-12-05 07:28:51 --> Session routines successfully run
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: url_helper
DEBUG - 2013-12-05 07:28:51 --> Database Driver Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: form_helper
DEBUG - 2013-12-05 07:28:51 --> Form Validation Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: number_helper
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: pager_helper
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: invoice_helper
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: date_helper
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: redirect_helper
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: language_helper
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-05 07:28:51 --> Layout MX_Controller Initialized
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/useraccess/models/mdl_useraccess.php
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/sitepages/models/mdl_sitepages.php
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Config Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Hooks Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Utf8 Class Initialized
DEBUG - 2013-12-05 07:28:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-05 07:28:51 --> URI Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Router Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Output Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Security Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Input Class Initialized
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> XSS Filtering completed
DEBUG - 2013-12-05 07:28:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-05 07:28:51 --> Language Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Language Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Config Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Loader Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Controller Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Useraccess MX_Controller Initialized
DEBUG - 2013-12-05 07:28:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-05 07:28:51 --> Session Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: string_helper
DEBUG - 2013-12-05 07:28:51 --> Session routines successfully run
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: url_helper
DEBUG - 2013-12-05 07:28:51 --> Database Driver Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: form_helper
DEBUG - 2013-12-05 07:28:51 --> Form Validation Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: number_helper
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: pager_helper
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: invoice_helper
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: date_helper
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: redirect_helper
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-05 07:28:51 --> Helper loaded: language_helper
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-05 07:28:51 --> Layout MX_Controller Initialized
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/useraccess/models/mdl_useraccess.php
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/sitepages/models/mdl_sitepages.php
DEBUG - 2013-12-05 07:28:51 --> Model Class Initialized
DEBUG - 2013-12-05 07:28:51 --> Pagination Class Initialized
ERROR - 2013-12-05 07:28:51 --> Could not find the language line "filter_pages"
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/useraccess/views/index.php
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-12-05 07:28:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-05 07:28:51 --> Final output sent to browser
DEBUG - 2013-12-05 07:28:51 --> Total execution time: 0.1558
