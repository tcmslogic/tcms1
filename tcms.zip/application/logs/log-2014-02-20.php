<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-20 10:40:35 --> Config Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:40:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:40:35 --> URI Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Router Class Initialized
DEBUG - 2014-02-20 10:40:35 --> No URI present. Default controller set.
DEBUG - 2014-02-20 10:40:35 --> Output Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Security Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Input Class Initialized
DEBUG - 2014-02-20 10:40:35 --> XSS Filtering completed
DEBUG - 2014-02-20 10:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:40:35 --> Language Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Language Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Config Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Loader Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:40:35 --> Controller Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Session Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:40:35 --> A session cookie was not found.
DEBUG - 2014-02-20 10:40:35 --> Session routines successfully run
DEBUG - 2014-02-20 10:40:35 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 10:40:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:40:35 --> Database Driver Class Initialized
ERROR - 2014-02-20 10:40:35 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:40:35 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:40:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:40:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:40:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:40:35 --> Config Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:40:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:40:35 --> URI Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Router Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Output Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Security Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Input Class Initialized
DEBUG - 2014-02-20 10:40:35 --> XSS Filtering completed
DEBUG - 2014-02-20 10:40:35 --> XSS Filtering completed
DEBUG - 2014-02-20 10:40:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:40:35 --> Language Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Language Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Config Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Loader Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:40:35 --> Controller Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 10:40:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:40:35 --> Session Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:40:35 --> Session routines successfully run
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:40:35 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:40:35 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:40:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:40:35 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:40:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:40:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:40:35 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 10:40:35 --> Final output sent to browser
DEBUG - 2014-02-20 10:40:35 --> Total execution time: 0.0342
DEBUG - 2014-02-20 10:41:01 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:41:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:41:01 --> URI Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Router Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Output Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Security Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Input Class Initialized
DEBUG - 2014-02-20 10:41:01 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:01 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:01 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:01 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:01 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:41:01 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Loader Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:41:01 --> Controller Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 10:41:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:41:01 --> Session Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:41:01 --> Session routines successfully run
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:41:01 --> Database Driver Class Initialized
ERROR - 2014-02-20 10:41:01 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:41:01 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:41:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:41:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:41:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:41:01 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:01 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 10:41:01 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:41:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:41:01 --> URI Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Router Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Output Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Security Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Input Class Initialized
DEBUG - 2014-02-20 10:41:01 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:01 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:41:01 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Loader Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:41:01 --> Controller Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Session Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:41:01 --> Session routines successfully run
DEBUG - 2014-02-20 10:41:01 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 10:41:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:41:01 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:41:01 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:41:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:41:01 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:41:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:41:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:41:01 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:01 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 10:41:01 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:01 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:41:01 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:01 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 10:41:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:41:01 --> Final output sent to browser
DEBUG - 2014-02-20 10:41:01 --> Total execution time: 0.0395
DEBUG - 2014-02-20 10:41:30 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:41:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:41:30 --> URI Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Router Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Output Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Security Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Input Class Initialized
DEBUG - 2014-02-20 10:41:30 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:30 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:41:30 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Loader Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:41:30 --> Controller Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Session Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:41:30 --> Session routines successfully run
DEBUG - 2014-02-20 10:41:30 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:41:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:41:30 --> Database Driver Class Initialized
ERROR - 2014-02-20 10:41:30 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:41:30 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:41:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:41:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:41:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:41:30 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:41:30 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:30 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:41:30 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 10:41:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:41:30 --> Final output sent to browser
DEBUG - 2014-02-20 10:41:30 --> Total execution time: 0.0698
DEBUG - 2014-02-20 10:41:38 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:41:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:41:38 --> URI Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Router Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Output Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Security Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Input Class Initialized
DEBUG - 2014-02-20 10:41:38 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:38 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:41:38 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Loader Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:41:38 --> Controller Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Session Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:41:38 --> Session routines successfully run
DEBUG - 2014-02-20 10:41:38 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:41:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:41:38 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:41:38 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:41:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:41:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:41:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:41:38 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:41:38 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:38 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:41:38 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 10:41:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:41:38 --> Final output sent to browser
DEBUG - 2014-02-20 10:41:38 --> Total execution time: 0.0646
DEBUG - 2014-02-20 10:41:42 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:41:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:41:42 --> URI Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Router Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Output Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Security Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Input Class Initialized
DEBUG - 2014-02-20 10:41:42 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:42 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:41:42 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Loader Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:41:42 --> Controller Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Session Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:41:42 --> Session routines successfully run
DEBUG - 2014-02-20 10:41:42 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:41:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:41:42 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:41:42 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:41:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:41:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:41:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:41:42 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:41:42 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:42 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:41:42 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-20 10:41:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:41:42 --> Final output sent to browser
DEBUG - 2014-02-20 10:41:42 --> Total execution time: 0.0546
DEBUG - 2014-02-20 10:41:43 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:41:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:41:43 --> URI Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Router Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Output Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Security Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Input Class Initialized
DEBUG - 2014-02-20 10:41:43 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:43 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:41:43 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Loader Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:41:43 --> Controller Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Session Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:41:43 --> Session routines successfully run
DEBUG - 2014-02-20 10:41:43 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:41:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:41:43 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:41:43 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:41:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:41:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:41:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:41:43 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:41:43 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:43 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:41:43 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-20 10:41:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:41:43 --> Final output sent to browser
DEBUG - 2014-02-20 10:41:43 --> Total execution time: 0.0672
DEBUG - 2014-02-20 10:41:44 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:41:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:41:44 --> URI Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Router Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Output Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Security Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Input Class Initialized
DEBUG - 2014-02-20 10:41:44 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:44 --> XSS Filtering completed
DEBUG - 2014-02-20 10:41:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:41:44 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Language Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Config Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Loader Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:41:44 --> Controller Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Session Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:41:44 --> Session routines successfully run
DEBUG - 2014-02-20 10:41:44 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:41:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:41:44 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:41:44 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:41:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:41:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:41:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:41:44 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:41:44 --> Model Class Initialized
DEBUG - 2014-02-20 10:41:44 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:41:44 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 10:41:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:41:44 --> Final output sent to browser
DEBUG - 2014-02-20 10:41:44 --> Total execution time: 0.0539
DEBUG - 2014-02-20 10:42:05 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:05 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:05 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:05 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:05 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:05 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:05 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:05 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:05 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:05 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:05 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:05 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:05 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:05 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-20 10:42:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:05 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:05 --> Total execution time: 0.0543
DEBUG - 2014-02-20 10:42:17 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:17 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:17 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:17 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:17 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:17 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:17 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:17 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:17 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:17 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:17 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:17 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:17 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:17 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:17 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:17 --> Total execution time: 0.0607
DEBUG - 2014-02-20 10:42:22 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:22 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:22 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:22 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:22 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:22 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:22 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:22 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:22 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:22 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:22 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:22 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:22 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:22 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-20 10:42:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:22 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:22 --> Total execution time: 0.0606
DEBUG - 2014-02-20 10:42:30 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:30 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:30 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:30 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:30 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:30 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:30 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:30 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:30 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:30 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:30 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:30 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:30 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:30 --> File loaded: application/modules/patient/views/add_note.php
DEBUG - 2014-02-20 10:42:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:30 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:30 --> Total execution time: 0.0612
DEBUG - 2014-02-20 10:42:38 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:38 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:38 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:38 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:38 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:38 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:38 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:38 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:38 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:38 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:38 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:38 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:38 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:38 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-20 10:42:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:38 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:38 --> Total execution time: 0.0554
DEBUG - 2014-02-20 10:42:40 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:40 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:40 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:40 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:40 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:40 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:40 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:40 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:40 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:40 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:40 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:40 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:40 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:40 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:40 --> File loaded: application/modules/patient/views/certificate.php
DEBUG - 2014-02-20 10:42:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:40 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:40 --> Total execution time: 0.0545
DEBUG - 2014-02-20 10:42:43 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:43 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:43 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:43 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:43 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:43 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:43 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:43 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:43 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:43 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:43 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:43 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:43 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:43 --> File loaded: application/modules/patient/views/prescription.php
DEBUG - 2014-02-20 10:42:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:43 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:43 --> Total execution time: 0.0616
DEBUG - 2014-02-20 10:42:45 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:45 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:45 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:45 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:45 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:45 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:45 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:45 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:45 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:45 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:45 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:45 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:45 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:45 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:45 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:45 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:45 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 10:42:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:45 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:45 --> Total execution time: 0.0659
DEBUG - 2014-02-20 10:42:48 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:48 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:48 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:48 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:48 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:48 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:48 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:48 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:48 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:48 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:48 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:48 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:48 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:48 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 10:42:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:48 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:48 --> Total execution time: 0.0690
DEBUG - 2014-02-20 10:42:50 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:50 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:50 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:50 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:50 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:50 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:50 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:50 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:50 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:50 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:50 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:50 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:50 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:50 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 10:42:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:50 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:50 --> Total execution time: 0.0591
DEBUG - 2014-02-20 10:42:51 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:51 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:51 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:51 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:51 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:51 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:51 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:51 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:51 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:51 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:51 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:51 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:51 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:51 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:51 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-20 10:42:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:51 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:51 --> Total execution time: 0.0532
DEBUG - 2014-02-20 10:42:53 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:53 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:53 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:53 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:53 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:53 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:53 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:53 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:53 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:53 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:53 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:53 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:53 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:53 --> File loaded: application/modules/patient/views/notes.php
DEBUG - 2014-02-20 10:42:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:53 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:53 --> Total execution time: 0.0635
DEBUG - 2014-02-20 10:42:54 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:42:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:42:54 --> URI Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Router Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Output Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Security Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Input Class Initialized
DEBUG - 2014-02-20 10:42:54 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:54 --> XSS Filtering completed
DEBUG - 2014-02-20 10:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:42:54 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Language Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Config Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Loader Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:42:54 --> Controller Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Session Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:42:54 --> Session routines successfully run
DEBUG - 2014-02-20 10:42:54 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:42:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:42:54 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:42:54 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:42:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:42:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:42:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:42:54 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:54 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 10:42:54 --> Model Class Initialized
DEBUG - 2014-02-20 10:42:54 --> Helper loaded: image_helper
DEBUG - 2014-02-20 10:42:54 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 10:42:54 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 10:42:54 --> Final output sent to browser
DEBUG - 2014-02-20 10:42:54 --> Total execution time: 0.0664
DEBUG - 2014-02-20 10:43:22 --> Config Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:43:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:43:22 --> URI Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Router Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Output Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Security Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Input Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:43:22 --> Language Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Language Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Config Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Loader Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:43:22 --> Controller Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 10:43:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:43:22 --> Session Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:43:22 --> A session cookie was not found.
DEBUG - 2014-02-20 10:43:22 --> Session routines successfully run
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:43:22 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:43:22 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:43:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:43:22 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:43:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:43:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:43:22 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 10:43:22 --> Final output sent to browser
DEBUG - 2014-02-20 10:43:22 --> Total execution time: 0.0525
DEBUG - 2014-02-20 10:57:57 --> Config Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:57:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:57:57 --> URI Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Router Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Output Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Security Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Input Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:57:57 --> Language Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Language Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Config Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Loader Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:57:57 --> Controller Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Session Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:57:57 --> A session cookie was not found.
DEBUG - 2014-02-20 10:57:57 --> Session routines successfully run
DEBUG - 2014-02-20 10:57:57 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 10:57:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:57:57 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:57:57 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:57:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:57:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:57:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:57:57 --> Config Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Hooks Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Utf8 Class Initialized
DEBUG - 2014-02-20 10:57:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 10:57:57 --> URI Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Router Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Output Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Security Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Input Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 10:57:57 --> Language Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Language Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Config Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Loader Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: text_helper
DEBUG - 2014-02-20 10:57:57 --> Controller Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 10:57:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 10:57:57 --> Session Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: string_helper
DEBUG - 2014-02-20 10:57:57 --> A session cookie was not found.
DEBUG - 2014-02-20 10:57:57 --> Session routines successfully run
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: url_helper
DEBUG - 2014-02-20 10:57:57 --> Database Driver Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: form_helper
DEBUG - 2014-02-20 10:57:57 --> Form Validation Class Initialized
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: number_helper
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: date_helper
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 10:57:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 10:57:57 --> Helper loaded: language_helper
DEBUG - 2014-02-20 10:57:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 10:57:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 10:57:57 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 10:57:57 --> Final output sent to browser
DEBUG - 2014-02-20 10:57:57 --> Total execution time: 0.0330
DEBUG - 2014-02-20 11:00:06 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:00:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:00:06 --> URI Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Router Class Initialized
DEBUG - 2014-02-20 11:00:06 --> No URI present. Default controller set.
DEBUG - 2014-02-20 11:00:06 --> Output Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Security Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Input Class Initialized
DEBUG - 2014-02-20 11:00:06 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:06 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:00:06 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Loader Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:00:06 --> Controller Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Session Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:00:06 --> A session cookie was not found.
DEBUG - 2014-02-20 11:00:06 --> Session routines successfully run
DEBUG - 2014-02-20 11:00:06 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:00:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:00:06 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:00:06 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:00:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:00:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:00:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:00:06 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:00:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:00:06 --> URI Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Router Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Output Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Security Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Input Class Initialized
DEBUG - 2014-02-20 11:00:06 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:06 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:06 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:00:06 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Loader Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:00:06 --> Controller Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 11:00:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:00:06 --> Session Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:00:06 --> Session routines successfully run
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:00:06 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:00:06 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:00:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:00:06 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:00:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:00:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:00:06 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 11:00:06 --> Final output sent to browser
DEBUG - 2014-02-20 11:00:06 --> Total execution time: 0.0342
DEBUG - 2014-02-20 11:00:14 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:00:14 --> URI Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Router Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Output Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Security Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Input Class Initialized
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:00:14 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Loader Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:00:14 --> Controller Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 11:00:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:00:14 --> Session Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:00:14 --> Session routines successfully run
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:00:14 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:00:14 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:00:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:00:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:00:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:00:14 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:14 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 11:00:14 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:00:14 --> URI Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Router Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Output Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Security Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Input Class Initialized
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:00:14 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Loader Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:00:14 --> Controller Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Session Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:00:14 --> Session routines successfully run
DEBUG - 2014-02-20 11:00:14 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:00:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:00:14 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:00:14 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:00:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:00:14 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:00:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:00:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:00:14 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:14 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:00:14 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:00:14 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:14 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:00:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:00:14 --> Final output sent to browser
DEBUG - 2014-02-20 11:00:14 --> Total execution time: 0.0586
DEBUG - 2014-02-20 11:00:18 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:00:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:00:18 --> URI Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Router Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Output Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Security Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Input Class Initialized
DEBUG - 2014-02-20 11:00:18 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:18 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:18 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:00:18 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Loader Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:00:18 --> Controller Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Session Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:00:18 --> Session routines successfully run
DEBUG - 2014-02-20 11:00:18 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 11:00:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:00:18 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:00:18 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:00:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:00:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:00:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:00:18 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:18 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 11:00:18 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:18 --> Helper loaded: image_helper
ERROR - 2014-02-20 11:00:18 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 11:00:18 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 11:00:18 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 11:00:18 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 11:00:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:00:18 --> Final output sent to browser
DEBUG - 2014-02-20 11:00:18 --> Total execution time: 0.0698
DEBUG - 2014-02-20 11:00:25 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:00:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:00:25 --> URI Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Router Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Output Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Security Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Input Class Initialized
DEBUG - 2014-02-20 11:00:25 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:25 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:25 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:25 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:25 --> XSS Filtering completed
DEBUG - 2014-02-20 11:00:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:00:25 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Language Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Config Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Loader Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:00:25 --> Controller Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Session Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:00:25 --> Session routines successfully run
DEBUG - 2014-02-20 11:00:25 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 11:00:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:00:25 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:00:25 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:00:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:00:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:00:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:00:25 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:25 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 11:00:25 --> Model Class Initialized
DEBUG - 2014-02-20 11:00:25 --> Helper loaded: image_helper
DEBUG - 2014-02-20 11:00:25 --> Final output sent to browser
DEBUG - 2014-02-20 11:00:25 --> Total execution time: 0.0573
DEBUG - 2014-02-20 11:01:29 --> Config Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:01:29 --> URI Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Router Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Output Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Security Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Input Class Initialized
DEBUG - 2014-02-20 11:01:29 --> XSS Filtering completed
DEBUG - 2014-02-20 11:01:29 --> XSS Filtering completed
DEBUG - 2014-02-20 11:01:29 --> XSS Filtering completed
DEBUG - 2014-02-20 11:01:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:01:29 --> Language Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Language Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Config Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Loader Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:01:29 --> Controller Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Session Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:01:29 --> Session routines successfully run
DEBUG - 2014-02-20 11:01:29 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:01:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:01:29 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:01:29 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:01:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:01:29 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:01:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:01:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:01:29 --> Model Class Initialized
DEBUG - 2014-02-20 11:01:29 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:01:29 --> Model Class Initialized
DEBUG - 2014-02-20 11:01:29 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:01:29 --> Model Class Initialized
DEBUG - 2014-02-20 11:01:29 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:01:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:01:29 --> Final output sent to browser
DEBUG - 2014-02-20 11:01:29 --> Total execution time: 0.0609
DEBUG - 2014-02-20 11:03:08 --> Config Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:03:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:03:08 --> URI Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Router Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Output Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Security Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Input Class Initialized
DEBUG - 2014-02-20 11:03:08 --> XSS Filtering completed
DEBUG - 2014-02-20 11:03:08 --> XSS Filtering completed
DEBUG - 2014-02-20 11:03:08 --> XSS Filtering completed
DEBUG - 2014-02-20 11:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:03:08 --> Language Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Language Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Config Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Loader Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:03:08 --> Controller Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Session Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:03:08 --> Session routines successfully run
DEBUG - 2014-02-20 11:03:08 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:03:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:03:08 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:03:08 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:03:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:03:08 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:03:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:03:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:03:08 --> Model Class Initialized
DEBUG - 2014-02-20 11:03:08 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:03:08 --> Model Class Initialized
DEBUG - 2014-02-20 11:03:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:03:08 --> Model Class Initialized
DEBUG - 2014-02-20 11:03:08 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:03:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:03:08 --> Final output sent to browser
DEBUG - 2014-02-20 11:03:08 --> Total execution time: 0.0566
DEBUG - 2014-02-20 11:25:42 --> Config Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:25:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:25:42 --> URI Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Router Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Output Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Security Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Input Class Initialized
DEBUG - 2014-02-20 11:25:42 --> XSS Filtering completed
DEBUG - 2014-02-20 11:25:42 --> XSS Filtering completed
DEBUG - 2014-02-20 11:25:42 --> XSS Filtering completed
DEBUG - 2014-02-20 11:25:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:25:42 --> Language Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Language Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Config Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Loader Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:25:42 --> Controller Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Session Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:25:42 --> Session routines successfully run
DEBUG - 2014-02-20 11:25:42 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:25:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:25:42 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:25:42 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:25:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:25:42 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:25:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:25:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:25:42 --> Model Class Initialized
DEBUG - 2014-02-20 11:25:42 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:25:42 --> Model Class Initialized
DEBUG - 2014-02-20 11:25:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:25:42 --> Model Class Initialized
DEBUG - 2014-02-20 11:25:42 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:25:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:25:42 --> Final output sent to browser
DEBUG - 2014-02-20 11:25:42 --> Total execution time: 0.0506
DEBUG - 2014-02-20 11:25:54 --> Config Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:25:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:25:54 --> URI Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Router Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Output Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Security Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Input Class Initialized
DEBUG - 2014-02-20 11:25:54 --> XSS Filtering completed
DEBUG - 2014-02-20 11:25:54 --> XSS Filtering completed
DEBUG - 2014-02-20 11:25:54 --> XSS Filtering completed
DEBUG - 2014-02-20 11:25:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:25:54 --> Language Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Language Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Config Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Loader Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:25:54 --> Controller Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Session Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:25:54 --> Session routines successfully run
DEBUG - 2014-02-20 11:25:54 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:25:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:25:54 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:25:54 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:25:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:25:54 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:25:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:25:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:25:54 --> Model Class Initialized
DEBUG - 2014-02-20 11:25:54 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:25:54 --> Model Class Initialized
DEBUG - 2014-02-20 11:25:54 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:25:54 --> Model Class Initialized
DEBUG - 2014-02-20 11:25:54 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:25:54 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:25:54 --> Final output sent to browser
DEBUG - 2014-02-20 11:25:54 --> Total execution time: 0.0544
DEBUG - 2014-02-20 11:26:11 --> Config Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:26:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:26:11 --> URI Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Router Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Output Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Security Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Input Class Initialized
DEBUG - 2014-02-20 11:26:11 --> XSS Filtering completed
DEBUG - 2014-02-20 11:26:11 --> XSS Filtering completed
DEBUG - 2014-02-20 11:26:11 --> XSS Filtering completed
DEBUG - 2014-02-20 11:26:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:26:11 --> Language Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Language Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Config Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Loader Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:26:11 --> Controller Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Session Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:26:11 --> Session routines successfully run
DEBUG - 2014-02-20 11:26:11 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:26:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:26:11 --> Database Driver Class Initialized
ERROR - 2014-02-20 11:26:11 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:26:11 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:26:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:26:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:26:12 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:26:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:26:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:26:12 --> Model Class Initialized
DEBUG - 2014-02-20 11:26:12 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:26:12 --> Model Class Initialized
DEBUG - 2014-02-20 11:26:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:26:12 --> Model Class Initialized
DEBUG - 2014-02-20 11:26:12 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:26:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:26:12 --> Final output sent to browser
DEBUG - 2014-02-20 11:26:12 --> Total execution time: 0.0572
DEBUG - 2014-02-20 11:31:46 --> Config Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:31:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:31:46 --> URI Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Router Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Output Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Security Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Input Class Initialized
DEBUG - 2014-02-20 11:31:46 --> XSS Filtering completed
DEBUG - 2014-02-20 11:31:46 --> XSS Filtering completed
DEBUG - 2014-02-20 11:31:46 --> XSS Filtering completed
DEBUG - 2014-02-20 11:31:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:31:46 --> Language Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Language Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Config Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Loader Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:31:46 --> Controller Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Session Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:31:46 --> Session routines successfully run
DEBUG - 2014-02-20 11:31:46 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:31:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:31:46 --> Database Driver Class Initialized
ERROR - 2014-02-20 11:31:46 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:31:46 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:31:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:31:46 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:31:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:31:46 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:31:46 --> Model Class Initialized
DEBUG - 2014-02-20 11:31:46 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:31:46 --> Model Class Initialized
DEBUG - 2014-02-20 11:31:46 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:31:46 --> Model Class Initialized
DEBUG - 2014-02-20 11:31:46 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:31:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:31:46 --> Final output sent to browser
DEBUG - 2014-02-20 11:31:46 --> Total execution time: 0.0653
DEBUG - 2014-02-20 11:33:48 --> Config Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:33:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:33:48 --> URI Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Router Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Output Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Security Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Input Class Initialized
DEBUG - 2014-02-20 11:33:48 --> XSS Filtering completed
DEBUG - 2014-02-20 11:33:48 --> XSS Filtering completed
DEBUG - 2014-02-20 11:33:48 --> XSS Filtering completed
DEBUG - 2014-02-20 11:33:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:33:48 --> Language Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Language Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Config Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Loader Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:33:48 --> Controller Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Session Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:33:48 --> Session routines successfully run
DEBUG - 2014-02-20 11:33:48 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:33:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:33:48 --> Database Driver Class Initialized
ERROR - 2014-02-20 11:33:48 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:33:48 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:33:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:33:48 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:33:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:33:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:33:48 --> Model Class Initialized
DEBUG - 2014-02-20 11:33:48 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:33:48 --> Model Class Initialized
DEBUG - 2014-02-20 11:33:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:33:48 --> Model Class Initialized
DEBUG - 2014-02-20 11:33:48 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:33:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:33:48 --> Final output sent to browser
DEBUG - 2014-02-20 11:33:48 --> Total execution time: 0.0649
DEBUG - 2014-02-20 11:34:07 --> Config Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:34:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:34:07 --> URI Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Router Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Output Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Security Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Input Class Initialized
DEBUG - 2014-02-20 11:34:07 --> XSS Filtering completed
DEBUG - 2014-02-20 11:34:07 --> XSS Filtering completed
DEBUG - 2014-02-20 11:34:07 --> XSS Filtering completed
DEBUG - 2014-02-20 11:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:34:07 --> Language Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Language Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Config Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Loader Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:34:07 --> Controller Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Session Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:34:07 --> Session routines successfully run
DEBUG - 2014-02-20 11:34:07 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:34:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:34:07 --> Database Driver Class Initialized
ERROR - 2014-02-20 11:34:07 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:34:07 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:34:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:34:07 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:34:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:34:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:34:07 --> Model Class Initialized
DEBUG - 2014-02-20 11:34:07 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:34:07 --> Model Class Initialized
DEBUG - 2014-02-20 11:34:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:34:07 --> Model Class Initialized
DEBUG - 2014-02-20 11:34:07 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:34:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:34:07 --> Final output sent to browser
DEBUG - 2014-02-20 11:34:07 --> Total execution time: 0.0645
DEBUG - 2014-02-20 11:37:41 --> Config Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:37:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:37:41 --> URI Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Router Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Output Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Security Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Input Class Initialized
DEBUG - 2014-02-20 11:37:41 --> XSS Filtering completed
DEBUG - 2014-02-20 11:37:41 --> XSS Filtering completed
DEBUG - 2014-02-20 11:37:41 --> XSS Filtering completed
DEBUG - 2014-02-20 11:37:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:37:41 --> Language Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Language Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Config Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Loader Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:37:41 --> Controller Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Session Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:37:41 --> Session routines successfully run
DEBUG - 2014-02-20 11:37:41 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:37:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:37:41 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:37:41 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:37:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:37:41 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:37:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:37:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:37:41 --> Model Class Initialized
DEBUG - 2014-02-20 11:37:41 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:37:41 --> Model Class Initialized
DEBUG - 2014-02-20 11:37:41 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:37:41 --> Model Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Config Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:38:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:38:50 --> URI Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Router Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Output Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Security Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Input Class Initialized
DEBUG - 2014-02-20 11:38:50 --> XSS Filtering completed
DEBUG - 2014-02-20 11:38:50 --> XSS Filtering completed
DEBUG - 2014-02-20 11:38:50 --> XSS Filtering completed
DEBUG - 2014-02-20 11:38:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:38:50 --> Language Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Language Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Config Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Loader Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:38:50 --> Controller Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Session Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:38:50 --> Session routines successfully run
DEBUG - 2014-02-20 11:38:50 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:38:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:38:50 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:38:50 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:38:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:38:50 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:38:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:38:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:38:50 --> Model Class Initialized
DEBUG - 2014-02-20 11:38:50 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:38:50 --> Model Class Initialized
DEBUG - 2014-02-20 11:38:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:38:50 --> Model Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Config Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:43:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:43:55 --> URI Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Router Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Output Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Security Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Input Class Initialized
DEBUG - 2014-02-20 11:43:55 --> XSS Filtering completed
DEBUG - 2014-02-20 11:43:55 --> XSS Filtering completed
DEBUG - 2014-02-20 11:43:55 --> XSS Filtering completed
DEBUG - 2014-02-20 11:43:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:43:55 --> Language Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Language Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Config Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Loader Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:43:55 --> Controller Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Session Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:43:55 --> Session routines successfully run
DEBUG - 2014-02-20 11:43:55 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:43:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:43:55 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:43:55 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:43:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:43:55 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:43:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:43:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:43:55 --> Model Class Initialized
DEBUG - 2014-02-20 11:43:55 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:43:55 --> Model Class Initialized
DEBUG - 2014-02-20 11:43:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:43:55 --> Model Class Initialized
DEBUG - 2014-02-20 11:43:55 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:43:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:43:55 --> Final output sent to browser
DEBUG - 2014-02-20 11:43:55 --> Total execution time: 0.0529
DEBUG - 2014-02-20 11:45:35 --> Config Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Hooks Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Utf8 Class Initialized
DEBUG - 2014-02-20 11:45:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 11:45:35 --> URI Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Router Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Output Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Security Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Input Class Initialized
DEBUG - 2014-02-20 11:45:35 --> XSS Filtering completed
DEBUG - 2014-02-20 11:45:35 --> XSS Filtering completed
DEBUG - 2014-02-20 11:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 11:45:35 --> Language Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Language Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Config Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Loader Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: text_helper
DEBUG - 2014-02-20 11:45:35 --> Controller Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Session Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: string_helper
DEBUG - 2014-02-20 11:45:35 --> Session routines successfully run
DEBUG - 2014-02-20 11:45:35 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 11:45:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: url_helper
DEBUG - 2014-02-20 11:45:35 --> Database Driver Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: form_helper
DEBUG - 2014-02-20 11:45:35 --> Form Validation Class Initialized
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: number_helper
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: date_helper
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 11:45:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 11:45:35 --> Helper loaded: language_helper
DEBUG - 2014-02-20 11:45:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 11:45:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 11:45:35 --> Model Class Initialized
DEBUG - 2014-02-20 11:45:35 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 11:45:35 --> Model Class Initialized
DEBUG - 2014-02-20 11:45:35 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 11:45:35 --> Model Class Initialized
DEBUG - 2014-02-20 11:45:35 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 11:45:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 11:45:35 --> Final output sent to browser
DEBUG - 2014-02-20 11:45:35 --> Total execution time: 0.0579
DEBUG - 2014-02-20 12:57:10 --> Config Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Hooks Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Utf8 Class Initialized
DEBUG - 2014-02-20 12:57:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 12:57:10 --> URI Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Router Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Output Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Security Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Input Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 12:57:10 --> Language Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Language Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Config Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Loader Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: text_helper
DEBUG - 2014-02-20 12:57:10 --> Controller Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Session Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: string_helper
DEBUG - 2014-02-20 12:57:10 --> A session cookie was not found.
DEBUG - 2014-02-20 12:57:10 --> Session routines successfully run
DEBUG - 2014-02-20 12:57:10 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 12:57:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: url_helper
DEBUG - 2014-02-20 12:57:10 --> Database Driver Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: form_helper
DEBUG - 2014-02-20 12:57:10 --> Form Validation Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: number_helper
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: date_helper
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 12:57:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: language_helper
DEBUG - 2014-02-20 12:57:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 12:57:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 12:57:10 --> Config Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Hooks Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Utf8 Class Initialized
DEBUG - 2014-02-20 12:57:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 12:57:10 --> URI Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Router Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Output Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Security Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Input Class Initialized
DEBUG - 2014-02-20 12:57:10 --> XSS Filtering completed
DEBUG - 2014-02-20 12:57:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 12:57:10 --> Language Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Language Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Config Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Loader Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: text_helper
DEBUG - 2014-02-20 12:57:10 --> Controller Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 12:57:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 12:57:10 --> Session Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: string_helper
DEBUG - 2014-02-20 12:57:10 --> Session routines successfully run
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: url_helper
DEBUG - 2014-02-20 12:57:10 --> Database Driver Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: form_helper
DEBUG - 2014-02-20 12:57:10 --> Form Validation Class Initialized
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: number_helper
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: date_helper
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 12:57:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 12:57:10 --> Helper loaded: language_helper
DEBUG - 2014-02-20 12:57:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 12:57:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 12:57:10 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 12:57:10 --> Final output sent to browser
DEBUG - 2014-02-20 12:57:10 --> Total execution time: 0.0433
DEBUG - 2014-02-20 12:57:25 --> Config Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Hooks Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Utf8 Class Initialized
DEBUG - 2014-02-20 12:57:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 12:57:25 --> URI Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Router Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Output Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Security Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Input Class Initialized
DEBUG - 2014-02-20 12:57:25 --> XSS Filtering completed
DEBUG - 2014-02-20 12:57:25 --> XSS Filtering completed
DEBUG - 2014-02-20 12:57:25 --> XSS Filtering completed
DEBUG - 2014-02-20 12:57:25 --> XSS Filtering completed
DEBUG - 2014-02-20 12:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 12:57:25 --> Language Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Language Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Config Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Loader Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: text_helper
DEBUG - 2014-02-20 12:57:25 --> Controller Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 12:57:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 12:57:25 --> Session Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: string_helper
DEBUG - 2014-02-20 12:57:25 --> Session routines successfully run
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: url_helper
DEBUG - 2014-02-20 12:57:25 --> Database Driver Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: form_helper
DEBUG - 2014-02-20 12:57:25 --> Form Validation Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: number_helper
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: date_helper
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 12:57:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: language_helper
DEBUG - 2014-02-20 12:57:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 12:57:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 12:57:25 --> Model Class Initialized
DEBUG - 2014-02-20 12:57:25 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 12:57:25 --> Model Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Config Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Hooks Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Utf8 Class Initialized
DEBUG - 2014-02-20 12:57:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 12:57:25 --> URI Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Router Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Output Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Security Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Input Class Initialized
DEBUG - 2014-02-20 12:57:25 --> XSS Filtering completed
DEBUG - 2014-02-20 12:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 12:57:25 --> Language Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Language Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Config Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Loader Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: text_helper
DEBUG - 2014-02-20 12:57:25 --> Controller Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Session Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: string_helper
DEBUG - 2014-02-20 12:57:25 --> Session routines successfully run
DEBUG - 2014-02-20 12:57:25 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 12:57:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: url_helper
DEBUG - 2014-02-20 12:57:25 --> Database Driver Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: form_helper
DEBUG - 2014-02-20 12:57:25 --> Form Validation Class Initialized
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: number_helper
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: date_helper
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 12:57:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 12:57:25 --> Helper loaded: language_helper
DEBUG - 2014-02-20 12:57:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 12:57:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 12:57:25 --> Model Class Initialized
DEBUG - 2014-02-20 12:57:25 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 12:57:25 --> Model Class Initialized
DEBUG - 2014-02-20 12:57:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 12:57:25 --> Model Class Initialized
DEBUG - 2014-02-20 12:57:25 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 12:57:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 12:57:25 --> Final output sent to browser
DEBUG - 2014-02-20 12:57:25 --> Total execution time: 0.0480
DEBUG - 2014-02-20 13:02:11 --> Config Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Hooks Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Utf8 Class Initialized
DEBUG - 2014-02-20 13:02:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 13:02:11 --> URI Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Router Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Output Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Security Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Input Class Initialized
DEBUG - 2014-02-20 13:02:11 --> XSS Filtering completed
DEBUG - 2014-02-20 13:02:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 13:02:11 --> Language Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Language Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Config Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Loader Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: text_helper
DEBUG - 2014-02-20 13:02:11 --> Controller Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Session Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: string_helper
DEBUG - 2014-02-20 13:02:11 --> Session routines successfully run
DEBUG - 2014-02-20 13:02:11 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 13:02:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: url_helper
DEBUG - 2014-02-20 13:02:11 --> Database Driver Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: form_helper
DEBUG - 2014-02-20 13:02:11 --> Form Validation Class Initialized
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: number_helper
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: date_helper
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 13:02:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 13:02:11 --> Helper loaded: language_helper
DEBUG - 2014-02-20 13:02:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 13:02:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 13:02:11 --> Model Class Initialized
DEBUG - 2014-02-20 13:02:11 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 13:02:11 --> Model Class Initialized
DEBUG - 2014-02-20 13:02:11 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 13:02:11 --> Model Class Initialized
DEBUG - 2014-02-20 13:02:11 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 13:02:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 13:02:11 --> Final output sent to browser
DEBUG - 2014-02-20 13:02:11 --> Total execution time: 0.0600
DEBUG - 2014-02-20 13:02:42 --> Config Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Hooks Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Utf8 Class Initialized
DEBUG - 2014-02-20 13:02:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 13:02:42 --> URI Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Router Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Output Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Security Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Input Class Initialized
DEBUG - 2014-02-20 13:02:42 --> XSS Filtering completed
DEBUG - 2014-02-20 13:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 13:02:42 --> Language Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Language Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Config Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Loader Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: text_helper
DEBUG - 2014-02-20 13:02:42 --> Controller Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Session Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: string_helper
DEBUG - 2014-02-20 13:02:42 --> Session routines successfully run
DEBUG - 2014-02-20 13:02:42 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 13:02:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: url_helper
DEBUG - 2014-02-20 13:02:42 --> Database Driver Class Initialized
ERROR - 2014-02-20 13:02:42 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: form_helper
DEBUG - 2014-02-20 13:02:42 --> Form Validation Class Initialized
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: number_helper
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: date_helper
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 13:02:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 13:02:42 --> Helper loaded: language_helper
DEBUG - 2014-02-20 13:02:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 13:02:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 13:02:42 --> Model Class Initialized
DEBUG - 2014-02-20 13:02:42 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 13:02:42 --> Model Class Initialized
DEBUG - 2014-02-20 13:02:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 13:02:42 --> Model Class Initialized
DEBUG - 2014-02-20 13:02:42 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 13:02:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 13:02:42 --> Final output sent to browser
DEBUG - 2014-02-20 13:02:42 --> Total execution time: 0.0543
DEBUG - 2014-02-20 13:03:05 --> Config Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Hooks Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Utf8 Class Initialized
DEBUG - 2014-02-20 13:03:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 13:03:05 --> URI Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Router Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Output Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Security Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Input Class Initialized
DEBUG - 2014-02-20 13:03:05 --> XSS Filtering completed
DEBUG - 2014-02-20 13:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 13:03:05 --> Language Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Language Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Config Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Loader Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: text_helper
DEBUG - 2014-02-20 13:03:05 --> Controller Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Session Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: string_helper
DEBUG - 2014-02-20 13:03:05 --> Session routines successfully run
DEBUG - 2014-02-20 13:03:05 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 13:03:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: url_helper
DEBUG - 2014-02-20 13:03:05 --> Database Driver Class Initialized
ERROR - 2014-02-20 13:03:05 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: form_helper
DEBUG - 2014-02-20 13:03:05 --> Form Validation Class Initialized
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: number_helper
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: date_helper
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 13:03:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 13:03:05 --> Helper loaded: language_helper
DEBUG - 2014-02-20 13:03:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 13:03:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 13:03:05 --> Model Class Initialized
DEBUG - 2014-02-20 13:03:05 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 13:03:05 --> Model Class Initialized
DEBUG - 2014-02-20 13:03:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 13:03:05 --> Model Class Initialized
DEBUG - 2014-02-20 13:03:05 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 13:03:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 13:03:05 --> Final output sent to browser
DEBUG - 2014-02-20 13:03:05 --> Total execution time: 0.0564
DEBUG - 2014-02-20 13:04:30 --> Config Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Hooks Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Utf8 Class Initialized
DEBUG - 2014-02-20 13:04:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 13:04:30 --> URI Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Router Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Output Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Security Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Input Class Initialized
DEBUG - 2014-02-20 13:04:30 --> XSS Filtering completed
DEBUG - 2014-02-20 13:04:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 13:04:30 --> Language Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Language Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Config Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Loader Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: text_helper
DEBUG - 2014-02-20 13:04:30 --> Controller Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Session Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: string_helper
DEBUG - 2014-02-20 13:04:30 --> Session routines successfully run
DEBUG - 2014-02-20 13:04:30 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 13:04:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: url_helper
DEBUG - 2014-02-20 13:04:30 --> Database Driver Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: form_helper
DEBUG - 2014-02-20 13:04:30 --> Form Validation Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: number_helper
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: date_helper
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 13:04:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: language_helper
DEBUG - 2014-02-20 13:04:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 13:04:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 13:04:30 --> Model Class Initialized
DEBUG - 2014-02-20 13:04:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 13:04:30 --> Model Class Initialized
DEBUG - 2014-02-20 13:04:30 --> Helper loaded: image_helper
DEBUG - 2014-02-20 13:04:30 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 13:04:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 13:04:30 --> Final output sent to browser
DEBUG - 2014-02-20 13:04:30 --> Total execution time: 0.0734
DEBUG - 2014-02-20 14:00:33 --> Config Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:00:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:00:33 --> URI Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Router Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Output Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Security Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Input Class Initialized
DEBUG - 2014-02-20 14:00:33 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:33 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:00:33 --> Language Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Language Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Config Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Loader Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:00:33 --> Controller Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Session Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:00:33 --> A session cookie was not found.
DEBUG - 2014-02-20 14:00:33 --> Session routines successfully run
DEBUG - 2014-02-20 14:00:33 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:00:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:00:33 --> Database Driver Class Initialized
ERROR - 2014-02-20 14:00:33 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:00:33 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:00:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:00:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:00:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:00:33 --> Config Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:00:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:00:33 --> URI Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Router Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Output Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Security Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Input Class Initialized
DEBUG - 2014-02-20 14:00:33 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:33 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:33 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:00:33 --> Language Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Language Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Config Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Loader Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:00:33 --> Controller Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 14:00:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:00:33 --> Session Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:00:33 --> Session routines successfully run
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:00:33 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:00:33 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:00:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:00:33 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:00:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:00:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:00:33 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 14:00:33 --> Final output sent to browser
DEBUG - 2014-02-20 14:00:33 --> Total execution time: 0.0453
DEBUG - 2014-02-20 14:00:42 --> Config Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:00:42 --> URI Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Router Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Output Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Security Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Input Class Initialized
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:00:42 --> Language Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Language Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Config Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Loader Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:00:42 --> Controller Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 14:00:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:00:42 --> Session Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:00:42 --> Session routines successfully run
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:00:42 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:00:42 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:00:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:00:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:00:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:00:42 --> Model Class Initialized
DEBUG - 2014-02-20 14:00:42 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 14:00:42 --> Model Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Config Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:00:42 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:00:42 --> URI Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Router Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Output Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Security Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Input Class Initialized
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> XSS Filtering completed
DEBUG - 2014-02-20 14:00:42 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:00:42 --> Language Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Language Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Config Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Loader Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:00:42 --> Controller Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Session Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:00:42 --> Session routines successfully run
DEBUG - 2014-02-20 14:00:42 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:00:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:00:42 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:00:42 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:00:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:00:42 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:00:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:00:42 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:00:42 --> Model Class Initialized
DEBUG - 2014-02-20 14:00:42 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:00:42 --> Model Class Initialized
DEBUG - 2014-02-20 14:00:42 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:00:42 --> Model Class Initialized
DEBUG - 2014-02-20 14:00:42 --> DB Transaction Failure
ERROR - 2014-02-20 14:00:42 --> Query error: Incorrect parameter count in the call to native function 'DATEDIFF'
DEBUG - 2014-02-20 14:00:42 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-02-20 14:01:26 --> Config Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:01:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:01:26 --> URI Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Router Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Output Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Security Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Input Class Initialized
DEBUG - 2014-02-20 14:01:26 --> XSS Filtering completed
DEBUG - 2014-02-20 14:01:26 --> XSS Filtering completed
DEBUG - 2014-02-20 14:01:26 --> XSS Filtering completed
DEBUG - 2014-02-20 14:01:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:01:26 --> Language Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Language Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Config Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Loader Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:01:26 --> Controller Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Session Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:01:26 --> Session routines successfully run
DEBUG - 2014-02-20 14:01:26 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:01:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:01:26 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:01:26 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:01:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:01:26 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:01:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:01:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:01:26 --> Model Class Initialized
DEBUG - 2014-02-20 14:01:26 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:01:26 --> Model Class Initialized
DEBUG - 2014-02-20 14:01:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:01:26 --> Model Class Initialized
DEBUG - 2014-02-20 14:01:26 --> DB Transaction Failure
ERROR - 2014-02-20 14:01:26 --> Query error: Incorrect parameter count in the call to native function 'DATEDIFF'
DEBUG - 2014-02-20 14:01:26 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-02-20 14:03:05 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:03:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:03:05 --> URI Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Router Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Output Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Security Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Input Class Initialized
DEBUG - 2014-02-20 14:03:05 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:05 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:05 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:03:05 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Loader Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:03:05 --> Controller Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Session Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:03:05 --> Session routines successfully run
DEBUG - 2014-02-20 14:03:05 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:03:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:03:05 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:03:05 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:03:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:03:05 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:03:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:03:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:03:05 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:05 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:03:05 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:03:05 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:05 --> DB Transaction Failure
ERROR - 2014-02-20 14:03:05 --> Query error: Unknown column 'startdate' in 'field list'
DEBUG - 2014-02-20 14:03:05 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-02-20 14:03:13 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:03:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:03:13 --> URI Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Router Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Output Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Security Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Input Class Initialized
DEBUG - 2014-02-20 14:03:13 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:13 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:13 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:03:13 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Loader Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:03:13 --> Controller Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Session Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:03:13 --> Session routines successfully run
DEBUG - 2014-02-20 14:03:13 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:03:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:03:13 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:03:13 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:03:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:03:13 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:03:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:03:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:03:13 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:13 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:03:13 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:03:13 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:03:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:03:17 --> URI Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Router Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Output Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Security Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Input Class Initialized
DEBUG - 2014-02-20 14:03:17 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:03:17 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Loader Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:03:17 --> Controller Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Session Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:03:17 --> Session routines successfully run
DEBUG - 2014-02-20 14:03:17 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:03:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:03:17 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:03:17 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:03:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:03:17 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:03:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:03:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:03:17 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:17 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:03:17 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:03:17 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:03:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:03:39 --> URI Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Router Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Output Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Security Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Input Class Initialized
DEBUG - 2014-02-20 14:03:39 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:03:39 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Loader Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:03:39 --> Controller Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Session Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:03:39 --> Session routines successfully run
DEBUG - 2014-02-20 14:03:39 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:03:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:03:39 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:03:39 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:03:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:03:39 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:03:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:03:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:03:39 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:39 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:03:39 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:39 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:03:39 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:03:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:03:56 --> URI Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Router Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Output Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Security Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Input Class Initialized
DEBUG - 2014-02-20 14:03:56 --> XSS Filtering completed
DEBUG - 2014-02-20 14:03:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:03:56 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Language Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Config Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Loader Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:03:56 --> Controller Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Session Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:03:56 --> Session routines successfully run
DEBUG - 2014-02-20 14:03:56 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:03:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:03:56 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:03:56 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:03:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:03:56 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:03:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:03:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:03:56 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:56 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:03:56 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:03:56 --> Model Class Initialized
DEBUG - 2014-02-20 14:03:56 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:03:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:03:56 --> Final output sent to browser
DEBUG - 2014-02-20 14:03:56 --> Total execution time: 0.0602
DEBUG - 2014-02-20 14:07:26 --> Config Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:07:26 --> URI Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Router Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Output Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Security Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Input Class Initialized
DEBUG - 2014-02-20 14:07:26 --> XSS Filtering completed
DEBUG - 2014-02-20 14:07:26 --> XSS Filtering completed
DEBUG - 2014-02-20 14:07:26 --> XSS Filtering completed
DEBUG - 2014-02-20 14:07:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:07:26 --> Language Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Language Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Config Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Loader Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:07:26 --> Controller Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Session Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:07:26 --> Session routines successfully run
DEBUG - 2014-02-20 14:07:26 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:07:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:07:26 --> Database Driver Class Initialized
ERROR - 2014-02-20 14:07:26 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\tcms\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:07:26 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:07:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:07:26 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:07:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:07:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:07:26 --> Model Class Initialized
DEBUG - 2014-02-20 14:07:26 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:07:26 --> Model Class Initialized
DEBUG - 2014-02-20 14:07:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:07:26 --> Model Class Initialized
DEBUG - 2014-02-20 14:07:26 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:07:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:07:26 --> Final output sent to browser
DEBUG - 2014-02-20 14:07:26 --> Total execution time: 0.0658
DEBUG - 2014-02-20 14:32:13 --> Config Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:32:13 --> URI Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Router Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Output Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Security Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Input Class Initialized
DEBUG - 2014-02-20 14:32:13 --> XSS Filtering completed
DEBUG - 2014-02-20 14:32:13 --> XSS Filtering completed
DEBUG - 2014-02-20 14:32:13 --> XSS Filtering completed
DEBUG - 2014-02-20 14:32:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:32:13 --> Language Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Language Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Config Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Loader Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:32:13 --> Controller Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Session Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:32:13 --> Session routines successfully run
DEBUG - 2014-02-20 14:32:13 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:32:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:32:13 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:32:13 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:32:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:32:13 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:32:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:32:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:32:13 --> Model Class Initialized
DEBUG - 2014-02-20 14:32:13 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:32:13 --> Model Class Initialized
DEBUG - 2014-02-20 14:32:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:32:13 --> Model Class Initialized
ERROR - 2014-02-20 14:32:13 --> Severity: Notice  --> Undefined variable: twodate D:\xampp\htdocs\tcms\application\modules\patient\models\mdl_patient.php 44
ERROR - 2014-02-20 14:32:13 --> Severity: Notice  --> Undefined variable: sevndate D:\xampp\htdocs\tcms\application\modules\patient\models\mdl_patient.php 44
DEBUG - 2014-02-20 14:32:13 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:32:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:32:13 --> Final output sent to browser
DEBUG - 2014-02-20 14:32:13 --> Total execution time: 0.0565
DEBUG - 2014-02-20 14:33:07 --> Config Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:33:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:33:07 --> URI Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Router Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Output Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Security Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Input Class Initialized
DEBUG - 2014-02-20 14:33:07 --> XSS Filtering completed
DEBUG - 2014-02-20 14:33:07 --> XSS Filtering completed
DEBUG - 2014-02-20 14:33:07 --> XSS Filtering completed
DEBUG - 2014-02-20 14:33:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:33:07 --> Language Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Language Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Config Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Loader Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:33:07 --> Controller Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Session Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:33:07 --> Session routines successfully run
DEBUG - 2014-02-20 14:33:07 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:33:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:33:07 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:33:07 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:33:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:33:07 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:33:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:33:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:33:07 --> Model Class Initialized
DEBUG - 2014-02-20 14:33:07 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:33:07 --> Model Class Initialized
DEBUG - 2014-02-20 14:33:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:33:07 --> Model Class Initialized
ERROR - 2014-02-20 14:33:07 --> Severity: Notice  --> Undefined variable: twodate D:\xampp\htdocs\tcms\application\modules\patient\models\mdl_patient.php 44
ERROR - 2014-02-20 14:33:07 --> Severity: Notice  --> Undefined variable: sevndate D:\xampp\htdocs\tcms\application\modules\patient\models\mdl_patient.php 44
DEBUG - 2014-02-20 14:33:07 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:33:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:33:07 --> Final output sent to browser
DEBUG - 2014-02-20 14:33:07 --> Total execution time: 0.0556
DEBUG - 2014-02-20 14:33:37 --> Config Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:33:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:33:37 --> URI Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Router Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Output Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Security Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Input Class Initialized
DEBUG - 2014-02-20 14:33:37 --> XSS Filtering completed
DEBUG - 2014-02-20 14:33:37 --> XSS Filtering completed
DEBUG - 2014-02-20 14:33:37 --> XSS Filtering completed
DEBUG - 2014-02-20 14:33:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:33:37 --> Language Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Language Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Config Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Loader Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:33:37 --> Controller Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Session Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:33:37 --> Session routines successfully run
DEBUG - 2014-02-20 14:33:37 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:33:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:33:37 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:33:37 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:33:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:33:37 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:33:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:33:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:33:37 --> Model Class Initialized
DEBUG - 2014-02-20 14:33:37 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:33:37 --> Model Class Initialized
DEBUG - 2014-02-20 14:33:37 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:33:37 --> Model Class Initialized
DEBUG - 2014-02-20 14:33:37 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:33:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:33:37 --> Final output sent to browser
DEBUG - 2014-02-20 14:33:37 --> Total execution time: 0.0510
DEBUG - 2014-02-20 14:34:22 --> Config Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:34:22 --> URI Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Router Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Output Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Security Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Input Class Initialized
DEBUG - 2014-02-20 14:34:22 --> XSS Filtering completed
DEBUG - 2014-02-20 14:34:22 --> XSS Filtering completed
DEBUG - 2014-02-20 14:34:22 --> XSS Filtering completed
DEBUG - 2014-02-20 14:34:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:34:22 --> Language Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Language Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Config Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Loader Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:34:22 --> Controller Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Session Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:34:22 --> Session routines successfully run
DEBUG - 2014-02-20 14:34:22 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:34:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:34:22 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:34:22 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:34:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:34:22 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:34:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:34:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:34:22 --> Model Class Initialized
DEBUG - 2014-02-20 14:34:22 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:34:22 --> Model Class Initialized
DEBUG - 2014-02-20 14:34:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:34:22 --> Model Class Initialized
DEBUG - 2014-02-20 14:34:22 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:34:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:34:22 --> Final output sent to browser
DEBUG - 2014-02-20 14:34:22 --> Total execution time: 0.0511
DEBUG - 2014-02-20 14:34:48 --> Config Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:34:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:34:48 --> URI Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Router Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Output Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Security Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Input Class Initialized
DEBUG - 2014-02-20 14:34:48 --> XSS Filtering completed
DEBUG - 2014-02-20 14:34:48 --> XSS Filtering completed
DEBUG - 2014-02-20 14:34:48 --> XSS Filtering completed
DEBUG - 2014-02-20 14:34:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:34:48 --> Language Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Language Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Config Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Loader Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:34:48 --> Controller Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Session Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:34:48 --> Session routines successfully run
DEBUG - 2014-02-20 14:34:48 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:34:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:34:48 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:34:48 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:34:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:34:48 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:34:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:34:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:34:48 --> Model Class Initialized
DEBUG - 2014-02-20 14:34:48 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:34:48 --> Model Class Initialized
DEBUG - 2014-02-20 14:34:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:34:48 --> Model Class Initialized
DEBUG - 2014-02-20 14:34:48 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:34:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:34:48 --> Final output sent to browser
DEBUG - 2014-02-20 14:34:48 --> Total execution time: 0.0534
DEBUG - 2014-02-20 14:36:35 --> Config Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:36:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:36:35 --> URI Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Router Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Output Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Security Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Input Class Initialized
DEBUG - 2014-02-20 14:36:35 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:35 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:35 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:36:35 --> Language Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Language Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Config Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Loader Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:36:35 --> Controller Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Session Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:36:35 --> Session routines successfully run
DEBUG - 2014-02-20 14:36:35 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:36:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:36:35 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:36:35 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:36:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:36:35 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:36:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:36:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:36:35 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:35 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:36:35 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:35 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:36:35 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:35 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:36:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:36:35 --> Final output sent to browser
DEBUG - 2014-02-20 14:36:35 --> Total execution time: 0.0543
DEBUG - 2014-02-20 14:36:49 --> Config Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:36:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:36:49 --> URI Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Router Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Output Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Security Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Input Class Initialized
DEBUG - 2014-02-20 14:36:49 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:49 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:49 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:36:49 --> Language Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Language Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Config Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Loader Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:36:49 --> Controller Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Session Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:36:49 --> Session routines successfully run
DEBUG - 2014-02-20 14:36:49 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:36:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:36:49 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:36:49 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:36:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:36:49 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:36:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:36:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:36:49 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:49 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:36:49 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:49 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:36:49 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:49 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:36:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:36:49 --> Final output sent to browser
DEBUG - 2014-02-20 14:36:49 --> Total execution time: 0.0554
DEBUG - 2014-02-20 14:36:55 --> Config Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:36:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:36:55 --> URI Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Router Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Output Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Security Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Input Class Initialized
DEBUG - 2014-02-20 14:36:55 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:55 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:55 --> XSS Filtering completed
DEBUG - 2014-02-20 14:36:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:36:55 --> Language Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Language Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Config Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Loader Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:36:55 --> Controller Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Session Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:36:55 --> Session routines successfully run
DEBUG - 2014-02-20 14:36:55 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:36:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:36:55 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:36:55 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:36:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:36:55 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:36:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:36:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:36:55 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:55 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:36:55 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:36:55 --> Model Class Initialized
DEBUG - 2014-02-20 14:36:55 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:36:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:36:55 --> Final output sent to browser
DEBUG - 2014-02-20 14:36:55 --> Total execution time: 0.0562
DEBUG - 2014-02-20 14:37:02 --> Config Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:37:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:37:02 --> URI Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Router Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Output Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Security Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Input Class Initialized
DEBUG - 2014-02-20 14:37:02 --> XSS Filtering completed
DEBUG - 2014-02-20 14:37:02 --> XSS Filtering completed
DEBUG - 2014-02-20 14:37:02 --> XSS Filtering completed
DEBUG - 2014-02-20 14:37:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:37:02 --> Language Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Language Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Config Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Loader Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:37:02 --> Controller Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Session Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:37:02 --> Session routines successfully run
DEBUG - 2014-02-20 14:37:02 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:37:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:37:02 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:37:02 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:37:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:37:02 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:37:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:37:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:37:02 --> Model Class Initialized
DEBUG - 2014-02-20 14:37:02 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:37:02 --> Model Class Initialized
DEBUG - 2014-02-20 14:37:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:37:02 --> Model Class Initialized
DEBUG - 2014-02-20 14:37:02 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:37:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:37:02 --> Final output sent to browser
DEBUG - 2014-02-20 14:37:02 --> Total execution time: 0.0529
DEBUG - 2014-02-20 14:37:21 --> Config Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:37:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:37:21 --> URI Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Router Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Output Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Security Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Input Class Initialized
DEBUG - 2014-02-20 14:37:21 --> XSS Filtering completed
DEBUG - 2014-02-20 14:37:21 --> XSS Filtering completed
DEBUG - 2014-02-20 14:37:21 --> XSS Filtering completed
DEBUG - 2014-02-20 14:37:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:37:21 --> Language Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Language Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Config Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Loader Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:37:21 --> Controller Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Session Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:37:21 --> Session routines successfully run
DEBUG - 2014-02-20 14:37:21 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:37:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:37:21 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:37:21 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:37:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:37:21 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:37:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:37:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:37:21 --> Model Class Initialized
DEBUG - 2014-02-20 14:37:21 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:37:21 --> Model Class Initialized
DEBUG - 2014-02-20 14:37:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:37:21 --> Model Class Initialized
DEBUG - 2014-02-20 14:37:21 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:37:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:37:21 --> Final output sent to browser
DEBUG - 2014-02-20 14:37:21 --> Total execution time: 0.0545
DEBUG - 2014-02-20 14:51:07 --> Config Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 14:51:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 14:51:07 --> URI Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Router Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Output Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Security Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Input Class Initialized
DEBUG - 2014-02-20 14:51:07 --> XSS Filtering completed
DEBUG - 2014-02-20 14:51:07 --> XSS Filtering completed
DEBUG - 2014-02-20 14:51:07 --> XSS Filtering completed
DEBUG - 2014-02-20 14:51:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 14:51:07 --> Language Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Language Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Config Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Loader Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 14:51:07 --> Controller Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Session Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 14:51:07 --> Session routines successfully run
DEBUG - 2014-02-20 14:51:07 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 14:51:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 14:51:07 --> Database Driver Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: form_helper
DEBUG - 2014-02-20 14:51:07 --> Form Validation Class Initialized
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: number_helper
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: date_helper
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 14:51:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 14:51:07 --> Helper loaded: language_helper
DEBUG - 2014-02-20 14:51:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 14:51:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 14:51:07 --> Model Class Initialized
DEBUG - 2014-02-20 14:51:07 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 14:51:07 --> Model Class Initialized
DEBUG - 2014-02-20 14:51:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 14:51:07 --> Model Class Initialized
DEBUG - 2014-02-20 14:51:07 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 14:51:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 14:51:07 --> Final output sent to browser
DEBUG - 2014-02-20 14:51:07 --> Total execution time: 0.0646
DEBUG - 2014-02-20 15:00:03 --> Config Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:00:03 --> URI Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Router Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Output Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Security Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Input Class Initialized
DEBUG - 2014-02-20 15:00:03 --> XSS Filtering completed
DEBUG - 2014-02-20 15:00:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:00:03 --> Language Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Language Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Config Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Loader Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:00:03 --> Controller Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Session Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:00:03 --> Session routines successfully run
DEBUG - 2014-02-20 15:00:03 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:00:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:00:03 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:00:03 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:00:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:00:03 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:00:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:00:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:00:03 --> Model Class Initialized
DEBUG - 2014-02-20 15:00:03 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:00:03 --> Model Class Initialized
DEBUG - 2014-02-20 15:00:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:00:03 --> Model Class Initialized
DEBUG - 2014-02-20 15:00:03 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:00:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:00:03 --> Final output sent to browser
DEBUG - 2014-02-20 15:00:03 --> Total execution time: 0.0548
DEBUG - 2014-02-20 15:10:50 --> Config Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:10:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:10:50 --> URI Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Router Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Output Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Security Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Input Class Initialized
DEBUG - 2014-02-20 15:10:50 --> XSS Filtering completed
DEBUG - 2014-02-20 15:10:50 --> XSS Filtering completed
DEBUG - 2014-02-20 15:10:50 --> XSS Filtering completed
DEBUG - 2014-02-20 15:10:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:10:50 --> Language Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Language Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Config Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Loader Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:10:50 --> Controller Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Session Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:10:50 --> Session routines successfully run
DEBUG - 2014-02-20 15:10:50 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:10:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:10:50 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:10:50 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:10:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:10:50 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:10:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:10:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:10:50 --> Model Class Initialized
DEBUG - 2014-02-20 15:10:50 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:10:50 --> Model Class Initialized
DEBUG - 2014-02-20 15:10:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:10:50 --> Model Class Initialized
ERROR - 2014-02-20 15:10:50 --> Severity: Notice  --> Undefined variable: statistics D:\xampp\htdocs\tcms\application\modules\dashboard\views\index.php 130
DEBUG - 2014-02-20 15:10:50 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:10:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:10:50 --> Final output sent to browser
DEBUG - 2014-02-20 15:10:50 --> Total execution time: 0.0586
DEBUG - 2014-02-20 15:33:29 --> Config Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:33:29 --> URI Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Router Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Output Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Security Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Input Class Initialized
DEBUG - 2014-02-20 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-20 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-20 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-20 15:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:33:29 --> Language Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Language Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Config Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Loader Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:33:29 --> Controller Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Session Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:33:29 --> Session routines successfully run
DEBUG - 2014-02-20 15:33:29 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:33:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:33:29 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:33:29 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:33:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:33:29 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:33:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:33:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:33:29 --> Model Class Initialized
DEBUG - 2014-02-20 15:33:29 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:33:29 --> Model Class Initialized
DEBUG - 2014-02-20 15:33:29 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:33:29 --> Model Class Initialized
DEBUG - 2014-02-20 15:33:29 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:33:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:33:29 --> Final output sent to browser
DEBUG - 2014-02-20 15:33:29 --> Total execution time: 0.0550
DEBUG - 2014-02-20 15:34:07 --> Config Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:34:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:34:07 --> URI Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Router Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Output Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Security Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Input Class Initialized
DEBUG - 2014-02-20 15:34:07 --> XSS Filtering completed
DEBUG - 2014-02-20 15:34:07 --> XSS Filtering completed
DEBUG - 2014-02-20 15:34:07 --> XSS Filtering completed
DEBUG - 2014-02-20 15:34:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:34:07 --> Language Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Language Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Config Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Loader Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:34:07 --> Controller Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Session Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:34:07 --> Session routines successfully run
DEBUG - 2014-02-20 15:34:07 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:34:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:34:07 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:34:07 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:34:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:34:07 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:34:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:34:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:34:07 --> Model Class Initialized
DEBUG - 2014-02-20 15:34:07 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:34:07 --> Model Class Initialized
DEBUG - 2014-02-20 15:34:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:34:07 --> Model Class Initialized
DEBUG - 2014-02-20 15:34:07 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:34:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:34:07 --> Final output sent to browser
DEBUG - 2014-02-20 15:34:07 --> Total execution time: 0.0529
DEBUG - 2014-02-20 15:35:05 --> Config Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:35:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:35:05 --> URI Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Router Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Output Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Security Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Input Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:35:05 --> Language Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Language Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Config Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Loader Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:35:05 --> Controller Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Session Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:35:05 --> A session cookie was not found.
DEBUG - 2014-02-20 15:35:05 --> Session routines successfully run
DEBUG - 2014-02-20 15:35:05 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 15:35:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:35:05 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:35:05 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:35:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:35:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:35:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:35:05 --> Config Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:35:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:35:05 --> URI Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Router Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Output Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Security Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Input Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:35:05 --> Language Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Language Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Config Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Loader Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:35:05 --> Controller Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 15:35:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:35:05 --> Session Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:35:05 --> A session cookie was not found.
DEBUG - 2014-02-20 15:35:05 --> Session routines successfully run
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:35:05 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:35:05 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:35:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:35:05 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:35:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:35:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:35:05 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 15:35:05 --> Final output sent to browser
DEBUG - 2014-02-20 15:35:05 --> Total execution time: 0.0332
DEBUG - 2014-02-20 15:53:18 --> Config Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:53:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:53:18 --> URI Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Router Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Output Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Security Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Input Class Initialized
DEBUG - 2014-02-20 15:53:18 --> XSS Filtering completed
DEBUG - 2014-02-20 15:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:53:18 --> Language Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Language Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Config Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Loader Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:53:18 --> Controller Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Session Class Initialized
DEBUG - 2014-02-20 15:53:18 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:53:18 --> Session routines successfully run
DEBUG - 2014-02-20 15:53:18 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:53:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:53:18 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:53:18 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:53:19 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:53:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:53:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:53:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:53:19 --> Config Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:53:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:53:19 --> URI Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Router Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Output Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Security Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Input Class Initialized
DEBUG - 2014-02-20 15:53:19 --> XSS Filtering completed
DEBUG - 2014-02-20 15:53:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:53:19 --> Language Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Language Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Config Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Loader Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:53:19 --> Controller Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 15:53:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:53:19 --> Session Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:53:19 --> Session routines successfully run
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:53:19 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:53:19 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:53:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:53:19 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:53:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:53:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:53:19 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 15:53:19 --> Final output sent to browser
DEBUG - 2014-02-20 15:53:19 --> Total execution time: 0.1293
DEBUG - 2014-02-20 15:53:24 --> Config Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:53:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:53:24 --> URI Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Router Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Output Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Security Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Input Class Initialized
DEBUG - 2014-02-20 15:53:24 --> XSS Filtering completed
DEBUG - 2014-02-20 15:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:53:24 --> Language Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Language Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Config Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Loader Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:53:24 --> Controller Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Session Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:53:24 --> A session cookie was not found.
DEBUG - 2014-02-20 15:53:24 --> Session routines successfully run
DEBUG - 2014-02-20 15:53:24 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:53:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:53:24 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:53:24 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:53:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:53:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:53:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:53:24 --> Config Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:53:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:53:24 --> URI Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Router Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Output Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Security Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Input Class Initialized
DEBUG - 2014-02-20 15:53:24 --> XSS Filtering completed
DEBUG - 2014-02-20 15:53:24 --> XSS Filtering completed
DEBUG - 2014-02-20 15:53:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:53:24 --> Language Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Language Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Config Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Loader Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:53:24 --> Controller Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 15:53:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:53:24 --> Session Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:53:24 --> Session routines successfully run
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:53:24 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:53:24 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:53:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:53:24 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:53:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:53:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:53:24 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 15:53:24 --> Final output sent to browser
DEBUG - 2014-02-20 15:53:24 --> Total execution time: 0.0353
DEBUG - 2014-02-20 15:54:43 --> Config Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:54:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:54:43 --> URI Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Router Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Output Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Security Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Input Class Initialized
DEBUG - 2014-02-20 15:54:43 --> XSS Filtering completed
DEBUG - 2014-02-20 15:54:43 --> XSS Filtering completed
DEBUG - 2014-02-20 15:54:43 --> XSS Filtering completed
DEBUG - 2014-02-20 15:54:43 --> XSS Filtering completed
DEBUG - 2014-02-20 15:54:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:54:43 --> Language Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Language Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Config Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Loader Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:54:43 --> Controller Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 15:54:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:54:43 --> Session Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:54:43 --> Session routines successfully run
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:54:43 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:54:43 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:54:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:54:43 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:54:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:54:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:54:43 --> Model Class Initialized
DEBUG - 2014-02-20 15:54:43 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 15:54:43 --> Model Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Config Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:54:44 --> URI Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Router Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Output Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Security Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Input Class Initialized
DEBUG - 2014-02-20 15:54:44 --> XSS Filtering completed
DEBUG - 2014-02-20 15:54:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:54:44 --> Language Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Language Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Config Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Loader Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:54:44 --> Controller Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Session Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:54:44 --> Session routines successfully run
DEBUG - 2014-02-20 15:54:44 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:54:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:54:44 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:54:44 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:54:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:54:44 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:54:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:54:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:54:44 --> Model Class Initialized
DEBUG - 2014-02-20 15:54:44 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:54:44 --> Model Class Initialized
DEBUG - 2014-02-20 15:54:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:54:44 --> Model Class Initialized
DEBUG - 2014-02-20 15:54:44 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:54:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:54:44 --> Final output sent to browser
DEBUG - 2014-02-20 15:54:44 --> Total execution time: 0.2083
DEBUG - 2014-02-20 15:54:48 --> Config Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:54:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:54:48 --> URI Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Router Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Output Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Security Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Input Class Initialized
DEBUG - 2014-02-20 15:54:48 --> XSS Filtering completed
DEBUG - 2014-02-20 15:54:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:54:48 --> Language Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Language Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Config Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Loader Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:54:48 --> Controller Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Session Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:54:48 --> Session routines successfully run
DEBUG - 2014-02-20 15:54:48 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 15:54:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:54:48 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:54:48 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:54:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:54:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:54:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:54:48 --> Model Class Initialized
DEBUG - 2014-02-20 15:54:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:54:48 --> Model Class Initialized
DEBUG - 2014-02-20 15:54:48 --> Helper loaded: image_helper
DEBUG - 2014-02-20 15:54:48 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 15:54:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:54:48 --> Final output sent to browser
DEBUG - 2014-02-20 15:54:48 --> Total execution time: 0.1554
DEBUG - 2014-02-20 15:55:59 --> Config Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:55:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:55:59 --> URI Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Router Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Output Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Security Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Input Class Initialized
DEBUG - 2014-02-20 15:55:59 --> XSS Filtering completed
DEBUG - 2014-02-20 15:55:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:55:59 --> Language Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Language Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Config Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Loader Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:55:59 --> Controller Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Session Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:55:59 --> Session routines successfully run
DEBUG - 2014-02-20 15:55:59 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:55:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:55:59 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:55:59 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:55:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:55:59 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:55:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:55:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:55:59 --> Model Class Initialized
DEBUG - 2014-02-20 15:55:59 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:55:59 --> Model Class Initialized
DEBUG - 2014-02-20 15:55:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:55:59 --> Model Class Initialized
DEBUG - 2014-02-20 15:55:59 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:55:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:55:59 --> Final output sent to browser
DEBUG - 2014-02-20 15:55:59 --> Total execution time: 0.0610
DEBUG - 2014-02-20 15:56:04 --> Config Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:56:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:56:04 --> URI Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Router Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Output Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Security Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Input Class Initialized
DEBUG - 2014-02-20 15:56:04 --> XSS Filtering completed
DEBUG - 2014-02-20 15:56:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:56:04 --> Language Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Language Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Config Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Loader Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:56:04 --> Controller Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Session Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:56:04 --> Session routines successfully run
DEBUG - 2014-02-20 15:56:04 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:56:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:56:04 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:56:04 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:56:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:56:04 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:56:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:56:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:56:04 --> Model Class Initialized
DEBUG - 2014-02-20 15:56:04 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:56:04 --> Model Class Initialized
DEBUG - 2014-02-20 15:56:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:56:04 --> Model Class Initialized
DEBUG - 2014-02-20 15:56:04 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:56:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:56:04 --> Final output sent to browser
DEBUG - 2014-02-20 15:56:04 --> Total execution time: 0.0539
DEBUG - 2014-02-20 15:56:37 --> Config Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:56:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:56:37 --> URI Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Router Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Output Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Security Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Input Class Initialized
DEBUG - 2014-02-20 15:56:37 --> XSS Filtering completed
DEBUG - 2014-02-20 15:56:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:56:37 --> Language Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Language Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Config Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Loader Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:56:37 --> Controller Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Session Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:56:37 --> Session routines successfully run
DEBUG - 2014-02-20 15:56:37 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:56:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:56:37 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:56:37 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:56:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:56:37 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:56:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:56:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:56:37 --> Model Class Initialized
DEBUG - 2014-02-20 15:56:37 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:56:37 --> Model Class Initialized
DEBUG - 2014-02-20 15:56:37 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:56:37 --> Model Class Initialized
DEBUG - 2014-02-20 15:56:37 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:56:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:56:37 --> Final output sent to browser
DEBUG - 2014-02-20 15:56:37 --> Total execution time: 0.0517
DEBUG - 2014-02-20 15:57:21 --> Config Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:57:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:57:21 --> URI Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Router Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Output Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Security Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Input Class Initialized
DEBUG - 2014-02-20 15:57:21 --> XSS Filtering completed
DEBUG - 2014-02-20 15:57:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:57:21 --> Language Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Language Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Config Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Loader Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:57:21 --> Controller Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Session Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:57:21 --> Session routines successfully run
DEBUG - 2014-02-20 15:57:21 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:57:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:57:21 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:57:21 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:57:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:57:21 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:57:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:57:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:57:21 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:21 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:57:21 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:57:21 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:21 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:57:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:57:21 --> Final output sent to browser
DEBUG - 2014-02-20 15:57:21 --> Total execution time: 0.0560
DEBUG - 2014-02-20 15:57:28 --> Config Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:57:28 --> URI Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Router Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Output Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Security Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Input Class Initialized
DEBUG - 2014-02-20 15:57:28 --> XSS Filtering completed
DEBUG - 2014-02-20 15:57:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:57:28 --> Language Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Language Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Config Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Loader Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:57:28 --> Controller Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Session Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:57:28 --> Session routines successfully run
DEBUG - 2014-02-20 15:57:28 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:57:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:57:28 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:57:28 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:57:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:57:28 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:57:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:57:28 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:57:28 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:28 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:57:28 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:28 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:57:28 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:28 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:57:28 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:57:28 --> Final output sent to browser
DEBUG - 2014-02-20 15:57:28 --> Total execution time: 0.0504
DEBUG - 2014-02-20 15:57:51 --> Config Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:57:51 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:57:51 --> URI Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Router Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Output Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Security Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Input Class Initialized
DEBUG - 2014-02-20 15:57:51 --> XSS Filtering completed
DEBUG - 2014-02-20 15:57:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:57:51 --> Language Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Language Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Config Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Loader Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:57:51 --> Controller Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Session Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:57:51 --> Session routines successfully run
DEBUG - 2014-02-20 15:57:51 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:57:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:57:51 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:57:51 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:57:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:57:51 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:57:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:57:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:57:51 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:51 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:57:51 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:51 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:57:51 --> Model Class Initialized
DEBUG - 2014-02-20 15:57:51 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:57:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:57:51 --> Final output sent to browser
DEBUG - 2014-02-20 15:57:51 --> Total execution time: 0.0586
DEBUG - 2014-02-20 15:58:17 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:58:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:58:17 --> URI Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Router Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Output Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Security Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Input Class Initialized
DEBUG - 2014-02-20 15:58:17 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:58:17 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Loader Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:58:17 --> Controller Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Session Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:58:17 --> Session routines successfully run
DEBUG - 2014-02-20 15:58:17 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:58:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:58:17 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:58:17 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:58:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:58:17 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:58:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:58:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:58:17 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:17 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:58:17 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:58:17 --> Model Class Initialized
ERROR - 2014-02-20 15:58:17 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\tcms\application\modules\dashboard\views\index.php 137
DEBUG - 2014-02-20 15:58:17 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:58:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:58:17 --> Final output sent to browser
DEBUG - 2014-02-20 15:58:17 --> Total execution time: 0.0710
DEBUG - 2014-02-20 15:58:24 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:58:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:58:24 --> URI Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Router Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Output Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Security Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Input Class Initialized
DEBUG - 2014-02-20 15:58:24 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:58:24 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Loader Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:58:24 --> Controller Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Session Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:58:24 --> Session routines successfully run
DEBUG - 2014-02-20 15:58:24 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:58:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:58:24 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:58:24 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:58:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:58:24 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:58:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:58:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:58:24 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:24 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:58:24 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:58:24 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:24 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:58:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:58:24 --> Final output sent to browser
DEBUG - 2014-02-20 15:58:24 --> Total execution time: 0.0534
DEBUG - 2014-02-20 15:58:41 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:58:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:58:41 --> URI Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Router Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Output Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Security Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Input Class Initialized
DEBUG - 2014-02-20 15:58:41 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:58:41 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Loader Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:58:41 --> Controller Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Session Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:58:41 --> Session routines successfully run
DEBUG - 2014-02-20 15:58:41 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:58:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:58:41 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:58:41 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:58:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:58:41 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:58:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:58:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:58:41 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:41 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:58:41 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:41 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:58:41 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:41 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:58:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:58:41 --> Final output sent to browser
DEBUG - 2014-02-20 15:58:41 --> Total execution time: 0.0528
DEBUG - 2014-02-20 15:58:53 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:58:53 --> URI Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Router Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Output Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Security Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Input Class Initialized
DEBUG - 2014-02-20 15:58:53 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:53 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:53 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:53 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:53 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:58:53 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Loader Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:58:53 --> Controller Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 15:58:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:58:53 --> Session Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:58:53 --> Session routines successfully run
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:58:53 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:58:53 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:58:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:58:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:58:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:58:53 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:53 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 15:58:53 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:58:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:58:53 --> URI Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Router Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Output Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Security Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Input Class Initialized
DEBUG - 2014-02-20 15:58:53 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:53 --> XSS Filtering completed
DEBUG - 2014-02-20 15:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:58:53 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Language Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Config Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Loader Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:58:53 --> Controller Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Session Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:58:53 --> Session routines successfully run
DEBUG - 2014-02-20 15:58:53 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:58:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:58:53 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:58:53 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:58:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:58:53 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:58:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:58:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:58:53 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:53 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:58:53 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:58:53 --> Model Class Initialized
DEBUG - 2014-02-20 15:58:53 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:58:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:58:53 --> Final output sent to browser
DEBUG - 2014-02-20 15:58:53 --> Total execution time: 0.0594
DEBUG - 2014-02-20 15:59:00 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:00 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:00 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:00 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:00 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:00 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:00 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:59:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:00 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:00 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:00 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:00 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:00 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:59:00 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:59:00 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:00 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:59:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:59:00 --> Final output sent to browser
DEBUG - 2014-02-20 15:59:00 --> Total execution time: 0.0627
DEBUG - 2014-02-20 15:59:15 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:15 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:15 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:15 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:15 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:15 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:15 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:15 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 15:59:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:15 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:15 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:15 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:59:15 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:15 --> Helper loaded: image_helper
DEBUG - 2014-02-20 15:59:15 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 15:59:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:59:15 --> Final output sent to browser
DEBUG - 2014-02-20 15:59:15 --> Total execution time: 0.0626
DEBUG - 2014-02-20 15:59:21 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:21 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:21 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:21 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:21 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:21 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:21 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:21 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 15:59:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:21 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:21 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:21 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:21 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 15:59:21 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:21 --> Helper loaded: image_helper
ERROR - 2014-02-20 15:59:21 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 15:59:21 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 15:59:21 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 15:59:21 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 15:59:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:59:21 --> Final output sent to browser
DEBUG - 2014-02-20 15:59:21 --> Total execution time: 0.0985
DEBUG - 2014-02-20 15:59:23 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:23 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:23 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:23 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:23 --> Router Class Initialized
ERROR - 2014-02-20 15:59:23 --> 404 Page Not Found --> 
DEBUG - 2014-02-20 15:59:29 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:29 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:29 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:29 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:29 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:29 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:29 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:29 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:59:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:29 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:29 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:29 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:29 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:29 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:59:29 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:29 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:59:29 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:29 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:59:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:59:29 --> Final output sent to browser
DEBUG - 2014-02-20 15:59:29 --> Total execution time: 0.0643
DEBUG - 2014-02-20 15:59:33 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:33 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:33 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:33 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:33 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:33 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:33 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:33 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:59:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:33 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:33 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:33 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:33 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:33 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:59:33 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:59:33 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:33 --> File loaded: application/modules/dashboard/views/add_notice.php
DEBUG - 2014-02-20 15:59:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:59:33 --> Final output sent to browser
DEBUG - 2014-02-20 15:59:33 --> Total execution time: 0.0705
DEBUG - 2014-02-20 15:59:37 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:37 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:37 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:37 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:37 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:37 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:37 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:59:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:37 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:37 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:37 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:37 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:37 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:37 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:37 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 15:59:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:37 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:37 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:37 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:37 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:37 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:37 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 15:59:37 --> Final output sent to browser
DEBUG - 2014-02-20 15:59:37 --> Total execution time: 0.0442
DEBUG - 2014-02-20 15:59:55 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:55 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:55 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:55 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:55 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:55 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:55 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:55 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 15:59:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:55 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:55 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:55 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:55 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:55 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:55 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 15:59:55 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Hooks Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Utf8 Class Initialized
DEBUG - 2014-02-20 15:59:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 15:59:55 --> URI Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Router Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Output Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Security Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Input Class Initialized
DEBUG - 2014-02-20 15:59:55 --> XSS Filtering completed
DEBUG - 2014-02-20 15:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 15:59:55 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Language Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Config Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Loader Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: text_helper
DEBUG - 2014-02-20 15:59:55 --> Controller Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Session Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: string_helper
DEBUG - 2014-02-20 15:59:55 --> Session routines successfully run
DEBUG - 2014-02-20 15:59:55 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 15:59:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: url_helper
DEBUG - 2014-02-20 15:59:55 --> Database Driver Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: form_helper
DEBUG - 2014-02-20 15:59:55 --> Form Validation Class Initialized
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: number_helper
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: date_helper
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 15:59:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 15:59:55 --> Helper loaded: language_helper
DEBUG - 2014-02-20 15:59:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 15:59:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 15:59:55 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:55 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 15:59:55 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 15:59:55 --> Model Class Initialized
DEBUG - 2014-02-20 15:59:55 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 15:59:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 15:59:55 --> Final output sent to browser
DEBUG - 2014-02-20 15:59:55 --> Total execution time: 0.0598
DEBUG - 2014-02-20 16:00:33 --> Config Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Hooks Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Utf8 Class Initialized
DEBUG - 2014-02-20 16:00:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 16:00:33 --> URI Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Router Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Output Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Security Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Input Class Initialized
DEBUG - 2014-02-20 16:00:33 --> XSS Filtering completed
DEBUG - 2014-02-20 16:00:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 16:00:33 --> Language Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Language Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Config Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Loader Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: text_helper
DEBUG - 2014-02-20 16:00:33 --> Controller Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Session Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: string_helper
DEBUG - 2014-02-20 16:00:33 --> Session routines successfully run
DEBUG - 2014-02-20 16:00:33 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 16:00:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: url_helper
DEBUG - 2014-02-20 16:00:33 --> Database Driver Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: form_helper
DEBUG - 2014-02-20 16:00:33 --> Form Validation Class Initialized
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: number_helper
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: date_helper
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 16:00:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 16:00:33 --> Helper loaded: language_helper
DEBUG - 2014-02-20 16:00:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 16:00:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 16:00:33 --> Model Class Initialized
DEBUG - 2014-02-20 16:00:33 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 16:00:33 --> Model Class Initialized
DEBUG - 2014-02-20 16:00:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 16:00:33 --> Model Class Initialized
DEBUG - 2014-02-20 16:00:33 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 16:00:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 16:00:33 --> Final output sent to browser
DEBUG - 2014-02-20 16:00:33 --> Total execution time: 0.0552
DEBUG - 2014-02-20 16:01:18 --> Config Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Hooks Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Utf8 Class Initialized
DEBUG - 2014-02-20 16:01:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 16:01:18 --> URI Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Router Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Output Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Security Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Input Class Initialized
DEBUG - 2014-02-20 16:01:18 --> XSS Filtering completed
DEBUG - 2014-02-20 16:01:18 --> XSS Filtering completed
DEBUG - 2014-02-20 16:01:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 16:01:18 --> Language Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Language Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Config Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Loader Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: text_helper
DEBUG - 2014-02-20 16:01:18 --> Controller Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Session Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: string_helper
DEBUG - 2014-02-20 16:01:18 --> Session routines successfully run
DEBUG - 2014-02-20 16:01:18 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 16:01:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: url_helper
DEBUG - 2014-02-20 16:01:18 --> Database Driver Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: form_helper
DEBUG - 2014-02-20 16:01:18 --> Form Validation Class Initialized
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: number_helper
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: date_helper
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 16:01:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 16:01:18 --> Helper loaded: language_helper
DEBUG - 2014-02-20 16:01:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 16:01:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 16:01:18 --> Model Class Initialized
DEBUG - 2014-02-20 16:01:18 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 16:01:18 --> Model Class Initialized
DEBUG - 2014-02-20 16:01:18 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 16:01:18 --> Model Class Initialized
DEBUG - 2014-02-20 16:01:18 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 16:01:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 16:01:18 --> Final output sent to browser
DEBUG - 2014-02-20 16:01:18 --> Total execution time: 0.0575
DEBUG - 2014-02-20 16:03:59 --> Config Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Hooks Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Utf8 Class Initialized
DEBUG - 2014-02-20 16:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 16:03:59 --> URI Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Router Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Output Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Security Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Input Class Initialized
DEBUG - 2014-02-20 16:03:59 --> XSS Filtering completed
DEBUG - 2014-02-20 16:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 16:03:59 --> Language Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Language Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Config Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Loader Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: text_helper
DEBUG - 2014-02-20 16:03:59 --> Controller Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Session Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: string_helper
DEBUG - 2014-02-20 16:03:59 --> Session routines successfully run
DEBUG - 2014-02-20 16:03:59 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 16:03:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: url_helper
DEBUG - 2014-02-20 16:03:59 --> Database Driver Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: form_helper
DEBUG - 2014-02-20 16:03:59 --> Form Validation Class Initialized
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: number_helper
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: date_helper
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 16:03:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 16:03:59 --> Helper loaded: language_helper
DEBUG - 2014-02-20 16:03:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 16:03:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 16:03:59 --> Model Class Initialized
DEBUG - 2014-02-20 16:03:59 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 16:03:59 --> Model Class Initialized
DEBUG - 2014-02-20 16:03:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 16:03:59 --> Model Class Initialized
DEBUG - 2014-02-20 16:03:59 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 16:03:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 16:03:59 --> Final output sent to browser
DEBUG - 2014-02-20 16:03:59 --> Total execution time: 0.0546
DEBUG - 2014-02-20 16:40:33 --> Config Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Hooks Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Utf8 Class Initialized
DEBUG - 2014-02-20 16:40:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 16:40:33 --> URI Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Router Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Output Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Security Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Input Class Initialized
DEBUG - 2014-02-20 16:40:33 --> XSS Filtering completed
DEBUG - 2014-02-20 16:40:33 --> XSS Filtering completed
DEBUG - 2014-02-20 16:40:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 16:40:33 --> Language Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Language Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Config Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Loader Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: text_helper
DEBUG - 2014-02-20 16:40:33 --> Controller Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Session Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: string_helper
DEBUG - 2014-02-20 16:40:33 --> Session routines successfully run
DEBUG - 2014-02-20 16:40:33 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 16:40:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: url_helper
DEBUG - 2014-02-20 16:40:33 --> Database Driver Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: form_helper
DEBUG - 2014-02-20 16:40:33 --> Form Validation Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: number_helper
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: date_helper
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 16:40:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: language_helper
DEBUG - 2014-02-20 16:40:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 16:40:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 16:40:33 --> Model Class Initialized
DEBUG - 2014-02-20 16:40:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 16:40:33 --> Model Class Initialized
DEBUG - 2014-02-20 16:40:33 --> Helper loaded: image_helper
DEBUG - 2014-02-20 16:40:33 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 16:40:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 16:40:33 --> Final output sent to browser
DEBUG - 2014-02-20 16:40:33 --> Total execution time: 0.0683
DEBUG - 2014-02-20 16:42:09 --> Config Class Initialized
DEBUG - 2014-02-20 16:42:09 --> Hooks Class Initialized
DEBUG - 2014-02-20 16:42:09 --> Utf8 Class Initialized
DEBUG - 2014-02-20 16:42:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 16:42:09 --> URI Class Initialized
DEBUG - 2014-02-20 16:42:09 --> Router Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Output Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Security Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Input Class Initialized
DEBUG - 2014-02-20 16:42:10 --> XSS Filtering completed
DEBUG - 2014-02-20 16:42:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 16:42:10 --> Language Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Language Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Config Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Loader Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: text_helper
DEBUG - 2014-02-20 16:42:10 --> Controller Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Session Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: string_helper
DEBUG - 2014-02-20 16:42:10 --> Session routines successfully run
DEBUG - 2014-02-20 16:42:10 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 16:42:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: url_helper
DEBUG - 2014-02-20 16:42:10 --> Database Driver Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: form_helper
DEBUG - 2014-02-20 16:42:10 --> Form Validation Class Initialized
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: number_helper
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: date_helper
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 16:42:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 16:42:10 --> Helper loaded: language_helper
DEBUG - 2014-02-20 16:42:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 16:42:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 16:42:10 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:10 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 16:42:10 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 16:42:10 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:10 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 16:42:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 16:42:10 --> Final output sent to browser
DEBUG - 2014-02-20 16:42:10 --> Total execution time: 0.0546
DEBUG - 2014-02-20 16:42:47 --> Config Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Hooks Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Utf8 Class Initialized
DEBUG - 2014-02-20 16:42:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 16:42:47 --> URI Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Router Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Output Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Security Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Input Class Initialized
DEBUG - 2014-02-20 16:42:47 --> XSS Filtering completed
DEBUG - 2014-02-20 16:42:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 16:42:47 --> Language Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Language Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Config Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Loader Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: text_helper
DEBUG - 2014-02-20 16:42:47 --> Controller Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Session Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: string_helper
DEBUG - 2014-02-20 16:42:47 --> Session routines successfully run
DEBUG - 2014-02-20 16:42:47 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 16:42:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: url_helper
DEBUG - 2014-02-20 16:42:47 --> Database Driver Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: form_helper
DEBUG - 2014-02-20 16:42:47 --> Form Validation Class Initialized
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: number_helper
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: date_helper
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 16:42:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 16:42:47 --> Helper loaded: language_helper
DEBUG - 2014-02-20 16:42:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 16:42:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 16:42:47 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:47 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 16:42:47 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:47 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 16:42:47 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:47 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 16:42:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 16:42:47 --> Final output sent to browser
DEBUG - 2014-02-20 16:42:47 --> Total execution time: 0.0651
DEBUG - 2014-02-20 16:42:54 --> Config Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Hooks Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Utf8 Class Initialized
DEBUG - 2014-02-20 16:42:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 16:42:54 --> URI Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Router Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Output Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Security Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Input Class Initialized
DEBUG - 2014-02-20 16:42:54 --> XSS Filtering completed
DEBUG - 2014-02-20 16:42:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 16:42:54 --> Language Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Language Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Config Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Loader Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: text_helper
DEBUG - 2014-02-20 16:42:54 --> Controller Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Session Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: string_helper
DEBUG - 2014-02-20 16:42:54 --> Session routines successfully run
DEBUG - 2014-02-20 16:42:54 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 16:42:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: url_helper
DEBUG - 2014-02-20 16:42:54 --> Database Driver Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: form_helper
DEBUG - 2014-02-20 16:42:54 --> Form Validation Class Initialized
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: number_helper
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: date_helper
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 16:42:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 16:42:54 --> Helper loaded: language_helper
DEBUG - 2014-02-20 16:42:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 16:42:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 16:42:54 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:54 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 16:42:54 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:54 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 16:42:54 --> Model Class Initialized
DEBUG - 2014-02-20 16:42:54 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 16:42:54 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 16:42:54 --> Final output sent to browser
DEBUG - 2014-02-20 16:42:54 --> Total execution time: 0.0659
DEBUG - 2014-02-20 17:01:05 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:05 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:05 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:05 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:05 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:05 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:06 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:06 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:06 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:06 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 17:01:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:06 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:06 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:06 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:06 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 17:01:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 17:01:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:06 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 17:01:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:06 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:06 --> Total execution time: 0.0573
DEBUG - 2014-02-20 17:01:12 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:12 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:12 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:12 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:12 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:12 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:12 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:12 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:12 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:12 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:12 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:12 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:12 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:12 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:01:12 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:01:12 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:01:12 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:01:12 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:01:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:12 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:12 --> Total execution time: 0.0803
DEBUG - 2014-02-20 17:01:22 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:22 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:22 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:22 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:22 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:22 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:22 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:22 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:22 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:22 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:22 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:22 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:01:22 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:01:22 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:22 --> Total execution time: 0.0704
DEBUG - 2014-02-20 17:01:28 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:28 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:28 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:28 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:28 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:28 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:28 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:28 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:28 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:28 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:28 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:28 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:28 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:28 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:28 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:01:28 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:01:28 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:01:28 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:01:28 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:01:28 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:28 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:28 --> Total execution time: 0.0689
DEBUG - 2014-02-20 17:01:33 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:33 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:33 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:33 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:33 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:33 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:33 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:33 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:33 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:33 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:33 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:33 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:33 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:33 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:01:33 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:01:33 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:01:33 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:01:33 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:01:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:33 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:33 --> Total execution time: 0.0687
DEBUG - 2014-02-20 17:01:36 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:36 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:36 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:36 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:36 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:36 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:36 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:36 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:36 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:36 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:36 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:36 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:36 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:36 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:36 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:36 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:01:36 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:01:36 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:36 --> Total execution time: 0.0630
DEBUG - 2014-02-20 17:01:38 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:38 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:38 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:39 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:39 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:39 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:39 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:39 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:39 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:39 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:39 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:39 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:39 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:39 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:39 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:39 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:39 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:39 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:01:39 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:01:39 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:39 --> Total execution time: 0.0696
DEBUG - 2014-02-20 17:01:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:40 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:40 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:40 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:40 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:40 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:40 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:40 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:40 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:40 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:01:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:40 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:40 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:40 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:40 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:40 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:40 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:40 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:40 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:40 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:40 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:01:40 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:01:40 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:01:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:01:40 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:01:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:40 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:40 --> Total execution time: 0.0518
DEBUG - 2014-02-20 17:01:47 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:47 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:47 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:47 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:47 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:47 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:47 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:47 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:47 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:47 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:47 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:47 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:47 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:47 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:01:47 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:01:47 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:01:47 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:01:47 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:01:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:47 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:47 --> Total execution time: 0.0728
DEBUG - 2014-02-20 17:01:50 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:50 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:50 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:50 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:50 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:50 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:50 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:50 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:50 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:50 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:50 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:50 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:01:50 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:01:50 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:01:50 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:01:50 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:01:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:50 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:50 --> Total execution time: 0.0630
DEBUG - 2014-02-20 17:01:54 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:54 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:54 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:54 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:54 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:54 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:54 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:54 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:54 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:54 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:54 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:54 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:01:54 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:01:54 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:54 --> Total execution time: 0.0663
DEBUG - 2014-02-20 17:01:55 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:55 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:55 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:55 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:55 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:55 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:55 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:55 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:55 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:55 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:55 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:01:55 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:55 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:55 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:55 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:55 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:55 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:55 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:55 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:55 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:55 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:55 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:55 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:01:55 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:01:55 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:01:55 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:01:55 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:01:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:55 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:55 --> Total execution time: 0.0747
DEBUG - 2014-02-20 17:01:57 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:57 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:57 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:57 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:57 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:57 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:57 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:57 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:57 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:57 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:57 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:57 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:57 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:57 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:57 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:57 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:01:57 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:01:57 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:57 --> Total execution time: 0.0623
DEBUG - 2014-02-20 17:01:59 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:59 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:59 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:59 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:59 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:59 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:59 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:59 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:59 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:59 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:59 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:01:59 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:01:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:01:59 --> URI Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Router Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Output Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Security Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Input Class Initialized
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:01:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:01:59 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Language Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Config Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Loader Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:01:59 --> Controller Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Session Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:01:59 --> Session routines successfully run
DEBUG - 2014-02-20 17:01:59 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:01:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:01:59 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:01:59 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:01:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:01:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:01:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:01:59 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:59 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:01:59 --> Model Class Initialized
DEBUG - 2014-02-20 17:01:59 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:01:59 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:01:59 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:01:59 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:01:59 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:01:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:01:59 --> Final output sent to browser
DEBUG - 2014-02-20 17:01:59 --> Total execution time: 0.0511
DEBUG - 2014-02-20 17:02:01 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:01 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:01 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:01 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:01 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:01 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:01 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:01 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:01 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:01 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:01 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:01 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:01 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:01 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:01 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:01 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:01 --> Total execution time: 0.0585
DEBUG - 2014-02-20 17:02:01 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:01 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:01 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:01 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:01 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:01 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:01 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:01 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:01 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:01 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:01 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:01 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:01 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:01 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:01 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:01 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:01 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:01 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:01 --> Total execution time: 0.0635
DEBUG - 2014-02-20 17:02:03 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:03 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:03 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:03 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:03 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:03 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:03 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:03 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:03 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:03 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:03 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:03 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:03 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:03 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:03 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:03 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:03 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:03 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:03 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:03 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:03 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:02:03 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:02:03 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:02:03 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:02:03 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:02:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:02:03 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:03 --> Total execution time: 0.0505
DEBUG - 2014-02-20 17:02:04 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:04 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:04 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:04 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:04 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:04 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:04 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:04 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:04 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:04 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:04 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:04 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:04 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:04 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:04 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:04 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:04 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:04 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:04 --> Total execution time: 0.0636
DEBUG - 2014-02-20 17:02:05 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:05 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:05 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:05 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:05 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:05 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:05 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:06 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:06 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:06 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:06 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:06 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:06 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:06 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:06 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:06 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:06 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:06 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:06 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:06 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:06 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:06 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:06 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:06 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:02:06 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:02:06 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:02:06 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:02:06 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:02:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:02:06 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:06 --> Total execution time: 0.0508
DEBUG - 2014-02-20 17:02:07 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:07 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:07 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:07 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:07 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:07 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:07 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:07 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:07 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:07 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:07 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:07 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:07 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:07 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:07 --> Total execution time: 0.0556
DEBUG - 2014-02-20 17:02:10 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:10 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:10 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:10 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:10 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:10 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:10 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:10 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:10 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:10 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:10 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:10 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:10 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:10 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:10 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:10 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:10 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:10 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:10 --> Total execution time: 0.0612
DEBUG - 2014-02-20 17:02:13 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:13 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:13 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:13 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:13 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:13 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:13 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:13 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:13 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:13 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:13 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:13 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:13 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:13 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:13 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:13 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:13 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:13 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:13 --> Total execution time: 0.0702
DEBUG - 2014-02-20 17:02:15 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:15 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:15 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:15 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:15 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:15 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:15 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:15 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:15 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:15 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:15 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:15 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:15 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:15 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:15 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:15 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:15 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:15 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:15 --> Total execution time: 0.0627
DEBUG - 2014-02-20 17:02:18 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:18 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:18 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:18 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:18 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:18 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:18 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:18 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:18 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:18 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:18 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:18 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:18 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:18 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:18 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:18 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:18 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:18 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:18 --> Total execution time: 0.0621
DEBUG - 2014-02-20 17:02:21 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:21 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:21 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:21 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:21 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:21 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:21 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:21 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:21 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:21 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:21 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:21 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:21 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:21 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:21 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:21 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:21 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:21 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:21 --> Total execution time: 0.0566
DEBUG - 2014-02-20 17:02:22 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:22 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:22 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:22 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:22 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:22 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:22 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:22 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:22 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:22 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:22 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:22 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:22 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:22 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:22 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:22 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:22 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:22 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:22 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:22 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:22 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:22 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:22 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:02:22 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:02:22 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:02:22 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:02:22 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:02:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:02:22 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:22 --> Total execution time: 0.0501
DEBUG - 2014-02-20 17:02:24 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:24 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:24 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:24 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:24 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:24 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:24 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:24 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:24 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:24 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:24 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:24 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:24 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:24 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:24 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:24 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:24 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:24 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:24 --> Total execution time: 0.0579
DEBUG - 2014-02-20 17:02:25 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:25 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:25 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:25 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:25 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:25 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:25 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:25 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:25 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:25 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:25 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:25 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:25 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:25 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:25 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:25 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:25 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:25 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:25 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:25 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:25 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:25 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:25 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:02:25 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:02:25 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:02:25 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:02:25 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:02:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:02:25 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:25 --> Total execution time: 0.0502
DEBUG - 2014-02-20 17:02:27 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:27 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:27 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:27 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:27 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:27 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:27 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:27 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:27 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:27 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:27 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:27 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:27 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:27 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:27 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:27 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:27 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:27 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:27 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:27 --> Total execution time: 0.0608
DEBUG - 2014-02-20 17:02:30 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:30 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:30 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:30 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:30 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:30 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:30 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:30 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:30 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:30 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:30 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:30 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:30 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:30 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:30 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:30 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:30 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:30 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:30 --> Total execution time: 0.0698
DEBUG - 2014-02-20 17:02:32 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:32 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:32 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:32 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:32 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:32 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:32 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:32 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:32 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:32 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:32 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:32 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:32 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:32 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:32 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:32 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:32 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:32 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:32 --> Total execution time: 0.0557
DEBUG - 2014-02-20 17:02:34 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:34 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:34 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:34 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:34 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:34 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:34 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:34 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:34 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:34 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:34 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:34 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:34 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:34 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:34 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:34 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:34 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:34 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:34 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:34 --> Total execution time: 0.0564
DEBUG - 2014-02-20 17:02:36 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:36 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:36 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:36 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:36 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:36 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:36 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:36 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:36 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:36 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:36 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:36 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:36 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:36 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:36 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:36 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:36 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:36 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:36 --> Total execution time: 0.0677
DEBUG - 2014-02-20 17:02:37 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:37 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:37 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:37 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:37 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:37 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:37 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:37 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:37 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:37 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:37 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:37 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:37 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:37 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:37 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:37 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:37 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:37 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:37 --> Total execution time: 0.0570
DEBUG - 2014-02-20 17:02:39 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:39 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:39 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:39 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:39 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:39 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:39 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:39 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:39 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:39 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:39 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:39 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:39 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:39 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:39 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:39 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:39 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:39 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:39 --> Total execution time: 0.0467
DEBUG - 2014-02-20 17:02:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:40 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:40 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:40 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:40 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:40 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:40 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:40 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:40 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:40 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:40 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:40 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:40 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:40 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:40 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:40 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:40 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:40 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:40 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:40 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:02:40 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:02:40 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:02:40 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:02:40 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:02:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:02:40 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:40 --> Total execution time: 0.0647
DEBUG - 2014-02-20 17:02:43 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:43 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:43 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:43 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:43 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:43 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:43 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:43 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:43 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:43 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:43 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:43 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:43 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:43 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:43 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:43 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:43 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:43 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:43 --> Total execution time: 0.0711
DEBUG - 2014-02-20 17:02:50 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:50 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:50 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:50 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:50 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:50 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:50 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:50 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:50 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:50 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:50 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:50 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:50 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:50 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:50 --> Total execution time: 0.0648
DEBUG - 2014-02-20 17:02:52 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:52 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:52 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:52 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:52 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:52 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:52 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:52 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:52 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:52 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:52 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:52 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:52 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:52 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:52 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:52 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:52 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:52 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:52 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:52 --> Total execution time: 0.0592
DEBUG - 2014-02-20 17:02:54 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:54 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:54 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:54 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:54 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:54 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:54 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:54 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:54 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:54 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:54 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:54 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:54 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:54 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:54 --> Total execution time: 0.0642
DEBUG - 2014-02-20 17:02:56 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:56 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:56 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:56 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:56 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:56 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:56 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:56 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:56 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:56 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:56 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:56 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:56 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:56 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:56 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:56 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:56 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:56 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:56 --> Total execution time: 0.0675
DEBUG - 2014-02-20 17:02:58 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:02:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:02:58 --> URI Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Router Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Output Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Security Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Input Class Initialized
DEBUG - 2014-02-20 17:02:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:02:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:02:58 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Language Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Config Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Loader Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:02:58 --> Controller Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Session Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:02:58 --> Session routines successfully run
DEBUG - 2014-02-20 17:02:58 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:02:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:02:58 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:02:58 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:02:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:02:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:02:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:02:58 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:58 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:02:58 --> Model Class Initialized
DEBUG - 2014-02-20 17:02:58 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:02:58 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:02:58 --> Final output sent to browser
DEBUG - 2014-02-20 17:02:58 --> Total execution time: 0.0615
DEBUG - 2014-02-20 17:03:00 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:00 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:00 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:00 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:00 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:00 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:00 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:00 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:00 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:00 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:00 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:00 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:00 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:00 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:00 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:00 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:03:00 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:03:00 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:00 --> Total execution time: 0.0692
DEBUG - 2014-02-20 17:03:02 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:02 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:02 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:02 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:02 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:02 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:02 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:02 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:02 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:02 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:02 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:02 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:02 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:02 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:02 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:02 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:03:02 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:03:02 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:02 --> Total execution time: 0.0612
DEBUG - 2014-02-20 17:03:50 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:50 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:50 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:50 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:50 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:50 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:50 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:50 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:50 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:51 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:51 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:51 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:51 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:51 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:51 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:51 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:51 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:51 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:51 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:51 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:51 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:51 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:51 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:03:51 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:51 --> Total execution time: 0.0529
DEBUG - 2014-02-20 17:03:53 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:53 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:53 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:53 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:53 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:53 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:53 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:53 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:53 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:53 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:53 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:53 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:53 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:53 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:53 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:53 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:03:53 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:53 --> Total execution time: 0.0622
DEBUG - 2014-02-20 17:03:54 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:54 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:54 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:54 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:54 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:54 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:54 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:54 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:54 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:54 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:54 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:54 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:54 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:03:54 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:54 --> Total execution time: 0.0600
DEBUG - 2014-02-20 17:03:55 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:55 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:55 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:55 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:55 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:55 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:55 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:55 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:55 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:55 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:55 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:55 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:03:55 --> Severity: Notice  --> Undefined offset: 0 D:\xampp\htdocs\tcms\application\modules\scheduler\models\mdl_scheduler.php 107
DEBUG - 2014-02-20 17:03:55 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:55 --> Total execution time: 0.0571
DEBUG - 2014-02-20 17:03:57 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:57 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:57 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:57 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:58 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:58 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:58 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:58 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:58 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:58 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:58 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:58 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:58 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:03:58 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:58 --> Total execution time: 0.0599
DEBUG - 2014-02-20 17:03:58 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:58 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:58 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:58 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:58 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:58 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:58 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:58 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:58 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:58 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:58 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:58 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:58 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:03:58 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:58 --> Total execution time: 0.0537
DEBUG - 2014-02-20 17:03:59 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:03:59 --> URI Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Router Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Output Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Security Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Input Class Initialized
DEBUG - 2014-02-20 17:03:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:59 --> XSS Filtering completed
DEBUG - 2014-02-20 17:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:03:59 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Language Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Config Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Loader Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:03:59 --> Controller Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Session Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:03:59 --> Session routines successfully run
DEBUG - 2014-02-20 17:03:59 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:03:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:03:59 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:03:59 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:03:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:03:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:03:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:03:59 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:59 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:03:59 --> Model Class Initialized
DEBUG - 2014-02-20 17:03:59 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:03:59 --> Final output sent to browser
DEBUG - 2014-02-20 17:03:59 --> Total execution time: 0.0595
DEBUG - 2014-02-20 17:04:00 --> Config Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:04:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:04:00 --> URI Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Router Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Output Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Security Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Input Class Initialized
DEBUG - 2014-02-20 17:04:00 --> XSS Filtering completed
DEBUG - 2014-02-20 17:04:00 --> XSS Filtering completed
DEBUG - 2014-02-20 17:04:00 --> XSS Filtering completed
DEBUG - 2014-02-20 17:04:00 --> XSS Filtering completed
DEBUG - 2014-02-20 17:04:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:04:00 --> Language Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Language Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Config Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Loader Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:04:00 --> Controller Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Session Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:04:00 --> Session routines successfully run
DEBUG - 2014-02-20 17:04:00 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:04:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:04:00 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:04:00 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:04:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:04:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:04:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:04:00 --> Model Class Initialized
DEBUG - 2014-02-20 17:04:00 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:04:00 --> Model Class Initialized
DEBUG - 2014-02-20 17:04:00 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:04:00 --> Final output sent to browser
DEBUG - 2014-02-20 17:04:00 --> Total execution time: 0.0610
DEBUG - 2014-02-20 17:43:02 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:02 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:02 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:02 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:02 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:02 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:02 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:02 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:02 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:02 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:02 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:02 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:02 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:02 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:02 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:02 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:43:02 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:02 --> Total execution time: 0.0414
DEBUG - 2014-02-20 17:43:03 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:03 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:03 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:03 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:03 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:03 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:03 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:03 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:03 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:03 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:03 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:03 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:43:03 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:03 --> Total execution time: 0.0444
DEBUG - 2014-02-20 17:43:05 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:05 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:05 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:05 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:05 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:05 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:05 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:05 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:05 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:05 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:05 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:05 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:05 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:05 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:05 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:05 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:43:05 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:05 --> Total execution time: 0.0407
DEBUG - 2014-02-20 17:43:06 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:06 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:06 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:06 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:06 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:06 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:06 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:06 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:06 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:06 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:06 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:06 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:43:06 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-20 17:43:06 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:06 --> Total execution time: 0.0544
DEBUG - 2014-02-20 17:43:07 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:07 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:07 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:07 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:07 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:07 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:07 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:07 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:07 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:07 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:07 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:43:07 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:07 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:07 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:07 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:07 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:07 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:07 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:07 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:07 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:07 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:07 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:07 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:43:07 --> Severity: Notice  --> Undefined variable: message D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 3
ERROR - 2014-02-20 17:43:07 --> Severity: Notice  --> Undefined variable: shifts D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
ERROR - 2014-02-20 17:43:07 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\tcms\application\modules\scheduler\views\scheduler.php 230
DEBUG - 2014-02-20 17:43:07 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-20 17:43:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:43:07 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:07 --> Total execution time: 0.0657
DEBUG - 2014-02-20 17:43:11 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:11 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:11 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:11 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:11 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:11 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:11 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:11 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:11 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:11 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:11 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:11 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:11 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:11 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:11 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:11 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:43:11 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:11 --> Total execution time: 0.0405
DEBUG - 2014-02-20 17:43:13 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:13 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:13 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:13 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:13 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:13 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:13 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:13 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:13 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:13 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:13 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:13 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:13 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:13 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:13 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:13 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:43:13 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:13 --> Total execution time: 0.0433
DEBUG - 2014-02-20 17:43:14 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:14 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:14 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:14 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:14 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:14 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:14 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:14 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:14 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:14 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:14 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:14 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:14 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:14 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:14 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:14 --> Helper loaded: image_helper
DEBUG - 2014-02-20 17:43:14 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:14 --> Total execution time: 0.0410
DEBUG - 2014-02-20 17:43:17 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:43:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:43:17 --> URI Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Router Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Output Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Security Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Input Class Initialized
DEBUG - 2014-02-20 17:43:17 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:17 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:17 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:17 --> XSS Filtering completed
DEBUG - 2014-02-20 17:43:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:43:17 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Language Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Config Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Loader Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:43:17 --> Controller Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Session Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:43:17 --> Session routines successfully run
DEBUG - 2014-02-20 17:43:17 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-20 17:43:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:43:17 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:43:17 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:43:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:43:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:43:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:43:17 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:17 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-20 17:43:17 --> Model Class Initialized
DEBUG - 2014-02-20 17:43:17 --> Helper loaded: image_helper
ERROR - 2014-02-20 17:43:17 --> Severity: Notice  --> Undefined offset: 0 D:\xampp\htdocs\tcms\application\modules\scheduler\models\mdl_scheduler.php 107
DEBUG - 2014-02-20 17:43:17 --> Final output sent to browser
DEBUG - 2014-02-20 17:43:17 --> Total execution time: 0.0419
DEBUG - 2014-02-20 17:54:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:54:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:54:40 --> URI Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Router Class Initialized
DEBUG - 2014-02-20 17:54:40 --> No URI present. Default controller set.
DEBUG - 2014-02-20 17:54:40 --> Output Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Security Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Input Class Initialized
DEBUG - 2014-02-20 17:54:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:54:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Loader Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:54:40 --> Controller Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Session Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:54:40 --> Session routines successfully run
DEBUG - 2014-02-20 17:54:40 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 17:54:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:54:40 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:54:40 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:54:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:54:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:54:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:54:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:54:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:54:40 --> URI Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Router Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Output Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Security Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Input Class Initialized
DEBUG - 2014-02-20 17:54:40 --> XSS Filtering completed
DEBUG - 2014-02-20 17:54:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:54:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Language Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Config Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Loader Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:54:40 --> Controller Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 17:54:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:54:40 --> Session Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:54:40 --> Session routines successfully run
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:54:40 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:54:40 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:54:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:54:40 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:54:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:54:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:54:40 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 17:54:40 --> Final output sent to browser
DEBUG - 2014-02-20 17:54:40 --> Total execution time: 0.0416
DEBUG - 2014-02-20 17:54:55 --> Config Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:54:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:54:55 --> URI Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Router Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Output Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Security Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Input Class Initialized
DEBUG - 2014-02-20 17:54:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:54:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:54:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:54:55 --> XSS Filtering completed
DEBUG - 2014-02-20 17:54:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:54:55 --> Language Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Language Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Config Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Loader Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:54:55 --> Controller Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 17:54:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:54:55 --> Session Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:54:55 --> Session routines successfully run
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:54:55 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:54:55 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:54:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:54:55 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:54:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:54:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:54:55 --> Model Class Initialized
DEBUG - 2014-02-20 17:54:55 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 17:54:55 --> Model Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Config Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Hooks Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Utf8 Class Initialized
DEBUG - 2014-02-20 17:54:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 17:54:56 --> URI Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Router Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Output Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Security Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Input Class Initialized
DEBUG - 2014-02-20 17:54:56 --> XSS Filtering completed
DEBUG - 2014-02-20 17:54:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 17:54:56 --> Language Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Language Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Config Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Loader Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: text_helper
DEBUG - 2014-02-20 17:54:56 --> Controller Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Session Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: string_helper
DEBUG - 2014-02-20 17:54:56 --> Session routines successfully run
DEBUG - 2014-02-20 17:54:56 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 17:54:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: url_helper
DEBUG - 2014-02-20 17:54:56 --> Database Driver Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: form_helper
DEBUG - 2014-02-20 17:54:56 --> Form Validation Class Initialized
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: number_helper
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: date_helper
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 17:54:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 17:54:56 --> Helper loaded: language_helper
DEBUG - 2014-02-20 17:54:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 17:54:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 17:54:56 --> Model Class Initialized
DEBUG - 2014-02-20 17:54:56 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 17:54:56 --> Model Class Initialized
DEBUG - 2014-02-20 17:54:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 17:54:56 --> Model Class Initialized
DEBUG - 2014-02-20 17:54:56 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 17:54:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 17:54:56 --> Final output sent to browser
DEBUG - 2014-02-20 17:54:56 --> Total execution time: 0.0461
DEBUG - 2014-02-20 18:10:54 --> Config Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:10:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:10:54 --> URI Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Router Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Output Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Security Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Input Class Initialized
DEBUG - 2014-02-20 18:10:54 --> XSS Filtering completed
DEBUG - 2014-02-20 18:10:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:10:54 --> Language Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Language Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Config Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Loader Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:10:54 --> Controller Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Session Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:10:54 --> Session routines successfully run
DEBUG - 2014-02-20 18:10:54 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 18:10:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:10:54 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:10:54 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:10:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:10:54 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:10:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:10:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:10:54 --> Model Class Initialized
DEBUG - 2014-02-20 18:10:54 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 18:10:54 --> Model Class Initialized
DEBUG - 2014-02-20 18:10:54 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:10:54 --> Model Class Initialized
DEBUG - 2014-02-20 18:10:54 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 18:10:54 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:10:54 --> Final output sent to browser
DEBUG - 2014-02-20 18:10:54 --> Total execution time: 0.0660
DEBUG - 2014-02-20 18:11:01 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:01 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:01 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:01 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:01 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 18:11:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:01 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:01 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:01 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:01 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:01 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:01 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:01 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:01 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 18:11:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:01 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:01 --> A session cookie was not found.
DEBUG - 2014-02-20 18:11:01 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:01 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:01 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:01 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:01 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 18:11:01 --> Final output sent to browser
DEBUG - 2014-02-20 18:11:01 --> Total execution time: 0.0334
DEBUG - 2014-02-20 18:11:07 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:07 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:07 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:07 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:07 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:07 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:07 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:07 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 18:11:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:07 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:07 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:07 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:08 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:08 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:08 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 18:11:08 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:08 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:08 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:08 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:08 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:08 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:08 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 18:11:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:08 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:08 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:08 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:08 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:08 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 18:11:08 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:11:08 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:08 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 18:11:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:11:08 --> Final output sent to browser
DEBUG - 2014-02-20 18:11:08 --> Total execution time: 0.0533
DEBUG - 2014-02-20 18:11:18 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:18 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:18 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:18 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:18 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 18:11:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:18 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:18 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:18 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:18 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:18 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:18 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:18 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:18 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 18:11:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:18 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:18 --> A session cookie was not found.
DEBUG - 2014-02-20 18:11:18 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:18 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:18 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:18 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:18 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-20 18:11:18 --> Final output sent to browser
DEBUG - 2014-02-20 18:11:18 --> Total execution time: 0.0473
DEBUG - 2014-02-20 18:11:31 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:31 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:31 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:31 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-20 18:11:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:31 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:31 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:31 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:31 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:31 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-20 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:31 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:31 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:31 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:31 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:31 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:31 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 18:11:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:31 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:31 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:31 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:31 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:31 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:11:31 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:31 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 18:11:31 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:11:31 --> Final output sent to browser
DEBUG - 2014-02-20 18:11:31 --> Total execution time: 0.0532
DEBUG - 2014-02-20 18:11:50 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:11:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:11:50 --> URI Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Router Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Output Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Security Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Input Class Initialized
DEBUG - 2014-02-20 18:11:50 --> XSS Filtering completed
DEBUG - 2014-02-20 18:11:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:11:50 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Language Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Config Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Loader Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:11:50 --> Controller Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Session Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:11:50 --> Session routines successfully run
DEBUG - 2014-02-20 18:11:50 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:11:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:11:50 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:11:50 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:11:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:11:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:11:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:11:50 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:11:50 --> Model Class Initialized
DEBUG - 2014-02-20 18:11:50 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:11:50 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 18:11:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:11:50 --> Final output sent to browser
DEBUG - 2014-02-20 18:11:50 --> Total execution time: 0.0654
DEBUG - 2014-02-20 18:19:04 --> Config Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:19:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:19:04 --> URI Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Router Class Initialized
DEBUG - 2014-02-20 18:19:04 --> No URI present. Default controller set.
DEBUG - 2014-02-20 18:19:04 --> Output Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Security Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Input Class Initialized
DEBUG - 2014-02-20 18:19:04 --> XSS Filtering completed
DEBUG - 2014-02-20 18:19:04 --> XSS Filtering completed
DEBUG - 2014-02-20 18:19:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:19:04 --> Language Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Language Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Config Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Loader Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:19:04 --> Controller Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Session Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:19:04 --> Session routines successfully run
DEBUG - 2014-02-20 18:19:04 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 18:19:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:19:04 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:19:04 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:19:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:19:04 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:19:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:19:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:19:04 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:04 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 18:19:04 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:04 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:19:04 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:04 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 18:19:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:19:04 --> Final output sent to browser
DEBUG - 2014-02-20 18:19:04 --> Total execution time: 0.0615
DEBUG - 2014-02-20 18:19:13 --> Config Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:19:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:19:13 --> URI Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Router Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Output Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Security Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Input Class Initialized
DEBUG - 2014-02-20 18:19:13 --> XSS Filtering completed
DEBUG - 2014-02-20 18:19:13 --> XSS Filtering completed
DEBUG - 2014-02-20 18:19:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:19:13 --> Language Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Language Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Config Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Loader Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:19:13 --> Controller Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Session Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:19:13 --> Session routines successfully run
DEBUG - 2014-02-20 18:19:13 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:19:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:19:13 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:19:13 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:19:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:19:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:19:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:19:13 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:19:13 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:13 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:19:13 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 18:19:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:19:13 --> Final output sent to browser
DEBUG - 2014-02-20 18:19:13 --> Total execution time: 0.0659
DEBUG - 2014-02-20 18:19:29 --> Config Class Initialized
DEBUG - 2014-02-20 18:19:29 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:19:29 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:19:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:19:29 --> URI Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Router Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Output Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Security Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Input Class Initialized
DEBUG - 2014-02-20 18:19:30 --> XSS Filtering completed
DEBUG - 2014-02-20 18:19:30 --> XSS Filtering completed
DEBUG - 2014-02-20 18:19:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:19:30 --> Language Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Language Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Config Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Loader Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:19:30 --> Controller Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Session Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:19:30 --> Session routines successfully run
DEBUG - 2014-02-20 18:19:30 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:19:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:19:30 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:19:30 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:19:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:19:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:19:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:19:30 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:30 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:19:30 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:30 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:19:30 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 18:19:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:19:30 --> Final output sent to browser
DEBUG - 2014-02-20 18:19:30 --> Total execution time: 0.0672
DEBUG - 2014-02-20 18:19:59 --> Config Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:19:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:19:59 --> URI Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Router Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Output Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Security Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Input Class Initialized
DEBUG - 2014-02-20 18:19:59 --> XSS Filtering completed
DEBUG - 2014-02-20 18:19:59 --> XSS Filtering completed
DEBUG - 2014-02-20 18:19:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:19:59 --> Language Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Language Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Config Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Loader Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:19:59 --> Controller Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Session Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:19:59 --> Session routines successfully run
DEBUG - 2014-02-20 18:19:59 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:19:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:19:59 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:19:59 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:19:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:19:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:19:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:19:59 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:19:59 --> Model Class Initialized
DEBUG - 2014-02-20 18:19:59 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:19:59 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 18:19:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:19:59 --> Final output sent to browser
DEBUG - 2014-02-20 18:19:59 --> Total execution time: 0.0607
DEBUG - 2014-02-20 18:21:10 --> Config Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:21:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:21:10 --> URI Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Router Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Output Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Security Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Input Class Initialized
DEBUG - 2014-02-20 18:21:10 --> XSS Filtering completed
DEBUG - 2014-02-20 18:21:10 --> XSS Filtering completed
DEBUG - 2014-02-20 18:21:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:21:10 --> Language Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Language Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Config Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Loader Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:21:10 --> Controller Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Session Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:21:10 --> Session routines successfully run
DEBUG - 2014-02-20 18:21:10 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:21:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:21:10 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:21:10 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:21:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:21:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:21:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:21:10 --> Model Class Initialized
DEBUG - 2014-02-20 18:21:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:21:10 --> Model Class Initialized
DEBUG - 2014-02-20 18:21:10 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:21:10 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 18:21:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:21:10 --> Final output sent to browser
DEBUG - 2014-02-20 18:21:10 --> Total execution time: 0.0663
DEBUG - 2014-02-20 18:21:33 --> Config Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:21:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:21:33 --> URI Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Router Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Output Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Security Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Input Class Initialized
DEBUG - 2014-02-20 18:21:33 --> XSS Filtering completed
DEBUG - 2014-02-20 18:21:33 --> XSS Filtering completed
DEBUG - 2014-02-20 18:21:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:21:33 --> Language Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Language Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Config Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Loader Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:21:33 --> Controller Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Session Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:21:33 --> Session routines successfully run
DEBUG - 2014-02-20 18:21:33 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:21:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:21:33 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:21:33 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:21:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:21:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:21:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:21:33 --> Model Class Initialized
DEBUG - 2014-02-20 18:21:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:21:33 --> Model Class Initialized
DEBUG - 2014-02-20 18:21:33 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:21:33 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 18:21:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:21:33 --> Final output sent to browser
DEBUG - 2014-02-20 18:21:33 --> Total execution time: 0.0622
DEBUG - 2014-02-20 18:21:49 --> Config Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:21:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:21:49 --> URI Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Router Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Output Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Security Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Input Class Initialized
DEBUG - 2014-02-20 18:21:49 --> XSS Filtering completed
DEBUG - 2014-02-20 18:21:49 --> XSS Filtering completed
DEBUG - 2014-02-20 18:21:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:21:49 --> Language Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Language Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Config Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Loader Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:21:49 --> Controller Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Session Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:21:49 --> Session routines successfully run
DEBUG - 2014-02-20 18:21:49 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:21:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:21:49 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:21:49 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:21:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:21:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:21:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:21:49 --> Model Class Initialized
DEBUG - 2014-02-20 18:21:49 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:21:49 --> Model Class Initialized
DEBUG - 2014-02-20 18:21:49 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:21:49 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 18:21:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:21:49 --> Final output sent to browser
DEBUG - 2014-02-20 18:21:49 --> Total execution time: 0.0547
DEBUG - 2014-02-20 18:22:24 --> Config Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:22:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:22:24 --> URI Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Router Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Output Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Security Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Input Class Initialized
DEBUG - 2014-02-20 18:22:24 --> XSS Filtering completed
DEBUG - 2014-02-20 18:22:24 --> XSS Filtering completed
DEBUG - 2014-02-20 18:22:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:22:24 --> Language Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Language Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Config Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Loader Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:22:24 --> Controller Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Session Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:22:24 --> Session routines successfully run
DEBUG - 2014-02-20 18:22:24 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:22:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:22:24 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:22:24 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:22:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:22:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:22:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:22:24 --> Model Class Initialized
DEBUG - 2014-02-20 18:22:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:22:24 --> Model Class Initialized
DEBUG - 2014-02-20 18:22:24 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:22:24 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 18:22:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:22:24 --> Final output sent to browser
DEBUG - 2014-02-20 18:22:24 --> Total execution time: 0.0622
DEBUG - 2014-02-20 18:22:50 --> Config Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:22:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:22:50 --> URI Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Router Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Output Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Security Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Input Class Initialized
DEBUG - 2014-02-20 18:22:50 --> XSS Filtering completed
DEBUG - 2014-02-20 18:22:50 --> XSS Filtering completed
DEBUG - 2014-02-20 18:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:22:50 --> Language Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Language Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Config Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Loader Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:22:50 --> Controller Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Session Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:22:50 --> Session routines successfully run
DEBUG - 2014-02-20 18:22:50 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:22:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:22:50 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:22:50 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:22:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:22:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:22:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:22:50 --> Model Class Initialized
DEBUG - 2014-02-20 18:22:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:22:50 --> Model Class Initialized
DEBUG - 2014-02-20 18:22:50 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:22:50 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 18:22:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:22:50 --> Final output sent to browser
DEBUG - 2014-02-20 18:22:50 --> Total execution time: 0.0519
DEBUG - 2014-02-20 18:23:07 --> Config Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:23:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:23:07 --> URI Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Router Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Output Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Security Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Input Class Initialized
DEBUG - 2014-02-20 18:23:07 --> XSS Filtering completed
DEBUG - 2014-02-20 18:23:07 --> XSS Filtering completed
DEBUG - 2014-02-20 18:23:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:23:07 --> Language Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Language Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Config Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Loader Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:23:07 --> Controller Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Session Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:23:07 --> Session routines successfully run
DEBUG - 2014-02-20 18:23:07 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:23:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:23:07 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:23:07 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:23:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:23:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:23:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:23:07 --> Model Class Initialized
DEBUG - 2014-02-20 18:23:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:23:07 --> Model Class Initialized
DEBUG - 2014-02-20 18:23:07 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:23:07 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 18:23:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:23:07 --> Final output sent to browser
DEBUG - 2014-02-20 18:23:07 --> Total execution time: 0.0653
DEBUG - 2014-02-20 18:23:09 --> Config Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:23:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:23:09 --> URI Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Router Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Output Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Security Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Input Class Initialized
DEBUG - 2014-02-20 18:23:09 --> XSS Filtering completed
DEBUG - 2014-02-20 18:23:09 --> XSS Filtering completed
DEBUG - 2014-02-20 18:23:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:23:09 --> Language Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Language Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Config Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Loader Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:23:09 --> Controller Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Session Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:23:09 --> Session routines successfully run
DEBUG - 2014-02-20 18:23:09 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:23:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:23:09 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:23:09 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:23:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:23:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:23:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:23:09 --> Model Class Initialized
DEBUG - 2014-02-20 18:23:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:23:09 --> Model Class Initialized
DEBUG - 2014-02-20 18:23:09 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:23:09 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 18:23:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:23:09 --> Final output sent to browser
DEBUG - 2014-02-20 18:23:09 --> Total execution time: 0.0604
DEBUG - 2014-02-20 18:23:18 --> Config Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:23:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:23:18 --> URI Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Router Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Output Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Security Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Input Class Initialized
DEBUG - 2014-02-20 18:23:18 --> XSS Filtering completed
DEBUG - 2014-02-20 18:23:18 --> XSS Filtering completed
DEBUG - 2014-02-20 18:23:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:23:18 --> Language Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Language Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Config Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Loader Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:23:18 --> Controller Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Session Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:23:18 --> Session routines successfully run
DEBUG - 2014-02-20 18:23:18 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:23:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:23:18 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:23:18 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:23:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:23:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:23:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:23:18 --> Model Class Initialized
DEBUG - 2014-02-20 18:23:18 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:23:18 --> Model Class Initialized
DEBUG - 2014-02-20 18:23:18 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:23:18 --> File loaded: application/modules/patient/views/patient_attendance.php
DEBUG - 2014-02-20 18:23:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:23:18 --> Final output sent to browser
DEBUG - 2014-02-20 18:23:18 --> Total execution time: 0.0503
DEBUG - 2014-02-20 18:23:20 --> Config Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:23:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:23:20 --> URI Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Router Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Output Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Security Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Input Class Initialized
DEBUG - 2014-02-20 18:23:20 --> XSS Filtering completed
DEBUG - 2014-02-20 18:23:20 --> XSS Filtering completed
DEBUG - 2014-02-20 18:23:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:23:20 --> Language Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Language Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Config Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Loader Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:23:20 --> Controller Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Session Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:23:20 --> Session routines successfully run
DEBUG - 2014-02-20 18:23:20 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:23:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:23:20 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:23:20 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:23:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:23:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:23:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:23:20 --> Model Class Initialized
DEBUG - 2014-02-20 18:23:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:23:20 --> Model Class Initialized
DEBUG - 2014-02-20 18:23:20 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:23:20 --> File loaded: application/modules/patient/views/referral.php
DEBUG - 2014-02-20 18:23:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:23:20 --> Final output sent to browser
DEBUG - 2014-02-20 18:23:20 --> Total execution time: 0.0617
DEBUG - 2014-02-20 18:31:20 --> Config Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:31:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:31:20 --> URI Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Router Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Output Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Security Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Input Class Initialized
DEBUG - 2014-02-20 18:31:20 --> XSS Filtering completed
DEBUG - 2014-02-20 18:31:20 --> XSS Filtering completed
DEBUG - 2014-02-20 18:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:31:20 --> Language Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Language Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Config Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Loader Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:31:20 --> Controller Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Session Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:31:20 --> Session routines successfully run
DEBUG - 2014-02-20 18:31:20 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:31:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:31:20 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:31:20 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:31:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:31:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:31:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:31:20 --> Model Class Initialized
DEBUG - 2014-02-20 18:31:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:31:20 --> Model Class Initialized
DEBUG - 2014-02-20 18:31:20 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:31:20 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-20 18:31:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:31:20 --> Final output sent to browser
DEBUG - 2014-02-20 18:31:20 --> Total execution time: 0.0705
DEBUG - 2014-02-20 18:36:00 --> Config Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:36:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:36:00 --> URI Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Router Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Output Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Security Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Input Class Initialized
DEBUG - 2014-02-20 18:36:00 --> XSS Filtering completed
DEBUG - 2014-02-20 18:36:00 --> XSS Filtering completed
DEBUG - 2014-02-20 18:36:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:36:00 --> Language Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Language Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Config Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Loader Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:36:00 --> Controller Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Session Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:36:00 --> Session routines successfully run
DEBUG - 2014-02-20 18:36:00 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:36:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:36:00 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:36:00 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:36:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:36:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:36:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:36:00 --> Model Class Initialized
DEBUG - 2014-02-20 18:36:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:36:00 --> Model Class Initialized
DEBUG - 2014-02-20 18:36:00 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:36:00 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 18:36:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:36:00 --> Final output sent to browser
DEBUG - 2014-02-20 18:36:00 --> Total execution time: 0.0577
DEBUG - 2014-02-20 18:38:22 --> Config Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Hooks Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Utf8 Class Initialized
DEBUG - 2014-02-20 18:38:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 18:38:22 --> URI Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Router Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Output Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Security Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Input Class Initialized
DEBUG - 2014-02-20 18:38:22 --> XSS Filtering completed
DEBUG - 2014-02-20 18:38:22 --> XSS Filtering completed
DEBUG - 2014-02-20 18:38:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 18:38:22 --> Language Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Language Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Config Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Loader Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: text_helper
DEBUG - 2014-02-20 18:38:22 --> Controller Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Session Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: string_helper
DEBUG - 2014-02-20 18:38:22 --> Session routines successfully run
DEBUG - 2014-02-20 18:38:22 --> Patient MX_Controller Initialized
DEBUG - 2014-02-20 18:38:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: url_helper
DEBUG - 2014-02-20 18:38:22 --> Database Driver Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: form_helper
DEBUG - 2014-02-20 18:38:22 --> Form Validation Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: number_helper
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: date_helper
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 18:38:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: language_helper
DEBUG - 2014-02-20 18:38:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 18:38:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 18:38:22 --> Model Class Initialized
DEBUG - 2014-02-20 18:38:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 18:38:22 --> Model Class Initialized
DEBUG - 2014-02-20 18:38:22 --> Helper loaded: image_helper
DEBUG - 2014-02-20 18:38:22 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-20 18:38:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 18:38:22 --> Final output sent to browser
DEBUG - 2014-02-20 18:38:22 --> Total execution time: 0.0610
DEBUG - 2014-02-20 19:31:23 --> Config Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Hooks Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Utf8 Class Initialized
DEBUG - 2014-02-20 19:31:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 19:31:23 --> URI Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Router Class Initialized
DEBUG - 2014-02-20 19:31:23 --> No URI present. Default controller set.
DEBUG - 2014-02-20 19:31:23 --> Output Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Security Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Input Class Initialized
DEBUG - 2014-02-20 19:31:23 --> XSS Filtering completed
DEBUG - 2014-02-20 19:31:23 --> XSS Filtering completed
DEBUG - 2014-02-20 19:31:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 19:31:23 --> Language Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Language Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Config Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Loader Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: text_helper
DEBUG - 2014-02-20 19:31:23 --> Controller Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Session Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: string_helper
DEBUG - 2014-02-20 19:31:23 --> Session routines successfully run
DEBUG - 2014-02-20 19:31:23 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 19:31:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: url_helper
DEBUG - 2014-02-20 19:31:23 --> Database Driver Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: form_helper
DEBUG - 2014-02-20 19:31:23 --> Form Validation Class Initialized
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: number_helper
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: date_helper
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 19:31:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 19:31:23 --> Helper loaded: language_helper
DEBUG - 2014-02-20 19:31:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 19:31:23 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 19:31:23 --> Model Class Initialized
DEBUG - 2014-02-20 19:31:23 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 19:31:23 --> Model Class Initialized
DEBUG - 2014-02-20 19:31:23 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 19:31:23 --> Model Class Initialized
DEBUG - 2014-02-20 19:31:23 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 19:31:23 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 19:31:23 --> Final output sent to browser
DEBUG - 2014-02-20 19:31:23 --> Total execution time: 0.0764
DEBUG - 2014-02-20 19:32:46 --> Config Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Hooks Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Utf8 Class Initialized
DEBUG - 2014-02-20 19:32:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 19:32:46 --> URI Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Router Class Initialized
DEBUG - 2014-02-20 19:32:46 --> No URI present. Default controller set.
DEBUG - 2014-02-20 19:32:46 --> Output Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Security Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Input Class Initialized
DEBUG - 2014-02-20 19:32:46 --> XSS Filtering completed
DEBUG - 2014-02-20 19:32:46 --> XSS Filtering completed
DEBUG - 2014-02-20 19:32:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 19:32:46 --> Language Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Language Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Config Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Loader Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: text_helper
DEBUG - 2014-02-20 19:32:46 --> Controller Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Session Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: string_helper
DEBUG - 2014-02-20 19:32:46 --> Session routines successfully run
DEBUG - 2014-02-20 19:32:46 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 19:32:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: url_helper
DEBUG - 2014-02-20 19:32:46 --> Database Driver Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: form_helper
DEBUG - 2014-02-20 19:32:46 --> Form Validation Class Initialized
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: number_helper
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: date_helper
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 19:32:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 19:32:46 --> Helper loaded: language_helper
DEBUG - 2014-02-20 19:32:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 19:32:46 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 19:32:46 --> Model Class Initialized
DEBUG - 2014-02-20 19:32:46 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 19:32:46 --> Model Class Initialized
DEBUG - 2014-02-20 19:32:46 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 19:32:46 --> Model Class Initialized
DEBUG - 2014-02-20 19:32:46 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 19:32:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 19:32:46 --> Final output sent to browser
DEBUG - 2014-02-20 19:32:46 --> Total execution time: 0.0552
DEBUG - 2014-02-20 19:33:54 --> Config Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Hooks Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Utf8 Class Initialized
DEBUG - 2014-02-20 19:33:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 19:33:54 --> URI Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Router Class Initialized
DEBUG - 2014-02-20 19:33:54 --> No URI present. Default controller set.
DEBUG - 2014-02-20 19:33:54 --> Output Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Security Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Input Class Initialized
DEBUG - 2014-02-20 19:33:54 --> XSS Filtering completed
DEBUG - 2014-02-20 19:33:54 --> XSS Filtering completed
DEBUG - 2014-02-20 19:33:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 19:33:54 --> Language Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Language Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Config Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Loader Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: text_helper
DEBUG - 2014-02-20 19:33:54 --> Controller Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Session Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: string_helper
DEBUG - 2014-02-20 19:33:54 --> Session routines successfully run
DEBUG - 2014-02-20 19:33:54 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 19:33:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: url_helper
DEBUG - 2014-02-20 19:33:54 --> Database Driver Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: form_helper
DEBUG - 2014-02-20 19:33:54 --> Form Validation Class Initialized
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: number_helper
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: date_helper
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 19:33:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 19:33:54 --> Helper loaded: language_helper
DEBUG - 2014-02-20 19:33:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 19:33:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 19:33:54 --> Model Class Initialized
DEBUG - 2014-02-20 19:33:54 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 19:33:54 --> Model Class Initialized
DEBUG - 2014-02-20 19:33:54 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 19:33:54 --> Model Class Initialized
DEBUG - 2014-02-20 19:33:54 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 19:33:54 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 19:33:54 --> Final output sent to browser
DEBUG - 2014-02-20 19:33:54 --> Total execution time: 0.0526
DEBUG - 2014-02-20 19:33:57 --> Config Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Hooks Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Utf8 Class Initialized
DEBUG - 2014-02-20 19:33:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 19:33:57 --> URI Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Router Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Output Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Security Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Input Class Initialized
DEBUG - 2014-02-20 19:33:57 --> XSS Filtering completed
DEBUG - 2014-02-20 19:33:57 --> XSS Filtering completed
DEBUG - 2014-02-20 19:33:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 19:33:57 --> Language Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Language Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Config Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Loader Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: text_helper
DEBUG - 2014-02-20 19:33:57 --> Controller Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Session Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: string_helper
DEBUG - 2014-02-20 19:33:57 --> Session routines successfully run
DEBUG - 2014-02-20 19:33:57 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 19:33:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: url_helper
DEBUG - 2014-02-20 19:33:57 --> Database Driver Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: form_helper
DEBUG - 2014-02-20 19:33:57 --> Form Validation Class Initialized
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: number_helper
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: date_helper
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 19:33:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 19:33:57 --> Helper loaded: language_helper
DEBUG - 2014-02-20 19:33:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 19:33:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 19:33:57 --> Model Class Initialized
DEBUG - 2014-02-20 19:33:57 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 19:33:57 --> Model Class Initialized
DEBUG - 2014-02-20 19:33:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 19:33:57 --> Model Class Initialized
DEBUG - 2014-02-20 19:33:57 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 19:33:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 19:33:57 --> Final output sent to browser
DEBUG - 2014-02-20 19:33:57 --> Total execution time: 0.0613
DEBUG - 2014-02-20 19:36:39 --> Config Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Hooks Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Utf8 Class Initialized
DEBUG - 2014-02-20 19:36:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-20 19:36:39 --> URI Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Router Class Initialized
DEBUG - 2014-02-20 19:36:39 --> No URI present. Default controller set.
DEBUG - 2014-02-20 19:36:39 --> Output Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Security Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Input Class Initialized
DEBUG - 2014-02-20 19:36:39 --> XSS Filtering completed
DEBUG - 2014-02-20 19:36:39 --> XSS Filtering completed
DEBUG - 2014-02-20 19:36:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-20 19:36:39 --> Language Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Language Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Config Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Loader Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: text_helper
DEBUG - 2014-02-20 19:36:39 --> Controller Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Session Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: string_helper
DEBUG - 2014-02-20 19:36:39 --> Session routines successfully run
DEBUG - 2014-02-20 19:36:39 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-20 19:36:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: url_helper
DEBUG - 2014-02-20 19:36:39 --> Database Driver Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: form_helper
DEBUG - 2014-02-20 19:36:39 --> Form Validation Class Initialized
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: number_helper
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: date_helper
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-20 19:36:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-20 19:36:39 --> Helper loaded: language_helper
DEBUG - 2014-02-20 19:36:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-20 19:36:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-20 19:36:39 --> Model Class Initialized
DEBUG - 2014-02-20 19:36:39 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-20 19:36:39 --> Model Class Initialized
DEBUG - 2014-02-20 19:36:39 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-20 19:36:39 --> Model Class Initialized
DEBUG - 2014-02-20 19:36:39 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-20 19:36:39 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-20 19:36:39 --> Final output sent to browser
DEBUG - 2014-02-20 19:36:39 --> Total execution time: 0.0529
