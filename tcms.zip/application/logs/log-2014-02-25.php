<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-25 10:40:54 --> Config Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Hooks Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Utf8 Class Initialized
DEBUG - 2014-02-25 10:40:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-25 10:40:54 --> URI Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Router Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Output Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Security Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Input Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-25 10:40:54 --> Language Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Language Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Config Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Loader Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: text_helper
DEBUG - 2014-02-25 10:40:54 --> Controller Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Session Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: string_helper
DEBUG - 2014-02-25 10:40:54 --> A session cookie was not found.
DEBUG - 2014-02-25 10:40:54 --> Session routines successfully run
DEBUG - 2014-02-25 10:40:54 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-25 10:40:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: url_helper
DEBUG - 2014-02-25 10:40:54 --> Database Driver Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: form_helper
DEBUG - 2014-02-25 10:40:54 --> Form Validation Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: number_helper
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: date_helper
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-25 10:40:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: language_helper
DEBUG - 2014-02-25 10:40:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-25 10:40:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-25 10:40:54 --> Config Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Hooks Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Utf8 Class Initialized
DEBUG - 2014-02-25 10:40:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-25 10:40:54 --> URI Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Router Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Output Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Security Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Input Class Initialized
DEBUG - 2014-02-25 10:40:54 --> XSS Filtering completed
DEBUG - 2014-02-25 10:40:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-25 10:40:54 --> Language Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Language Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Config Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Loader Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: text_helper
DEBUG - 2014-02-25 10:40:54 --> Controller Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-25 10:40:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-25 10:40:54 --> Session Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: string_helper
DEBUG - 2014-02-25 10:40:54 --> Session routines successfully run
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: url_helper
DEBUG - 2014-02-25 10:40:54 --> Database Driver Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: form_helper
DEBUG - 2014-02-25 10:40:54 --> Form Validation Class Initialized
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: number_helper
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: date_helper
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-25 10:40:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-25 10:40:54 --> Helper loaded: language_helper
DEBUG - 2014-02-25 10:40:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-25 10:40:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-25 10:40:54 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-25 10:40:54 --> Final output sent to browser
DEBUG - 2014-02-25 10:40:54 --> Total execution time: 0.0976
