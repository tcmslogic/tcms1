<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-12-14 09:41:35 --> Config Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Hooks Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Utf8 Class Initialized
DEBUG - 2013-12-14 09:41:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 09:41:35 --> URI Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Router Class Initialized
DEBUG - 2013-12-14 09:41:35 --> No URI present. Default controller set.
DEBUG - 2013-12-14 09:41:35 --> Output Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Security Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Input Class Initialized
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 09:41:35 --> Language Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Language Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Config Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Loader Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Controller Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 09:41:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 09:41:35 --> Session Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: string_helper
DEBUG - 2013-12-14 09:41:35 --> A session cookie was not found.
DEBUG - 2013-12-14 09:41:35 --> Session routines successfully run
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: url_helper
DEBUG - 2013-12-14 09:41:35 --> Database Driver Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: form_helper
DEBUG - 2013-12-14 09:41:35 --> Form Validation Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: number_helper
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: date_helper
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 09:41:35 --> Model Class Initialized
DEBUG - 2013-12-14 09:41:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 09:41:35 --> Model Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 09:41:35 --> Helper loaded: language_helper
DEBUG - 2013-12-14 09:41:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 09:41:35 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 09:41:35 --> Config Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Hooks Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Utf8 Class Initialized
DEBUG - 2013-12-14 09:41:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 09:41:35 --> URI Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Router Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Output Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Security Class Initialized
DEBUG - 2013-12-14 09:41:35 --> Input Class Initialized
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> XSS Filtering completed
DEBUG - 2013-12-14 09:41:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 09:41:35 --> Language Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Language Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Config Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Loader Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Controller Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 09:41:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 09:41:36 --> Session Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: string_helper
DEBUG - 2013-12-14 09:41:36 --> Session routines successfully run
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: url_helper
DEBUG - 2013-12-14 09:41:36 --> Database Driver Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: form_helper
DEBUG - 2013-12-14 09:41:36 --> Form Validation Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: number_helper
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: date_helper
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 09:41:36 --> Model Class Initialized
DEBUG - 2013-12-14 09:41:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 09:41:36 --> Model Class Initialized
DEBUG - 2013-12-14 09:41:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 09:41:36 --> Helper loaded: language_helper
DEBUG - 2013-12-14 09:41:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 09:41:36 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 09:41:36 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-14 09:41:36 --> Final output sent to browser
DEBUG - 2013-12-14 09:41:36 --> Total execution time: 0.2471
DEBUG - 2013-12-14 10:02:57 --> Config Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:02:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:02:57 --> URI Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Router Class Initialized
DEBUG - 2013-12-14 10:02:57 --> No URI present. Default controller set.
DEBUG - 2013-12-14 10:02:57 --> Output Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Security Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Input Class Initialized
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:02:57 --> Language Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Language Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Config Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Loader Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Controller Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:02:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:02:57 --> Session Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:02:57 --> Session routines successfully run
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:02:57 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:02:57 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:02:57 --> Model Class Initialized
DEBUG - 2013-12-14 10:02:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:02:57 --> Model Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:02:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:02:57 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:02:57 --> Config Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:02:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:02:57 --> URI Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Router Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Output Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Security Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Input Class Initialized
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> XSS Filtering completed
DEBUG - 2013-12-14 10:02:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:02:57 --> Language Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Language Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Config Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Loader Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Controller Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:02:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:02:57 --> Session Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:02:57 --> Session routines successfully run
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:02:57 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:02:57 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:02:57 --> Model Class Initialized
DEBUG - 2013-12-14 10:02:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:02:57 --> Model Class Initialized
DEBUG - 2013-12-14 10:02:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:02:57 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:02:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:02:57 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:02:57 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-14 10:02:57 --> Final output sent to browser
DEBUG - 2013-12-14 10:02:57 --> Total execution time: 0.0492
DEBUG - 2013-12-14 10:20:02 --> Config Class Initialized
DEBUG - 2013-12-14 10:20:02 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:20:02 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:20:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:20:02 --> URI Class Initialized
DEBUG - 2013-12-14 10:20:02 --> Router Class Initialized
ERROR - 2013-12-14 10:20:02 --> 404 Page Not Found --> 
DEBUG - 2013-12-14 10:21:09 --> Config Class Initialized
DEBUG - 2013-12-14 10:21:09 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:21:09 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:21:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:21:09 --> URI Class Initialized
DEBUG - 2013-12-14 10:21:09 --> Router Class Initialized
ERROR - 2013-12-14 10:21:09 --> 404 Page Not Found --> 
DEBUG - 2013-12-14 10:23:19 --> Config Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:23:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:23:19 --> URI Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Router Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Output Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Security Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Input Class Initialized
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:23:19 --> Language Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Language Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Config Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Loader Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Controller Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:23:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:23:19 --> Session Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:23:19 --> Session routines successfully run
DEBUG - 2013-12-14 10:23:19 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:23:19 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:23:19 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:23:19 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:23:19 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:23:19 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:23:19 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:23:19 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:23:39 --> Config Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:23:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:23:39 --> URI Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Router Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Output Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Security Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Input Class Initialized
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> XSS Filtering completed
DEBUG - 2013-12-14 10:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:23:39 --> Language Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Language Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Config Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Loader Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Controller Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:23:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:23:39 --> Session Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:23:39 --> Session routines successfully run
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:23:39 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:23:39 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:23:39 --> Model Class Initialized
DEBUG - 2013-12-14 10:23:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:23:39 --> Model Class Initialized
DEBUG - 2013-12-14 10:23:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:23:39 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:23:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:23:39 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:23:39 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-14 10:23:39 --> Final output sent to browser
DEBUG - 2013-12-14 10:23:39 --> Total execution time: 0.0799
DEBUG - 2013-12-14 10:24:05 --> Config Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:24:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:24:05 --> URI Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Router Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Output Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Security Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Input Class Initialized
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:24:05 --> Language Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Language Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Config Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Loader Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Controller Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:24:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:24:05 --> Session Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:24:05 --> Session routines successfully run
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:24:05 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:24:05 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:24:05 --> Model Class Initialized
DEBUG - 2013-12-14 10:24:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:24:05 --> Model Class Initialized
DEBUG - 2013-12-14 10:24:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:24:05 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:24:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:24:05 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:24:05 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-12-14 10:24:05 --> Model Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Config Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:24:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:24:06 --> URI Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Router Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Output Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Security Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Input Class Initialized
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:24:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:24:06 --> Language Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Language Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Config Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Loader Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Controller Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:24:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:24:06 --> Session Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:24:06 --> Session routines successfully run
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:24:06 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:24:06 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:24:06 --> Model Class Initialized
DEBUG - 2013-12-14 10:24:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:24:06 --> Model Class Initialized
DEBUG - 2013-12-14 10:24:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:24:06 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:24:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:24:06 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:26:16 --> Config Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:26:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:26:16 --> URI Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Router Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Output Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Security Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Input Class Initialized
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:26:16 --> Language Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Language Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Config Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Loader Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Controller Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:26:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:26:16 --> Session Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:26:16 --> Session routines successfully run
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:26:16 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:26:16 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:26:16 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:26:16 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:26:16 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:26:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:26:16 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:26:16 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:26:16 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:16 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-12-14 10:26:16 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:26:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:26:16 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 101
ERROR - 2013-12-14 10:26:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 101
ERROR - 2013-12-14 10:26:16 --> Severity: Notice  --> Undefined variable: orders_overview D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 141
ERROR - 2013-12-14 10:26:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 141
ERROR - 2013-12-14 10:26:16 --> Severity: Notice  --> Undefined variable: top_vendors D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 173
ERROR - 2013-12-14 10:26:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 173
ERROR - 2013-12-14 10:26:16 --> Severity: Notice  --> Undefined variable: recent_orders D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 207
ERROR - 2013-12-14 10:26:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 207
ERROR - 2013-12-14 10:26:16 --> Severity: Notice  --> Undefined variable: invoices D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 243
ERROR - 2013-12-14 10:26:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 243
DEBUG - 2013-12-14 10:26:16 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:26:16 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:26:16 --> Final output sent to browser
DEBUG - 2013-12-14 10:26:16 --> Total execution time: 0.0591
DEBUG - 2013-12-14 10:26:17 --> Config Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:26:17 --> URI Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Router Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Config Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Output Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:26:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:26:17 --> Security Class Initialized
DEBUG - 2013-12-14 10:26:17 --> URI Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Router Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Input Class Initialized
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> Output Class Initialized
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> Security Class Initialized
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> Input Class Initialized
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:26:17 --> Language Class Initialized
DEBUG - 2013-12-14 10:26:17 --> XSS Filtering completed
DEBUG - 2013-12-14 10:26:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:26:17 --> Language Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Language Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Config Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Language Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Loader Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Config Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Controller Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Ajax MX_Controller Initialized
DEBUG - 2013-12-14 10:26:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:26:17 --> Loader Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Controller Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Ajax MX_Controller Initialized
DEBUG - 2013-12-14 10:26:17 --> Session Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:26:17 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:26:17 --> Session routines successfully run
DEBUG - 2013-12-14 10:26:17 --> Session Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:26:17 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:26:17 --> Session routines successfully run
DEBUG - 2013-12-14 10:26:17 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:26:17 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:26:17 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:26:18 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:26:18 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:26:18 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:18 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:26:18 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:26:18 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:26:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:26:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:26:18 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:26:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:26:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:26:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:26:18 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:26:18 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:18 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:26:18 --> Model Class Initialized
DEBUG - 2013-12-14 10:26:18 --> Final output sent to browser
DEBUG - 2013-12-14 10:26:18 --> Total execution time: 0.2323
DEBUG - 2013-12-14 10:26:18 --> Final output sent to browser
DEBUG - 2013-12-14 10:26:18 --> Total execution time: 0.2363
DEBUG - 2013-12-14 10:31:13 --> Config Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:31:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:31:13 --> URI Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Router Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Output Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Security Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Input Class Initialized
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> XSS Filtering completed
DEBUG - 2013-12-14 10:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:31:13 --> Language Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Language Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Config Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Loader Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Controller Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:31:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:31:13 --> Session Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:31:13 --> Session routines successfully run
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:31:13 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:31:13 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:31:13 --> Model Class Initialized
DEBUG - 2013-12-14 10:31:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:31:13 --> Model Class Initialized
DEBUG - 2013-12-14 10:31:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:31:13 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:31:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:31:13 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:31:13 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:31:13 --> Model Class Initialized
DEBUG - 2013-12-14 10:31:13 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-12-14 10:31:13 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:31:13 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 101
ERROR - 2013-12-14 10:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 101
ERROR - 2013-12-14 10:31:13 --> Severity: Notice  --> Undefined variable: orders_overview D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 141
ERROR - 2013-12-14 10:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 141
ERROR - 2013-12-14 10:31:13 --> Severity: Notice  --> Undefined variable: top_vendors D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 173
ERROR - 2013-12-14 10:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 173
ERROR - 2013-12-14 10:31:13 --> Severity: Notice  --> Undefined variable: recent_orders D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 207
ERROR - 2013-12-14 10:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 207
ERROR - 2013-12-14 10:31:13 --> Severity: Notice  --> Undefined variable: invoices D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 243
ERROR - 2013-12-14 10:31:13 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 243
DEBUG - 2013-12-14 10:31:13 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:31:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:31:13 --> Final output sent to browser
DEBUG - 2013-12-14 10:31:13 --> Total execution time: 0.0712
DEBUG - 2013-12-14 10:39:26 --> Config Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:39:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:39:26 --> URI Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Router Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Output Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Security Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Input Class Initialized
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:39:26 --> Language Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Language Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Config Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Loader Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Controller Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:39:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:39:26 --> Session Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:39:26 --> Session routines successfully run
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:39:26 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:39:26 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:39:26 --> Model Class Initialized
DEBUG - 2013-12-14 10:39:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:39:26 --> Model Class Initialized
DEBUG - 2013-12-14 10:39:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:39:26 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:39:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:39:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:39:26 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:39:26 --> Model Class Initialized
DEBUG - 2013-12-14 10:39:26 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-12-14 10:39:26 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:39:26 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 101
ERROR - 2013-12-14 10:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 101
ERROR - 2013-12-14 10:39:26 --> Severity: Notice  --> Undefined variable: orders_overview D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 141
ERROR - 2013-12-14 10:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 141
ERROR - 2013-12-14 10:39:26 --> Severity: Notice  --> Undefined variable: top_vendors D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 173
ERROR - 2013-12-14 10:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 173
ERROR - 2013-12-14 10:39:26 --> Severity: Notice  --> Undefined variable: recent_orders D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 207
ERROR - 2013-12-14 10:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 207
ERROR - 2013-12-14 10:39:26 --> Severity: Notice  --> Undefined variable: invoices D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 243
ERROR - 2013-12-14 10:39:26 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 243
DEBUG - 2013-12-14 10:39:26 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:39:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:39:26 --> Final output sent to browser
DEBUG - 2013-12-14 10:39:26 --> Total execution time: 0.0656
DEBUG - 2013-12-14 10:39:41 --> Config Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:39:41 --> URI Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Router Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Output Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Security Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Input Class Initialized
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:39:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:39:41 --> Language Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Language Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Config Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Loader Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Controller Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:39:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:39:41 --> Session Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:39:41 --> Session routines successfully run
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:39:41 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:39:41 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:39:41 --> Model Class Initialized
DEBUG - 2013-12-14 10:39:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:39:41 --> Model Class Initialized
DEBUG - 2013-12-14 10:39:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:39:41 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:39:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:39:41 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:39:41 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:39:41 --> Model Class Initialized
DEBUG - 2013-12-14 10:39:41 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-12-14 10:39:41 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:39:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:39:41 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 101
ERROR - 2013-12-14 10:39:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 101
ERROR - 2013-12-14 10:39:41 --> Severity: Notice  --> Undefined variable: orders_overview D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 141
ERROR - 2013-12-14 10:39:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 141
ERROR - 2013-12-14 10:39:41 --> Severity: Notice  --> Undefined variable: top_vendors D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 173
ERROR - 2013-12-14 10:39:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 173
ERROR - 2013-12-14 10:39:41 --> Severity: Notice  --> Undefined variable: recent_orders D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 207
ERROR - 2013-12-14 10:39:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 207
ERROR - 2013-12-14 10:39:41 --> Severity: Notice  --> Undefined variable: invoices D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 243
ERROR - 2013-12-14 10:39:41 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 243
DEBUG - 2013-12-14 10:39:41 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:39:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:39:41 --> Final output sent to browser
DEBUG - 2013-12-14 10:39:41 --> Total execution time: 0.0661
DEBUG - 2013-12-14 10:41:37 --> Config Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:41:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:41:37 --> URI Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Router Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Output Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Security Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Input Class Initialized
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:41:37 --> Language Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Language Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Config Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Loader Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Controller Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:41:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:41:37 --> Session Class Initialized
DEBUG - 2013-12-14 10:41:37 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:41:37 --> Session routines successfully run
DEBUG - 2013-12-14 10:41:37 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:41:37 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:41:38 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:41:38 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:41:38 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:41:38 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:41:38 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:41:38 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:41:38 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:41:38 --> Model Class Initialized
DEBUG - 2013-12-14 10:41:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:41:38 --> Model Class Initialized
DEBUG - 2013-12-14 10:41:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:41:38 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:41:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:41:38 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:41:38 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:41:38 --> Model Class Initialized
ERROR - 2013-12-14 10:41:38 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 47
ERROR - 2013-12-14 10:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 47
ERROR - 2013-12-14 10:41:38 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 54
ERROR - 2013-12-14 10:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 54
ERROR - 2013-12-14 10:41:38 --> Severity: Notice  --> Undefined variable: orders_overview D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 94
ERROR - 2013-12-14 10:41:38 --> Severity: Notice  --> Undefined variable: top_vendors D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 126
ERROR - 2013-12-14 10:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 126
ERROR - 2013-12-14 10:41:38 --> Severity: Notice  --> Undefined variable: recent_orders D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 160
ERROR - 2013-12-14 10:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 160
ERROR - 2013-12-14 10:41:38 --> Severity: Notice  --> Undefined variable: invoices D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 196
ERROR - 2013-12-14 10:41:38 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 196
DEBUG - 2013-12-14 10:41:38 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:41:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:41:38 --> Final output sent to browser
DEBUG - 2013-12-14 10:41:38 --> Total execution time: 0.0650
DEBUG - 2013-12-14 10:41:53 --> Config Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:41:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:41:53 --> URI Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Router Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Output Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Security Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Input Class Initialized
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:41:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:41:53 --> Language Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Language Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Config Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Loader Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Controller Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:41:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:41:53 --> Session Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:41:53 --> Session routines successfully run
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:41:53 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:41:53 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:41:53 --> Model Class Initialized
DEBUG - 2013-12-14 10:41:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:41:53 --> Model Class Initialized
DEBUG - 2013-12-14 10:41:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:41:53 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:41:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:41:53 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:41:53 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:41:53 --> Model Class Initialized
ERROR - 2013-12-14 10:41:53 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 37
ERROR - 2013-12-14 10:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 37
ERROR - 2013-12-14 10:41:53 --> Severity: Notice  --> Undefined variable: quote_status_totals D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 44
ERROR - 2013-12-14 10:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 44
ERROR - 2013-12-14 10:41:53 --> Severity: Notice  --> Undefined variable: orders_overview D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 84
ERROR - 2013-12-14 10:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 84
ERROR - 2013-12-14 10:41:53 --> Severity: Notice  --> Undefined variable: top_vendors D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 116
ERROR - 2013-12-14 10:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 116
ERROR - 2013-12-14 10:41:53 --> Severity: Notice  --> Undefined variable: recent_orders D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 150
ERROR - 2013-12-14 10:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 150
ERROR - 2013-12-14 10:41:53 --> Severity: Notice  --> Undefined variable: invoices D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 186
ERROR - 2013-12-14 10:41:53 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 186
DEBUG - 2013-12-14 10:41:53 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:41:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:41:53 --> Final output sent to browser
DEBUG - 2013-12-14 10:41:53 --> Total execution time: 0.0769
DEBUG - 2013-12-14 10:42:16 --> Config Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:42:16 --> URI Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Router Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Output Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Security Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Input Class Initialized
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:42:16 --> Language Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Language Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Config Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Loader Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Controller Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:42:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:42:16 --> Session Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:42:16 --> Session routines successfully run
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:42:16 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:42:16 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:42:16 --> Model Class Initialized
DEBUG - 2013-12-14 10:42:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:42:16 --> Model Class Initialized
DEBUG - 2013-12-14 10:42:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:42:16 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:42:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:42:16 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:42:16 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:42:16 --> Model Class Initialized
ERROR - 2013-12-14 10:42:16 --> Severity: Notice  --> Undefined variable: top_vendors D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 47
ERROR - 2013-12-14 10:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 47
ERROR - 2013-12-14 10:42:16 --> Severity: Notice  --> Undefined variable: recent_orders D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 81
ERROR - 2013-12-14 10:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 81
ERROR - 2013-12-14 10:42:16 --> Severity: Notice  --> Undefined variable: invoices D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 117
ERROR - 2013-12-14 10:42:16 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\xampp\htdocs\renalemr\application\modules\dashboard\views\index.php 117
DEBUG - 2013-12-14 10:42:16 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:42:16 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:42:16 --> Final output sent to browser
DEBUG - 2013-12-14 10:42:16 --> Total execution time: 0.0979
DEBUG - 2013-12-14 10:42:35 --> Config Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:42:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:42:35 --> URI Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Router Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Output Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Security Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Input Class Initialized
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:42:35 --> Language Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Language Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Config Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Loader Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Controller Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:42:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:42:35 --> Session Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:42:35 --> Session routines successfully run
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:42:35 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:42:35 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:42:35 --> Model Class Initialized
DEBUG - 2013-12-14 10:42:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:42:35 --> Model Class Initialized
DEBUG - 2013-12-14 10:42:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:42:35 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:42:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:42:35 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:42:35 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:42:35 --> Model Class Initialized
DEBUG - 2013-12-14 10:42:35 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:42:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:42:35 --> Final output sent to browser
DEBUG - 2013-12-14 10:42:35 --> Total execution time: 0.0658
DEBUG - 2013-12-14 10:42:40 --> Config Class Initialized
DEBUG - 2013-12-14 10:42:40 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:42:40 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:42:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:42:40 --> URI Class Initialized
DEBUG - 2013-12-14 10:42:40 --> Router Class Initialized
ERROR - 2013-12-14 10:42:40 --> 404 Page Not Found --> 
DEBUG - 2013-12-14 10:43:35 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:43:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:43:35 --> URI Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Router Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Output Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Security Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Input Class Initialized
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:43:35 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Loader Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Controller Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:43:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:43:35 --> Session Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:43:35 --> Session routines successfully run
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:43:35 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:43:35 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:43:35 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:43:35 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:43:35 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:43:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:43:35 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:43:35 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:43:35 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:35 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:43:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:43:35 --> Final output sent to browser
DEBUG - 2013-12-14 10:43:35 --> Total execution time: 0.0609
DEBUG - 2013-12-14 10:43:42 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:43:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:43:42 --> URI Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Router Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Output Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Security Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Input Class Initialized
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:43:42 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Loader Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Controller Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:43:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:43:42 --> Session Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:43:42 --> Session routines successfully run
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:43:42 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:43:42 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:43:42 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:43:42 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:43:42 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:43:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:43:42 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:43:42 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:43:42 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:42 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:43:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:43:42 --> Final output sent to browser
DEBUG - 2013-12-14 10:43:42 --> Total execution time: 0.0603
DEBUG - 2013-12-14 10:43:44 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:43:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:43:44 --> URI Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Router Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Output Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Security Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Input Class Initialized
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:43:44 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Loader Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Controller Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:43:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:43:44 --> Session Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:43:44 --> Session routines successfully run
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:43:44 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:43:44 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:43:44 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:43:44 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:43:44 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:43:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:43:44 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:43:44 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:43:44 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:44 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:43:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:43:44 --> Final output sent to browser
DEBUG - 2013-12-14 10:43:44 --> Total execution time: 0.0610
DEBUG - 2013-12-14 10:43:45 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:43:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:43:45 --> URI Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Router Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Output Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Security Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Input Class Initialized
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:43:45 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Loader Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Controller Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:43:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:43:45 --> Session Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:43:45 --> Session routines successfully run
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:43:45 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:43:45 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:43:45 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:43:45 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:43:45 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:43:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:43:45 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:43:45 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:43:45 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:45 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:43:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:43:45 --> Final output sent to browser
DEBUG - 2013-12-14 10:43:45 --> Total execution time: 0.0613
DEBUG - 2013-12-14 10:43:53 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:43:53 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:43:53 --> URI Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Router Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Output Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Security Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Input Class Initialized
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> XSS Filtering completed
DEBUG - 2013-12-14 10:43:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:43:53 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Language Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Config Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Loader Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Controller Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:43:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:43:53 --> Session Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:43:53 --> Session routines successfully run
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:43:53 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:43:53 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:43:53 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:43:53 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:43:53 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:43:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:43:53 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:43:53 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:43:53 --> Model Class Initialized
DEBUG - 2013-12-14 10:43:53 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:43:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:43:53 --> Final output sent to browser
DEBUG - 2013-12-14 10:43:53 --> Total execution time: 0.0573
DEBUG - 2013-12-14 10:45:32 --> Config Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:45:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:45:32 --> URI Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Router Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Output Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Security Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Input Class Initialized
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> XSS Filtering completed
DEBUG - 2013-12-14 10:45:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:45:32 --> Language Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Language Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Config Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Loader Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Controller Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:45:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:45:32 --> Session Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:45:32 --> Session routines successfully run
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:45:32 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:45:32 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:45:32 --> Model Class Initialized
DEBUG - 2013-12-14 10:45:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:45:32 --> Model Class Initialized
DEBUG - 2013-12-14 10:45:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:45:32 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:45:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:45:32 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:45:32 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:45:32 --> Model Class Initialized
DEBUG - 2013-12-14 10:45:32 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:45:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:45:32 --> Final output sent to browser
DEBUG - 2013-12-14 10:45:32 --> Total execution time: 0.0667
DEBUG - 2013-12-14 10:46:37 --> Config Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:46:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:46:37 --> URI Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Router Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Output Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Security Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Input Class Initialized
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:46:37 --> Language Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Language Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Config Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Loader Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Controller Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:46:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:46:37 --> Session Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:46:37 --> Session routines successfully run
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:46:37 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:46:37 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:46:37 --> Model Class Initialized
DEBUG - 2013-12-14 10:46:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:46:37 --> Model Class Initialized
DEBUG - 2013-12-14 10:46:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:46:37 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:46:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:46:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:46:37 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:46:37 --> Model Class Initialized
DEBUG - 2013-12-14 10:46:37 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:46:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:46:37 --> Final output sent to browser
DEBUG - 2013-12-14 10:46:37 --> Total execution time: 0.0615
DEBUG - 2013-12-14 10:46:41 --> Config Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:46:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:46:41 --> URI Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Router Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Output Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Security Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Input Class Initialized
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:46:41 --> Language Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Language Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Config Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Loader Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Controller Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:46:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:46:41 --> Session Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:46:41 --> Session routines successfully run
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:46:41 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:46:41 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:46:41 --> Model Class Initialized
DEBUG - 2013-12-14 10:46:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:46:41 --> Model Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:46:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:46:41 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:46:41 --> Config Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:46:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:46:41 --> URI Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Router Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Output Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Security Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Input Class Initialized
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> XSS Filtering completed
DEBUG - 2013-12-14 10:46:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:46:41 --> Language Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Language Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Config Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Loader Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Controller Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:46:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:46:41 --> Session Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:46:41 --> A session cookie was not found.
DEBUG - 2013-12-14 10:46:41 --> Session routines successfully run
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:46:41 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:46:41 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:46:41 --> Model Class Initialized
DEBUG - 2013-12-14 10:46:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:46:41 --> Model Class Initialized
DEBUG - 2013-12-14 10:46:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:46:41 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:46:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:46:41 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:46:41 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-14 10:46:41 --> Final output sent to browser
DEBUG - 2013-12-14 10:46:41 --> Total execution time: 0.0613
DEBUG - 2013-12-14 10:50:54 --> Config Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:50:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:50:54 --> URI Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Router Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Output Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Security Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Input Class Initialized
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> XSS Filtering completed
DEBUG - 2013-12-14 10:50:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:50:54 --> Language Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Language Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Config Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Loader Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Controller Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:50:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:50:54 --> Session Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:50:54 --> Session routines successfully run
DEBUG - 2013-12-14 10:50:54 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:50:54 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:50:54 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:50:54 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:50:54 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:50:54 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:50:54 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:50:54 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:50:54 --> Model Class Initialized
DEBUG - 2013-12-14 10:50:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:50:54 --> Model Class Initialized
DEBUG - 2013-12-14 10:50:54 --> DB Transaction Failure
ERROR - 2013-12-14 10:50:54 --> Query error: Table 'renalemr.fi_settings' doesn't exist
DEBUG - 2013-12-14 10:50:54 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-14 10:52:02 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:52:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:52:02 --> URI Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Router Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Output Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Security Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Input Class Initialized
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:52:02 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Loader Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Controller Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:52:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:52:02 --> Session Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:52:02 --> Session routines successfully run
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:52:02 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:52:02 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:52:02 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:52:02 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:52:02 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:52:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:52:02 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:52:02 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-14 10:52:02 --> Final output sent to browser
DEBUG - 2013-12-14 10:52:02 --> Total execution time: 0.0570
DEBUG - 2013-12-14 10:52:06 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:52:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:52:06 --> URI Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Router Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Output Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Security Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Input Class Initialized
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:52:06 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Loader Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Controller Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:52:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:52:06 --> Session Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:52:06 --> Session routines successfully run
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:52:06 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:52:06 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:52:06 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:52:06 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:52:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:52:06 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:52:06 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-12-14 10:52:06 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:52:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:52:06 --> URI Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Router Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Output Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Security Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Input Class Initialized
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:52:06 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Loader Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Controller Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 10:52:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:52:06 --> Session Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:52:06 --> Session routines successfully run
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:52:06 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:52:06 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:52:06 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:52:06 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:52:06 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:52:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:52:06 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:52:06 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 10:52:06 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:06 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 10:52:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 10:52:06 --> Final output sent to browser
DEBUG - 2013-12-14 10:52:06 --> Total execution time: 0.0623
DEBUG - 2013-12-14 10:52:08 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:52:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:52:08 --> URI Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Router Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Output Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Security Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Input Class Initialized
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:52:08 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Loader Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Controller Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:52:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:52:08 --> Session Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:52:08 --> Session routines successfully run
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:52:08 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:52:08 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:52:08 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:52:08 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:52:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:52:08 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:52:08 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Hooks Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Utf8 Class Initialized
DEBUG - 2013-12-14 10:52:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 10:52:08 --> URI Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Router Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Output Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Security Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Input Class Initialized
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> XSS Filtering completed
DEBUG - 2013-12-14 10:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 10:52:08 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Language Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Config Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Loader Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Controller Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 10:52:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 10:52:08 --> Session Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: string_helper
DEBUG - 2013-12-14 10:52:08 --> A session cookie was not found.
DEBUG - 2013-12-14 10:52:08 --> Session routines successfully run
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: url_helper
DEBUG - 2013-12-14 10:52:08 --> Database Driver Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: form_helper
DEBUG - 2013-12-14 10:52:08 --> Form Validation Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: number_helper
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: date_helper
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 10:52:08 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 10:52:08 --> Model Class Initialized
DEBUG - 2013-12-14 10:52:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 10:52:08 --> Helper loaded: language_helper
DEBUG - 2013-12-14 10:52:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 10:52:08 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 10:52:08 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-14 10:52:08 --> Final output sent to browser
DEBUG - 2013-12-14 10:52:08 --> Total execution time: 0.0520
DEBUG - 2013-12-14 11:06:10 --> Config Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:06:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:06:10 --> URI Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Router Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Output Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Security Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Input Class Initialized
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:06:10 --> Language Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Language Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Config Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Loader Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Controller Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-14 11:06:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:06:10 --> Session Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:06:10 --> Session routines successfully run
DEBUG - 2013-12-14 11:06:10 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:06:10 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:06:10 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:06:10 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:06:11 --> Model Class Initialized
DEBUG - 2013-12-14 11:06:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:06:11 --> Model Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:06:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:06:11 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:06:11 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-12-14 11:06:11 --> Model Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Config Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:06:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:06:11 --> URI Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Router Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Output Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Security Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Input Class Initialized
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> XSS Filtering completed
DEBUG - 2013-12-14 11:06:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:06:11 --> Language Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Language Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Config Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Loader Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Controller Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:06:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:06:11 --> Session Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:06:11 --> Session routines successfully run
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:06:11 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:06:11 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:06:11 --> Model Class Initialized
DEBUG - 2013-12-14 11:06:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:06:11 --> Model Class Initialized
DEBUG - 2013-12-14 11:06:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:06:11 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:06:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:06:11 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:06:11 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:06:11 --> Model Class Initialized
DEBUG - 2013-12-14 11:06:11 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:06:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:06:11 --> Final output sent to browser
DEBUG - 2013-12-14 11:06:11 --> Total execution time: 0.0542
DEBUG - 2013-12-14 11:14:55 --> Config Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:14:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:14:55 --> URI Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Router Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Output Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Security Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Input Class Initialized
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> XSS Filtering completed
DEBUG - 2013-12-14 11:14:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:14:55 --> Language Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Language Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Config Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Loader Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Controller Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:14:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:14:55 --> Session Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:14:55 --> Session routines successfully run
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:14:55 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:14:55 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:14:55 --> Model Class Initialized
DEBUG - 2013-12-14 11:14:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:14:55 --> Model Class Initialized
DEBUG - 2013-12-14 11:14:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:14:55 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:14:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:14:55 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:14:55 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:14:55 --> Model Class Initialized
DEBUG - 2013-12-14 11:14:55 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:14:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:14:55 --> Final output sent to browser
DEBUG - 2013-12-14 11:14:55 --> Total execution time: 0.0652
DEBUG - 2013-12-14 11:17:42 --> Config Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:17:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:17:42 --> URI Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Router Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Output Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Security Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Input Class Initialized
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> XSS Filtering completed
DEBUG - 2013-12-14 11:17:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:17:42 --> Language Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Language Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Config Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Loader Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Controller Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:17:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:17:42 --> Session Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:17:42 --> Session routines successfully run
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:17:42 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:17:42 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:17:42 --> Model Class Initialized
DEBUG - 2013-12-14 11:17:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:17:42 --> Model Class Initialized
DEBUG - 2013-12-14 11:17:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:17:42 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:17:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:17:42 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:17:42 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:17:42 --> Model Class Initialized
DEBUG - 2013-12-14 11:17:42 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:17:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:17:42 --> Final output sent to browser
DEBUG - 2013-12-14 11:17:42 --> Total execution time: 0.0594
DEBUG - 2013-12-14 11:19:32 --> Config Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:19:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:19:32 --> URI Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Router Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Output Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Security Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Input Class Initialized
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> XSS Filtering completed
DEBUG - 2013-12-14 11:19:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:19:32 --> Language Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Language Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Config Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Loader Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Controller Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:19:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:19:32 --> Session Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:19:32 --> Session routines successfully run
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:19:32 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:19:32 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:19:32 --> Model Class Initialized
DEBUG - 2013-12-14 11:19:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:19:32 --> Model Class Initialized
DEBUG - 2013-12-14 11:19:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:19:32 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:19:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:19:32 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:19:32 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:19:32 --> Model Class Initialized
DEBUG - 2013-12-14 11:19:32 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:19:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:19:32 --> Final output sent to browser
DEBUG - 2013-12-14 11:19:32 --> Total execution time: 0.0622
DEBUG - 2013-12-14 11:20:52 --> Config Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:20:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:20:52 --> URI Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Router Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Output Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Security Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Input Class Initialized
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> XSS Filtering completed
DEBUG - 2013-12-14 11:20:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:20:52 --> Language Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Language Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Config Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Loader Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Controller Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:20:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:20:52 --> Session Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:20:52 --> Session routines successfully run
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:20:52 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:20:52 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:20:52 --> Model Class Initialized
DEBUG - 2013-12-14 11:20:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:20:52 --> Model Class Initialized
DEBUG - 2013-12-14 11:20:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:20:52 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:20:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:20:52 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:20:52 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:20:52 --> Model Class Initialized
DEBUG - 2013-12-14 11:20:52 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:20:52 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:20:52 --> Final output sent to browser
DEBUG - 2013-12-14 11:20:52 --> Total execution time: 0.0624
DEBUG - 2013-12-14 11:21:00 --> Config Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:21:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:21:00 --> URI Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Router Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Output Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Security Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Input Class Initialized
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:21:00 --> Language Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Language Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Config Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Loader Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Controller Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:21:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:21:00 --> Session Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:21:00 --> Session routines successfully run
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:21:00 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:21:00 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:21:00 --> Model Class Initialized
DEBUG - 2013-12-14 11:21:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:21:00 --> Model Class Initialized
DEBUG - 2013-12-14 11:21:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:21:00 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:21:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:21:00 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:21:00 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:21:00 --> Model Class Initialized
DEBUG - 2013-12-14 11:21:00 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:21:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:21:00 --> Final output sent to browser
DEBUG - 2013-12-14 11:21:00 --> Total execution time: 0.0500
DEBUG - 2013-12-14 11:21:22 --> Config Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:21:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:21:22 --> URI Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Router Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Output Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Security Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Input Class Initialized
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> XSS Filtering completed
DEBUG - 2013-12-14 11:21:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:21:22 --> Language Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Language Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Config Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Loader Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Controller Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:21:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:21:22 --> Session Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:21:22 --> Session routines successfully run
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:21:22 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:21:22 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:21:22 --> Model Class Initialized
DEBUG - 2013-12-14 11:21:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:21:22 --> Model Class Initialized
DEBUG - 2013-12-14 11:21:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:21:22 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:21:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:21:22 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:21:22 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:21:22 --> Model Class Initialized
DEBUG - 2013-12-14 11:21:22 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:21:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:21:22 --> Final output sent to browser
DEBUG - 2013-12-14 11:21:22 --> Total execution time: 0.0620
DEBUG - 2013-12-14 11:22:19 --> Config Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:22:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:22:19 --> URI Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Router Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Output Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Security Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Input Class Initialized
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> XSS Filtering completed
DEBUG - 2013-12-14 11:22:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:22:19 --> Language Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Language Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Config Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Loader Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Controller Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:22:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:22:19 --> Session Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:22:19 --> Session routines successfully run
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:22:19 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:22:19 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:22:19 --> Model Class Initialized
DEBUG - 2013-12-14 11:22:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:22:19 --> Model Class Initialized
DEBUG - 2013-12-14 11:22:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:22:19 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:22:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:22:19 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:22:19 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:22:19 --> Model Class Initialized
DEBUG - 2013-12-14 11:22:19 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:22:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:22:19 --> Final output sent to browser
DEBUG - 2013-12-14 11:22:19 --> Total execution time: 0.0509
DEBUG - 2013-12-14 11:25:05 --> Config Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:25:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:25:05 --> URI Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Router Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Output Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Security Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Input Class Initialized
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> XSS Filtering completed
DEBUG - 2013-12-14 11:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:25:05 --> Language Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Language Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Config Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Loader Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Controller Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:25:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:25:05 --> Session Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:25:05 --> Session routines successfully run
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:25:05 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:25:05 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:25:05 --> Model Class Initialized
DEBUG - 2013-12-14 11:25:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:25:05 --> Model Class Initialized
DEBUG - 2013-12-14 11:25:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:25:05 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:25:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:25:05 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:25:05 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:25:05 --> Model Class Initialized
DEBUG - 2013-12-14 11:25:05 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:25:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:25:05 --> Final output sent to browser
DEBUG - 2013-12-14 11:25:05 --> Total execution time: 0.0784
DEBUG - 2013-12-14 11:34:37 --> Config Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:34:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:34:37 --> URI Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Router Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Output Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Security Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Input Class Initialized
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> XSS Filtering completed
DEBUG - 2013-12-14 11:34:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:34:37 --> Language Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Language Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Config Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Loader Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Controller Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:34:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:34:37 --> Session Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:34:37 --> Session routines successfully run
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:34:37 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:34:37 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:34:37 --> Model Class Initialized
DEBUG - 2013-12-14 11:34:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:34:37 --> Model Class Initialized
DEBUG - 2013-12-14 11:34:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:34:37 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:34:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:34:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:34:37 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:34:37 --> Model Class Initialized
DEBUG - 2013-12-14 11:34:37 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:34:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:34:37 --> Final output sent to browser
DEBUG - 2013-12-14 11:34:37 --> Total execution time: 0.0553
DEBUG - 2013-12-14 11:35:50 --> Config Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:35:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:35:50 --> URI Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Router Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Output Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Security Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Input Class Initialized
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> XSS Filtering completed
DEBUG - 2013-12-14 11:35:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:35:50 --> Language Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Language Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Config Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Loader Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Controller Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:35:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:35:50 --> Session Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:35:50 --> Session routines successfully run
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:35:50 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:35:50 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:35:50 --> Model Class Initialized
DEBUG - 2013-12-14 11:35:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:35:50 --> Model Class Initialized
DEBUG - 2013-12-14 11:35:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:35:50 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:35:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:35:50 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:35:50 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:35:50 --> Model Class Initialized
DEBUG - 2013-12-14 11:35:50 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:35:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:35:50 --> Final output sent to browser
DEBUG - 2013-12-14 11:35:50 --> Total execution time: 0.0527
DEBUG - 2013-12-14 11:42:45 --> Config Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:42:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:42:45 --> URI Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Router Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Output Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Security Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Input Class Initialized
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:42:45 --> Language Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Language Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Config Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Loader Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Controller Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 11:42:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:42:45 --> Session Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:42:45 --> Session routines successfully run
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:42:45 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:42:45 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:42:45 --> Model Class Initialized
DEBUG - 2013-12-14 11:42:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:42:45 --> Model Class Initialized
DEBUG - 2013-12-14 11:42:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:42:45 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:42:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:42:45 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:42:45 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 11:42:45 --> Model Class Initialized
DEBUG - 2013-12-14 11:42:45 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 11:42:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 11:42:45 --> Final output sent to browser
DEBUG - 2013-12-14 11:42:45 --> Total execution time: 0.0616
DEBUG - 2013-12-14 11:42:46 --> Config Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Hooks Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Utf8 Class Initialized
DEBUG - 2013-12-14 11:42:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 11:42:46 --> URI Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Router Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Output Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Security Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Input Class Initialized
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> XSS Filtering completed
DEBUG - 2013-12-14 11:42:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 11:42:46 --> Language Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Language Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Config Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Loader Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Controller Class Initialized
DEBUG - 2013-12-14 11:42:46 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 11:42:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 11:42:46 --> Session Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: string_helper
DEBUG - 2013-12-14 11:42:46 --> Session routines successfully run
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: url_helper
DEBUG - 2013-12-14 11:42:46 --> Database Driver Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: form_helper
DEBUG - 2013-12-14 11:42:46 --> Form Validation Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: number_helper
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: date_helper
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 11:42:46 --> Model Class Initialized
DEBUG - 2013-12-14 11:42:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 11:42:46 --> Model Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 11:42:46 --> Helper loaded: language_helper
DEBUG - 2013-12-14 11:42:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 11:42:46 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 11:42:46 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 11:42:46 --> Model Class Initialized
DEBUG - 2013-12-14 11:42:46 --> Final output sent to browser
DEBUG - 2013-12-14 11:42:46 --> Total execution time: 0.0496
DEBUG - 2013-12-14 12:36:51 --> Config Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Hooks Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Utf8 Class Initialized
DEBUG - 2013-12-14 12:36:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 12:36:51 --> URI Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Router Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Output Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Security Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Input Class Initialized
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 12:36:51 --> Language Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Language Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Config Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Loader Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Controller Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 12:36:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 12:36:51 --> Session Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: string_helper
DEBUG - 2013-12-14 12:36:51 --> Session routines successfully run
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: url_helper
DEBUG - 2013-12-14 12:36:51 --> Database Driver Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: form_helper
DEBUG - 2013-12-14 12:36:51 --> Form Validation Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: number_helper
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: date_helper
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 12:36:51 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 12:36:51 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 12:36:51 --> Helper loaded: language_helper
DEBUG - 2013-12-14 12:36:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 12:36:51 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 12:36:51 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 12:36:51 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:51 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 12:36:51 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 12:36:51 --> Final output sent to browser
DEBUG - 2013-12-14 12:36:51 --> Total execution time: 0.0592
DEBUG - 2013-12-14 12:36:52 --> Config Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Hooks Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Utf8 Class Initialized
DEBUG - 2013-12-14 12:36:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 12:36:52 --> URI Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Router Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Output Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Security Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Input Class Initialized
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 12:36:52 --> Language Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Language Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Config Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Loader Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Controller Class Initialized
DEBUG - 2013-12-14 12:36:52 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 12:36:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 12:36:52 --> Session Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: string_helper
DEBUG - 2013-12-14 12:36:52 --> Session routines successfully run
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: url_helper
DEBUG - 2013-12-14 12:36:52 --> Database Driver Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: form_helper
DEBUG - 2013-12-14 12:36:52 --> Form Validation Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: number_helper
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: date_helper
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 12:36:52 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 12:36:52 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 12:36:52 --> Helper loaded: language_helper
DEBUG - 2013-12-14 12:36:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 12:36:52 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 12:36:52 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 12:36:52 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:52 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 12:36:52 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 12:36:52 --> Final output sent to browser
DEBUG - 2013-12-14 12:36:52 --> Total execution time: 0.0631
DEBUG - 2013-12-14 12:36:58 --> Config Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Hooks Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Utf8 Class Initialized
DEBUG - 2013-12-14 12:36:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 12:36:58 --> URI Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Router Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Output Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Security Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Input Class Initialized
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 12:36:58 --> Language Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Language Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Config Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Loader Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Controller Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-14 12:36:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 12:36:58 --> Session Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: string_helper
DEBUG - 2013-12-14 12:36:58 --> Session routines successfully run
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: url_helper
DEBUG - 2013-12-14 12:36:58 --> Database Driver Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: form_helper
DEBUG - 2013-12-14 12:36:58 --> Form Validation Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: number_helper
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: date_helper
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 12:36:58 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 12:36:58 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 12:36:58 --> Helper loaded: language_helper
DEBUG - 2013-12-14 12:36:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 12:36:58 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 12:36:58 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-14 12:36:58 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:58 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-14 12:36:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 12:36:58 --> Final output sent to browser
DEBUG - 2013-12-14 12:36:58 --> Total execution time: 0.0572
DEBUG - 2013-12-14 12:36:59 --> Config Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Hooks Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Utf8 Class Initialized
DEBUG - 2013-12-14 12:36:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 12:36:59 --> URI Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Router Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Output Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Security Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Input Class Initialized
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> XSS Filtering completed
DEBUG - 2013-12-14 12:36:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 12:36:59 --> Language Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Language Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Config Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Loader Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Controller Class Initialized
DEBUG - 2013-12-14 12:36:59 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 12:36:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 12:36:59 --> Session Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: string_helper
DEBUG - 2013-12-14 12:36:59 --> Session routines successfully run
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: url_helper
DEBUG - 2013-12-14 12:36:59 --> Database Driver Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: form_helper
DEBUG - 2013-12-14 12:36:59 --> Form Validation Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: number_helper
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: date_helper
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 12:36:59 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 12:36:59 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 12:36:59 --> Helper loaded: language_helper
DEBUG - 2013-12-14 12:36:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 12:36:59 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 12:36:59 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 12:36:59 --> Model Class Initialized
DEBUG - 2013-12-14 12:36:59 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 12:36:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 12:36:59 --> Final output sent to browser
DEBUG - 2013-12-14 12:36:59 --> Total execution time: 0.0566
DEBUG - 2013-12-14 12:37:39 --> Config Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Hooks Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Utf8 Class Initialized
DEBUG - 2013-12-14 12:37:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 12:37:39 --> URI Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Router Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Output Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Security Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Input Class Initialized
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> XSS Filtering completed
DEBUG - 2013-12-14 12:37:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 12:37:39 --> Language Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Language Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Config Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Loader Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Controller Class Initialized
DEBUG - 2013-12-14 12:37:39 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 12:37:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 12:37:39 --> Session Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: string_helper
DEBUG - 2013-12-14 12:37:39 --> Session routines successfully run
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: url_helper
DEBUG - 2013-12-14 12:37:39 --> Database Driver Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: form_helper
DEBUG - 2013-12-14 12:37:39 --> Form Validation Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: number_helper
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: date_helper
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 12:37:39 --> Model Class Initialized
DEBUG - 2013-12-14 12:37:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 12:37:39 --> Model Class Initialized
DEBUG - 2013-12-14 12:37:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 12:37:39 --> Helper loaded: language_helper
DEBUG - 2013-12-14 12:37:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 12:37:39 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 12:37:39 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 12:37:39 --> Model Class Initialized
DEBUG - 2013-12-14 12:37:39 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 12:37:39 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 12:37:39 --> Final output sent to browser
DEBUG - 2013-12-14 12:37:39 --> Total execution time: 0.0783
DEBUG - 2013-12-14 12:39:19 --> Config Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Hooks Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Utf8 Class Initialized
DEBUG - 2013-12-14 12:39:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 12:39:19 --> URI Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Router Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Output Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Security Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Input Class Initialized
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> XSS Filtering completed
DEBUG - 2013-12-14 12:39:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 12:39:19 --> Language Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Language Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Config Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Loader Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Controller Class Initialized
DEBUG - 2013-12-14 12:39:19 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 12:39:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 12:39:19 --> Session Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: string_helper
DEBUG - 2013-12-14 12:39:19 --> Session routines successfully run
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: url_helper
DEBUG - 2013-12-14 12:39:19 --> Database Driver Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: form_helper
DEBUG - 2013-12-14 12:39:19 --> Form Validation Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: number_helper
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: date_helper
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 12:39:19 --> Model Class Initialized
DEBUG - 2013-12-14 12:39:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 12:39:19 --> Model Class Initialized
DEBUG - 2013-12-14 12:39:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 12:39:19 --> Helper loaded: language_helper
DEBUG - 2013-12-14 12:39:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 12:39:19 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 12:39:19 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 12:39:19 --> Model Class Initialized
DEBUG - 2013-12-14 12:39:19 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 12:39:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 12:39:19 --> Final output sent to browser
DEBUG - 2013-12-14 12:39:19 --> Total execution time: 0.0597
DEBUG - 2013-12-14 13:32:50 --> Config Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:32:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:32:50 --> URI Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Router Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Output Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Security Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Input Class Initialized
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> XSS Filtering completed
DEBUG - 2013-12-14 13:32:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:32:50 --> Language Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Language Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Config Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Loader Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Controller Class Initialized
DEBUG - 2013-12-14 13:32:50 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:32:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:32:50 --> Session Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:32:50 --> Session routines successfully run
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:32:50 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:32:50 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:32:50 --> Model Class Initialized
DEBUG - 2013-12-14 13:32:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:32:50 --> Model Class Initialized
DEBUG - 2013-12-14 13:32:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:32:50 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:32:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:32:50 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:32:50 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:32:50 --> Model Class Initialized
DEBUG - 2013-12-14 13:32:50 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 13:32:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 13:32:50 --> Final output sent to browser
DEBUG - 2013-12-14 13:32:50 --> Total execution time: 0.0571
DEBUG - 2013-12-14 13:33:47 --> Config Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:33:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:33:47 --> URI Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Router Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Output Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Security Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Input Class Initialized
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:33:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:33:47 --> Language Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Language Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Config Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Loader Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Controller Class Initialized
DEBUG - 2013-12-14 13:33:47 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:33:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:33:47 --> Session Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:33:47 --> Session routines successfully run
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:33:47 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:33:47 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:33:47 --> Model Class Initialized
DEBUG - 2013-12-14 13:33:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:33:47 --> Model Class Initialized
DEBUG - 2013-12-14 13:33:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:33:47 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:33:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:33:47 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:33:47 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:33:47 --> Model Class Initialized
DEBUG - 2013-12-14 13:33:47 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 13:33:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 13:33:47 --> Final output sent to browser
DEBUG - 2013-12-14 13:33:47 --> Total execution time: 0.0736
DEBUG - 2013-12-14 13:34:02 --> Config Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:34:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:34:02 --> URI Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Router Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Output Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Security Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Input Class Initialized
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:34:02 --> Language Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Language Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Config Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Loader Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Controller Class Initialized
DEBUG - 2013-12-14 13:34:02 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:34:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:34:02 --> Session Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:34:02 --> Session routines successfully run
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:34:02 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:34:02 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:34:02 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:34:02 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:34:02 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:34:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:34:02 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:34:02 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:34:02 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:02 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 13:34:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 13:34:02 --> Final output sent to browser
DEBUG - 2013-12-14 13:34:02 --> Total execution time: 0.0580
DEBUG - 2013-12-14 13:34:10 --> Config Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:34:10 --> URI Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Router Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Output Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Security Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Input Class Initialized
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:34:10 --> Language Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Language Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Config Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Loader Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Controller Class Initialized
DEBUG - 2013-12-14 13:34:10 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:34:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:34:10 --> Session Class Initialized
DEBUG - 2013-12-14 13:34:10 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:34:10 --> Session routines successfully run
DEBUG - 2013-12-14 13:34:10 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:34:11 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:34:11 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:34:11 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:34:11 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:34:11 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:34:11 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:34:11 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:34:11 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:34:11 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:34:11 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:34:11 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:34:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:34:11 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:34:11 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:34:11 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:11 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 13:34:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 13:34:11 --> Final output sent to browser
DEBUG - 2013-12-14 13:34:11 --> Total execution time: 0.0568
DEBUG - 2013-12-14 13:34:30 --> Config Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:34:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:34:30 --> URI Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Router Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Output Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Security Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Input Class Initialized
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:34:30 --> Language Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Language Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Config Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Loader Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Controller Class Initialized
DEBUG - 2013-12-14 13:34:30 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:34:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:34:30 --> Session Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:34:30 --> Session routines successfully run
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:34:30 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:34:30 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:34:30 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:34:30 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:34:30 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:34:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:34:30 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:34:30 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:34:30 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:30 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-14 13:34:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 13:34:30 --> Final output sent to browser
DEBUG - 2013-12-14 13:34:30 --> Total execution time: 0.0537
DEBUG - 2013-12-14 13:34:32 --> Config Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:34:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:34:32 --> URI Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Router Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Output Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Security Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Input Class Initialized
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> XSS Filtering completed
DEBUG - 2013-12-14 13:34:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:34:32 --> Language Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Language Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Config Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Loader Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Controller Class Initialized
DEBUG - 2013-12-14 13:34:32 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:34:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:34:32 --> Session Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:34:32 --> Session routines successfully run
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:34:32 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:34:32 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:34:32 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:34:32 --> Model Class Initialized
DEBUG - 2013-12-14 13:34:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:34:32 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:34:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:34:32 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:34:32 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:34:32 --> Model Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Config Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:35:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:35:52 --> URI Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Router Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Output Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Security Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Input Class Initialized
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> XSS Filtering completed
DEBUG - 2013-12-14 13:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:35:52 --> Language Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Language Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Config Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Loader Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Controller Class Initialized
DEBUG - 2013-12-14 13:35:52 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:35:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:35:52 --> Session Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:35:52 --> Session routines successfully run
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:35:52 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:35:52 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:35:52 --> Model Class Initialized
DEBUG - 2013-12-14 13:35:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:35:52 --> Model Class Initialized
DEBUG - 2013-12-14 13:35:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:35:52 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:35:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:35:52 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:35:52 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:35:52 --> Model Class Initialized
ERROR - 2013-12-14 13:35:52 --> Severity: Warning  --> Missing argument 1 for Mdl_admin::get_company_detail(), called in D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php on line 28 and defined D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 23
DEBUG - 2013-12-14 13:35:52 --> DB Transaction Failure
ERROR - 2013-12-14 13:35:52 --> Query error: Unknown column 'company' in 'field list'
DEBUG - 2013-12-14 13:35:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-14 13:36:14 --> Config Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:36:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:36:14 --> URI Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Router Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Output Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Security Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Input Class Initialized
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:36:14 --> Language Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Language Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Config Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Loader Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Controller Class Initialized
DEBUG - 2013-12-14 13:36:14 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:36:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:36:14 --> Session Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:36:14 --> Session routines successfully run
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:36:14 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:36:14 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:36:14 --> Model Class Initialized
DEBUG - 2013-12-14 13:36:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:36:14 --> Model Class Initialized
DEBUG - 2013-12-14 13:36:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:36:14 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:36:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:36:14 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:36:14 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:36:14 --> Model Class Initialized
ERROR - 2013-12-14 13:36:14 --> Severity: Warning  --> Missing argument 1 for Mdl_admin::get_company_detail(), called in D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php on line 28 and defined D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 23
DEBUG - 2013-12-14 13:36:14 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 13:36:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 13:36:14 --> Final output sent to browser
DEBUG - 2013-12-14 13:36:14 --> Total execution time: 0.0618
DEBUG - 2013-12-14 13:36:47 --> Config Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Hooks Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Utf8 Class Initialized
DEBUG - 2013-12-14 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 13:36:47 --> URI Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Router Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Output Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Security Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Input Class Initialized
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> XSS Filtering completed
DEBUG - 2013-12-14 13:36:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 13:36:47 --> Language Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Language Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Config Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Loader Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Controller Class Initialized
DEBUG - 2013-12-14 13:36:47 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 13:36:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 13:36:47 --> Session Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: string_helper
DEBUG - 2013-12-14 13:36:47 --> Session routines successfully run
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: url_helper
DEBUG - 2013-12-14 13:36:47 --> Database Driver Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: form_helper
DEBUG - 2013-12-14 13:36:47 --> Form Validation Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: number_helper
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: date_helper
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 13:36:47 --> Model Class Initialized
DEBUG - 2013-12-14 13:36:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 13:36:47 --> Model Class Initialized
DEBUG - 2013-12-14 13:36:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 13:36:47 --> Helper loaded: language_helper
DEBUG - 2013-12-14 13:36:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 13:36:47 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 13:36:47 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 13:36:47 --> Model Class Initialized
DEBUG - 2013-12-14 13:36:47 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 13:36:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 13:36:47 --> Final output sent to browser
DEBUG - 2013-12-14 13:36:47 --> Total execution time: 0.0681
DEBUG - 2013-12-14 14:04:10 --> Config Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:04:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:04:10 --> URI Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Router Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Output Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Security Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Input Class Initialized
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:04:10 --> Language Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Language Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Config Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Loader Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Controller Class Initialized
DEBUG - 2013-12-14 14:04:10 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:04:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:04:10 --> Session Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:04:10 --> Session routines successfully run
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:04:10 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:04:10 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:04:10 --> Model Class Initialized
DEBUG - 2013-12-14 14:04:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:04:10 --> Model Class Initialized
DEBUG - 2013-12-14 14:04:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:04:10 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:04:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:04:10 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:04:10 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:04:10 --> Model Class Initialized
DEBUG - 2013-12-14 14:04:10 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:04:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:04:10 --> Final output sent to browser
DEBUG - 2013-12-14 14:04:10 --> Total execution time: 0.0606
DEBUG - 2013-12-14 14:04:33 --> Config Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:04:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:04:33 --> URI Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Router Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Output Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Security Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Input Class Initialized
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> XSS Filtering completed
DEBUG - 2013-12-14 14:04:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:04:33 --> Language Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Language Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Config Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Loader Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Controller Class Initialized
DEBUG - 2013-12-14 14:04:33 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:04:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:04:33 --> Session Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:04:33 --> Session routines successfully run
DEBUG - 2013-12-14 14:04:33 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:04:33 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:04:33 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:04:33 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:04:33 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:04:33 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:04:33 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:04:33 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:04:33 --> Model Class Initialized
DEBUG - 2013-12-14 14:04:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:04:34 --> Model Class Initialized
DEBUG - 2013-12-14 14:04:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:04:34 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:04:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:04:34 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:04:34 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:04:34 --> Model Class Initialized
DEBUG - 2013-12-14 14:04:34 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:04:34 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:04:34 --> Final output sent to browser
DEBUG - 2013-12-14 14:04:34 --> Total execution time: 0.0584
DEBUG - 2013-12-14 14:07:43 --> Config Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:07:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:07:43 --> URI Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Router Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Output Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Security Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Input Class Initialized
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> XSS Filtering completed
DEBUG - 2013-12-14 14:07:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:07:43 --> Language Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Language Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Config Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Loader Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Controller Class Initialized
DEBUG - 2013-12-14 14:07:43 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:07:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:07:43 --> Session Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:07:43 --> Session routines successfully run
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:07:43 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:07:43 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:07:43 --> Model Class Initialized
DEBUG - 2013-12-14 14:07:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:07:43 --> Model Class Initialized
DEBUG - 2013-12-14 14:07:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:07:43 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:07:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:07:43 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:07:43 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:07:43 --> Model Class Initialized
DEBUG - 2013-12-14 14:07:43 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:07:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:07:43 --> Final output sent to browser
DEBUG - 2013-12-14 14:07:43 --> Total execution time: 0.0571
DEBUG - 2013-12-14 14:09:03 --> Config Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:09:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:09:03 --> URI Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Router Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Output Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Security Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Input Class Initialized
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:09:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:09:03 --> Language Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Language Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Config Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Loader Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Controller Class Initialized
DEBUG - 2013-12-14 14:09:03 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:09:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:09:03 --> Session Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:09:03 --> Session routines successfully run
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:09:03 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:09:03 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:09:03 --> Model Class Initialized
DEBUG - 2013-12-14 14:09:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:09:03 --> Model Class Initialized
DEBUG - 2013-12-14 14:09:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:09:03 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:09:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:09:03 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:09:03 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:09:03 --> Model Class Initialized
DEBUG - 2013-12-14 14:09:03 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:09:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:09:03 --> Final output sent to browser
DEBUG - 2013-12-14 14:09:03 --> Total execution time: 0.0598
DEBUG - 2013-12-14 14:10:55 --> Config Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:10:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:10:55 --> URI Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Router Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Output Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Security Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Input Class Initialized
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> XSS Filtering completed
DEBUG - 2013-12-14 14:10:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:10:55 --> Language Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Language Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Config Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Loader Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Controller Class Initialized
DEBUG - 2013-12-14 14:10:55 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:10:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:10:55 --> Session Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:10:55 --> Session routines successfully run
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:10:55 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:10:55 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:10:55 --> Model Class Initialized
DEBUG - 2013-12-14 14:10:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:10:55 --> Model Class Initialized
DEBUG - 2013-12-14 14:10:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:10:55 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:10:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:10:55 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:10:55 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:10:55 --> Model Class Initialized
DEBUG - 2013-12-14 14:10:55 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:10:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:10:55 --> Final output sent to browser
DEBUG - 2013-12-14 14:10:55 --> Total execution time: 0.0545
DEBUG - 2013-12-14 14:11:17 --> Config Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:11:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:11:17 --> URI Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Router Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Output Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Security Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Input Class Initialized
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> XSS Filtering completed
DEBUG - 2013-12-14 14:11:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:11:17 --> Language Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Language Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Config Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Loader Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Controller Class Initialized
DEBUG - 2013-12-14 14:11:17 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:11:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:11:17 --> Session Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:11:17 --> Session routines successfully run
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:11:17 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:11:17 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:11:17 --> Model Class Initialized
DEBUG - 2013-12-14 14:11:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:11:17 --> Model Class Initialized
DEBUG - 2013-12-14 14:11:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:11:17 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:11:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:11:17 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:11:17 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:11:17 --> Model Class Initialized
DEBUG - 2013-12-14 14:11:17 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:11:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:11:17 --> Final output sent to browser
DEBUG - 2013-12-14 14:11:17 --> Total execution time: 0.0591
DEBUG - 2013-12-14 14:12:28 --> Config Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:12:28 --> URI Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Router Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Output Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Security Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Input Class Initialized
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:12:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:12:28 --> Language Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Language Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Config Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Loader Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Controller Class Initialized
DEBUG - 2013-12-14 14:12:28 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:12:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:12:28 --> Session Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:12:28 --> Session routines successfully run
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:12:28 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:12:28 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:12:28 --> Model Class Initialized
DEBUG - 2013-12-14 14:12:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:12:28 --> Model Class Initialized
DEBUG - 2013-12-14 14:12:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:12:28 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:12:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:12:28 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:12:28 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:12:28 --> Model Class Initialized
DEBUG - 2013-12-14 14:12:28 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:12:28 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:12:28 --> Final output sent to browser
DEBUG - 2013-12-14 14:12:28 --> Total execution time: 0.0573
DEBUG - 2013-12-14 14:14:30 --> Config Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:14:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:14:30 --> URI Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Router Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Output Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Security Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Input Class Initialized
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:14:30 --> Language Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Language Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Config Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Loader Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Controller Class Initialized
DEBUG - 2013-12-14 14:14:30 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:14:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:14:30 --> Session Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:14:30 --> Session routines successfully run
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:14:30 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:14:30 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:14:30 --> Model Class Initialized
DEBUG - 2013-12-14 14:14:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:14:30 --> Model Class Initialized
DEBUG - 2013-12-14 14:14:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:14:30 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:14:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:14:30 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:14:30 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:14:30 --> Model Class Initialized
DEBUG - 2013-12-14 14:14:30 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:14:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:14:30 --> Final output sent to browser
DEBUG - 2013-12-14 14:14:30 --> Total execution time: 0.0505
DEBUG - 2013-12-14 14:14:35 --> Config Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:14:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:14:35 --> URI Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Router Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Output Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Security Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Input Class Initialized
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:14:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:14:35 --> Language Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Language Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Config Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Loader Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Controller Class Initialized
DEBUG - 2013-12-14 14:14:35 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:14:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:14:35 --> Session Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:14:35 --> Session routines successfully run
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:14:35 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:14:35 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:14:35 --> Model Class Initialized
DEBUG - 2013-12-14 14:14:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:14:35 --> Model Class Initialized
DEBUG - 2013-12-14 14:14:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:14:35 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:14:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:14:35 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:14:35 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:14:35 --> Model Class Initialized
DEBUG - 2013-12-14 14:14:35 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:14:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:14:35 --> Final output sent to browser
DEBUG - 2013-12-14 14:14:35 --> Total execution time: 0.0665
DEBUG - 2013-12-14 14:15:10 --> Config Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:15:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:15:10 --> URI Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Router Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Output Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Security Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Input Class Initialized
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:15:10 --> Language Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Language Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Config Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Loader Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Controller Class Initialized
DEBUG - 2013-12-14 14:15:10 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:15:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:15:10 --> Session Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:15:10 --> Session routines successfully run
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:15:10 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:15:10 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:15:10 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:15:10 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:15:10 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:15:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:15:10 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:15:10 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:15:10 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:10 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:15:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:15:10 --> Final output sent to browser
DEBUG - 2013-12-14 14:15:10 --> Total execution time: 0.0546
DEBUG - 2013-12-14 14:15:12 --> Config Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:15:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:15:12 --> URI Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Router Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Output Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Security Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Input Class Initialized
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:15:12 --> Language Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Language Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Config Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Loader Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Controller Class Initialized
DEBUG - 2013-12-14 14:15:12 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:15:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:15:12 --> Session Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:15:12 --> Session routines successfully run
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:15:12 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:15:12 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:15:12 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:15:12 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:15:12 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:15:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:15:12 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:15:12 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:15:12 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:12 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:15:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:15:12 --> Final output sent to browser
DEBUG - 2013-12-14 14:15:12 --> Total execution time: 0.0489
DEBUG - 2013-12-14 14:15:35 --> Config Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:15:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:15:35 --> URI Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Router Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Output Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Security Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Input Class Initialized
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:15:35 --> Language Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Language Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Config Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Loader Class Initialized
DEBUG - 2013-12-14 14:15:35 --> Controller Class Initialized
DEBUG - 2013-12-14 14:15:35 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:15:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:15:35 --> Session Class Initialized
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:15:36 --> Session routines successfully run
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:15:36 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:15:36 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:15:36 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:15:36 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:15:36 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:15:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:15:36 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:15:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:15:36 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:36 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:15:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:15:36 --> Final output sent to browser
DEBUG - 2013-12-14 14:15:36 --> Total execution time: 0.0657
DEBUG - 2013-12-14 14:15:37 --> Config Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:15:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:15:37 --> URI Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Router Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Output Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Security Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Input Class Initialized
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> XSS Filtering completed
DEBUG - 2013-12-14 14:15:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:15:37 --> Language Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Language Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Config Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Loader Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Controller Class Initialized
DEBUG - 2013-12-14 14:15:37 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:15:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:15:37 --> Session Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:15:37 --> Session routines successfully run
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:15:37 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:15:37 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:15:37 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:15:37 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:15:37 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:15:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:15:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:15:37 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:15:37 --> Model Class Initialized
DEBUG - 2013-12-14 14:15:37 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:15:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:15:37 --> Final output sent to browser
DEBUG - 2013-12-14 14:15:37 --> Total execution time: 0.0618
DEBUG - 2013-12-14 14:18:11 --> Config Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:18:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:18:11 --> URI Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Router Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Output Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Security Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Input Class Initialized
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:18:11 --> Language Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Language Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Config Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Loader Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Controller Class Initialized
DEBUG - 2013-12-14 14:18:11 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:18:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:18:11 --> Session Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:18:11 --> Session routines successfully run
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:18:11 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:18:11 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:18:11 --> Model Class Initialized
DEBUG - 2013-12-14 14:18:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:18:11 --> Model Class Initialized
DEBUG - 2013-12-14 14:18:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:18:11 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:18:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:18:11 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:18:11 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:18:11 --> Model Class Initialized
DEBUG - 2013-12-14 14:18:11 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:18:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:18:11 --> Final output sent to browser
DEBUG - 2013-12-14 14:18:11 --> Total execution time: 0.0624
DEBUG - 2013-12-14 14:18:28 --> Config Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:18:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:18:28 --> URI Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Router Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Output Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Security Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Input Class Initialized
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:18:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:18:28 --> Language Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Language Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Config Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Loader Class Initialized
DEBUG - 2013-12-14 14:18:28 --> Controller Class Initialized
DEBUG - 2013-12-14 14:18:28 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:18:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:18:29 --> Session Class Initialized
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:18:29 --> Session routines successfully run
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:18:29 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:18:29 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:18:29 --> Model Class Initialized
DEBUG - 2013-12-14 14:18:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:18:29 --> Model Class Initialized
DEBUG - 2013-12-14 14:18:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:18:29 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:18:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:18:29 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:18:29 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:18:29 --> Model Class Initialized
DEBUG - 2013-12-14 14:18:29 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:18:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:18:29 --> Final output sent to browser
DEBUG - 2013-12-14 14:18:29 --> Total execution time: 0.0640
DEBUG - 2013-12-14 14:19:36 --> Config Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:19:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:19:36 --> URI Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Router Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Output Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Security Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Input Class Initialized
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> XSS Filtering completed
DEBUG - 2013-12-14 14:19:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:19:36 --> Language Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Language Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Config Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Loader Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Controller Class Initialized
DEBUG - 2013-12-14 14:19:36 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:19:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:19:36 --> Session Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:19:36 --> Session routines successfully run
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:19:36 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:19:36 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:19:36 --> Model Class Initialized
DEBUG - 2013-12-14 14:19:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:19:36 --> Model Class Initialized
DEBUG - 2013-12-14 14:19:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:19:36 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:19:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:19:36 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:19:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:19:36 --> Model Class Initialized
DEBUG - 2013-12-14 14:19:36 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:19:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:19:36 --> Final output sent to browser
DEBUG - 2013-12-14 14:19:36 --> Total execution time: 0.0629
DEBUG - 2013-12-14 14:20:09 --> Config Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:20:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:20:09 --> URI Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Router Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Output Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Security Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Input Class Initialized
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:20:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:20:09 --> Language Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Language Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Config Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Loader Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Controller Class Initialized
DEBUG - 2013-12-14 14:20:09 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:20:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:20:09 --> Session Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:20:09 --> Session routines successfully run
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:20:09 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:20:09 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:20:09 --> Model Class Initialized
DEBUG - 2013-12-14 14:20:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:20:09 --> Model Class Initialized
DEBUG - 2013-12-14 14:20:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:20:09 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:20:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:20:10 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:20:10 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:20:10 --> Model Class Initialized
DEBUG - 2013-12-14 14:20:10 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:20:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:20:10 --> Final output sent to browser
DEBUG - 2013-12-14 14:20:10 --> Total execution time: 0.0754
DEBUG - 2013-12-14 14:21:26 --> Config Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:21:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:21:26 --> URI Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Router Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Output Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Security Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Input Class Initialized
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:21:26 --> Language Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Language Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Config Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Loader Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Controller Class Initialized
DEBUG - 2013-12-14 14:21:26 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:21:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:21:26 --> Session Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:21:26 --> Session routines successfully run
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:21:26 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:21:26 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:21:26 --> Model Class Initialized
DEBUG - 2013-12-14 14:21:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:21:26 --> Model Class Initialized
DEBUG - 2013-12-14 14:21:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:21:26 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:21:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:21:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:21:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:21:26 --> Model Class Initialized
DEBUG - 2013-12-14 14:21:26 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:21:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:21:26 --> Final output sent to browser
DEBUG - 2013-12-14 14:21:26 --> Total execution time: 0.0790
DEBUG - 2013-12-14 14:21:29 --> Config Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:21:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:21:29 --> URI Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Router Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Output Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Security Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Input Class Initialized
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> XSS Filtering completed
DEBUG - 2013-12-14 14:21:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:21:29 --> Language Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Language Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Config Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Loader Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Controller Class Initialized
DEBUG - 2013-12-14 14:21:29 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:21:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:21:29 --> Session Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:21:29 --> Session routines successfully run
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:21:29 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:21:29 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:21:29 --> Model Class Initialized
DEBUG - 2013-12-14 14:21:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:21:29 --> Model Class Initialized
DEBUG - 2013-12-14 14:21:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:21:29 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:21:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:21:29 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:21:29 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:21:29 --> Model Class Initialized
DEBUG - 2013-12-14 14:21:29 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:21:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:21:29 --> Final output sent to browser
DEBUG - 2013-12-14 14:21:29 --> Total execution time: 0.0462
DEBUG - 2013-12-14 14:22:03 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:22:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:22:03 --> URI Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Router Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Output Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Security Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Input Class Initialized
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:22:03 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Loader Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Controller Class Initialized
DEBUG - 2013-12-14 14:22:03 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:22:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:22:03 --> Session Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:22:03 --> Session routines successfully run
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:22:03 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:22:03 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:22:03 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:22:03 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:22:03 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:22:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:22:03 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:22:03 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:22:03 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:03 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:22:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:22:03 --> Final output sent to browser
DEBUG - 2013-12-14 14:22:03 --> Total execution time: 0.0628
DEBUG - 2013-12-14 14:22:06 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:22:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:22:06 --> URI Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Router Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Output Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Security Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Input Class Initialized
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:22:06 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Loader Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Controller Class Initialized
DEBUG - 2013-12-14 14:22:06 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:22:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:22:06 --> Session Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:22:06 --> Session routines successfully run
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:22:06 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:22:06 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:22:06 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:22:06 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:22:06 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:22:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:22:06 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:22:06 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:22:06 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:06 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:22:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:22:06 --> Final output sent to browser
DEBUG - 2013-12-14 14:22:06 --> Total execution time: 0.0613
DEBUG - 2013-12-14 14:22:09 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:22:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:22:09 --> URI Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Router Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Output Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Security Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Input Class Initialized
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:22:09 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Loader Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Controller Class Initialized
DEBUG - 2013-12-14 14:22:09 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:22:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:22:09 --> Session Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:22:09 --> Session routines successfully run
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:22:09 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:22:09 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:22:09 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:22:09 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:22:09 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:22:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:22:09 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:22:09 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:22:09 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:09 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:22:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:22:09 --> Final output sent to browser
DEBUG - 2013-12-14 14:22:09 --> Total execution time: 0.0601
DEBUG - 2013-12-14 14:22:12 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:22:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:22:12 --> URI Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Router Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Output Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Security Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Input Class Initialized
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:22:12 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Loader Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Controller Class Initialized
DEBUG - 2013-12-14 14:22:12 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:22:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:22:12 --> Session Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:22:12 --> Session routines successfully run
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:22:12 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:22:12 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:22:12 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:22:12 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:22:12 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:22:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:22:12 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:22:12 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:22:12 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:12 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:22:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:22:12 --> Final output sent to browser
DEBUG - 2013-12-14 14:22:12 --> Total execution time: 0.0583
DEBUG - 2013-12-14 14:22:16 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:22:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:22:16 --> URI Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Router Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Output Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Security Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Input Class Initialized
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:22:16 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Loader Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Controller Class Initialized
DEBUG - 2013-12-14 14:22:16 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:22:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:22:16 --> Session Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:22:16 --> Session routines successfully run
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:22:16 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:22:16 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:22:16 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:22:16 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:22:16 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:22:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:22:16 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:22:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:22:16 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:16 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:22:16 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:22:16 --> Final output sent to browser
DEBUG - 2013-12-14 14:22:16 --> Total execution time: 0.0509
DEBUG - 2013-12-14 14:22:18 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:22:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:22:18 --> URI Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Router Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Output Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Security Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Input Class Initialized
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> XSS Filtering completed
DEBUG - 2013-12-14 14:22:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:22:18 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Language Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Config Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Loader Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Controller Class Initialized
DEBUG - 2013-12-14 14:22:18 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:22:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:22:18 --> Session Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:22:18 --> Session routines successfully run
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:22:18 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:22:18 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:22:18 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:22:18 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:22:18 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:22:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:22:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:22:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:22:18 --> Model Class Initialized
DEBUG - 2013-12-14 14:22:18 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:22:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:22:18 --> Final output sent to browser
DEBUG - 2013-12-14 14:22:18 --> Total execution time: 0.0503
DEBUG - 2013-12-14 14:24:21 --> Config Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:24:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:24:21 --> URI Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Router Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Output Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Security Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Input Class Initialized
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:24:21 --> Language Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Language Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Config Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Loader Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Controller Class Initialized
DEBUG - 2013-12-14 14:24:21 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:24:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:24:21 --> Session Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:24:21 --> Session routines successfully run
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:24:21 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:24:21 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:24:21 --> Model Class Initialized
DEBUG - 2013-12-14 14:24:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:24:21 --> Model Class Initialized
DEBUG - 2013-12-14 14:24:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:24:21 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:24:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:24:21 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:24:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:24:21 --> Model Class Initialized
DEBUG - 2013-12-14 14:24:21 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:24:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:24:21 --> Final output sent to browser
DEBUG - 2013-12-14 14:24:21 --> Total execution time: 0.0582
DEBUG - 2013-12-14 14:24:44 --> Config Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:24:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:24:44 --> URI Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Router Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Output Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Security Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Input Class Initialized
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> XSS Filtering completed
DEBUG - 2013-12-14 14:24:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:24:44 --> Language Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Language Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Config Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Loader Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Controller Class Initialized
DEBUG - 2013-12-14 14:24:44 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:24:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:24:44 --> Session Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:24:44 --> Session routines successfully run
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:24:44 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:24:44 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:24:44 --> Model Class Initialized
DEBUG - 2013-12-14 14:24:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:24:44 --> Model Class Initialized
DEBUG - 2013-12-14 14:24:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:24:44 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:24:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:24:44 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:24:44 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:24:44 --> Model Class Initialized
DEBUG - 2013-12-14 14:24:44 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:24:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:24:44 --> Final output sent to browser
DEBUG - 2013-12-14 14:24:44 --> Total execution time: 0.0762
DEBUG - 2013-12-14 14:25:28 --> Config Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:25:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:25:28 --> URI Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Router Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Output Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Security Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Input Class Initialized
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:25:28 --> Language Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Language Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Config Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Loader Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Controller Class Initialized
DEBUG - 2013-12-14 14:25:28 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:25:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:25:28 --> Session Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:25:28 --> Session routines successfully run
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:25:28 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:25:28 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:25:28 --> Model Class Initialized
DEBUG - 2013-12-14 14:25:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:25:28 --> Model Class Initialized
DEBUG - 2013-12-14 14:25:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:25:28 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:25:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:25:28 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:25:28 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:25:28 --> Model Class Initialized
DEBUG - 2013-12-14 14:25:28 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:25:28 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:25:28 --> Final output sent to browser
DEBUG - 2013-12-14 14:25:28 --> Total execution time: 0.0607
DEBUG - 2013-12-14 14:25:30 --> Config Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:25:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:25:30 --> URI Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Router Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Output Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Security Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Input Class Initialized
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> XSS Filtering completed
DEBUG - 2013-12-14 14:25:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:25:30 --> Language Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Language Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Config Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Loader Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Controller Class Initialized
DEBUG - 2013-12-14 14:25:30 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:25:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:25:30 --> Session Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:25:30 --> Session routines successfully run
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:25:30 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:25:30 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:25:30 --> Model Class Initialized
DEBUG - 2013-12-14 14:25:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:25:30 --> Model Class Initialized
DEBUG - 2013-12-14 14:25:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:25:30 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:25:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:25:30 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:25:30 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:25:30 --> Model Class Initialized
DEBUG - 2013-12-14 14:25:30 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:25:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:25:30 --> Final output sent to browser
DEBUG - 2013-12-14 14:25:30 --> Total execution time: 0.0561
DEBUG - 2013-12-14 14:26:27 --> Config Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:26:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:26:27 --> URI Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Router Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Output Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Security Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Input Class Initialized
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> XSS Filtering completed
DEBUG - 2013-12-14 14:26:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:26:27 --> Language Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Language Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Config Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Loader Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Controller Class Initialized
DEBUG - 2013-12-14 14:26:27 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:26:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:26:27 --> Session Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:26:27 --> Session routines successfully run
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:26:27 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:26:27 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:26:27 --> Model Class Initialized
DEBUG - 2013-12-14 14:26:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:26:27 --> Model Class Initialized
DEBUG - 2013-12-14 14:26:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:26:27 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:26:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:26:27 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:26:27 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:26:27 --> Model Class Initialized
DEBUG - 2013-12-14 14:26:27 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:26:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:26:27 --> Final output sent to browser
DEBUG - 2013-12-14 14:26:27 --> Total execution time: 0.0641
DEBUG - 2013-12-14 14:27:04 --> Config Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:27:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:27:04 --> URI Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Router Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Output Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Security Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Input Class Initialized
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> XSS Filtering completed
DEBUG - 2013-12-14 14:27:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:27:04 --> Language Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Language Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Config Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Loader Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Controller Class Initialized
DEBUG - 2013-12-14 14:27:04 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:27:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:27:04 --> Session Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:27:04 --> Session routines successfully run
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:27:04 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:27:04 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:27:04 --> Model Class Initialized
DEBUG - 2013-12-14 14:27:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:27:04 --> Model Class Initialized
DEBUG - 2013-12-14 14:27:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:27:04 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:27:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:27:04 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:27:04 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:27:04 --> Model Class Initialized
DEBUG - 2013-12-14 14:27:04 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:27:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:27:04 --> Final output sent to browser
DEBUG - 2013-12-14 14:27:04 --> Total execution time: 0.0624
DEBUG - 2013-12-14 14:28:11 --> Config Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:28:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:28:11 --> URI Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Router Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Output Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Security Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Input Class Initialized
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:28:11 --> Language Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Language Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Config Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Loader Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Controller Class Initialized
DEBUG - 2013-12-14 14:28:11 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:28:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:28:11 --> Session Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:28:11 --> Session routines successfully run
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:28:11 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:28:11 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:28:11 --> Model Class Initialized
DEBUG - 2013-12-14 14:28:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:28:11 --> Model Class Initialized
DEBUG - 2013-12-14 14:28:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:28:11 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:28:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:28:11 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:28:11 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:28:11 --> Model Class Initialized
DEBUG - 2013-12-14 14:28:11 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:28:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:28:11 --> Final output sent to browser
DEBUG - 2013-12-14 14:28:11 --> Total execution time: 0.0559
DEBUG - 2013-12-14 14:28:48 --> Config Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:28:48 --> URI Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Router Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Output Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Security Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Input Class Initialized
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> XSS Filtering completed
DEBUG - 2013-12-14 14:28:48 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:28:48 --> Language Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Language Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Config Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Loader Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Controller Class Initialized
DEBUG - 2013-12-14 14:28:48 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:28:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:28:48 --> Session Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:28:48 --> Session routines successfully run
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:28:48 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:28:48 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:28:48 --> Model Class Initialized
DEBUG - 2013-12-14 14:28:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:28:48 --> Model Class Initialized
DEBUG - 2013-12-14 14:28:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:28:48 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:28:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:28:48 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:28:48 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:28:48 --> Model Class Initialized
DEBUG - 2013-12-14 14:28:48 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:28:48 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:28:48 --> Final output sent to browser
DEBUG - 2013-12-14 14:28:48 --> Total execution time: 0.0527
DEBUG - 2013-12-14 14:29:06 --> Config Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:29:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:29:06 --> URI Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Router Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Output Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Security Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Input Class Initialized
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> XSS Filtering completed
DEBUG - 2013-12-14 14:29:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:29:06 --> Language Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Language Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Config Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Loader Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Controller Class Initialized
DEBUG - 2013-12-14 14:29:06 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:29:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:29:06 --> Session Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:29:06 --> Session routines successfully run
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:29:06 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:29:06 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:29:06 --> Model Class Initialized
DEBUG - 2013-12-14 14:29:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:29:06 --> Model Class Initialized
DEBUG - 2013-12-14 14:29:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:29:06 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:29:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:29:06 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:29:06 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:29:06 --> Model Class Initialized
DEBUG - 2013-12-14 14:29:06 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:29:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:29:06 --> Final output sent to browser
DEBUG - 2013-12-14 14:29:06 --> Total execution time: 0.0542
DEBUG - 2013-12-14 14:31:21 --> Config Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:31:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:31:21 --> URI Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Router Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Output Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Security Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Input Class Initialized
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> XSS Filtering completed
DEBUG - 2013-12-14 14:31:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:31:21 --> Language Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Language Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Config Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Loader Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Controller Class Initialized
DEBUG - 2013-12-14 14:31:21 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:31:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:31:21 --> Session Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:31:21 --> Session routines successfully run
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:31:21 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:31:21 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:31:21 --> Model Class Initialized
DEBUG - 2013-12-14 14:31:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:31:21 --> Model Class Initialized
DEBUG - 2013-12-14 14:31:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:31:21 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:31:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:31:21 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:31:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:31:21 --> Model Class Initialized
DEBUG - 2013-12-14 14:31:21 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:31:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:31:21 --> Final output sent to browser
DEBUG - 2013-12-14 14:31:21 --> Total execution time: 0.0678
DEBUG - 2013-12-14 14:39:54 --> Config Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Hooks Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Utf8 Class Initialized
DEBUG - 2013-12-14 14:39:54 --> UTF-8 Support Enabled
DEBUG - 2013-12-14 14:39:54 --> URI Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Router Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Output Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Security Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Input Class Initialized
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> XSS Filtering completed
DEBUG - 2013-12-14 14:39:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-14 14:39:54 --> Language Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Language Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Config Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Loader Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Controller Class Initialized
DEBUG - 2013-12-14 14:39:54 --> admin MX_Controller Initialized
DEBUG - 2013-12-14 14:39:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-14 14:39:54 --> Session Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: string_helper
DEBUG - 2013-12-14 14:39:54 --> Session routines successfully run
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: url_helper
DEBUG - 2013-12-14 14:39:54 --> Database Driver Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: form_helper
DEBUG - 2013-12-14 14:39:54 --> Form Validation Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: number_helper
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: pager_helper
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: invoice_helper
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: date_helper
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: redirect_helper
DEBUG - 2013-12-14 14:39:54 --> Model Class Initialized
DEBUG - 2013-12-14 14:39:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-14 14:39:54 --> Model Class Initialized
DEBUG - 2013-12-14 14:39:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-14 14:39:54 --> Helper loaded: language_helper
DEBUG - 2013-12-14 14:39:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-14 14:39:54 --> Layout MX_Controller Initialized
DEBUG - 2013-12-14 14:39:54 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-14 14:39:54 --> Model Class Initialized
DEBUG - 2013-12-14 14:39:54 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-14 14:39:54 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-14 14:39:54 --> Final output sent to browser
DEBUG - 2013-12-14 14:39:54 --> Total execution time: 0.0587
