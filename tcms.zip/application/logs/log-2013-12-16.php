<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-12-16 06:51:58 --> Config Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Hooks Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Utf8 Class Initialized
DEBUG - 2013-12-16 06:51:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 06:51:58 --> URI Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Router Class Initialized
DEBUG - 2013-12-16 06:51:58 --> No URI present. Default controller set.
DEBUG - 2013-12-16 06:51:58 --> Output Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Security Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Input Class Initialized
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 06:51:58 --> Language Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Language Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Config Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Loader Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Controller Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-16 06:51:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 06:51:58 --> Session Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: string_helper
DEBUG - 2013-12-16 06:51:58 --> A session cookie was not found.
DEBUG - 2013-12-16 06:51:58 --> Session routines successfully run
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: url_helper
DEBUG - 2013-12-16 06:51:58 --> Database Driver Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: form_helper
DEBUG - 2013-12-16 06:51:58 --> Form Validation Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: number_helper
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: date_helper
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 06:51:58 --> Model Class Initialized
DEBUG - 2013-12-16 06:51:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 06:51:58 --> Model Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: language_helper
DEBUG - 2013-12-16 06:51:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 06:51:58 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 06:51:58 --> Config Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Hooks Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Utf8 Class Initialized
DEBUG - 2013-12-16 06:51:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 06:51:58 --> URI Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Router Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Output Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Security Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Input Class Initialized
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> XSS Filtering completed
DEBUG - 2013-12-16 06:51:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 06:51:58 --> Language Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Language Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Config Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Loader Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Controller Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-16 06:51:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 06:51:58 --> Session Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: string_helper
DEBUG - 2013-12-16 06:51:58 --> Session routines successfully run
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: url_helper
DEBUG - 2013-12-16 06:51:58 --> Database Driver Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: form_helper
DEBUG - 2013-12-16 06:51:58 --> Form Validation Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: number_helper
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: date_helper
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 06:51:58 --> Model Class Initialized
DEBUG - 2013-12-16 06:51:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 06:51:58 --> Model Class Initialized
DEBUG - 2013-12-16 06:51:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 06:51:58 --> Helper loaded: language_helper
DEBUG - 2013-12-16 06:51:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 06:51:58 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 06:51:58 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-16 06:51:58 --> Final output sent to browser
DEBUG - 2013-12-16 06:51:58 --> Total execution time: 0.0850
DEBUG - 2013-12-16 06:52:02 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Hooks Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Utf8 Class Initialized
DEBUG - 2013-12-16 06:52:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 06:52:02 --> URI Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Router Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Output Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Security Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Input Class Initialized
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 06:52:02 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Loader Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Controller Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-16 06:52:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 06:52:02 --> Session Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: string_helper
DEBUG - 2013-12-16 06:52:02 --> Session routines successfully run
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: url_helper
DEBUG - 2013-12-16 06:52:02 --> Database Driver Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: form_helper
DEBUG - 2013-12-16 06:52:02 --> Form Validation Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: number_helper
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: date_helper
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 06:52:02 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 06:52:02 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 06:52:02 --> Helper loaded: language_helper
DEBUG - 2013-12-16 06:52:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 06:52:02 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 06:52:02 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-12-16 06:52:02 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:02 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-12-16 06:52:02 --> Final output sent to browser
DEBUG - 2013-12-16 06:52:02 --> Total execution time: 0.1824
DEBUG - 2013-12-16 06:52:05 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Hooks Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Utf8 Class Initialized
DEBUG - 2013-12-16 06:52:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 06:52:05 --> URI Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Router Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Output Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Security Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Input Class Initialized
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 06:52:05 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Loader Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Controller Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Sessions MX_Controller Initialized
DEBUG - 2013-12-16 06:52:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 06:52:05 --> Session Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: string_helper
DEBUG - 2013-12-16 06:52:05 --> Session routines successfully run
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: url_helper
DEBUG - 2013-12-16 06:52:05 --> Database Driver Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: form_helper
DEBUG - 2013-12-16 06:52:05 --> Form Validation Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: number_helper
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: date_helper
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 06:52:05 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 06:52:05 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 06:52:05 --> Helper loaded: language_helper
DEBUG - 2013-12-16 06:52:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 06:52:05 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 06:52:05 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-12-16 06:52:05 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Hooks Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Utf8 Class Initialized
DEBUG - 2013-12-16 06:52:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 06:52:06 --> URI Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Router Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Output Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Security Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Input Class Initialized
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 06:52:06 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Loader Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Controller Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Dashboard MX_Controller Initialized
DEBUG - 2013-12-16 06:52:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 06:52:06 --> Session Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: string_helper
DEBUG - 2013-12-16 06:52:06 --> Session routines successfully run
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: url_helper
DEBUG - 2013-12-16 06:52:06 --> Database Driver Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: form_helper
DEBUG - 2013-12-16 06:52:06 --> Form Validation Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: number_helper
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: date_helper
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 06:52:06 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 06:52:06 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 06:52:06 --> Helper loaded: language_helper
DEBUG - 2013-12-16 06:52:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 06:52:06 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 06:52:06 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-12-16 06:52:06 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:06 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-12-16 06:52:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 06:52:06 --> Final output sent to browser
DEBUG - 2013-12-16 06:52:06 --> Total execution time: 0.0472
DEBUG - 2013-12-16 06:52:08 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Hooks Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Utf8 Class Initialized
DEBUG - 2013-12-16 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 06:52:08 --> URI Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Router Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Output Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Security Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Input Class Initialized
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 06:52:08 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Loader Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Controller Class Initialized
DEBUG - 2013-12-16 06:52:08 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 06:52:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 06:52:08 --> Session Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: string_helper
DEBUG - 2013-12-16 06:52:08 --> Session routines successfully run
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: url_helper
DEBUG - 2013-12-16 06:52:08 --> Database Driver Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: form_helper
DEBUG - 2013-12-16 06:52:08 --> Form Validation Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: number_helper
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: date_helper
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 06:52:08 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 06:52:08 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 06:52:08 --> Helper loaded: language_helper
DEBUG - 2013-12-16 06:52:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 06:52:08 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 06:52:08 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 06:52:08 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:08 --> File loaded: application/modules/admin/views/admin.php
DEBUG - 2013-12-16 06:52:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 06:52:08 --> Final output sent to browser
DEBUG - 2013-12-16 06:52:08 --> Total execution time: 0.0680
DEBUG - 2013-12-16 06:52:09 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Hooks Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Utf8 Class Initialized
DEBUG - 2013-12-16 06:52:09 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 06:52:09 --> URI Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Router Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Output Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Security Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Input Class Initialized
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> XSS Filtering completed
DEBUG - 2013-12-16 06:52:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 06:52:09 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Language Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Config Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Loader Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Controller Class Initialized
DEBUG - 2013-12-16 06:52:09 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 06:52:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 06:52:09 --> Session Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: string_helper
DEBUG - 2013-12-16 06:52:09 --> Session routines successfully run
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: url_helper
DEBUG - 2013-12-16 06:52:09 --> Database Driver Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: form_helper
DEBUG - 2013-12-16 06:52:09 --> Form Validation Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: number_helper
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: date_helper
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 06:52:09 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 06:52:09 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 06:52:09 --> Helper loaded: language_helper
DEBUG - 2013-12-16 06:52:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 06:52:09 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 06:52:09 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 06:52:09 --> Model Class Initialized
DEBUG - 2013-12-16 06:52:09 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 06:52:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 06:52:09 --> Final output sent to browser
DEBUG - 2013-12-16 06:52:09 --> Total execution time: 0.0882
DEBUG - 2013-12-16 07:04:20 --> Config Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:04:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:04:20 --> URI Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Router Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Output Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Security Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Input Class Initialized
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:04:20 --> Language Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Language Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Config Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Loader Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Controller Class Initialized
DEBUG - 2013-12-16 07:04:20 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:04:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:04:20 --> Session Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:04:20 --> Session routines successfully run
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:04:20 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:04:20 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:04:20 --> Model Class Initialized
DEBUG - 2013-12-16 07:04:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:04:20 --> Model Class Initialized
DEBUG - 2013-12-16 07:04:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:04:20 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:04:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:04:20 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:04:20 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:04:20 --> Model Class Initialized
ERROR - 2013-12-16 07:04:20 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php on line 25 and defined D:\xampp\htdocs\renalemr\system\libraries\Session.php 428
ERROR - 2013-12-16 07:04:20 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\renalemr\system\libraries\Session.php 430
DEBUG - 2013-12-16 07:04:20 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 07:04:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 07:04:20 --> Final output sent to browser
DEBUG - 2013-12-16 07:04:20 --> Total execution time: 0.0776
DEBUG - 2013-12-16 07:04:26 --> Config Class Initialized
DEBUG - 2013-12-16 07:04:26 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:04:26 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:04:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:04:26 --> URI Class Initialized
DEBUG - 2013-12-16 07:04:26 --> Router Class Initialized
DEBUG - 2013-12-16 07:04:26 --> Output Class Initialized
DEBUG - 2013-12-16 07:04:26 --> Security Class Initialized
DEBUG - 2013-12-16 07:04:26 --> Input Class Initialized
DEBUG - 2013-12-16 07:04:26 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:26 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:26 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:26 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:26 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> XSS Filtering completed
DEBUG - 2013-12-16 07:04:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:04:27 --> Language Class Initialized
DEBUG - 2013-12-16 07:04:27 --> Language Class Initialized
DEBUG - 2013-12-16 07:04:27 --> Config Class Initialized
DEBUG - 2013-12-16 07:04:27 --> Loader Class Initialized
DEBUG - 2013-12-16 07:04:27 --> Controller Class Initialized
DEBUG - 2013-12-16 07:04:27 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:04:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:04:27 --> Session Class Initialized
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:04:27 --> Session routines successfully run
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:04:27 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:04:27 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:04:27 --> Model Class Initialized
DEBUG - 2013-12-16 07:04:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:04:27 --> Model Class Initialized
DEBUG - 2013-12-16 07:04:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:04:27 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:04:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:04:27 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:04:27 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:04:27 --> Model Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Config Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:05:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:05:18 --> URI Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Router Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Output Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Security Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Input Class Initialized
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:05:18 --> Language Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Language Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Config Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Loader Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Controller Class Initialized
DEBUG - 2013-12-16 07:05:18 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:05:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:05:18 --> Session Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:05:18 --> Session routines successfully run
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:05:18 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:05:18 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:05:18 --> Model Class Initialized
DEBUG - 2013-12-16 07:05:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:05:18 --> Model Class Initialized
DEBUG - 2013-12-16 07:05:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:05:18 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:05:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:05:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:05:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:05:18 --> Model Class Initialized
ERROR - 2013-12-16 07:05:18 --> Severity: Warning  --> Missing argument 1 for CI_Session::userdata(), called in D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php on line 25 and defined D:\xampp\htdocs\renalemr\system\libraries\Session.php 428
ERROR - 2013-12-16 07:05:18 --> Severity: Notice  --> Undefined variable: item D:\xampp\htdocs\renalemr\system\libraries\Session.php 430
DEBUG - 2013-12-16 07:05:18 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 07:05:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 07:05:18 --> Final output sent to browser
DEBUG - 2013-12-16 07:05:18 --> Total execution time: 0.0663
DEBUG - 2013-12-16 07:05:36 --> Config Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:05:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:05:36 --> URI Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Router Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Output Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Security Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Input Class Initialized
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> XSS Filtering completed
DEBUG - 2013-12-16 07:05:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:05:36 --> Language Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Language Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Config Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Loader Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Controller Class Initialized
DEBUG - 2013-12-16 07:05:36 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:05:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:05:36 --> Session Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:05:36 --> Session routines successfully run
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:05:36 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:05:36 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:05:36 --> Model Class Initialized
DEBUG - 2013-12-16 07:05:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:05:36 --> Model Class Initialized
DEBUG - 2013-12-16 07:05:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:05:36 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:05:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:05:36 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:05:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:05:36 --> Model Class Initialized
DEBUG - 2013-12-16 07:05:36 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 07:05:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 07:05:36 --> Final output sent to browser
DEBUG - 2013-12-16 07:05:36 --> Total execution time: 0.0620
DEBUG - 2013-12-16 07:06:08 --> Config Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:06:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:06:08 --> URI Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Router Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Output Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Security Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Input Class Initialized
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> XSS Filtering completed
DEBUG - 2013-12-16 07:06:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:06:08 --> Language Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Language Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Config Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Loader Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Controller Class Initialized
DEBUG - 2013-12-16 07:06:08 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:06:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:06:08 --> Session Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:06:08 --> Session routines successfully run
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:06:08 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:06:08 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:06:08 --> Model Class Initialized
DEBUG - 2013-12-16 07:06:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:06:08 --> Model Class Initialized
DEBUG - 2013-12-16 07:06:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:06:08 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:06:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:06:08 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:06:08 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:06:08 --> Model Class Initialized
DEBUG - 2013-12-16 07:06:08 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 07:06:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 07:06:08 --> Final output sent to browser
DEBUG - 2013-12-16 07:06:08 --> Total execution time: 0.0513
DEBUG - 2013-12-16 07:08:04 --> Config Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:08:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:08:04 --> URI Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Router Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Output Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Security Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Input Class Initialized
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:08:04 --> Language Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Language Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Config Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Loader Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Controller Class Initialized
DEBUG - 2013-12-16 07:08:04 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:08:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:08:04 --> Session Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:08:04 --> Session routines successfully run
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:08:04 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:08:04 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:08:04 --> Model Class Initialized
DEBUG - 2013-12-16 07:08:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:08:04 --> Model Class Initialized
DEBUG - 2013-12-16 07:08:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:08:04 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:08:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:08:04 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:08:04 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:08:04 --> Model Class Initialized
DEBUG - 2013-12-16 07:08:04 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 07:08:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 07:08:04 --> Final output sent to browser
DEBUG - 2013-12-16 07:08:04 --> Total execution time: 0.0584
DEBUG - 2013-12-16 07:08:58 --> Config Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:08:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:08:58 --> URI Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Router Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Output Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Security Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Input Class Initialized
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> XSS Filtering completed
DEBUG - 2013-12-16 07:08:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:08:58 --> Language Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Language Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Config Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Loader Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Controller Class Initialized
DEBUG - 2013-12-16 07:08:58 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:08:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:08:58 --> Session Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:08:58 --> Session routines successfully run
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:08:58 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:08:58 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:08:58 --> Model Class Initialized
DEBUG - 2013-12-16 07:08:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:08:58 --> Model Class Initialized
DEBUG - 2013-12-16 07:08:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:08:58 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:08:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:08:58 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:08:58 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:08:58 --> Model Class Initialized
DEBUG - 2013-12-16 00:08:58 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 00:08:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 00:08:58 --> Final output sent to browser
DEBUG - 2013-12-16 00:08:58 --> Total execution time: 0.0746
DEBUG - 2013-12-16 07:09:37 --> Config Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:09:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:09:37 --> URI Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Router Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Output Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Security Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Input Class Initialized
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:09:37 --> Language Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Language Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Config Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Loader Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Controller Class Initialized
DEBUG - 2013-12-16 07:09:37 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:09:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:09:37 --> Session Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:09:37 --> Session routines successfully run
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:09:37 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:09:37 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:09:37 --> Model Class Initialized
DEBUG - 2013-12-16 07:09:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:09:37 --> Model Class Initialized
DEBUG - 2013-12-16 07:09:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:09:37 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:09:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:09:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:09:37 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:09:37 --> Model Class Initialized
DEBUG - 2013-12-16 09:09:37 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 09:09:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 09:09:37 --> Final output sent to browser
DEBUG - 2013-12-16 09:09:37 --> Total execution time: 0.0776
DEBUG - 2013-12-16 07:09:56 --> Config Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:09:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:09:56 --> URI Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Router Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Output Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Security Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Input Class Initialized
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> XSS Filtering completed
DEBUG - 2013-12-16 07:09:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:09:56 --> Language Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Language Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Config Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Loader Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Controller Class Initialized
DEBUG - 2013-12-16 07:09:56 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:09:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:09:56 --> Session Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:09:56 --> Session routines successfully run
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:09:56 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:09:56 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:09:56 --> Model Class Initialized
DEBUG - 2013-12-16 07:09:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:09:56 --> Model Class Initialized
DEBUG - 2013-12-16 07:09:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:09:56 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:09:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:09:56 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:09:56 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:09:56 --> Model Class Initialized
DEBUG - 2013-12-16 12:09:56 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 12:09:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 12:09:56 --> Final output sent to browser
DEBUG - 2013-12-16 12:09:56 --> Total execution time: 0.0611
DEBUG - 2013-12-16 07:10:12 --> Config Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:10:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:10:12 --> URI Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Router Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Output Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Security Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Input Class Initialized
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:10:12 --> Language Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Language Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Config Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Loader Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Controller Class Initialized
DEBUG - 2013-12-16 07:10:12 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:10:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:10:12 --> Session Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:10:12 --> Session routines successfully run
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:10:12 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:10:12 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:10:12 --> Model Class Initialized
DEBUG - 2013-12-16 07:10:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:10:12 --> Model Class Initialized
DEBUG - 2013-12-16 07:10:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:10:12 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:10:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:10:12 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:10:12 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:10:12 --> Model Class Initialized
DEBUG - 2013-12-16 12:10:12 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 12:10:12 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 12:10:12 --> Final output sent to browser
DEBUG - 2013-12-16 12:10:12 --> Total execution time: 0.0570
DEBUG - 2013-12-16 07:10:29 --> Config Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Hooks Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Utf8 Class Initialized
DEBUG - 2013-12-16 07:10:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 07:10:29 --> URI Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Router Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Output Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Security Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Input Class Initialized
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> XSS Filtering completed
DEBUG - 2013-12-16 07:10:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 07:10:29 --> Language Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Language Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Config Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Loader Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Controller Class Initialized
DEBUG - 2013-12-16 07:10:29 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 07:10:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 07:10:29 --> Session Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: string_helper
DEBUG - 2013-12-16 07:10:29 --> Session routines successfully run
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: url_helper
DEBUG - 2013-12-16 07:10:29 --> Database Driver Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: form_helper
DEBUG - 2013-12-16 07:10:29 --> Form Validation Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: number_helper
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: date_helper
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 07:10:29 --> Model Class Initialized
DEBUG - 2013-12-16 07:10:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 07:10:29 --> Model Class Initialized
DEBUG - 2013-12-16 07:10:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 07:10:29 --> Helper loaded: language_helper
DEBUG - 2013-12-16 07:10:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 07:10:29 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 07:10:29 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 07:10:29 --> Model Class Initialized
DEBUG - 2013-12-16 11:40:30 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 11:40:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 11:40:30 --> Final output sent to browser
DEBUG - 2013-12-16 11:40:30 --> Total execution time: 0.0750
DEBUG - 2013-12-16 11:53:55 --> Config Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Hooks Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Utf8 Class Initialized
DEBUG - 2013-12-16 11:53:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 11:53:55 --> URI Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Router Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Output Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Security Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Input Class Initialized
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:53:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 11:53:55 --> Language Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Language Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Config Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Loader Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Controller Class Initialized
DEBUG - 2013-12-16 11:53:55 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 11:53:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 11:53:55 --> Session Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: string_helper
DEBUG - 2013-12-16 11:53:55 --> Session routines successfully run
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: url_helper
DEBUG - 2013-12-16 11:53:55 --> Database Driver Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: form_helper
DEBUG - 2013-12-16 11:53:55 --> Form Validation Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: number_helper
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: date_helper
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 11:53:55 --> Model Class Initialized
DEBUG - 2013-12-16 11:53:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 11:53:55 --> Model Class Initialized
DEBUG - 2013-12-16 11:53:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 11:53:55 --> Helper loaded: language_helper
DEBUG - 2013-12-16 11:53:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 11:53:55 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 11:53:55 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 11:53:55 --> Model Class Initialized
DEBUG - 2013-12-16 11:53:55 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 11:53:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 11:53:55 --> Final output sent to browser
DEBUG - 2013-12-16 11:53:55 --> Total execution time: 0.0610
DEBUG - 2013-12-16 11:56:55 --> Config Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Hooks Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Utf8 Class Initialized
DEBUG - 2013-12-16 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 11:56:55 --> URI Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Router Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Output Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Security Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Input Class Initialized
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> XSS Filtering completed
DEBUG - 2013-12-16 11:56:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 11:56:55 --> Language Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Language Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Config Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Loader Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Controller Class Initialized
DEBUG - 2013-12-16 11:56:55 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 11:56:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 11:56:55 --> Session Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: string_helper
DEBUG - 2013-12-16 11:56:55 --> Session routines successfully run
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: url_helper
DEBUG - 2013-12-16 11:56:55 --> Database Driver Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: form_helper
DEBUG - 2013-12-16 11:56:55 --> Form Validation Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: number_helper
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: date_helper
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 11:56:55 --> Model Class Initialized
DEBUG - 2013-12-16 11:56:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 11:56:55 --> Model Class Initialized
DEBUG - 2013-12-16 11:56:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 11:56:55 --> Helper loaded: language_helper
DEBUG - 2013-12-16 11:56:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 11:56:55 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 11:56:55 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 11:56:55 --> Model Class Initialized
DEBUG - 2013-12-16 11:56:55 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 11:56:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 11:56:55 --> Final output sent to browser
DEBUG - 2013-12-16 11:56:55 --> Total execution time: 0.0597
DEBUG - 2013-12-16 11:58:02 --> Config Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Hooks Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Utf8 Class Initialized
DEBUG - 2013-12-16 11:58:02 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 11:58:02 --> URI Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Router Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Output Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Security Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Input Class Initialized
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 11:58:02 --> Language Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Language Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Config Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Loader Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Controller Class Initialized
DEBUG - 2013-12-16 11:58:02 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 11:58:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 11:58:02 --> Session Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: string_helper
DEBUG - 2013-12-16 11:58:02 --> Session routines successfully run
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: url_helper
DEBUG - 2013-12-16 11:58:02 --> Database Driver Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: form_helper
DEBUG - 2013-12-16 11:58:02 --> Form Validation Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: number_helper
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: date_helper
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 11:58:02 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 11:58:02 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 11:58:02 --> Helper loaded: language_helper
DEBUG - 2013-12-16 11:58:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 11:58:02 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 11:58:02 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 11:58:02 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Config Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Hooks Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Utf8 Class Initialized
DEBUG - 2013-12-16 11:58:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 11:58:04 --> URI Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Router Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Output Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Security Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Input Class Initialized
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 11:58:04 --> Language Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Language Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Config Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Loader Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Controller Class Initialized
DEBUG - 2013-12-16 11:58:04 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 11:58:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 11:58:04 --> Session Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: string_helper
DEBUG - 2013-12-16 11:58:04 --> Session routines successfully run
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: url_helper
DEBUG - 2013-12-16 11:58:04 --> Database Driver Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: form_helper
DEBUG - 2013-12-16 11:58:04 --> Form Validation Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: number_helper
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: date_helper
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 11:58:04 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 11:58:04 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 11:58:04 --> Helper loaded: language_helper
DEBUG - 2013-12-16 11:58:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 11:58:04 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 11:58:04 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 11:58:04 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:25 --> Config Class Initialized
DEBUG - 2013-12-16 11:58:25 --> Hooks Class Initialized
DEBUG - 2013-12-16 11:58:25 --> Utf8 Class Initialized
DEBUG - 2013-12-16 11:58:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 11:58:25 --> URI Class Initialized
DEBUG - 2013-12-16 11:58:25 --> Router Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Output Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Security Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Input Class Initialized
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 11:58:26 --> Language Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Language Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Config Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Loader Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Controller Class Initialized
DEBUG - 2013-12-16 11:58:26 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 11:58:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 11:58:26 --> Session Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: string_helper
DEBUG - 2013-12-16 11:58:26 --> Session routines successfully run
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: url_helper
DEBUG - 2013-12-16 11:58:26 --> Database Driver Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: form_helper
DEBUG - 2013-12-16 11:58:26 --> Form Validation Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: number_helper
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: date_helper
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 11:58:26 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 11:58:26 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 11:58:26 --> Helper loaded: language_helper
DEBUG - 2013-12-16 11:58:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 11:58:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 11:58:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 11:58:26 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:26 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 11:58:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 11:58:26 --> Final output sent to browser
DEBUG - 2013-12-16 11:58:26 --> Total execution time: 0.0652
DEBUG - 2013-12-16 11:58:57 --> Config Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Hooks Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Utf8 Class Initialized
DEBUG - 2013-12-16 11:58:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 11:58:57 --> URI Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Router Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Output Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Security Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Input Class Initialized
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 11:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 11:58:57 --> Language Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Language Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Config Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Loader Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Controller Class Initialized
DEBUG - 2013-12-16 11:58:57 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 11:58:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 11:58:57 --> Session Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: string_helper
DEBUG - 2013-12-16 11:58:57 --> Session routines successfully run
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: url_helper
DEBUG - 2013-12-16 11:58:57 --> Database Driver Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: form_helper
DEBUG - 2013-12-16 11:58:57 --> Form Validation Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: number_helper
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: date_helper
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 11:58:57 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 11:58:57 --> Model Class Initialized
DEBUG - 2013-12-16 11:58:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 11:58:57 --> Helper loaded: language_helper
DEBUG - 2013-12-16 11:58:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 11:58:57 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 11:58:57 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 11:58:57 --> Model Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Config Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:26:20 --> URI Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Router Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Output Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Security Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Input Class Initialized
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:26:20 --> Language Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Language Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Config Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Loader Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Controller Class Initialized
DEBUG - 2013-12-16 12:26:20 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:26:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:26:20 --> Session Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:26:20 --> Session routines successfully run
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:26:20 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:26:20 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:26:20 --> Model Class Initialized
DEBUG - 2013-12-16 12:26:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:26:20 --> Model Class Initialized
DEBUG - 2013-12-16 12:26:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:26:20 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:26:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:26:20 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:26:20 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:26:20 --> Model Class Initialized
ERROR - 2013-12-16 12:26:20 --> Severity: Notice  --> Undefined index: file D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 71
ERROR - 2013-12-16 12:26:20 --> Severity: Notice  --> Undefined index: file D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 73
ERROR - 2013-12-16 12:26:20 --> Severity: Notice  --> Undefined index: file D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 74
ERROR - 2013-12-16 12:26:20 --> Severity: Notice  --> Undefined index: file D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 75
ERROR - 2013-12-16 12:26:20 --> Severity: Notice  --> Undefined index: file D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 76
ERROR - 2013-12-16 12:26:20 --> Severity: Notice  --> Undefined index: file D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 77
ERROR - 2013-12-16 12:26:20 --> Severity: Notice  --> Undefined index: file D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 78
DEBUG - 2013-12-16 12:26:36 --> Config Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:26:36 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:26:36 --> URI Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Router Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Output Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Security Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Input Class Initialized
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:26:36 --> Language Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Language Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Config Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Loader Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Controller Class Initialized
DEBUG - 2013-12-16 12:26:36 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:26:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:26:36 --> Session Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:26:36 --> Session routines successfully run
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:26:36 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:26:36 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:26:36 --> Model Class Initialized
DEBUG - 2013-12-16 12:26:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:26:36 --> Model Class Initialized
DEBUG - 2013-12-16 12:26:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:26:36 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:26:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:26:36 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:26:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:26:36 --> Model Class Initialized
DEBUG - 2013-12-16 12:26:36 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 12:26:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 12:26:36 --> Final output sent to browser
DEBUG - 2013-12-16 12:26:36 --> Total execution time: 0.0903
DEBUG - 2013-12-16 12:26:44 --> Config Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:26:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:26:44 --> URI Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Router Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Output Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Security Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Input Class Initialized
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:26:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:26:44 --> Language Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Language Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Config Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Loader Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Controller Class Initialized
DEBUG - 2013-12-16 12:26:44 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:26:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:26:44 --> Session Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:26:44 --> Session routines successfully run
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:26:44 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:26:44 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:26:44 --> Model Class Initialized
DEBUG - 2013-12-16 12:26:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:26:44 --> Model Class Initialized
DEBUG - 2013-12-16 12:26:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:26:44 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:26:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:26:44 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:26:44 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:26:44 --> Model Class Initialized
ERROR - 2013-12-16 12:26:44 --> Severity: Warning  --> move_uploaded_file(upload/companylogo/view_code4.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: No such file or directory D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
ERROR - 2013-12-16 12:26:44 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php231D.tmp' to 'upload/companylogo/view_code4.png' D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
DEBUG - 2013-12-16 12:28:07 --> Config Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:28:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:28:07 --> URI Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Router Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Output Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Security Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Input Class Initialized
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> XSS Filtering completed
DEBUG - 2013-12-16 12:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:28:07 --> Language Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Language Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Config Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Loader Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Controller Class Initialized
DEBUG - 2013-12-16 12:28:07 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:28:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:28:07 --> Session Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:28:07 --> Session routines successfully run
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:28:07 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:28:07 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:28:07 --> Model Class Initialized
DEBUG - 2013-12-16 12:28:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:28:07 --> Model Class Initialized
DEBUG - 2013-12-16 12:28:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:28:07 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:28:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:28:07 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:28:07 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:28:07 --> Model Class Initialized
ERROR - 2013-12-16 12:28:07 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/index.php/upload/companylogoview_code4.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
ERROR - 2013-12-16 12:28:07 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php68A6.tmp' to 'http://localhost/renalemr/index.php/upload/companylogoview_code4.png' D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
DEBUG - 2013-12-16 12:29:00 --> Config Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:29:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:29:00 --> URI Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Router Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Output Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Security Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Input Class Initialized
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> XSS Filtering completed
DEBUG - 2013-12-16 12:29:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:29:00 --> Language Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Language Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Config Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Loader Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Controller Class Initialized
DEBUG - 2013-12-16 12:29:00 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:29:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:29:00 --> Session Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:29:00 --> Session routines successfully run
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:29:00 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:29:00 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:29:00 --> Model Class Initialized
DEBUG - 2013-12-16 12:29:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:29:00 --> Model Class Initialized
DEBUG - 2013-12-16 12:29:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:29:00 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:29:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:29:00 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:29:00 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:29:00 --> Model Class Initialized
ERROR - 2013-12-16 12:29:00 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/index.php/upload/companylogo/view_code4.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
ERROR - 2013-12-16 12:29:00 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php35D4.tmp' to 'http://localhost/renalemr/index.php/upload/companylogo/view_code4.png' D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
DEBUG - 2013-12-16 12:29:14 --> Config Class Initialized
DEBUG - 2013-12-16 12:29:14 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:29:14 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:29:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:29:14 --> URI Class Initialized
DEBUG - 2013-12-16 12:29:14 --> Router Class Initialized
ERROR - 2013-12-16 12:29:14 --> 404 Page Not Found --> 
DEBUG - 2013-12-16 12:30:04 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:04 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:30:04 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:30:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:30:04 --> URI Class Initialized
DEBUG - 2013-12-16 12:30:04 --> Router Class Initialized
ERROR - 2013-12-16 12:30:04 --> 404 Page Not Found --> 
DEBUG - 2013-12-16 12:30:08 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:30:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:30:08 --> URI Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Router Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Output Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Security Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Input Class Initialized
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:30:08 --> Language Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Language Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Loader Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Controller Class Initialized
DEBUG - 2013-12-16 12:30:08 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:30:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:30:08 --> Session Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:30:08 --> Session routines successfully run
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:30:08 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:30:08 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:30:08 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:30:08 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:30:08 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:30:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:30:08 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:30:08 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:30:08 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:08 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 12:30:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 12:30:08 --> Final output sent to browser
DEBUG - 2013-12-16 12:30:08 --> Total execution time: 0.0520
DEBUG - 2013-12-16 12:30:14 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:30:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:30:14 --> URI Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Router Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Output Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Security Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Input Class Initialized
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:30:14 --> Language Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Language Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Loader Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Controller Class Initialized
DEBUG - 2013-12-16 12:30:14 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:30:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:30:14 --> Session Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:30:14 --> Session routines successfully run
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:30:14 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:30:14 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:30:14 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:30:14 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:30:14 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:30:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:30:14 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:30:14 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:30:14 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:30:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:30:17 --> URI Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Router Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Output Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Security Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Input Class Initialized
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:30:17 --> Language Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Language Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Loader Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Controller Class Initialized
DEBUG - 2013-12-16 12:30:17 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:30:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:30:17 --> Session Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:30:17 --> Session routines successfully run
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:30:17 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:30:17 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:30:17 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:30:17 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:30:17 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:30:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:30:17 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:30:17 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:30:17 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:17 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 12:30:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 12:30:17 --> Final output sent to browser
DEBUG - 2013-12-16 12:30:17 --> Total execution time: 0.0586
DEBUG - 2013-12-16 12:30:22 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:30:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:30:22 --> URI Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Router Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Output Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Security Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Input Class Initialized
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> XSS Filtering completed
DEBUG - 2013-12-16 12:30:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:30:22 --> Language Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Language Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Config Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Loader Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Controller Class Initialized
DEBUG - 2013-12-16 12:30:22 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:30:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:30:22 --> Session Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:30:22 --> Session routines successfully run
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:30:22 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:30:22 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:30:22 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:30:22 --> Model Class Initialized
DEBUG - 2013-12-16 12:30:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:30:22 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:30:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:30:22 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:30:22 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:30:22 --> Model Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Config Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:31:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:31:08 --> URI Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Router Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Output Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Security Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Input Class Initialized
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:31:08 --> Language Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Language Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Config Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Loader Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Controller Class Initialized
DEBUG - 2013-12-16 12:31:08 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:31:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:31:08 --> Session Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:31:08 --> Session routines successfully run
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:31:08 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:31:08 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:31:08 --> Model Class Initialized
DEBUG - 2013-12-16 12:31:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:31:08 --> Model Class Initialized
DEBUG - 2013-12-16 12:31:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:31:08 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:31:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:31:08 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:31:08 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:31:08 --> Model Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Config Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:31:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:31:50 --> URI Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Router Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Output Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Security Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Input Class Initialized
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> XSS Filtering completed
DEBUG - 2013-12-16 12:31:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:31:50 --> Language Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Language Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Config Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Loader Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Controller Class Initialized
DEBUG - 2013-12-16 12:31:50 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:31:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:31:50 --> Session Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:31:50 --> Session routines successfully run
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:31:50 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:31:50 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:31:50 --> Model Class Initialized
DEBUG - 2013-12-16 12:31:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:31:50 --> Model Class Initialized
DEBUG - 2013-12-16 12:31:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:31:50 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:31:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:31:50 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:31:50 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:31:50 --> Model Class Initialized
ERROR - 2013-12-16 12:31:50 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/index.php/upload/companylogo/feed.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
ERROR - 2013-12-16 12:31:50 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpCE6F.tmp' to 'http://localhost/renalemr/index.php/upload/companylogo/feed.png' D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
DEBUG - 2013-12-16 12:31:56 --> Config Class Initialized
DEBUG - 2013-12-16 12:31:56 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:31:56 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:31:56 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:31:56 --> URI Class Initialized
DEBUG - 2013-12-16 12:31:56 --> Router Class Initialized
ERROR - 2013-12-16 12:31:56 --> 404 Page Not Found --> 
DEBUG - 2013-12-16 12:32:29 --> Config Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:32:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:32:29 --> URI Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Router Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Output Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Security Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Input Class Initialized
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:32:29 --> Language Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Language Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Config Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Loader Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Controller Class Initialized
DEBUG - 2013-12-16 12:32:29 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:32:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:32:29 --> Session Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:32:29 --> Session routines successfully run
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:32:29 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:32:29 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:32:29 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:32:29 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:32:29 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:32:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:32:29 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:32:29 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:32:29 --> Model Class Initialized
ERROR - 2013-12-16 12:32:29 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/index.php/upload/companylogo/feed.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
ERROR - 2013-12-16 12:32:29 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php6977.tmp' to 'http://localhost/renalemr/index.php/upload/companylogo/feed.png' D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
DEBUG - 2013-12-16 12:32:42 --> Config Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:32:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:32:42 --> URI Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Router Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Output Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Security Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Input Class Initialized
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:32:42 --> Language Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Language Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Config Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Loader Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Controller Class Initialized
DEBUG - 2013-12-16 12:32:42 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:32:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:32:42 --> Session Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:32:42 --> Session routines successfully run
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:32:42 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:32:42 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:32:42 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:32:42 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:32:42 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:32:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:32:42 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:32:42 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:32:42 --> Model Class Initialized
ERROR - 2013-12-16 12:32:42 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/index.php/upload/companylogo/feed.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
ERROR - 2013-12-16 12:32:42 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php9C1B.tmp' to 'http://localhost/renalemr/index.php/upload/companylogo/feed.png' D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
DEBUG - 2013-12-16 12:32:44 --> Config Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:32:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:32:44 --> URI Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Router Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Output Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Security Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Input Class Initialized
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:32:44 --> Language Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Language Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Config Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Loader Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Controller Class Initialized
DEBUG - 2013-12-16 12:32:44 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:32:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:32:44 --> Session Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:32:44 --> Session routines successfully run
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:32:44 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:32:44 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:32:44 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:32:44 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:32:44 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:32:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:32:44 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:32:44 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:32:44 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:44 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 12:32:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 12:32:44 --> Final output sent to browser
DEBUG - 2013-12-16 12:32:44 --> Total execution time: 0.0671
DEBUG - 2013-12-16 12:32:47 --> Config Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:32:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:32:47 --> URI Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Router Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Output Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Security Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Input Class Initialized
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> XSS Filtering completed
DEBUG - 2013-12-16 12:32:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:32:47 --> Language Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Language Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Config Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Loader Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Controller Class Initialized
DEBUG - 2013-12-16 12:32:47 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:32:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:32:47 --> Session Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:32:47 --> Session routines successfully run
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:32:47 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:32:47 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:32:47 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:32:47 --> Model Class Initialized
DEBUG - 2013-12-16 12:32:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:32:47 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:32:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:32:47 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:32:47 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:32:47 --> Model Class Initialized
ERROR - 2013-12-16 12:32:47 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/index.php/upload/companylogo/mail.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
ERROR - 2013-12-16 12:32:47 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpAE83.tmp' to 'http://localhost/renalemr/index.php/upload/companylogo/mail.png' D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
DEBUG - 2013-12-16 12:33:20 --> Config Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:33:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:33:20 --> URI Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Router Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Output Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Security Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Input Class Initialized
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> XSS Filtering completed
DEBUG - 2013-12-16 12:33:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:33:20 --> Language Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Language Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Config Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Loader Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Controller Class Initialized
DEBUG - 2013-12-16 12:33:20 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:33:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:33:20 --> Session Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:33:20 --> Session routines successfully run
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:33:20 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:33:20 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:33:20 --> Model Class Initialized
DEBUG - 2013-12-16 12:33:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:33:20 --> Model Class Initialized
DEBUG - 2013-12-16 12:33:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:33:20 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:33:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:33:20 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:33:20 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:33:20 --> Model Class Initialized
ERROR - 2013-12-16 12:33:20 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/upload/companylogo/mail.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
ERROR - 2013-12-16 12:33:20 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php2FC4.tmp' to 'http://localhost/renalemr/upload/companylogo/mail.png' D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 97
DEBUG - 2013-12-16 12:55:29 --> Config Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:55:29 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:55:29 --> URI Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Router Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Output Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Security Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Input Class Initialized
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:29 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:55:29 --> Language Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Language Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Config Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Loader Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Controller Class Initialized
DEBUG - 2013-12-16 12:55:29 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:55:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:55:29 --> Session Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:55:29 --> Session routines successfully run
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:55:29 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:55:29 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:55:29 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:55:29 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:55:29 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:55:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:55:29 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:55:29 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:55:29 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:29 --> Upload Class Initialized
DEBUG - 2013-12-16 12:55:29 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 12:55:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 12:55:29 --> Final output sent to browser
DEBUG - 2013-12-16 12:55:29 --> Total execution time: 0.0918
DEBUG - 2013-12-16 12:55:33 --> Config Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:55:33 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:55:33 --> URI Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Router Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Output Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Security Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Input Class Initialized
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:55:33 --> Language Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Language Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Config Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Loader Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Controller Class Initialized
DEBUG - 2013-12-16 12:55:33 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:55:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:55:33 --> Session Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:55:33 --> Session routines successfully run
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:55:33 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:55:33 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:55:33 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:55:33 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:55:33 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:55:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:55:33 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:55:33 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:55:33 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Upload Class Initialized
DEBUG - 2013-12-16 12:55:33 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 12:55:33 --> The upload path does not appear to be valid.
ERROR - 2013-12-16 12:55:33 --> Severity: Warning  --> Missing argument 2 for Mdl_admin::save(), called in D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php on line 59 and defined D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 38
ERROR - 2013-12-16 12:55:33 --> Severity: Notice  --> Undefined variable: value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 43
DEBUG - 2013-12-16 12:55:49 --> Config Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:55:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:55:49 --> URI Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Router Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Output Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Security Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Input Class Initialized
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:55:49 --> Language Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Language Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Config Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Loader Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Controller Class Initialized
DEBUG - 2013-12-16 12:55:49 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:55:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:55:49 --> Session Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:55:49 --> Session routines successfully run
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:55:49 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:55:49 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:55:49 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:55:49 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:55:49 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:55:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:55:49 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:55:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:55:49 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:49 --> Upload Class Initialized
DEBUG - 2013-12-16 12:55:49 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 12:55:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 12:55:49 --> Final output sent to browser
DEBUG - 2013-12-16 12:55:49 --> Total execution time: 0.0655
DEBUG - 2013-12-16 12:55:52 --> Config Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Hooks Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Utf8 Class Initialized
DEBUG - 2013-12-16 12:55:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 12:55:52 --> URI Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Router Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Output Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Security Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Input Class Initialized
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> XSS Filtering completed
DEBUG - 2013-12-16 12:55:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 12:55:52 --> Language Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Language Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Config Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Loader Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Controller Class Initialized
DEBUG - 2013-12-16 12:55:52 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 12:55:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 12:55:52 --> Session Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: string_helper
DEBUG - 2013-12-16 12:55:52 --> Session routines successfully run
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: url_helper
DEBUG - 2013-12-16 12:55:52 --> Database Driver Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: form_helper
DEBUG - 2013-12-16 12:55:52 --> Form Validation Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: number_helper
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: date_helper
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 12:55:52 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 12:55:52 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 12:55:52 --> Helper loaded: language_helper
DEBUG - 2013-12-16 12:55:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 12:55:52 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 12:55:52 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 12:55:52 --> Model Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Upload Class Initialized
DEBUG - 2013-12-16 12:55:52 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 12:55:52 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:02:13 --> Config Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:02:13 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:02:13 --> URI Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Router Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Output Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Security Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Input Class Initialized
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:02:13 --> Language Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Language Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Config Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Loader Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Controller Class Initialized
DEBUG - 2013-12-16 13:02:13 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:02:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:02:13 --> Session Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:02:13 --> Session routines successfully run
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:02:13 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:02:13 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:02:13 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:02:13 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:02:13 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:02:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:02:13 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:02:13 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:02:13 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:13 --> Upload Class Initialized
DEBUG - 2013-12-16 13:02:13 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:02:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:02:13 --> Final output sent to browser
DEBUG - 2013-12-16 13:02:13 --> Total execution time: 0.0647
DEBUG - 2013-12-16 13:02:16 --> Config Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:02:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:02:16 --> URI Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Router Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Output Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Security Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Input Class Initialized
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:02:16 --> Language Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Language Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Config Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Loader Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Controller Class Initialized
DEBUG - 2013-12-16 13:02:16 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:02:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:02:16 --> Session Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:02:16 --> Session routines successfully run
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:02:16 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:02:16 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:02:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:02:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:02:16 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:02:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:02:16 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:02:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:02:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Upload Class Initialized
DEBUG - 2013-12-16 13:02:16 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:02:16 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:02:42 --> Config Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:02:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:02:42 --> URI Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Router Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Output Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Security Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Input Class Initialized
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:02:42 --> Language Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Language Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Config Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Loader Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Controller Class Initialized
DEBUG - 2013-12-16 13:02:42 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:02:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:02:42 --> Session Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:02:42 --> Session routines successfully run
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:02:42 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:02:42 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:02:42 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:02:42 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:02:42 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:02:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:02:42 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:02:42 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:02:42 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:42 --> Upload Class Initialized
DEBUG - 2013-12-16 13:02:42 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:02:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:02:42 --> Final output sent to browser
DEBUG - 2013-12-16 13:02:42 --> Total execution time: 0.0636
DEBUG - 2013-12-16 13:02:45 --> Config Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:02:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:02:45 --> URI Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Router Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Output Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Security Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Input Class Initialized
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:02:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:02:45 --> Language Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Language Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Config Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Loader Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Controller Class Initialized
DEBUG - 2013-12-16 13:02:45 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:02:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:02:45 --> Session Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:02:45 --> Session routines successfully run
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:02:45 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:02:45 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:02:45 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:02:45 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:02:45 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:02:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:02:45 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:02:45 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:02:45 --> Model Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Upload Class Initialized
DEBUG - 2013-12-16 13:02:45 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:02:45 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:03:12 --> Config Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:03:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:03:12 --> URI Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Router Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Output Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Security Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Input Class Initialized
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:03:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:03:12 --> Language Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Language Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Config Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Loader Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Controller Class Initialized
DEBUG - 2013-12-16 13:03:12 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:03:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:03:12 --> Session Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:03:12 --> Session routines successfully run
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:03:12 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:03:12 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:03:12 --> Model Class Initialized
DEBUG - 2013-12-16 13:03:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:03:12 --> Model Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:03:12 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:03:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:03:12 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:03:12 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:03:12 --> Model Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Upload Class Initialized
DEBUG - 2013-12-16 13:03:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:03:12 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:04:07 --> Config Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:04:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:04:07 --> URI Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Router Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Output Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Security Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Input Class Initialized
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:04:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:04:07 --> Language Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Language Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Config Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Loader Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Controller Class Initialized
DEBUG - 2013-12-16 13:04:07 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:04:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:04:07 --> Session Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:04:07 --> Session routines successfully run
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:04:07 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:04:07 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:04:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:04:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:04:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:04:07 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:04:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:04:07 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:04:07 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:04:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Upload Class Initialized
DEBUG - 2013-12-16 13:04:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:04:07 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:05:21 --> Config Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:05:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:05:21 --> URI Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Router Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Output Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Security Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Input Class Initialized
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:05:21 --> Language Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Language Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Config Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Loader Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Controller Class Initialized
DEBUG - 2013-12-16 13:05:21 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:05:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:05:21 --> Session Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:05:21 --> Session routines successfully run
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:05:21 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:05:21 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:05:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:05:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:05:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:05:21 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:05:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:05:21 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:05:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:05:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Upload Class Initialized
DEBUG - 2013-12-16 13:05:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:05:21 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:05:32 --> Config Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:05:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:05:32 --> URI Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Router Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Output Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Security Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Input Class Initialized
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:05:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:05:32 --> Language Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Language Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Config Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Loader Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Controller Class Initialized
DEBUG - 2013-12-16 13:05:32 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:05:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:05:32 --> Session Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:05:32 --> Session routines successfully run
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:05:32 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:05:32 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:05:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:05:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:05:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:05:32 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:05:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:05:32 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:05:32 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:05:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Upload Class Initialized
DEBUG - 2013-12-16 13:05:32 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:05:32 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:08:16 --> Config Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:08:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:08:16 --> URI Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Router Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Output Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Security Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Input Class Initialized
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:08:16 --> Language Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Language Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Config Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Loader Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Controller Class Initialized
DEBUG - 2013-12-16 13:08:16 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:08:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:08:16 --> Session Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:08:16 --> Session routines successfully run
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:08:16 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:08:16 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:08:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:08:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:08:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:08:16 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:08:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:08:16 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:08:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:08:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Upload Class Initialized
DEBUG - 2013-12-16 13:08:16 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:08:16 --> You did not select a file to upload.
DEBUG - 2013-12-16 13:08:18 --> Config Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:08:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:08:18 --> URI Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Router Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Output Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Security Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Input Class Initialized
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:08:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:08:18 --> Language Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Language Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Config Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Loader Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Controller Class Initialized
DEBUG - 2013-12-16 13:08:18 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:08:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:08:18 --> Session Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:08:18 --> Session routines successfully run
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:08:18 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:08:18 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:08:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:08:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:08:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:08:18 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:08:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:08:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:08:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:08:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Upload Class Initialized
DEBUG - 2013-12-16 13:08:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:08:18 --> You did not select a file to upload.
DEBUG - 2013-12-16 13:09:42 --> Config Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:09:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:09:42 --> URI Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Router Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Output Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Security Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Input Class Initialized
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:09:42 --> Language Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Language Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Config Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Loader Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Controller Class Initialized
DEBUG - 2013-12-16 13:09:42 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:09:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:09:42 --> Session Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:09:42 --> Session routines successfully run
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:09:42 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:09:42 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:09:42 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:09:42 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:09:42 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:09:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:09:42 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:09:42 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:09:42 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Upload Class Initialized
DEBUG - 2013-12-16 13:09:42 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:09:42 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:09:51 --> Config Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:09:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:09:51 --> URI Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Router Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Output Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Security Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Input Class Initialized
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:09:51 --> Language Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Language Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Config Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Loader Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Controller Class Initialized
DEBUG - 2013-12-16 13:09:51 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:09:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:09:51 --> Session Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:09:51 --> Session routines successfully run
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:09:51 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:09:51 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:09:51 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:09:51 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:09:51 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:09:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:09:51 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:09:51 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:09:51 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Upload Class Initialized
DEBUG - 2013-12-16 13:09:51 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:09:51 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:09:55 --> Config Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:09:55 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:09:55 --> URI Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Router Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Output Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Security Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Input Class Initialized
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:09:55 --> Language Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Language Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Config Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Loader Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Controller Class Initialized
DEBUG - 2013-12-16 13:09:55 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:09:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:09:55 --> Session Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:09:55 --> Session routines successfully run
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:09:55 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:09:55 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:09:55 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:09:55 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:09:55 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:09:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:09:55 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:09:55 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:09:55 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:55 --> Upload Class Initialized
DEBUG - 2013-12-16 13:09:55 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:09:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:09:55 --> Final output sent to browser
DEBUG - 2013-12-16 13:09:55 --> Total execution time: 0.0673
DEBUG - 2013-12-16 13:09:59 --> Config Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:09:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:09:59 --> URI Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Router Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Output Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Security Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Input Class Initialized
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:09:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:09:59 --> Language Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Language Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Config Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Loader Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Controller Class Initialized
DEBUG - 2013-12-16 13:09:59 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:09:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:09:59 --> Session Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:09:59 --> Session routines successfully run
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:09:59 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:09:59 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:09:59 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:09:59 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:09:59 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:09:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:09:59 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:09:59 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:09:59 --> Model Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Upload Class Initialized
DEBUG - 2013-12-16 13:09:59 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:09:59 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:14:00 --> Config Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:14:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:14:00 --> URI Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Router Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Output Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Security Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Input Class Initialized
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:14:00 --> Language Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Language Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Config Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Loader Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Controller Class Initialized
DEBUG - 2013-12-16 13:14:00 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:14:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:14:00 --> Session Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:14:00 --> Session routines successfully run
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:14:00 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:14:00 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:14:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:14:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:14:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:14:00 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:14:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:14:00 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:14:00 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:14:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Upload Class Initialized
DEBUG - 2013-12-16 13:14:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:14:00 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:14:23 --> Config Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:14:23 --> URI Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Router Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Output Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Security Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Input Class Initialized
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:14:23 --> Language Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Language Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Config Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Loader Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Controller Class Initialized
DEBUG - 2013-12-16 13:14:23 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:14:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:14:23 --> Session Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:14:23 --> Session routines successfully run
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:14:23 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:14:23 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:14:23 --> Model Class Initialized
DEBUG - 2013-12-16 13:14:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:14:23 --> Model Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:14:23 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:14:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:14:23 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:14:23 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:14:23 --> Model Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Upload Class Initialized
DEBUG - 2013-12-16 13:14:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:14:23 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:31:22 --> Config Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:31:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:31:22 --> URI Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Router Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Output Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Security Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Input Class Initialized
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:31:22 --> Language Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Language Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Config Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Loader Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Controller Class Initialized
DEBUG - 2013-12-16 13:31:22 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:31:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:31:22 --> Session Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:31:22 --> Session routines successfully run
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:31:22 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:31:22 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:31:22 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:31:22 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:31:22 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:31:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:31:22 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:31:22 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:31:22 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Upload Class Initialized
DEBUG - 2013-12-16 13:31:22 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:31:22 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:31:37 --> Config Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:31:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:31:37 --> URI Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Router Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Output Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Security Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Input Class Initialized
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:31:37 --> Language Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Language Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Config Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Loader Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Controller Class Initialized
DEBUG - 2013-12-16 13:31:37 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:31:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:31:37 --> Session Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:31:37 --> Session routines successfully run
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:31:37 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:31:37 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:31:37 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:31:37 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:31:37 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:31:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:31:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:31:37 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:31:37 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Upload Class Initialized
DEBUG - 2013-12-16 13:31:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:31:37 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:31:57 --> Config Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:31:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:31:57 --> URI Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Router Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Output Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Security Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Input Class Initialized
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:31:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:31:57 --> Language Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Language Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Config Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Loader Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Controller Class Initialized
DEBUG - 2013-12-16 13:31:57 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:31:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:31:57 --> Session Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:31:57 --> Session routines successfully run
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:31:57 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:31:57 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:31:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:31:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:31:57 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:31:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:31:57 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:31:57 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:31:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Upload Class Initialized
DEBUG - 2013-12-16 13:31:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:31:57 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:32:38 --> Config Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:32:38 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:32:38 --> URI Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Router Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Output Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Security Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Input Class Initialized
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:32:38 --> Language Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Language Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Config Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Loader Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Controller Class Initialized
DEBUG - 2013-12-16 13:32:38 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:32:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:32:38 --> Session Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:32:38 --> Session routines successfully run
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:32:38 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:32:38 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:32:38 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:32:38 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:32:38 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:32:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:32:38 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:32:38 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:32:38 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Upload Class Initialized
DEBUG - 2013-12-16 13:32:38 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:32:38 --> You did not select a file to upload.
DEBUG - 2013-12-16 13:32:40 --> Config Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:32:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:32:40 --> URI Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Router Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Output Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Security Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Input Class Initialized
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:32:40 --> Language Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Language Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Config Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Loader Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Controller Class Initialized
DEBUG - 2013-12-16 13:32:40 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:32:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:32:40 --> Session Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:32:40 --> Session routines successfully run
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:32:40 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:32:40 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:32:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:32:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:32:40 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:32:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:32:40 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:32:40 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:32:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:40 --> Upload Class Initialized
DEBUG - 2013-12-16 13:32:40 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:32:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:32:40 --> Final output sent to browser
DEBUG - 2013-12-16 13:32:40 --> Total execution time: 0.0643
DEBUG - 2013-12-16 13:32:44 --> Config Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:32:44 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:32:44 --> URI Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Router Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Output Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Security Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Input Class Initialized
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> XSS Filtering completed
DEBUG - 2013-12-16 13:32:44 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:32:44 --> Language Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Language Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Config Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Loader Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Controller Class Initialized
DEBUG - 2013-12-16 13:32:44 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:32:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:32:44 --> Session Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:32:44 --> Session routines successfully run
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:32:44 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:32:44 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:32:44 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:32:44 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:32:44 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:32:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:32:44 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:32:44 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:32:44 --> Model Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Upload Class Initialized
DEBUG - 2013-12-16 13:32:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:32:44 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:34:15 --> Config Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:34:15 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:34:15 --> URI Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Router Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Output Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Security Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Input Class Initialized
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> XSS Filtering completed
DEBUG - 2013-12-16 13:34:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:34:15 --> Language Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Language Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Config Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Loader Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Controller Class Initialized
DEBUG - 2013-12-16 13:34:15 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:34:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:34:15 --> Session Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:34:15 --> Session routines successfully run
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:34:15 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:34:15 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:34:15 --> Model Class Initialized
DEBUG - 2013-12-16 13:34:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:34:15 --> Model Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:34:15 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:34:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:34:15 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:34:15 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:34:15 --> Model Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Upload Class Initialized
DEBUG - 2013-12-16 13:34:15 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:34:15 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:37:24 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:24 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:24 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:24 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:24 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:24 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:24 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:24 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:24 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:24 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:24 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:24 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:24 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:24 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:24 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:24 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:24 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:24 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:24 --> Total execution time: 0.0682
DEBUG - 2013-12-16 13:37:25 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:25 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:25 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:25 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:25 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:25 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:25 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:25 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:25 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:25 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:25 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:25 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:25 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:25 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:25 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:25 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:25 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:25 --> Total execution time: 0.0617
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:26 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:26 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:26 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:26 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:26 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:26 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:26 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:26 --> Total execution time: 0.0714
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:26 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:26 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:26 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:26 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:26 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:26 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:26 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:26 --> Total execution time: 0.0714
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:26 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:26 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:26 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:26 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:26 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:26 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:26 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:26 --> Total execution time: 0.0663
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:26 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:26 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:26 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:26 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:26 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:26 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:26 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:26 --> Total execution time: 0.0551
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:26 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:26 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:26 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:26 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:26 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:26 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:26 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:26 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:26 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:26 --> Total execution time: 0.0687
DEBUG - 2013-12-16 13:37:27 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:27 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:27 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:27 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:27 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:27 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:27 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:27 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:27 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:27 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:27 --> Total execution time: 0.0744
DEBUG - 2013-12-16 13:37:27 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:27 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:27 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:27 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:27 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:27 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:27 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:27 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:27 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:27 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:27 --> Total execution time: 0.0784
DEBUG - 2013-12-16 13:37:27 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:27 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:27 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:27 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:27 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:27 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:27 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:27 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:27 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:27 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:27 --> Total execution time: 0.0713
DEBUG - 2013-12-16 13:37:27 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:37:27 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:37:27 --> URI Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Router Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Output Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Security Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Input Class Initialized
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> XSS Filtering completed
DEBUG - 2013-12-16 13:37:27 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:37:27 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Language Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Config Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Loader Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Controller Class Initialized
DEBUG - 2013-12-16 13:37:27 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:37:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:37:27 --> Session Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:37:27 --> Session routines successfully run
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:37:27 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:37:27 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:37:27 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:37:27 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:37:27 --> Model Class Initialized
DEBUG - 2013-12-16 13:37:27 --> Upload Class Initialized
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:37:27 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:37:27 --> Final output sent to browser
DEBUG - 2013-12-16 13:37:27 --> Total execution time: 0.0538
DEBUG - 2013-12-16 13:38:23 --> Config Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:38:23 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:38:23 --> URI Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Router Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Output Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Security Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Input Class Initialized
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:38:23 --> Language Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Language Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Config Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Loader Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Controller Class Initialized
DEBUG - 2013-12-16 13:38:23 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:38:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:38:23 --> Session Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:38:23 --> Session routines successfully run
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:38:23 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:38:23 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:38:23 --> Model Class Initialized
DEBUG - 2013-12-16 13:38:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:38:23 --> Model Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:38:23 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:38:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:38:23 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:38:23 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:38:23 --> Model Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Upload Class Initialized
DEBUG - 2013-12-16 13:38:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:38:23 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:38:51 --> Config Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:38:51 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:38:51 --> URI Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Router Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Output Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Security Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Input Class Initialized
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> XSS Filtering completed
DEBUG - 2013-12-16 13:38:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:38:51 --> Language Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Language Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Config Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Loader Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Controller Class Initialized
DEBUG - 2013-12-16 13:38:51 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:38:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:38:51 --> Session Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:38:51 --> Session routines successfully run
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:38:51 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:38:51 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:38:51 --> Model Class Initialized
DEBUG - 2013-12-16 13:38:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:38:51 --> Model Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:38:51 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:38:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:38:51 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:38:51 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:38:51 --> Model Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Upload Class Initialized
DEBUG - 2013-12-16 13:38:51 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:38:51 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:39:03 --> Config Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:39:03 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:39:03 --> URI Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Router Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Output Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Security Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Input Class Initialized
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> XSS Filtering completed
DEBUG - 2013-12-16 13:39:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:39:03 --> Language Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Language Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Config Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Loader Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Controller Class Initialized
DEBUG - 2013-12-16 13:39:03 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:39:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:39:03 --> Session Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:39:03 --> Session routines successfully run
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:39:03 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:39:03 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:39:03 --> Model Class Initialized
DEBUG - 2013-12-16 13:39:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:39:03 --> Model Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:39:03 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:39:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:39:03 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:39:03 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:39:03 --> Model Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Upload Class Initialized
DEBUG - 2013-12-16 13:39:03 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:39:03 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:41:30 --> Config Class Initialized
DEBUG - 2013-12-16 13:41:30 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:41:30 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:41:30 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:41:30 --> URI Class Initialized
DEBUG - 2013-12-16 13:41:30 --> Router Class Initialized
ERROR - 2013-12-16 13:41:30 --> 404 Page Not Found --> 
DEBUG - 2013-12-16 13:42:11 --> Config Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:42:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:42:11 --> URI Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Router Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Output Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Security Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Input Class Initialized
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:42:11 --> Language Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Language Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Config Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Loader Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Controller Class Initialized
DEBUG - 2013-12-16 13:42:11 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:42:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:42:11 --> Session Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:42:11 --> Session routines successfully run
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:42:11 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:42:11 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:42:11 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:42:11 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:42:11 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:42:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:42:11 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:42:11 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:42:11 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Upload Class Initialized
DEBUG - 2013-12-16 13:42:11 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:42:11 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:42:14 --> Config Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:42:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:42:14 --> URI Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Router Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Output Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Security Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Input Class Initialized
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:42:14 --> Language Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Language Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Config Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Loader Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Controller Class Initialized
DEBUG - 2013-12-16 13:42:14 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:42:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:42:14 --> Session Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:42:14 --> Session routines successfully run
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:42:14 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:42:14 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:42:14 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:42:14 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:42:14 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:42:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:42:14 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:42:14 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:42:14 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:14 --> Upload Class Initialized
DEBUG - 2013-12-16 13:42:14 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:42:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:42:14 --> Final output sent to browser
DEBUG - 2013-12-16 13:42:14 --> Total execution time: 0.0547
DEBUG - 2013-12-16 13:42:31 --> Config Class Initialized
DEBUG - 2013-12-16 13:42:31 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:42:31 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:42:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:42:31 --> URI Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Router Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Output Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Security Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Input Class Initialized
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:42:32 --> Language Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Language Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Config Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Loader Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Controller Class Initialized
DEBUG - 2013-12-16 13:42:32 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:42:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:42:32 --> Session Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:42:32 --> Session routines successfully run
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:42:32 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:42:32 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:42:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:42:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:42:32 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:42:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:42:32 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:42:32 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:42:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:32 --> Upload Class Initialized
DEBUG - 2013-12-16 13:42:32 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:42:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:42:32 --> Final output sent to browser
DEBUG - 2013-12-16 13:42:32 --> Total execution time: 0.0638
DEBUG - 2013-12-16 13:42:35 --> Config Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:42:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:42:35 --> URI Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Router Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Output Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Security Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Input Class Initialized
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:42:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:42:35 --> Language Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Language Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Config Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Loader Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Controller Class Initialized
DEBUG - 2013-12-16 13:42:35 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:42:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:42:35 --> Session Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:42:35 --> Session routines successfully run
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:42:35 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:42:35 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:42:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:42:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:42:35 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:42:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:42:35 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:42:35 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:42:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Upload Class Initialized
DEBUG - 2013-12-16 13:42:35 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:42:35 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:43:37 --> Config Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:43:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:43:37 --> URI Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Router Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Output Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Security Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Input Class Initialized
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> XSS Filtering completed
DEBUG - 2013-12-16 13:43:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:43:37 --> Language Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Language Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Config Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Loader Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Controller Class Initialized
DEBUG - 2013-12-16 13:43:37 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:43:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:43:37 --> Session Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:43:37 --> Session routines successfully run
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:43:37 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:43:37 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:43:37 --> Model Class Initialized
DEBUG - 2013-12-16 13:43:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:43:37 --> Model Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:43:37 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:43:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:43:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:43:37 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:43:37 --> Model Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Upload Class Initialized
DEBUG - 2013-12-16 13:43:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:43:37 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:44:31 --> Config Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:44:31 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:44:31 --> URI Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Router Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Output Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Security Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Input Class Initialized
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> XSS Filtering completed
DEBUG - 2013-12-16 13:44:31 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:44:31 --> Language Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Language Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Config Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Loader Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Controller Class Initialized
DEBUG - 2013-12-16 13:44:31 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:44:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:44:31 --> Session Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:44:31 --> Session routines successfully run
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:44:31 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:44:31 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:44:31 --> Model Class Initialized
DEBUG - 2013-12-16 13:44:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:44:31 --> Model Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:44:31 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:44:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:44:31 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:44:31 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:44:31 --> Model Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Upload Class Initialized
DEBUG - 2013-12-16 13:44:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:44:31 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:45:00 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:45:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:45:00 --> URI Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Router Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Output Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Security Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Input Class Initialized
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:45:00 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Loader Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Controller Class Initialized
DEBUG - 2013-12-16 13:45:00 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:45:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:45:00 --> Session Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:45:00 --> Session routines successfully run
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:45:00 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:45:00 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:45:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:45:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:45:00 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:45:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:45:00 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:45:00 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:45:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Upload Class Initialized
DEBUG - 2013-12-16 13:45:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:45:00 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:45:17 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:45:17 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:45:17 --> URI Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Router Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Output Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Security Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Input Class Initialized
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:45:17 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Loader Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Controller Class Initialized
DEBUG - 2013-12-16 13:45:17 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:45:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:45:17 --> Session Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:45:17 --> Session routines successfully run
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:45:17 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:45:17 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:45:17 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:45:17 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:45:17 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:45:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:45:17 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:45:17 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:45:17 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Upload Class Initialized
DEBUG - 2013-12-16 13:45:17 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:45:17 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:45:20 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:20 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:45:20 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:45:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:45:20 --> URI Class Initialized
DEBUG - 2013-12-16 13:45:20 --> Router Class Initialized
DEBUG - 2013-12-16 13:45:20 --> Output Class Initialized
DEBUG - 2013-12-16 13:45:20 --> Security Class Initialized
DEBUG - 2013-12-16 13:45:20 --> Input Class Initialized
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:45:21 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Loader Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Controller Class Initialized
DEBUG - 2013-12-16 13:45:21 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:45:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:45:21 --> Session Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:45:21 --> Session routines successfully run
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:45:21 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:45:21 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:45:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:45:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:45:21 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:45:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:45:21 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:45:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:45:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Upload Class Initialized
DEBUG - 2013-12-16 13:45:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:45:21 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:45:35 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:45:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:45:35 --> URI Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Router Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Output Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Security Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Input Class Initialized
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:45:35 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Loader Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Controller Class Initialized
DEBUG - 2013-12-16 13:45:35 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:45:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:45:35 --> Session Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:45:35 --> Session routines successfully run
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:45:35 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:45:35 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:45:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:45:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:45:35 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:45:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:45:35 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:45:35 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:45:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Upload Class Initialized
DEBUG - 2013-12-16 13:45:35 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:45:35 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:45:57 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:45:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:45:57 --> URI Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Router Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Output Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Security Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Input Class Initialized
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:45:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:45:57 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Language Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Config Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Loader Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Controller Class Initialized
DEBUG - 2013-12-16 13:45:57 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:45:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:45:57 --> Session Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:45:57 --> Session routines successfully run
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:45:57 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:45:57 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:45:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:45:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:45:57 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:45:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:45:57 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:45:57 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:45:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Upload Class Initialized
DEBUG - 2013-12-16 13:45:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:45:57 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:46:00 --> Config Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:46:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:46:00 --> URI Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Router Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Output Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Security Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Input Class Initialized
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:46:00 --> Language Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Language Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Config Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Loader Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Controller Class Initialized
DEBUG - 2013-12-16 13:46:00 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:46:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:46:00 --> Session Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:46:00 --> Session routines successfully run
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:46:00 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:46:00 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:46:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:46:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:46:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:46:00 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:46:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:46:00 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:46:00 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:46:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Upload Class Initialized
DEBUG - 2013-12-16 13:46:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:46:00 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:46:18 --> Config Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:46:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:46:18 --> URI Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Router Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Output Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Security Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Input Class Initialized
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:46:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:46:18 --> Language Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Language Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Config Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Loader Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Controller Class Initialized
DEBUG - 2013-12-16 13:46:18 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:46:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:46:18 --> Session Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:46:18 --> Session routines successfully run
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:46:18 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:46:18 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:46:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:46:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:46:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:46:18 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:46:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:46:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:46:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:46:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Upload Class Initialized
DEBUG - 2013-12-16 13:46:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:46:18 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:47:40 --> Config Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:47:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:47:40 --> URI Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Router Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Output Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Security Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Input Class Initialized
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:47:40 --> Language Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Language Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Config Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Loader Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Controller Class Initialized
DEBUG - 2013-12-16 13:47:40 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:47:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:47:40 --> Session Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:47:40 --> Session routines successfully run
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:47:40 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:47:40 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:47:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:47:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:47:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:47:40 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:47:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:47:40 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:47:40 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:47:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Upload Class Initialized
DEBUG - 2013-12-16 13:47:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:47:40 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:47:43 --> Config Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:47:43 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:47:43 --> URI Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Router Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Output Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Security Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Input Class Initialized
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> XSS Filtering completed
DEBUG - 2013-12-16 13:47:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:47:43 --> Language Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Language Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Config Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Loader Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Controller Class Initialized
DEBUG - 2013-12-16 13:47:43 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:47:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:47:43 --> Session Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:47:43 --> Session routines successfully run
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:47:43 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:47:43 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:47:43 --> Model Class Initialized
DEBUG - 2013-12-16 13:47:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:47:43 --> Model Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:47:43 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:47:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:47:43 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:47:43 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:47:43 --> Model Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Upload Class Initialized
DEBUG - 2013-12-16 13:47:43 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:47:43 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:48:05 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:48:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:48:05 --> URI Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Router Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Output Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Security Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Input Class Initialized
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:48:05 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Loader Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Controller Class Initialized
DEBUG - 2013-12-16 13:48:05 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:48:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:48:05 --> Session Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:48:05 --> Session routines successfully run
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:48:05 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:48:05 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:48:05 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:48:05 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:48:05 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:48:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:48:05 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:48:05 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:48:05 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Upload Class Initialized
DEBUG - 2013-12-16 13:48:05 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:48:05 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:48:07 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:48:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:48:07 --> URI Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Router Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Output Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Security Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Input Class Initialized
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:48:07 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Loader Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Controller Class Initialized
DEBUG - 2013-12-16 13:48:07 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:48:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:48:07 --> Session Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:48:07 --> Session routines successfully run
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:48:07 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:48:07 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:48:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:48:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:48:07 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:48:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:48:07 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:48:07 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:48:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Upload Class Initialized
DEBUG - 2013-12-16 13:48:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:48:07 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:48:08 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:48:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:48:08 --> URI Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Router Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Output Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Security Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Input Class Initialized
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:48:08 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Loader Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Controller Class Initialized
DEBUG - 2013-12-16 13:48:08 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:48:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:48:08 --> Session Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:48:08 --> Session routines successfully run
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:48:08 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:48:08 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:48:08 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:48:08 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:48:08 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:48:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:48:08 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:48:08 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:48:08 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Upload Class Initialized
DEBUG - 2013-12-16 13:48:08 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:48:08 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:48:11 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:48:11 --> URI Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Router Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Output Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Security Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Input Class Initialized
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:11 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:48:11 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Loader Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Controller Class Initialized
DEBUG - 2013-12-16 13:48:11 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:48:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:48:11 --> Session Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:48:11 --> Session routines successfully run
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:48:11 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:48:11 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:48:11 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:48:11 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:48:11 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:48:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:48:11 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:48:11 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:48:11 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:11 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 13:48:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 13:48:11 --> Final output sent to browser
DEBUG - 2013-12-16 13:48:11 --> Total execution time: 0.0717
DEBUG - 2013-12-16 13:48:14 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:48:14 --> URI Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Router Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Output Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Security Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Input Class Initialized
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:48:14 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Loader Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Controller Class Initialized
DEBUG - 2013-12-16 13:48:14 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:48:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:48:14 --> Session Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:48:14 --> Session routines successfully run
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:48:14 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:48:14 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:48:14 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:48:14 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:48:14 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:48:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:48:14 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:48:14 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:48:14 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Upload Class Initialized
DEBUG - 2013-12-16 13:48:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:48:14 --> The upload path does not appear to be valid.
DEBUG - 2013-12-16 13:48:47 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:48:47 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:48:47 --> URI Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Router Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Output Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Security Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Input Class Initialized
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:48:47 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Loader Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Controller Class Initialized
DEBUG - 2013-12-16 13:48:47 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:48:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:48:47 --> Session Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:48:47 --> Session routines successfully run
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:48:47 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:48:47 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:48:47 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:48:47 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:48:47 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:48:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:48:47 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:48:47 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:48:47 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Upload Class Initialized
DEBUG - 2013-12-16 13:48:47 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:48:47 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:48:47 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:48:49 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:48:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:48:49 --> URI Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Router Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Output Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Security Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Input Class Initialized
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:48:49 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Loader Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Controller Class Initialized
DEBUG - 2013-12-16 13:48:49 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:48:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:48:49 --> Session Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:48:49 --> Session routines successfully run
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:48:49 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:48:49 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:48:49 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:48:49 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:48:49 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:48:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:48:49 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:48:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:48:49 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Upload Class Initialized
DEBUG - 2013-12-16 13:48:49 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:48:49 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:48:49 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:48:58 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:48:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:48:58 --> URI Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Router Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Output Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Security Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Input Class Initialized
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:48:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:48:58 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Language Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Config Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Loader Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Controller Class Initialized
DEBUG - 2013-12-16 13:48:58 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:48:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:48:58 --> Session Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:48:58 --> Session routines successfully run
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:48:58 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:48:58 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:48:58 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:48:58 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:48:58 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:48:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:48:58 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:48:58 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:48:58 --> Model Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Upload Class Initialized
DEBUG - 2013-12-16 13:48:58 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:48:58 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:48:58 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:49:00 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:49:00 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:49:00 --> URI Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Router Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Output Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Security Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Input Class Initialized
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:49:00 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Loader Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Controller Class Initialized
DEBUG - 2013-12-16 13:49:00 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:49:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:49:00 --> Session Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:49:00 --> Session routines successfully run
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:49:00 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:49:00 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:49:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:49:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:49:00 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:49:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:49:00 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:49:00 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:49:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Upload Class Initialized
DEBUG - 2013-12-16 13:49:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:49:00 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:49:00 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:49:06 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:49:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:49:06 --> URI Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Router Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Output Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Security Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Input Class Initialized
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:49:06 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Loader Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Controller Class Initialized
DEBUG - 2013-12-16 13:49:06 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:49:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:49:06 --> Session Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:49:06 --> Session routines successfully run
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:49:06 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:49:06 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:49:06 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:49:06 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:49:06 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:49:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:49:06 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:49:06 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:49:06 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Upload Class Initialized
DEBUG - 2013-12-16 13:49:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:49:06 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:49:06 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:49:07 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:49:07 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:49:07 --> URI Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Router Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Output Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Security Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Input Class Initialized
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:07 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:49:07 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Loader Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Controller Class Initialized
DEBUG - 2013-12-16 13:49:07 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:49:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:49:07 --> Session Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:49:07 --> Session routines successfully run
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:49:07 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:49:07 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:49:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:49:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:49:07 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:49:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:49:07 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:49:07 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:49:07 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Upload Class Initialized
DEBUG - 2013-12-16 13:49:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:49:07 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:49:07 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:49:39 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:49:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:49:39 --> URI Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Router Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Output Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Security Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Input Class Initialized
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:49:39 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Loader Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Controller Class Initialized
DEBUG - 2013-12-16 13:49:39 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:49:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:49:39 --> Session Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:49:39 --> Session routines successfully run
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:49:39 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:49:39 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:49:39 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:49:39 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:49:39 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:49:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:49:39 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:49:39 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:49:39 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Upload Class Initialized
DEBUG - 2013-12-16 13:49:39 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:49:39 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:49:39 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:49:41 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:49:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:49:41 --> URI Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Router Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Output Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Security Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Input Class Initialized
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:49:41 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Loader Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Controller Class Initialized
DEBUG - 2013-12-16 13:49:41 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:49:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:49:41 --> Session Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:49:41 --> Session routines successfully run
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:49:41 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:49:41 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:49:41 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:49:41 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:49:41 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:49:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:49:41 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:49:41 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:49:41 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Upload Class Initialized
DEBUG - 2013-12-16 13:49:41 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:49:41 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:49:41 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:49:59 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:49:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:49:59 --> URI Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Router Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Output Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Security Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Input Class Initialized
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:49:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:49:59 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Language Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Config Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Loader Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Controller Class Initialized
DEBUG - 2013-12-16 13:49:59 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:49:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:49:59 --> Session Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:49:59 --> Session routines successfully run
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:49:59 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:49:59 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:49:59 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:49:59 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:49:59 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:49:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:49:59 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:49:59 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:49:59 --> Model Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Upload Class Initialized
DEBUG - 2013-12-16 13:49:59 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:49:59 --> You have not specified any allowed file types.
ERROR - 2013-12-16 13:49:59 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2013-12-16 13:50:16 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:50:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:50:16 --> URI Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Router Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Output Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Security Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Input Class Initialized
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:50:16 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Loader Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Controller Class Initialized
DEBUG - 2013-12-16 13:50:16 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:50:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:50:16 --> Session Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:50:16 --> Session routines successfully run
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:50:16 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:50:16 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:50:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:50:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:50:16 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:50:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:50:16 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:50:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:50:16 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:16 --> Upload Class Initialized
ERROR - 2013-12-16 13:50:16 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 317
ERROR - 2013-12-16 13:50:16 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 319
ERROR - 2013-12-16 13:50:16 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpA038.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 319
DEBUG - 2013-12-16 13:50:16 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:50:16 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:50:32 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:50:32 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:50:32 --> URI Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Router Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Output Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Security Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Input Class Initialized
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:50:32 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Loader Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Controller Class Initialized
DEBUG - 2013-12-16 13:50:32 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:50:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:50:32 --> Session Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:50:32 --> Session routines successfully run
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:50:32 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:50:32 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:50:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:50:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:50:32 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:50:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:50:32 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:50:32 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:50:32 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:32 --> Upload Class Initialized
ERROR - 2013-12-16 13:50:32 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 318
ERROR - 2013-12-16 13:50:32 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
ERROR - 2013-12-16 13:50:32 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpDC6E.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
DEBUG - 2013-12-16 13:50:32 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:50:32 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:50:41 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:50:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:50:41 --> URI Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Router Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Output Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Security Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Input Class Initialized
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:50:41 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Loader Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Controller Class Initialized
DEBUG - 2013-12-16 13:50:41 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:50:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:50:41 --> Session Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:50:41 --> Session routines successfully run
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:50:41 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:50:41 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:50:41 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:50:41 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:50:41 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:50:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:50:41 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:50:41 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:50:41 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:41 --> Upload Class Initialized
ERROR - 2013-12-16 13:50:41 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 318
ERROR - 2013-12-16 13:50:41 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
ERROR - 2013-12-16 13:50:41 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpFF3B.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
DEBUG - 2013-12-16 13:50:41 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:50:41 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:50:50 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:50:50 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:50:50 --> URI Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Router Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Output Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Security Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Input Class Initialized
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:50:50 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Loader Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Controller Class Initialized
DEBUG - 2013-12-16 13:50:50 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:50:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:50:50 --> Session Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:50:50 --> Session routines successfully run
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:50:50 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:50:50 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:50:50 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:50:50 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:50:50 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:50:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:50:50 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:50:50 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:50:50 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:50 --> Upload Class Initialized
ERROR - 2013-12-16 13:50:50 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 318
ERROR - 2013-12-16 13:50:50 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
ERROR - 2013-12-16 13:50:50 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php2523.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
DEBUG - 2013-12-16 13:50:50 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:50:50 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:50:58 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:50:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:50:58 --> URI Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Router Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Output Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Security Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Input Class Initialized
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:50:58 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Loader Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Controller Class Initialized
DEBUG - 2013-12-16 13:50:58 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:50:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:50:58 --> Session Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:50:58 --> Session routines successfully run
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:50:58 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:50:58 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:50:58 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:50:58 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:50:58 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:50:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:50:58 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:50:58 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:50:58 --> Model Class Initialized
DEBUG - 2013-12-16 13:50:58 --> Upload Class Initialized
ERROR - 2013-12-16 13:50:58 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 318
ERROR - 2013-12-16 13:50:58 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
ERROR - 2013-12-16 13:50:58 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php433E.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
DEBUG - 2013-12-16 13:50:58 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:50:58 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:50:59 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:50:59 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:50:59 --> URI Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Router Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Output Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Security Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Input Class Initialized
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> XSS Filtering completed
DEBUG - 2013-12-16 13:50:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:50:59 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Language Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Config Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Loader Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Controller Class Initialized
DEBUG - 2013-12-16 13:50:59 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:50:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:50:59 --> Session Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:50:59 --> Session routines successfully run
DEBUG - 2013-12-16 13:50:59 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:50:59 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:50:59 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:50:59 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:50:59 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:50:59 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:50:59 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:50:59 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:50:59 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:51:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:51:00 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:51:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:51:00 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:51:00 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:51:00 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:00 --> Upload Class Initialized
ERROR - 2013-12-16 13:51:00 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 318
ERROR - 2013-12-16 13:51:00 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
ERROR - 2013-12-16 13:51:00 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php488D.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
DEBUG - 2013-12-16 13:51:00 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:51:00 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:51:12 --> Config Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:51:12 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:51:12 --> URI Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Router Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Output Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Security Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Input Class Initialized
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:12 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:51:12 --> Language Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Language Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Config Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Loader Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Controller Class Initialized
DEBUG - 2013-12-16 13:51:12 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:51:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:51:12 --> Session Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:51:12 --> Session routines successfully run
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:51:12 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:51:12 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:51:12 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:51:12 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:51:12 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:51:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:51:12 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:51:12 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:51:12 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:12 --> Upload Class Initialized
ERROR - 2013-12-16 13:51:12 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 319
ERROR - 2013-12-16 13:51:12 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:51:12 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php7A18.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
DEBUG - 2013-12-16 13:51:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:51:12 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:51:21 --> Config Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:51:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:51:21 --> URI Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Router Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Output Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Security Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Input Class Initialized
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:51:21 --> Language Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Language Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Config Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Loader Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Controller Class Initialized
DEBUG - 2013-12-16 13:51:21 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:51:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:51:21 --> Session Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:51:21 --> Session routines successfully run
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:51:21 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:51:21 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:51:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:51:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:51:21 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:51:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:51:21 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:51:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:51:21 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:21 --> Upload Class Initialized
ERROR - 2013-12-16 13:51:21 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
ERROR - 2013-12-16 13:51:21 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 322
ERROR - 2013-12-16 13:51:21 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php9B7E.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 322
DEBUG - 2013-12-16 13:51:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:51:21 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:51:57 --> Config Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:51:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:51:57 --> URI Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Router Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Output Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Security Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Input Class Initialized
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> XSS Filtering completed
DEBUG - 2013-12-16 13:51:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:51:57 --> Language Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Language Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Config Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Loader Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Controller Class Initialized
DEBUG - 2013-12-16 13:51:57 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:51:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:51:57 --> Session Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:51:57 --> Session routines successfully run
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:51:57 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:51:57 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:51:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:51:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:51:57 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:51:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:51:57 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:51:57 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:51:57 --> Model Class Initialized
DEBUG - 2013-12-16 13:51:57 --> Upload Class Initialized
ERROR - 2013-12-16 13:51:57 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 320
ERROR - 2013-12-16 13:51:57 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 322
ERROR - 2013-12-16 13:51:57 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php2A46.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 322
DEBUG - 2013-12-16 13:51:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:51:57 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:52:18 --> Config Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:52:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:52:18 --> URI Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Router Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Output Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Security Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Input Class Initialized
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:52:18 --> Language Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Language Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Config Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Loader Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Controller Class Initialized
DEBUG - 2013-12-16 13:52:18 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:52:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:52:18 --> Session Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:52:18 --> Session routines successfully run
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:52:18 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:52:18 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:52:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:52:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:52:18 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:52:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:52:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:52:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:52:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:18 --> Upload Class Initialized
ERROR - 2013-12-16 13:52:18 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:52:18 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 323
ERROR - 2013-12-16 13:52:18 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php7C0F.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 323
DEBUG - 2013-12-16 13:52:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:52:18 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:52:20 --> Config Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:52:20 --> URI Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Router Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Output Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Security Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Input Class Initialized
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:52:20 --> Language Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Language Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Config Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Loader Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Controller Class Initialized
DEBUG - 2013-12-16 13:52:20 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:52:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:52:20 --> Session Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:52:20 --> Session routines successfully run
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:52:20 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:52:20 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:52:20 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:52:20 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:52:20 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:52:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:52:20 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:52:20 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:52:20 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:20 --> Upload Class Initialized
ERROR - 2013-12-16 13:52:20 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:52:20 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 323
ERROR - 2013-12-16 13:52:20 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php8295.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 323
DEBUG - 2013-12-16 13:52:20 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:52:20 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:52:40 --> Config Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:52:40 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:52:40 --> URI Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Router Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Output Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Security Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Input Class Initialized
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> XSS Filtering completed
DEBUG - 2013-12-16 13:52:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:52:40 --> Language Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Language Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Config Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Loader Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Controller Class Initialized
DEBUG - 2013-12-16 13:52:40 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:52:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:52:40 --> Session Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:52:40 --> Session routines successfully run
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:52:40 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:52:40 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:52:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:52:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:52:40 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:52:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:52:40 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:52:40 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:52:40 --> Model Class Initialized
DEBUG - 2013-12-16 13:52:40 --> Upload Class Initialized
ERROR - 2013-12-16 13:52:40 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:52:40 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 324
ERROR - 2013-12-16 13:52:40 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpD151.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 324
DEBUG - 2013-12-16 13:52:40 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:52:40 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:53:39 --> Config Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:53:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:53:39 --> URI Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Router Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Output Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Security Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Input Class Initialized
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> XSS Filtering completed
DEBUG - 2013-12-16 13:53:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:53:39 --> Language Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Language Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Config Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Loader Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Controller Class Initialized
DEBUG - 2013-12-16 13:53:39 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:53:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:53:39 --> Session Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:53:39 --> Session routines successfully run
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:53:39 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:53:39 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:53:39 --> Model Class Initialized
DEBUG - 2013-12-16 13:53:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:53:39 --> Model Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:53:39 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:53:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:53:39 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:53:39 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:53:39 --> Model Class Initialized
DEBUG - 2013-12-16 13:53:39 --> Upload Class Initialized
ERROR - 2013-12-16 13:53:39 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:53:39 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 324
ERROR - 2013-12-16 13:53:39 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpB6C1.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 324
DEBUG - 2013-12-16 13:53:39 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:53:39 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:54:45 --> Config Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:54:45 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:54:45 --> URI Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Router Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Output Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Security Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Input Class Initialized
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> XSS Filtering completed
DEBUG - 2013-12-16 13:54:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:54:45 --> Language Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Language Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Config Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Loader Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Controller Class Initialized
DEBUG - 2013-12-16 13:54:45 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:54:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:54:45 --> Session Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:54:45 --> Session routines successfully run
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:54:45 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:54:45 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:54:45 --> Model Class Initialized
DEBUG - 2013-12-16 13:54:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:54:45 --> Model Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:54:45 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:54:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:54:45 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:54:45 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:54:45 --> Model Class Initialized
DEBUG - 2013-12-16 13:54:45 --> Upload Class Initialized
ERROR - 2013-12-16 13:54:45 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:54:45 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
ERROR - 2013-12-16 13:54:45 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpBB06.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
DEBUG - 2013-12-16 13:54:45 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:54:45 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:55:18 --> Config Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:55:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:55:18 --> URI Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Router Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Output Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Security Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Input Class Initialized
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:55:18 --> Language Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Language Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Config Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Loader Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Controller Class Initialized
DEBUG - 2013-12-16 13:55:18 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:55:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:55:18 --> Session Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:55:18 --> Session routines successfully run
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:55:18 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:55:18 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:55:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:55:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:55:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:55:18 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:55:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:55:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:55:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:55:18 --> Model Class Initialized
DEBUG - 2013-12-16 13:55:18 --> Upload Class Initialized
ERROR - 2013-12-16 13:55:18 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:55:18 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
ERROR - 2013-12-16 13:55:18 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php3BBA.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
DEBUG - 2013-12-16 13:55:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:55:18 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:55:35 --> Config Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:55:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:55:35 --> URI Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Router Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Output Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Security Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Input Class Initialized
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> XSS Filtering completed
DEBUG - 2013-12-16 13:55:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:55:35 --> Language Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Language Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Config Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Loader Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Controller Class Initialized
DEBUG - 2013-12-16 13:55:35 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:55:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:55:35 --> Session Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:55:35 --> Session routines successfully run
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:55:35 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:55:35 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:55:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:55:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:55:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:55:35 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:55:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:55:35 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:55:35 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:55:35 --> Model Class Initialized
DEBUG - 2013-12-16 13:55:35 --> Upload Class Initialized
ERROR - 2013-12-16 13:55:35 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:55:35 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
ERROR - 2013-12-16 13:55:35 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php7B1B.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
DEBUG - 2013-12-16 13:55:35 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:55:35 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:57:05 --> Config Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:57:05 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:57:05 --> URI Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Router Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Output Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Security Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Input Class Initialized
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:57:05 --> Language Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Language Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Config Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Loader Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Controller Class Initialized
DEBUG - 2013-12-16 13:57:05 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:57:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:57:05 --> Session Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:57:05 --> Session routines successfully run
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:57:05 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:57:05 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:57:05 --> Model Class Initialized
DEBUG - 2013-12-16 13:57:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:57:05 --> Model Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:57:05 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:57:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:57:05 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:57:05 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:57:05 --> Model Class Initialized
DEBUG - 2013-12-16 13:57:05 --> Upload Class Initialized
ERROR - 2013-12-16 13:57:05 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:57:05 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
ERROR - 2013-12-16 13:57:05 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\phpDB16.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
DEBUG - 2013-12-16 13:57:05 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:57:05 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:57:25 --> Config Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:57:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:57:25 --> URI Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Router Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Output Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Security Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Input Class Initialized
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:57:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:57:25 --> Language Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Language Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Config Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Loader Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Controller Class Initialized
DEBUG - 2013-12-16 13:57:25 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:57:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:57:25 --> Session Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:57:25 --> Session routines successfully run
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:57:25 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:57:25 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:57:25 --> Model Class Initialized
DEBUG - 2013-12-16 13:57:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:57:25 --> Model Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:57:25 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:57:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:57:25 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:57:25 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:57:25 --> Model Class Initialized
DEBUG - 2013-12-16 13:57:25 --> Upload Class Initialized
ERROR - 2013-12-16 13:57:25 --> Severity: Warning  --> copy(http://localhost/renalemr/index.php/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:57:25 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/index.php/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
ERROR - 2013-12-16 13:57:25 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php28AA.tmp' to 'http://localhost/renalemr/index.php/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
DEBUG - 2013-12-16 13:57:25 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:57:25 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 13:58:25 --> Config Class Initialized
DEBUG - 2013-12-16 13:58:25 --> Hooks Class Initialized
DEBUG - 2013-12-16 13:58:25 --> Utf8 Class Initialized
DEBUG - 2013-12-16 13:58:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 13:58:25 --> URI Class Initialized
DEBUG - 2013-12-16 13:58:25 --> Router Class Initialized
DEBUG - 2013-12-16 13:58:25 --> Output Class Initialized
DEBUG - 2013-12-16 13:58:25 --> Security Class Initialized
DEBUG - 2013-12-16 13:58:25 --> Input Class Initialized
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> XSS Filtering completed
DEBUG - 2013-12-16 13:58:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 13:58:25 --> Language Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Language Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Config Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Loader Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Controller Class Initialized
DEBUG - 2013-12-16 13:58:26 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 13:58:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 13:58:26 --> Session Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: string_helper
DEBUG - 2013-12-16 13:58:26 --> Session routines successfully run
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: url_helper
DEBUG - 2013-12-16 13:58:26 --> Database Driver Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: form_helper
DEBUG - 2013-12-16 13:58:26 --> Form Validation Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: number_helper
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: date_helper
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 13:58:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:58:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 13:58:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 13:58:26 --> Helper loaded: language_helper
DEBUG - 2013-12-16 13:58:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 13:58:26 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 13:58:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 13:58:26 --> Model Class Initialized
DEBUG - 2013-12-16 13:58:26 --> Upload Class Initialized
ERROR - 2013-12-16 13:58:26 --> Severity: Warning  --> copy(http://localhost/renalemr/uploads/search.png) [<a href='function.copy'>function.copy</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 321
ERROR - 2013-12-16 13:58:26 --> Severity: Warning  --> move_uploaded_file(http://localhost/renalemr/uploads/search.png) [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: failed to open stream: HTTP wrapper does not support writeable connections D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
ERROR - 2013-12-16 13:58:26 --> Severity: Warning  --> move_uploaded_file() [<a href='function.move-uploaded-file'>function.move-uploaded-file</a>]: Unable to move 'D:\xampp\tmp\php16D0.tmp' to 'http://localhost/renalemr/uploads/search.png' D:\xampp\htdocs\renalemr\system\libraries\Upload.php 326
DEBUG - 2013-12-16 13:58:26 --> Language file loaded: language/english/upload_lang.php
ERROR - 2013-12-16 13:58:26 --> A problem was encountered while attempting to move the uploaded file to the final destination.
DEBUG - 2013-12-16 14:48:41 --> Config Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:48:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:48:41 --> URI Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Router Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Output Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Security Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Input Class Initialized
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> XSS Filtering completed
DEBUG - 2013-12-16 14:48:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:48:41 --> Language Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Language Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Config Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Loader Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Controller Class Initialized
DEBUG - 2013-12-16 14:48:41 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:48:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:48:41 --> Session Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:48:41 --> Session routines successfully run
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:48:41 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:48:41 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:48:41 --> Model Class Initialized
DEBUG - 2013-12-16 14:48:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:48:41 --> Model Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:48:41 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:48:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:48:41 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:48:41 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:48:41 --> Model Class Initialized
DEBUG - 2013-12-16 14:48:41 --> Upload Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Config Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:50:49 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:50:49 --> URI Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Router Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Output Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Security Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Input Class Initialized
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:50:49 --> Language Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Language Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Config Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Loader Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Controller Class Initialized
DEBUG - 2013-12-16 14:50:49 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:50:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:50:49 --> Session Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:50:49 --> Session routines successfully run
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:50:49 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:50:49 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:50:49 --> Model Class Initialized
DEBUG - 2013-12-16 14:50:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:50:49 --> Model Class Initialized
DEBUG - 2013-12-16 14:50:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:50:49 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:50:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:50:49 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:50:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:50:49 --> Model Class Initialized
DEBUG - 2013-12-16 14:50:49 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 14:50:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 14:50:49 --> Final output sent to browser
DEBUG - 2013-12-16 14:50:49 --> Total execution time: 0.0680
DEBUG - 2013-12-16 14:50:52 --> Config Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:50:52 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:50:52 --> URI Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Router Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Output Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Security Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Input Class Initialized
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> XSS Filtering completed
DEBUG - 2013-12-16 14:50:52 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:50:52 --> Language Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Language Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Config Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Loader Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Controller Class Initialized
DEBUG - 2013-12-16 14:50:52 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:50:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:50:52 --> Session Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:50:52 --> Session routines successfully run
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:50:52 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:50:52 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:50:52 --> Model Class Initialized
DEBUG - 2013-12-16 14:50:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:50:52 --> Model Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:50:52 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:50:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:50:52 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:50:52 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:50:52 --> Model Class Initialized
DEBUG - 2013-12-16 14:50:52 --> Upload Class Initialized
ERROR - 2013-12-16 14:50:52 --> Severity: Notice  --> Undefined variable: _FILE D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 33
DEBUG - 2013-12-16 14:51:19 --> Config Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:51:19 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:51:19 --> URI Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Router Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Output Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Security Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Input Class Initialized
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> XSS Filtering completed
DEBUG - 2013-12-16 14:51:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:51:19 --> Language Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Language Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Config Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Loader Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Controller Class Initialized
DEBUG - 2013-12-16 14:51:19 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:51:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:51:19 --> Session Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:51:19 --> Session routines successfully run
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:51:19 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:51:19 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:51:19 --> Model Class Initialized
DEBUG - 2013-12-16 14:51:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:51:19 --> Model Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:51:19 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:51:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:51:19 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:51:19 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:51:19 --> Model Class Initialized
DEBUG - 2013-12-16 14:51:19 --> Upload Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Config Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:54:42 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:54:42 --> URI Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Router Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Output Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Security Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Input Class Initialized
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> XSS Filtering completed
DEBUG - 2013-12-16 14:54:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:54:42 --> Language Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Language Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Config Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Loader Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Controller Class Initialized
DEBUG - 2013-12-16 14:54:42 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:54:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:54:42 --> Session Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:54:42 --> Session routines successfully run
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:54:42 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:54:42 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:54:42 --> Model Class Initialized
DEBUG - 2013-12-16 14:54:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:54:42 --> Model Class Initialized
DEBUG - 2013-12-16 14:54:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:54:42 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:54:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:54:42 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:54:42 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:54:42 --> Model Class Initialized
DEBUG - 2013-12-16 14:54:42 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 14:54:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 14:54:42 --> Final output sent to browser
DEBUG - 2013-12-16 14:54:42 --> Total execution time: 0.0687
DEBUG - 2013-12-16 14:55:01 --> Config Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:55:01 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:55:01 --> URI Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Router Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Output Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Security Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Input Class Initialized
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:55:01 --> Language Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Language Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Config Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Loader Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Controller Class Initialized
DEBUG - 2013-12-16 14:55:01 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:55:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:55:01 --> Session Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:55:01 --> Session routines successfully run
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:55:01 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:55:01 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:55:01 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:55:01 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:55:01 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:55:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:55:01 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:55:01 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:55:01 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:01 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 14:55:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 14:55:01 --> Final output sent to browser
DEBUG - 2013-12-16 14:55:01 --> Total execution time: 0.0533
DEBUG - 2013-12-16 14:55:18 --> Config Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:55:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:55:18 --> URI Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Router Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Output Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Security Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Input Class Initialized
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:55:18 --> Language Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Language Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Config Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Loader Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Controller Class Initialized
DEBUG - 2013-12-16 14:55:18 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:55:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:55:18 --> Session Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:55:18 --> Session routines successfully run
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:55:18 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:55:18 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:55:18 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:55:18 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:55:18 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:55:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:55:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:55:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:55:18 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:18 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 14:55:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 14:55:18 --> Final output sent to browser
DEBUG - 2013-12-16 14:55:18 --> Total execution time: 0.0640
DEBUG - 2013-12-16 14:55:46 --> Config Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:55:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:55:46 --> URI Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Router Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Output Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Security Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Input Class Initialized
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> XSS Filtering completed
DEBUG - 2013-12-16 14:55:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:55:46 --> Language Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Language Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Config Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Loader Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Controller Class Initialized
DEBUG - 2013-12-16 14:55:46 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:55:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:55:46 --> Session Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:55:46 --> Session routines successfully run
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:55:46 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:55:46 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:55:46 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:55:46 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:55:46 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:55:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:55:46 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:55:47 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:55:47 --> Model Class Initialized
DEBUG - 2013-12-16 14:55:47 --> Upload Class Initialized
ERROR - 2013-12-16 14:55:47 --> Severity: Notice  --> Undefined variable: table D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 40
DEBUG - 2013-12-16 14:55:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-12-16 14:56:10 --> Config Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:56:10 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:56:10 --> URI Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Router Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Output Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Security Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Input Class Initialized
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> XSS Filtering completed
DEBUG - 2013-12-16 14:56:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:56:10 --> Language Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Language Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Config Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Loader Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Controller Class Initialized
DEBUG - 2013-12-16 14:56:10 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:56:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:56:10 --> Session Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:56:10 --> Session routines successfully run
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:56:10 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:56:10 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:56:10 --> Model Class Initialized
DEBUG - 2013-12-16 14:56:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:56:10 --> Model Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:56:10 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:56:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:56:10 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:56:10 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:56:10 --> Model Class Initialized
DEBUG - 2013-12-16 14:56:10 --> Upload Class Initialized
ERROR - 2013-12-16 14:56:10 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
DEBUG - 2013-12-16 14:56:10 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 14:56:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 14:56:10 --> Final output sent to browser
DEBUG - 2013-12-16 14:56:10 --> Total execution time: 0.1297
DEBUG - 2013-12-16 14:58:35 --> Config Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:58:35 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:58:35 --> URI Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Router Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Output Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Security Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Input Class Initialized
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:58:35 --> Language Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Language Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Config Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Loader Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Controller Class Initialized
DEBUG - 2013-12-16 14:58:35 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:58:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:58:35 --> Session Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:58:35 --> Session routines successfully run
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:58:35 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:58:35 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:58:35 --> Model Class Initialized
DEBUG - 2013-12-16 14:58:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:58:35 --> Model Class Initialized
DEBUG - 2013-12-16 14:58:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:58:35 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:58:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:58:35 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:58:35 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:58:35 --> Model Class Initialized
ERROR - 2013-12-16 14:58:35 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
DEBUG - 2013-12-16 14:58:35 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 14:58:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 14:58:35 --> Final output sent to browser
DEBUG - 2013-12-16 14:58:35 --> Total execution time: 0.0629
DEBUG - 2013-12-16 14:58:57 --> Config Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Hooks Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Utf8 Class Initialized
DEBUG - 2013-12-16 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 14:58:57 --> URI Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Router Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Output Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Security Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Input Class Initialized
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> XSS Filtering completed
DEBUG - 2013-12-16 14:58:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 14:58:57 --> Language Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Language Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Config Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Loader Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Controller Class Initialized
DEBUG - 2013-12-16 14:58:57 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 14:58:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 14:58:57 --> Session Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: string_helper
DEBUG - 2013-12-16 14:58:57 --> Session routines successfully run
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: url_helper
DEBUG - 2013-12-16 14:58:57 --> Database Driver Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: form_helper
DEBUG - 2013-12-16 14:58:57 --> Form Validation Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: number_helper
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: date_helper
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 14:58:57 --> Model Class Initialized
DEBUG - 2013-12-16 14:58:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 14:58:57 --> Model Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 14:58:57 --> Helper loaded: language_helper
DEBUG - 2013-12-16 14:58:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 14:58:57 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 14:58:57 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 14:58:57 --> Model Class Initialized
DEBUG - 2013-12-16 14:58:57 --> Upload Class Initialized
ERROR - 2013-12-16 14:58:57 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
DEBUG - 2013-12-16 14:58:57 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 14:58:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 14:58:57 --> Final output sent to browser
DEBUG - 2013-12-16 14:58:57 --> Total execution time: 0.1272
DEBUG - 2013-12-16 15:00:58 --> Config Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:00:58 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:00:58 --> URI Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Router Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Output Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Security Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Input Class Initialized
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> XSS Filtering completed
DEBUG - 2013-12-16 15:00:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:00:58 --> Language Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Language Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Config Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Loader Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Controller Class Initialized
DEBUG - 2013-12-16 15:00:58 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:00:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:00:58 --> Session Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:00:58 --> Session routines successfully run
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:00:58 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:00:58 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:00:58 --> Model Class Initialized
DEBUG - 2013-12-16 15:00:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:00:58 --> Model Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:00:58 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:00:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:00:58 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:00:58 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:00:58 --> Model Class Initialized
DEBUG - 2013-12-16 15:00:58 --> Upload Class Initialized
ERROR - 2013-12-16 15:00:58 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
DEBUG - 2013-12-16 15:00:58 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:00:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:00:58 --> Final output sent to browser
DEBUG - 2013-12-16 15:00:58 --> Total execution time: 0.1416
DEBUG - 2013-12-16 15:01:41 --> Config Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:01:41 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:01:41 --> URI Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Router Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Output Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Security Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Input Class Initialized
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> XSS Filtering completed
DEBUG - 2013-12-16 15:01:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:01:41 --> Language Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Language Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Config Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Loader Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Controller Class Initialized
DEBUG - 2013-12-16 15:01:41 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:01:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:01:41 --> Session Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:01:41 --> Session routines successfully run
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:01:41 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:01:41 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:01:41 --> Model Class Initialized
DEBUG - 2013-12-16 15:01:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:01:41 --> Model Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:01:41 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:01:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:01:41 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:01:41 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:01:41 --> Model Class Initialized
DEBUG - 2013-12-16 15:01:41 --> Upload Class Initialized
ERROR - 2013-12-16 15:01:41 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
DEBUG - 2013-12-16 15:01:41 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:01:41 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:01:41 --> Final output sent to browser
DEBUG - 2013-12-16 15:01:41 --> Total execution time: 0.1500
DEBUG - 2013-12-16 15:02:22 --> Config Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:02:22 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:02:22 --> URI Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Router Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Output Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Security Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Input Class Initialized
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> XSS Filtering completed
DEBUG - 2013-12-16 15:02:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:02:22 --> Language Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Language Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Config Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Loader Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Controller Class Initialized
DEBUG - 2013-12-16 15:02:22 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:02:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:02:22 --> Session Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:02:22 --> Session routines successfully run
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:02:22 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:02:22 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:02:22 --> Model Class Initialized
DEBUG - 2013-12-16 15:02:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:02:22 --> Model Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:02:22 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:02:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:02:22 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:02:22 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:02:22 --> Model Class Initialized
DEBUG - 2013-12-16 15:02:22 --> Upload Class Initialized
ERROR - 2013-12-16 15:02:22 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
DEBUG - 2013-12-16 15:02:22 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:02:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:02:22 --> Final output sent to browser
DEBUG - 2013-12-16 15:02:22 --> Total execution time: 0.1546
DEBUG - 2013-12-16 15:04:04 --> Config Class Initialized
DEBUG - 2013-12-16 15:04:04 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:04:04 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:04:04 --> URI Class Initialized
DEBUG - 2013-12-16 15:04:04 --> Router Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Output Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Security Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Input Class Initialized
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:04:05 --> Language Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Language Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Config Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Loader Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Controller Class Initialized
DEBUG - 2013-12-16 15:04:05 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:04:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:04:05 --> Session Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:04:05 --> Session routines successfully run
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:04:05 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:04:05 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:04:05 --> Model Class Initialized
DEBUG - 2013-12-16 15:04:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:04:05 --> Model Class Initialized
DEBUG - 2013-12-16 15:04:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:04:05 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:04:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:04:05 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:04:05 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:04:05 --> Model Class Initialized
ERROR - 2013-12-16 15:04:05 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
DEBUG - 2013-12-16 15:04:05 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:04:05 --> Final output sent to browser
DEBUG - 2013-12-16 15:04:05 --> Total execution time: 0.0540
DEBUG - 2013-12-16 15:04:25 --> Config Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:04:25 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:04:25 --> URI Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Router Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Output Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Security Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Input Class Initialized
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> XSS Filtering completed
DEBUG - 2013-12-16 15:04:25 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:04:25 --> Language Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Language Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Config Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Loader Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Controller Class Initialized
DEBUG - 2013-12-16 15:04:25 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:04:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:04:25 --> Session Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:04:25 --> Session routines successfully run
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:04:25 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:04:25 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:04:25 --> Model Class Initialized
DEBUG - 2013-12-16 15:04:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:04:25 --> Model Class Initialized
DEBUG - 2013-12-16 15:04:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:04:25 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:04:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:04:25 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:04:25 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:04:25 --> Model Class Initialized
ERROR - 2013-12-16 15:04:25 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
ERROR - 2013-12-16 15:04:25 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 25
DEBUG - 2013-12-16 15:04:25 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:04:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:04:25 --> Final output sent to browser
DEBUG - 2013-12-16 15:04:25 --> Total execution time: 0.0679
DEBUG - 2013-12-16 15:07:04 --> Config Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:07:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:07:04 --> URI Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Router Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Output Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Security Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Input Class Initialized
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:07:04 --> Language Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Language Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Config Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Loader Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Controller Class Initialized
DEBUG - 2013-12-16 15:07:04 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:07:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:07:04 --> Session Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:07:04 --> Session routines successfully run
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:07:04 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:07:04 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:07:04 --> Model Class Initialized
DEBUG - 2013-12-16 15:07:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:07:04 --> Model Class Initialized
DEBUG - 2013-12-16 15:07:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:07:04 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:07:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:07:04 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:07:04 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:07:04 --> Model Class Initialized
ERROR - 2013-12-16 15:07:04 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
ERROR - 2013-12-16 15:07:04 --> Severity: Notice  --> Undefined variable: company_name D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 25
DEBUG - 2013-12-16 15:07:04 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:07:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:07:04 --> Final output sent to browser
DEBUG - 2013-12-16 15:07:04 --> Total execution time: 0.0670
DEBUG - 2013-12-16 15:07:08 --> Config Class Initialized
DEBUG - 2013-12-16 15:07:08 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:07:08 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:07:08 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:07:08 --> URI Class Initialized
DEBUG - 2013-12-16 15:07:08 --> Router Class Initialized
DEBUG - 2013-12-16 15:07:08 --> Output Class Initialized
DEBUG - 2013-12-16 15:07:08 --> Security Class Initialized
DEBUG - 2013-12-16 15:07:08 --> Input Class Initialized
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:08 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:09 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:09 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:07:09 --> Language Class Initialized
DEBUG - 2013-12-16 15:07:09 --> Language Class Initialized
DEBUG - 2013-12-16 15:07:09 --> Config Class Initialized
DEBUG - 2013-12-16 15:07:09 --> Loader Class Initialized
DEBUG - 2013-12-16 15:07:09 --> Controller Class Initialized
DEBUG - 2013-12-16 15:07:09 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:07:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:07:09 --> Session Class Initialized
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:07:09 --> Session routines successfully run
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:07:09 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:07:09 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:07:09 --> Model Class Initialized
DEBUG - 2013-12-16 15:07:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:07:09 --> Model Class Initialized
DEBUG - 2013-12-16 15:07:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:07:09 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:07:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:07:09 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:07:09 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:07:09 --> Model Class Initialized
ERROR - 2013-12-16 15:07:09 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
ERROR - 2013-12-16 15:07:09 --> Severity: Notice  --> Undefined variable: company_name D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 25
DEBUG - 2013-12-16 15:07:09 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:07:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:07:09 --> Final output sent to browser
DEBUG - 2013-12-16 15:07:09 --> Total execution time: 0.0646
DEBUG - 2013-12-16 15:07:21 --> Config Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:07:21 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:07:21 --> URI Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Router Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Output Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Security Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Input Class Initialized
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:07:21 --> Language Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Language Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Config Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Loader Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Controller Class Initialized
DEBUG - 2013-12-16 15:07:21 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:07:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:07:21 --> Session Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:07:21 --> Session routines successfully run
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:07:21 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:07:21 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:07:21 --> Model Class Initialized
DEBUG - 2013-12-16 15:07:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:07:21 --> Model Class Initialized
DEBUG - 2013-12-16 15:07:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:07:21 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:07:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:07:21 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:07:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:07:21 --> Model Class Initialized
ERROR - 2013-12-16 15:07:21 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
ERROR - 2013-12-16 15:07:21 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 25
DEBUG - 2013-12-16 15:07:21 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:07:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:07:21 --> Final output sent to browser
DEBUG - 2013-12-16 15:07:21 --> Total execution time: 0.0588
DEBUG - 2013-12-16 15:07:23 --> Config Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:07:23 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:07:23 --> URI Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Router Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Output Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Security Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Input Class Initialized
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> XSS Filtering completed
DEBUG - 2013-12-16 15:07:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:07:23 --> Language Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Language Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Config Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Loader Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Controller Class Initialized
DEBUG - 2013-12-16 15:07:23 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:07:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:07:23 --> Session Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:07:23 --> Session routines successfully run
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:07:23 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:07:23 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:07:23 --> Model Class Initialized
DEBUG - 2013-12-16 15:07:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:07:23 --> Model Class Initialized
DEBUG - 2013-12-16 15:07:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:07:23 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:07:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:07:23 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:07:23 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:07:23 --> Model Class Initialized
ERROR - 2013-12-16 15:07:23 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
ERROR - 2013-12-16 15:07:23 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 25
DEBUG - 2013-12-16 15:07:23 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:07:23 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:07:23 --> Final output sent to browser
DEBUG - 2013-12-16 15:07:23 --> Total execution time: 0.0563
DEBUG - 2013-12-16 15:10:16 --> Config Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:10:16 --> URI Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Router Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Output Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Security Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Input Class Initialized
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:10:16 --> Language Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Language Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Config Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Loader Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Controller Class Initialized
DEBUG - 2013-12-16 15:10:16 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:10:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:10:16 --> Session Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:10:16 --> Session routines successfully run
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:10:16 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:10:16 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:10:16 --> Model Class Initialized
DEBUG - 2013-12-16 15:10:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:10:16 --> Model Class Initialized
DEBUG - 2013-12-16 15:10:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:10:16 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:10:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:10:16 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:10:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:10:16 --> Model Class Initialized
ERROR - 2013-12-16 15:10:16 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
ERROR - 2013-12-16 15:10:16 --> Severity: Notice  --> Undefined variable: content D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 25
DEBUG - 2013-12-16 15:10:16 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:10:16 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:10:16 --> Final output sent to browser
DEBUG - 2013-12-16 15:10:16 --> Total execution time: 0.0624
DEBUG - 2013-12-16 15:10:18 --> Config Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:10:18 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:10:18 --> URI Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Router Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Output Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Security Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Input Class Initialized
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:10:18 --> Language Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Language Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Config Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Loader Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Controller Class Initialized
DEBUG - 2013-12-16 15:10:18 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:10:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:10:18 --> Session Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:10:18 --> Session routines successfully run
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:10:18 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:10:18 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:10:18 --> Model Class Initialized
DEBUG - 2013-12-16 15:10:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:10:18 --> Model Class Initialized
DEBUG - 2013-12-16 15:10:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:10:18 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:10:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:10:18 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:10:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:10:18 --> Model Class Initialized
ERROR - 2013-12-16 15:10:18 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
ERROR - 2013-12-16 15:10:18 --> Severity: Notice  --> Undefined variable: content D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 25
DEBUG - 2013-12-16 15:10:18 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:10:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:10:18 --> Final output sent to browser
DEBUG - 2013-12-16 15:10:18 --> Total execution time: 0.0560
DEBUG - 2013-12-16 15:10:46 --> Config Class Initialized
DEBUG - 2013-12-16 15:10:46 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:10:46 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:10:46 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:10:46 --> URI Class Initialized
DEBUG - 2013-12-16 15:10:46 --> Router Class Initialized
DEBUG - 2013-12-16 15:10:46 --> Output Class Initialized
DEBUG - 2013-12-16 15:10:46 --> Security Class Initialized
DEBUG - 2013-12-16 15:10:46 --> Input Class Initialized
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> XSS Filtering completed
DEBUG - 2013-12-16 15:10:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:10:46 --> Language Class Initialized
DEBUG - 2013-12-16 15:10:47 --> Language Class Initialized
DEBUG - 2013-12-16 15:10:47 --> Config Class Initialized
DEBUG - 2013-12-16 15:10:47 --> Loader Class Initialized
DEBUG - 2013-12-16 15:10:47 --> Controller Class Initialized
DEBUG - 2013-12-16 15:10:47 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:10:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:10:47 --> Session Class Initialized
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:10:47 --> Session routines successfully run
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:10:47 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:10:47 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:10:47 --> Model Class Initialized
DEBUG - 2013-12-16 15:10:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:10:47 --> Model Class Initialized
DEBUG - 2013-12-16 15:10:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:10:47 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:10:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:10:47 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:10:47 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:10:47 --> Model Class Initialized
ERROR - 2013-12-16 15:10:47 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
ERROR - 2013-12-16 15:10:47 --> Severity: Notice  --> Undefined variable: data D:\xampp\htdocs\renalemr\application\modules\admin\controllers\admin.php 58
ERROR - 2013-12-16 15:10:47 --> Severity: Notice  --> Undefined variable: content D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 25
DEBUG - 2013-12-16 15:10:47 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:10:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:10:47 --> Final output sent to browser
DEBUG - 2013-12-16 15:10:47 --> Total execution time: 0.0631
DEBUG - 2013-12-16 15:12:04 --> Config Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:12:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:12:04 --> URI Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Router Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Output Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Security Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Input Class Initialized
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:12:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:12:04 --> Language Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Language Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Config Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Loader Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Controller Class Initialized
DEBUG - 2013-12-16 15:12:04 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:12:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:12:04 --> Session Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:12:04 --> Session routines successfully run
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:12:04 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:12:04 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:12:04 --> Model Class Initialized
DEBUG - 2013-12-16 15:12:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:12:04 --> Model Class Initialized
DEBUG - 2013-12-16 15:12:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:12:04 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:12:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:12:04 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:12:04 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:12:04 --> Model Class Initialized
ERROR - 2013-12-16 15:12:04 --> Severity: Notice  --> Undefined property: stdClass::$setting_value D:\xampp\htdocs\renalemr\application\modules\admin\models\mdl_admin.php 30
DEBUG - 2013-12-16 15:12:04 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:12:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:12:04 --> Final output sent to browser
DEBUG - 2013-12-16 15:12:04 --> Total execution time: 0.0591
DEBUG - 2013-12-16 15:21:06 --> Config Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:21:06 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:21:06 --> URI Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Router Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Output Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Security Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Input Class Initialized
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:21:06 --> Language Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Language Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Config Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Loader Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Controller Class Initialized
DEBUG - 2013-12-16 15:21:06 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:21:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:21:06 --> Session Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:21:06 --> Session routines successfully run
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:21:06 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:21:06 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:21:06 --> Model Class Initialized
DEBUG - 2013-12-16 15:21:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:21:06 --> Model Class Initialized
DEBUG - 2013-12-16 15:21:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:21:06 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:21:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:21:06 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:21:06 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:21:06 --> Model Class Initialized
DEBUG - 2013-12-16 15:21:06 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:21:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:21:06 --> Final output sent to browser
DEBUG - 2013-12-16 15:21:06 --> Total execution time: 0.0691
DEBUG - 2013-12-16 15:21:37 --> Config Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:21:37 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:21:37 --> URI Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Router Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Output Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Security Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Input Class Initialized
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> XSS Filtering completed
DEBUG - 2013-12-16 15:21:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:21:37 --> Language Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Language Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Config Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Loader Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Controller Class Initialized
DEBUG - 2013-12-16 15:21:37 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:21:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:21:37 --> Session Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:21:37 --> Session routines successfully run
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:21:37 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:21:37 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:21:37 --> Model Class Initialized
DEBUG - 2013-12-16 15:21:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:21:37 --> Model Class Initialized
DEBUG - 2013-12-16 15:21:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:21:37 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:21:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:21:37 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:21:37 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:21:37 --> Model Class Initialized
DEBUG - 2013-12-16 15:21:37 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:21:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:21:37 --> Final output sent to browser
DEBUG - 2013-12-16 15:21:37 --> Total execution time: 0.0597
DEBUG - 2013-12-16 15:23:04 --> Config Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:23:04 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:23:04 --> URI Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Router Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Output Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Security Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Input Class Initialized
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:04 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:23:04 --> Language Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Language Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Config Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Loader Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Controller Class Initialized
DEBUG - 2013-12-16 15:23:04 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:23:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:23:04 --> Session Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:23:04 --> Session routines successfully run
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:23:04 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:23:04 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:23:04 --> Model Class Initialized
DEBUG - 2013-12-16 15:23:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:23:04 --> Model Class Initialized
DEBUG - 2013-12-16 15:23:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:23:04 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:23:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:23:04 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:23:04 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:23:04 --> Model Class Initialized
DEBUG - 2013-12-16 15:23:04 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:23:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:23:04 --> Final output sent to browser
DEBUG - 2013-12-16 15:23:04 --> Total execution time: 0.0634
DEBUG - 2013-12-16 15:23:28 --> Config Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:23:28 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:23:28 --> URI Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Router Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Output Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Security Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Input Class Initialized
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:23:28 --> Language Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Language Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Config Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Loader Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Controller Class Initialized
DEBUG - 2013-12-16 15:23:28 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:23:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:23:28 --> Session Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:23:28 --> Session routines successfully run
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:23:28 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:23:28 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:23:28 --> Model Class Initialized
DEBUG - 2013-12-16 15:23:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:23:28 --> Model Class Initialized
DEBUG - 2013-12-16 15:23:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:23:28 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:23:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:23:28 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:23:28 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:23:28 --> Model Class Initialized
ERROR - 2013-12-16 15:23:28 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\renalemr\application\modules\admin\views\company.php 31
DEBUG - 2013-12-16 15:23:28 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:23:28 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:23:28 --> Final output sent to browser
DEBUG - 2013-12-16 15:23:28 --> Total execution time: 0.0539
DEBUG - 2013-12-16 15:23:39 --> Config Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Hooks Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Utf8 Class Initialized
DEBUG - 2013-12-16 15:23:39 --> UTF-8 Support Enabled
DEBUG - 2013-12-16 15:23:39 --> URI Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Router Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Output Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Security Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Input Class Initialized
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> XSS Filtering completed
DEBUG - 2013-12-16 15:23:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-12-16 15:23:39 --> Language Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Language Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Config Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Loader Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Controller Class Initialized
DEBUG - 2013-12-16 15:23:39 --> admin MX_Controller Initialized
DEBUG - 2013-12-16 15:23:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-12-16 15:23:39 --> Session Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: string_helper
DEBUG - 2013-12-16 15:23:39 --> Session routines successfully run
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: url_helper
DEBUG - 2013-12-16 15:23:39 --> Database Driver Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: form_helper
DEBUG - 2013-12-16 15:23:39 --> Form Validation Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: number_helper
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: pager_helper
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: invoice_helper
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: date_helper
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: redirect_helper
DEBUG - 2013-12-16 15:23:39 --> Model Class Initialized
DEBUG - 2013-12-16 15:23:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-12-16 15:23:39 --> Model Class Initialized
DEBUG - 2013-12-16 15:23:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-12-16 15:23:39 --> Helper loaded: language_helper
DEBUG - 2013-12-16 15:23:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-12-16 15:23:39 --> Layout MX_Controller Initialized
DEBUG - 2013-12-16 15:23:39 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2013-12-16 15:23:39 --> Model Class Initialized
DEBUG - 2013-12-16 15:23:39 --> File loaded: application/modules/admin/views/company.php
DEBUG - 2013-12-16 15:23:39 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-12-16 15:23:39 --> Final output sent to browser
DEBUG - 2013-12-16 15:23:39 --> Total execution time: 0.0613
