<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2013-11-29 06:26:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:26:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:26:20 --> URI Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Router Class Initialized
DEBUG - 2013-11-29 06:26:20 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:26:20 --> Output Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Security Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Input Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:26:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Loader Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Controller Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:26:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:26:20 --> Session Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:26:20 --> A session cookie was not found.
DEBUG - 2013-11-29 06:26:20 --> Session routines successfully run
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:26:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:26:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:26:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:26:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:26:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:26:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:26:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:26:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:26:20 --> URI Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Router Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Output Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Security Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Input Class Initialized
DEBUG - 2013-11-29 06:26:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:26:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Loader Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Controller Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:26:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:26:20 --> Session Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:26:20 --> Session routines successfully run
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:26:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:26:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:26:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:26:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:26:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:26:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:26:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:26:20 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:26:20 --> Final output sent to browser
DEBUG - 2013-11-29 06:26:20 --> Total execution time: 0.0735
DEBUG - 2013-11-29 06:26:40 --> Config Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:26:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:26:40 --> URI Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Router Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Output Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Security Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Input Class Initialized
DEBUG - 2013-11-29 06:26:40 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:40 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:40 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:40 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:26:40 --> Language Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Language Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Config Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Loader Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Controller Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:26:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:26:40 --> Session Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:26:40 --> Session routines successfully run
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:26:40 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:26:40 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:26:40 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:26:40 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:26:40 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:26:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:26:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:26:40 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:26:40 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:41 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:26:41 --> Final output sent to browser
DEBUG - 2013-11-29 06:26:41 --> Total execution time: 0.2174
DEBUG - 2013-11-29 06:26:57 --> Config Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:26:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:26:57 --> URI Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Router Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Output Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Security Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Input Class Initialized
DEBUG - 2013-11-29 06:26:57 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:57 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:57 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:57 --> XSS Filtering completed
DEBUG - 2013-11-29 06:26:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:26:57 --> Language Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Language Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Config Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Loader Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Controller Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:26:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:26:57 --> Session Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:26:57 --> Session routines successfully run
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:26:57 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:26:57 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:26:57 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:26:57 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:26:57 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:26:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:26:57 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:26:57 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:26:57 --> Model Class Initialized
DEBUG - 2013-11-29 06:26:57 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:26:57 --> Final output sent to browser
DEBUG - 2013-11-29 06:26:57 --> Total execution time: 0.1307
DEBUG - 2013-11-29 06:27:24 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:24 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:24 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:27:24 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:24 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:27:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:24 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:24 --> A session cookie was not found.
DEBUG - 2013-11-29 06:27:24 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:24 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:24 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:24 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:24 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:24 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:24 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:24 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:24 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:24 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:24 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:24 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:24 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:24 --> Total execution time: 0.0446
DEBUG - 2013-11-29 06:27:28 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:28 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:28 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:28 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:28 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:28 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:28 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:28 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:28 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:28 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:28 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:28 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:28 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:29 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:29 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:29 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:29 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:29 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:29 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:29 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:29 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:27:29 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:29 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:29 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:29 --> Total execution time: 0.1262
DEBUG - 2013-11-29 06:27:39 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:39 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:39 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:39 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:39 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:39 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:39 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:39 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:39 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:39 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:39 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:39 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:39 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:39 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:39 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:39 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:39 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:39 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:39 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:39 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:39 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:27:39 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:40 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:40 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:40 --> Total execution time: 0.1247
DEBUG - 2013-11-29 06:27:40 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:40 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:40 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:27:40 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:40 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:27:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:40 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:40 --> A session cookie was not found.
DEBUG - 2013-11-29 06:27:40 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:40 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:40 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:40 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:40 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:40 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:40 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:40 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:40 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:40 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:40 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:40 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:40 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:40 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:40 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:40 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:40 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:40 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:40 --> Total execution time: 0.0433
DEBUG - 2013-11-29 06:27:45 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:45 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:45 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:45 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:45 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:45 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:45 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:45 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:45 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:45 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:45 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:45 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:45 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:45 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:45 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:45 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:27:45 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:45 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:45 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:45 --> Total execution time: 0.1372
DEBUG - 2013-11-29 06:27:51 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:51 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:51 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:51 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:51 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:51 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:51 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:51 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:51 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:51 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:51 --> A session cookie was not found.
DEBUG - 2013-11-29 06:27:51 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:51 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:51 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:51 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:51 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:51 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:51 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:51 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:51 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:51 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:51 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:27:51 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:51 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:51 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:51 --> Total execution time: 0.1199
DEBUG - 2013-11-29 06:27:54 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:54 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:54 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:54 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:54 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:54 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:54 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:54 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:54 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:54 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:54 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:54 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:54 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:54 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:54 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:27:54 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:54 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:54 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:54 --> Total execution time: 0.0588
DEBUG - 2013-11-29 06:27:54 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:54 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:54 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:54 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:54 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:54 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:54 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:54 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:54 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:54 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:54 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:54 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:54 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:54 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:54 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:54 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:54 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:54 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:27:54 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:54 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:54 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:54 --> Total execution time: 0.0572
DEBUG - 2013-11-29 06:27:59 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:27:59 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:27:59 --> URI Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Router Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Output Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Security Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Input Class Initialized
DEBUG - 2013-11-29 06:27:59 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:59 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:59 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:59 --> XSS Filtering completed
DEBUG - 2013-11-29 06:27:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:27:59 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Language Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Config Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Loader Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Controller Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:27:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:27:59 --> Session Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:27:59 --> Session routines successfully run
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:27:59 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:27:59 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:27:59 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:27:59 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:27:59 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:27:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:27:59 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:27:59 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:27:59 --> Model Class Initialized
DEBUG - 2013-11-29 06:27:59 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:27:59 --> Final output sent to browser
DEBUG - 2013-11-29 06:27:59 --> Total execution time: 0.0508
DEBUG - 2013-11-29 06:28:00 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:00 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:00 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:00 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:00 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:00 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:00 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:00 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:00 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:00 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:00 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:00 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:00 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:00 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:00 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:28:00 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:00 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:00 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:00 --> Total execution time: 0.0478
DEBUG - 2013-11-29 06:28:01 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:01 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:01 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:01 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:01 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:01 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:01 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:01 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:01 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:01 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:01 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:01 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:02 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:02 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:02 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:02 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:02 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:02 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:02 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:02 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:02 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:02 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:02 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:02 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:28:02 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:02 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:02 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:02 --> Total execution time: 0.0591
DEBUG - 2013-11-29 06:28:10 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:10 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:10 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:10 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:10 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:10 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:10 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:10 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:10 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:10 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:10 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:10 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:10 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:10 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:10 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:10 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:10 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:28:10 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:11 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:11 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:11 --> Total execution time: 0.1280
DEBUG - 2013-11-29 06:28:15 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:15 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:15 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:28:15 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:15 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:28:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:15 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:15 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:15 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:15 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:15 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:15 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:15 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:15 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:15 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:15 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:15 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:15 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:16 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:16 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:16 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:16 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:16 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:16 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:16 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:16 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:16 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:16 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:16 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:16 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:16 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:16 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:16 --> Total execution time: 0.0581
DEBUG - 2013-11-29 06:28:19 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:19 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:19 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:19 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:19 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:19 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:19 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:19 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:19 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:19 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:19 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:19 --> Total execution time: 0.0538
DEBUG - 2013-11-29 06:28:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:20 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:20 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:20 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:20 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:20 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:21 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:21 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:21 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:21 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:21 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:21 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:21 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:21 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:21 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:21 --> Total execution time: 0.0783
DEBUG - 2013-11-29 06:28:21 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:21 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:21 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:21 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:21 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:21 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:21 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:21 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:21 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:21 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:21 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:21 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:21 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:21 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:21 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:21 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:28:21 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:21 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:21 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:21 --> Total execution time: 0.1197
DEBUG - 2013-11-29 06:28:26 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:26 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:26 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:28:26 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:26 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:28:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:26 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:26 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:26 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:26 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:26 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:26 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:26 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:26 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:26 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:26 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:26 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:26 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:26 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:26 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:26 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:26 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:26 --> Total execution time: 0.0486
DEBUG - 2013-11-29 06:28:30 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:30 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:30 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:28:30 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:30 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:30 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:28:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:30 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:30 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:30 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:30 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:30 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:30 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:30 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:30 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:30 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:30 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:30 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:30 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:30 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:30 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:30 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:30 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:30 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:30 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:30 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:30 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:30 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:30 --> Total execution time: 0.0617
DEBUG - 2013-11-29 06:28:34 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:34 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:34 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:28:34 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:34 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:34 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:28:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:34 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:34 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:34 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:34 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:34 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:34 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:34 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:34 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:35 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:35 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:35 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:35 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:35 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:35 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:35 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:35 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:35 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:35 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:35 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:35 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:35 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:35 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:35 --> Total execution time: 0.0504
DEBUG - 2013-11-29 06:28:56 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:56 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:56 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:56 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:28:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:56 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:56 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:56 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:56 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:56 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:56 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:56 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:56 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:28:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:28:56 --> URI Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Router Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Output Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Security Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Input Class Initialized
DEBUG - 2013-11-29 06:28:56 --> XSS Filtering completed
DEBUG - 2013-11-29 06:28:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:28:56 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Language Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Config Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Loader Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Controller Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:28:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:28:56 --> Session Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:28:56 --> Session routines successfully run
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:28:56 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:28:56 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:28:56 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:28:56 --> Model Class Initialized
DEBUG - 2013-11-29 06:28:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:28:56 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:28:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:28:56 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:28:56 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:28:56 --> Final output sent to browser
DEBUG - 2013-11-29 06:28:56 --> Total execution time: 0.0505
DEBUG - 2013-11-29 06:29:23 --> Config Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:29:23 --> URI Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Router Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Output Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Security Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Input Class Initialized
DEBUG - 2013-11-29 06:29:23 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:23 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:23 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:29:23 --> Language Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Language Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Config Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Loader Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Controller Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:29:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:29:23 --> Session Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:29:23 --> A session cookie was not found.
DEBUG - 2013-11-29 06:29:23 --> Session routines successfully run
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:29:23 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:29:23 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:29:23 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:29:23 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:29:23 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:29:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:29:23 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:29:23 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:29:23 --> Final output sent to browser
DEBUG - 2013-11-29 06:29:23 --> Total execution time: 0.0548
DEBUG - 2013-11-29 06:29:33 --> Config Class Initialized
DEBUG - 2013-11-29 06:29:33 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:29:33 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:29:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:29:33 --> URI Class Initialized
DEBUG - 2013-11-29 06:29:33 --> Router Class Initialized
DEBUG - 2013-11-29 06:29:33 --> Output Class Initialized
DEBUG - 2013-11-29 06:29:33 --> Security Class Initialized
DEBUG - 2013-11-29 06:29:33 --> Input Class Initialized
DEBUG - 2013-11-29 06:29:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:29:33 --> Language Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Language Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Config Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Loader Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Controller Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:29:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:29:34 --> Session Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:29:34 --> Session routines successfully run
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:29:34 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:29:34 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:29:34 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:29:34 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:29:34 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:29:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:29:34 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:29:34 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:29:34 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:34 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:29:34 --> Final output sent to browser
DEBUG - 2013-11-29 06:29:34 --> Total execution time: 0.1241
DEBUG - 2013-11-29 06:29:36 --> Config Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:29:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:29:36 --> URI Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Router Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Output Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Security Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Input Class Initialized
DEBUG - 2013-11-29 06:29:36 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:36 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:36 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:36 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:36 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:36 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:29:36 --> Language Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Language Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Config Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Loader Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Controller Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:29:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:29:36 --> Session Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:29:36 --> Session routines successfully run
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:29:36 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:29:36 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:29:36 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:29:36 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:29:36 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:29:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:29:36 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:29:36 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:29:36 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:36 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:29:36 --> Final output sent to browser
DEBUG - 2013-11-29 06:29:36 --> Total execution time: 0.0564
DEBUG - 2013-11-29 06:29:37 --> Config Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:29:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:29:37 --> URI Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Router Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Output Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Security Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Input Class Initialized
DEBUG - 2013-11-29 06:29:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:29:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:29:37 --> Language Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Language Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Config Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Loader Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Controller Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:29:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:29:37 --> Session Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:29:37 --> Session routines successfully run
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:29:37 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:29:37 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:29:37 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:29:37 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:29:37 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:29:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:29:37 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:29:37 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:29:37 --> Model Class Initialized
DEBUG - 2013-11-29 06:29:37 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:29:37 --> Final output sent to browser
DEBUG - 2013-11-29 06:29:37 --> Total execution time: 0.0550
DEBUG - 2013-11-29 06:32:49 --> Config Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:32:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:32:49 --> URI Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Router Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Output Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Security Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Input Class Initialized
DEBUG - 2013-11-29 06:32:49 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:49 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:49 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:49 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:32:49 --> Language Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Language Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Config Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Loader Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Controller Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:32:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:32:49 --> Session Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:32:49 --> Session routines successfully run
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:32:49 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:32:49 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:32:49 --> Model Class Initialized
DEBUG - 2013-11-29 06:32:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:32:49 --> Model Class Initialized
DEBUG - 2013-11-29 06:32:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:32:49 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:32:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:32:49 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:32:49 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:32:49 --> Model Class Initialized
DEBUG - 2013-11-29 06:32:49 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:32:49 --> Final output sent to browser
DEBUG - 2013-11-29 06:32:49 --> Total execution time: 0.1294
DEBUG - 2013-11-29 06:32:56 --> Config Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:32:56 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:32:56 --> URI Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Router Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Output Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Security Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Input Class Initialized
DEBUG - 2013-11-29 06:32:56 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:56 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:56 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:56 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:56 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:56 --> XSS Filtering completed
DEBUG - 2013-11-29 06:32:56 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:32:56 --> Language Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Language Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Config Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Loader Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Controller Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:32:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:32:56 --> Session Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:32:56 --> Session routines successfully run
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:32:56 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:32:56 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:32:56 --> Model Class Initialized
DEBUG - 2013-11-29 06:32:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:32:56 --> Model Class Initialized
DEBUG - 2013-11-29 06:32:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:32:56 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:32:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:32:56 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:32:56 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:32:56 --> Model Class Initialized
DEBUG - 2013-11-29 06:32:56 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:32:56 --> Final output sent to browser
DEBUG - 2013-11-29 06:32:56 --> Total execution time: 0.1249
DEBUG - 2013-11-29 06:33:00 --> Config Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:33:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:33:00 --> URI Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Router Class Initialized
DEBUG - 2013-11-29 06:33:00 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:33:00 --> Output Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Security Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Input Class Initialized
DEBUG - 2013-11-29 06:33:00 --> XSS Filtering completed
DEBUG - 2013-11-29 06:33:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:33:00 --> Language Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Language Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Config Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Loader Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Controller Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:33:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:33:00 --> Session Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:33:00 --> Session routines successfully run
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:33:00 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:33:00 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:33:00 --> Model Class Initialized
DEBUG - 2013-11-29 06:33:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:33:00 --> Model Class Initialized
DEBUG - 2013-11-29 06:33:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:33:00 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:33:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:33:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:33:01 --> Config Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:33:01 --> URI Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Router Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Output Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Security Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Input Class Initialized
DEBUG - 2013-11-29 06:33:01 --> XSS Filtering completed
DEBUG - 2013-11-29 06:33:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:33:01 --> Language Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Language Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Config Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Loader Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Controller Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:33:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:33:01 --> Session Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:33:01 --> Session routines successfully run
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:33:01 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:33:01 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:33:01 --> Model Class Initialized
DEBUG - 2013-11-29 06:33:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:33:01 --> Model Class Initialized
DEBUG - 2013-11-29 06:33:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:33:01 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:33:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:33:01 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:33:01 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:33:01 --> Final output sent to browser
DEBUG - 2013-11-29 06:33:01 --> Total execution time: 0.0391
DEBUG - 2013-11-29 06:34:33 --> Config Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:34:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:34:33 --> URI Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Router Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Output Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Security Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Input Class Initialized
DEBUG - 2013-11-29 06:34:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:34:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:34:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:34:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:34:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:34:33 --> Language Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Language Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Config Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Loader Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Controller Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:34:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:34:33 --> Session Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:34:33 --> Session routines successfully run
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:34:33 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:34:33 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:34:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:34:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:34:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:34:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:34:33 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:34:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:34:33 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:34:33 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:34:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:34:33 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:34:33 --> Final output sent to browser
DEBUG - 2013-11-29 06:34:33 --> Total execution time: 0.1265
DEBUG - 2013-11-29 06:38:15 --> Config Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:38:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:38:15 --> URI Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Router Class Initialized
DEBUG - 2013-11-29 06:38:15 --> No URI present. Default controller set.
DEBUG - 2013-11-29 06:38:15 --> Output Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Security Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Input Class Initialized
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:38:15 --> Language Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Language Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Config Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Loader Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Controller Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:38:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:38:15 --> Session Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:38:15 --> A session cookie was not found.
DEBUG - 2013-11-29 06:38:15 --> Session routines successfully run
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:38:15 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:38:15 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:38:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:38:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:38:15 --> Config Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:38:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:38:15 --> URI Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Router Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Output Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Security Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Input Class Initialized
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:38:15 --> Language Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Language Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Config Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Loader Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Controller Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:38:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:38:15 --> Session Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:38:15 --> Session routines successfully run
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:38:15 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:38:15 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:38:15 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:38:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:38:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:38:15 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 06:38:15 --> Final output sent to browser
DEBUG - 2013-11-29 06:38:15 --> Total execution time: 0.0632
DEBUG - 2013-11-29 06:38:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:38:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:38:20 --> URI Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Router Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Output Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Security Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Input Class Initialized
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:38:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Loader Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Controller Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 06:38:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:38:20 --> Session Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:38:20 --> Session routines successfully run
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:38:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:38:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:38:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:38:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:38:20 --> URI Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Router Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Output Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Security Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Input Class Initialized
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:38:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:38:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Loader Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Controller Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:38:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:38:20 --> Session Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:38:20 --> Session routines successfully run
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:38:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:38:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:38:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:38:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/modules/invoices/models/mdl_invoice_amounts.php
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/modules/quotes/models/mdl_quote_amounts.php
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/modules/quotes/models/mdl_quotes.php
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-29 06:38:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:38:20 --> DB Transaction Failure
ERROR - 2013-11-29 06:38:20 --> Query error: Column 'user_id' in where clause is ambiguous
DEBUG - 2013-11-29 06:38:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2013-11-29 06:39:24 --> Config Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:39:24 --> URI Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Router Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Output Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Security Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Input Class Initialized
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:39:24 --> Language Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Language Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Config Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Loader Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Controller Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 06:39:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:39:24 --> Session Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:39:24 --> Session routines successfully run
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:39:24 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:39:24 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:39:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:39:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:39:24 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:39:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/invoices/models/mdl_invoice_amounts.php
DEBUG - 2013-11-29 06:39:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/quotes/models/mdl_quote_amounts.php
DEBUG - 2013-11-29 06:39:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-29 06:39:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/quotes/models/mdl_quotes.php
DEBUG - 2013-11-29 06:39:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-29 06:39:24 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-11-29 06:39:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 06:39:24 --> Final output sent to browser
DEBUG - 2013-11-29 06:39:24 --> Total execution time: 0.0749
DEBUG - 2013-11-29 06:39:26 --> Config Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:39:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:39:26 --> URI Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Router Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Config Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:39:26 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:39:26 --> Output Class Initialized
DEBUG - 2013-11-29 06:39:26 --> URI Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Security Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Input Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Router Class Initialized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Output Class Initialized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Security Class Initialized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Input Class Initialized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Language Class Initialized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Language Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Config Class Initialized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Loader Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Controller Class Initialized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-29 06:39:26 --> XSS Filtering completed
DEBUG - 2013-11-29 06:39:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:39:26 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:39:26 --> Language Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Session Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:39:26 --> Session routines successfully run
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:39:26 --> Language Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Config Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Loader Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Controller Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-29 06:39:26 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:39:26 --> Session Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:39:26 --> Session routines successfully run
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:39:26 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:39:26 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:39:26 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:39:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:39:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:39:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:39:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:39:26 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:39:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:39:26 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:39:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:39:26 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:39:26 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-29 06:39:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:26 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-29 06:39:26 --> Model Class Initialized
DEBUG - 2013-11-29 06:39:26 --> Final output sent to browser
DEBUG - 2013-11-29 06:39:26 --> Total execution time: 0.0538
DEBUG - 2013-11-29 06:39:26 --> Final output sent to browser
DEBUG - 2013-11-29 06:39:26 --> Total execution time: 0.0597
DEBUG - 2013-11-29 06:41:19 --> Config Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:41:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:41:19 --> URI Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Router Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Output Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Security Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Input Class Initialized
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:41:19 --> Language Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Language Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Config Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Loader Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Controller Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:41:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:41:19 --> Session Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:41:19 --> Session routines successfully run
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:41:19 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:41:19 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:41:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:41:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:41:19 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:41:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Config Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:41:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:41:19 --> URI Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Router Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Output Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Security Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Input Class Initialized
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> XSS Filtering completed
DEBUG - 2013-11-29 06:41:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:41:19 --> Language Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Language Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Config Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Loader Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Controller Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:41:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:41:19 --> Session Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:41:19 --> Session routines successfully run
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:41:19 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:41:19 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:41:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:41:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:41:19 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:41:19 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:41:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:41:19 --> Pagination Class Initialized
ERROR - 2013-11-29 06:41:19 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/modules/usergroups/views/index.php
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 06:41:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 06:41:19 --> Final output sent to browser
DEBUG - 2013-11-29 06:41:19 --> Total execution time: 0.0554
DEBUG - 2013-11-29 06:53:17 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:53:17 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:53:17 --> URI Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Router Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Output Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Security Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Input Class Initialized
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:53:17 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Loader Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Controller Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:53:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:53:17 --> Session Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:53:17 --> Session routines successfully run
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:53:17 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:53:17 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:53:17 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:53:17 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:53:17 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:53:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:53:17 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:53:17 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:53:17 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:17 --> Pagination Class Initialized
ERROR - 2013-11-29 06:53:17 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 06:53:17 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 06:53:17 --> File loaded: application/modules/usergroups/views/index.php
DEBUG - 2013-11-29 06:53:17 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 06:53:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 06:53:17 --> Final output sent to browser
DEBUG - 2013-11-29 06:53:17 --> Total execution time: 0.0613
DEBUG - 2013-11-29 06:53:18 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:53:18 --> URI Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Router Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Output Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Security Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Input Class Initialized
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:53:18 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Loader Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Controller Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:53:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:53:18 --> Session Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:53:18 --> Session routines successfully run
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:53:18 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:53:18 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:53:18 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:53:18 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:53:18 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:53:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:53:18 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:53:18 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:53:18 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:53:18 --> URI Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Router Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Output Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Security Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Input Class Initialized
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:53:18 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:18 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:19 --> Loader Class Initialized
DEBUG - 2013-11-29 06:53:19 --> Controller Class Initialized
DEBUG - 2013-11-29 06:53:19 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:53:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:53:19 --> Session Class Initialized
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:53:19 --> Session routines successfully run
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:53:19 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:53:19 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:53:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:53:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:53:19 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:53:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:53:19 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:53:19 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:53:19 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:19 --> Pagination Class Initialized
ERROR - 2013-11-29 06:53:19 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 06:53:19 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 06:53:19 --> File loaded: application/modules/usergroups/views/index.php
DEBUG - 2013-11-29 06:53:19 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 06:53:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 06:53:19 --> Final output sent to browser
DEBUG - 2013-11-29 06:53:19 --> Total execution time: 0.0553
DEBUG - 2013-11-29 06:53:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:53:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:53:20 --> URI Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Router Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Output Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Security Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Input Class Initialized
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:53:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Loader Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Controller Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:53:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:53:20 --> Session Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:53:20 --> Session routines successfully run
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:53:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:53:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:53:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:53:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:53:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:53:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:53:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:53:20 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:53:20 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:20 --> Pagination Class Initialized
ERROR - 2013-11-29 06:53:20 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 06:53:20 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 06:53:20 --> File loaded: application/modules/usergroups/views/index.php
DEBUG - 2013-11-29 06:53:20 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 06:53:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 06:53:20 --> Final output sent to browser
DEBUG - 2013-11-29 06:53:20 --> Total execution time: 0.0558
DEBUG - 2013-11-29 06:53:33 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:53:33 --> URI Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Router Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Output Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Security Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Input Class Initialized
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:53:33 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Loader Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Controller Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:53:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:53:33 --> Session Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:53:33 --> Session routines successfully run
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:53:33 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:53:33 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:53:33 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:53:33 --> URI Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Router Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Output Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Security Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Input Class Initialized
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:33 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:53:33 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Loader Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Controller Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:53:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:53:33 --> Session Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:53:33 --> Session routines successfully run
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:53:33 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:53:33 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:53:33 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:53:33 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:53:33 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:33 --> Pagination Class Initialized
ERROR - 2013-11-29 06:53:33 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/modules/usergroups/views/index.php
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 06:53:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 06:53:33 --> Final output sent to browser
DEBUG - 2013-11-29 06:53:33 --> Total execution time: 0.0539
DEBUG - 2013-11-29 06:53:37 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Hooks Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Utf8 Class Initialized
DEBUG - 2013-11-29 06:53:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 06:53:37 --> URI Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Router Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Output Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Security Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Input Class Initialized
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> XSS Filtering completed
DEBUG - 2013-11-29 06:53:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 06:53:37 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Language Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Config Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Loader Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Controller Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 06:53:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 06:53:37 --> Session Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: string_helper
DEBUG - 2013-11-29 06:53:37 --> Session routines successfully run
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: url_helper
DEBUG - 2013-11-29 06:53:37 --> Database Driver Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: form_helper
DEBUG - 2013-11-29 06:53:37 --> Form Validation Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: number_helper
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: date_helper
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 06:53:37 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 06:53:37 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 06:53:37 --> Helper loaded: language_helper
DEBUG - 2013-11-29 06:53:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 06:53:37 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 06:53:37 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 06:53:37 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:37 --> File loaded: application/modules/custom_fields/models/mdl_usergroups_custom.php
DEBUG - 2013-11-29 06:53:37 --> Model Class Initialized
DEBUG - 2013-11-29 06:53:37 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 06:53:37 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 06:53:37 --> File loaded: application/modules/usergroups/views/form.php
DEBUG - 2013-11-29 06:53:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 06:53:37 --> Final output sent to browser
DEBUG - 2013-11-29 06:53:37 --> Total execution time: 0.0736
DEBUG - 2013-11-29 07:17:00 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:17:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:17:00 --> URI Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Router Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Output Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Security Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Input Class Initialized
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:17:00 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Loader Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Controller Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 07:17:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:17:00 --> Session Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:17:00 --> Session routines successfully run
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:17:00 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:17:00 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:17:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/custom_fields/models/mdl_usergroups_custom.php
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:17:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:17:00 --> URI Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Router Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Output Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Security Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Input Class Initialized
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:17:00 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Loader Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Controller Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 07:17:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:17:00 --> Session Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:17:00 --> Session routines successfully run
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:17:00 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:17:00 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:17:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:17:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:17:00 --> URI Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Router Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Output Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Security Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Input Class Initialized
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:17:00 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Loader Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Controller Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 07:17:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:17:00 --> Session Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:17:00 --> Session routines successfully run
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:17:00 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:17:00 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:17:00 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:17:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 07:17:00 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:00 --> Pagination Class Initialized
ERROR - 2013-11-29 07:17:00 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/usergroups/views/index.php
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:17:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:17:00 --> Final output sent to browser
DEBUG - 2013-11-29 07:17:00 --> Total execution time: 0.0563
DEBUG - 2013-11-29 07:17:14 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:17:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:17:14 --> URI Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Router Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Output Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Security Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Input Class Initialized
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:17:14 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Loader Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Controller Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:17:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:17:14 --> Session Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:17:14 --> Session routines successfully run
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:17:14 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:17:14 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:17:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:17:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:17:14 --> URI Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Router Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Output Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Security Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Input Class Initialized
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> XSS Filtering completed
DEBUG - 2013-11-29 07:17:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:17:14 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Language Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Config Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Loader Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Controller Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:17:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:17:14 --> Session Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:17:14 --> Session routines successfully run
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:17:14 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:17:14 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:17:14 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:17:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:17:14 --> Model Class Initialized
DEBUG - 2013-11-29 07:17:14 --> Pagination Class Initialized
ERROR - 2013-11-29 07:17:14 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:17:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:17:14 --> Final output sent to browser
DEBUG - 2013-11-29 07:17:14 --> Total execution time: 0.0758
DEBUG - 2013-11-29 07:20:42 --> Config Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:20:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:20:42 --> URI Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Router Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Output Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Security Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Input Class Initialized
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:20:42 --> Language Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Language Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Config Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Loader Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Controller Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:20:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:20:42 --> Session Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:20:42 --> Session routines successfully run
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:20:42 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:20:42 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:20:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:20:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:20:42 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:20:42 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:20:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:20:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:20:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:42 --> Pagination Class Initialized
ERROR - 2013-11-29 07:20:42 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:20:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:20:42 --> Final output sent to browser
DEBUG - 2013-11-29 07:20:42 --> Total execution time: 0.0635
DEBUG - 2013-11-29 07:20:43 --> Config Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:20:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:20:43 --> URI Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Router Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Output Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Security Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Input Class Initialized
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:20:43 --> Language Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Language Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Config Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Loader Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Controller Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:20:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:20:43 --> Session Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:20:43 --> Session routines successfully run
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:20:43 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:20:43 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:20:43 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:20:43 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:20:43 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:20:43 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:20:43 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:20:43 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:20:43 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:43 --> Pagination Class Initialized
ERROR - 2013-11-29 07:20:43 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:20:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:20:43 --> Final output sent to browser
DEBUG - 2013-11-29 07:20:43 --> Total execution time: 0.0537
DEBUG - 2013-11-29 07:20:45 --> Config Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:20:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:20:45 --> URI Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Router Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Output Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Security Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Input Class Initialized
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:20:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:20:45 --> Language Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Language Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Config Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Loader Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Controller Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:20:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:20:45 --> Session Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:20:45 --> Session routines successfully run
DEBUG - 2013-11-29 07:20:45 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:20:45 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:20:45 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:20:45 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:20:45 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:20:45 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:20:45 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:20:45 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:20:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:20:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:20:46 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:20:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:20:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:20:46 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:20:46 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:46 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:20:46 --> Model Class Initialized
DEBUG - 2013-11-29 07:20:46 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:20:46 --> Model Class Initialized
ERROR - 2013-11-29 07:20:46 --> Could not find the language line "baner_image"
ERROR - 2013-11-29 07:20:46 --> Could not find the language line "content"
DEBUG - 2013-11-29 07:20:46 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 07:20:46 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-29 07:20:46 --> Severity: Notice  --> Undefined variable: user_client_table D:\xampp\htdocs\adminpanel\application\modules\cms\views\form.php 115
DEBUG - 2013-11-29 07:20:46 --> File loaded: application/modules/cms/views/form.php
DEBUG - 2013-11-29 07:20:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:20:46 --> Final output sent to browser
DEBUG - 2013-11-29 07:20:46 --> Total execution time: 0.0648
DEBUG - 2013-11-29 07:21:58 --> Config Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:21:58 --> URI Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Router Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Output Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Security Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Input Class Initialized
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:21:58 --> Language Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Language Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Config Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Loader Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Controller Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 07:21:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:21:58 --> Session Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:21:58 --> Session routines successfully run
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:21:58 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:21:58 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:21:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:21:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:21:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 07:21:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Config Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:21:58 --> URI Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Router Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Output Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Security Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Input Class Initialized
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:21:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:21:58 --> Language Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Language Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Config Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Loader Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Controller Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 07:21:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:21:58 --> Session Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:21:58 --> Session routines successfully run
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:21:58 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:21:58 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:21:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:21:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:21:58 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:21:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 07:21:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:21:58 --> Pagination Class Initialized
ERROR - 2013-11-29 07:21:58 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/modules/usergroups/views/index.php
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:21:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:21:58 --> Final output sent to browser
DEBUG - 2013-11-29 07:21:58 --> Total execution time: 0.0814
DEBUG - 2013-11-29 07:31:13 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:13 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:13 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:13 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:13 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:13 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:13 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:13 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:13 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:13 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:13 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:13 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:13 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:13 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:13 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:13 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:13 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:13 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:13 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:13 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:13 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:13 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:13 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:13 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:13 --> Pagination Class Initialized
ERROR - 2013-11-29 07:31:13 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:31:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:31:13 --> Final output sent to browser
DEBUG - 2013-11-29 07:31:13 --> Total execution time: 0.0601
DEBUG - 2013-11-29 07:31:20 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:20 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:20 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:20 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:20 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:20 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:20 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:20 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:20 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:20 --> Model Class Initialized
ERROR - 2013-11-29 07:31:20 --> Could not find the language line "baner_image"
ERROR - 2013-11-29 07:31:20 --> Could not find the language line "content"
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-29 07:31:20 --> Severity: Notice  --> Undefined variable: user_client_table D:\xampp\htdocs\adminpanel\application\modules\cms\views\form.php 115
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/modules/cms/views/form.php
DEBUG - 2013-11-29 07:31:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:31:20 --> Final output sent to browser
DEBUG - 2013-11-29 07:31:20 --> Total execution time: 0.0860
DEBUG - 2013-11-29 07:31:32 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:32 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:32 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:32 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:32 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:32 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:32 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:32 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
ERROR - 2013-11-29 07:31:32 --> Could not find the language line "baner_image"
ERROR - 2013-11-29 07:31:32 --> Could not find the language line "content"
DEBUG - 2013-11-29 07:31:32 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2013-11-29 07:31:32 --> Could not find the language line "baner_image"
ERROR - 2013-11-29 07:31:32 --> Could not find the language line "content"
DEBUG - 2013-11-29 07:31:32 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:32 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:32 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:32 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:32 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:32 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:32 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:32 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:32 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:32 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:32 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:32 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:32 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:32 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:32 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:32 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:32 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:32 --> Pagination Class Initialized
ERROR - 2013-11-29 07:31:32 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:31:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:31:32 --> Final output sent to browser
DEBUG - 2013-11-29 07:31:32 --> Total execution time: 0.0615
DEBUG - 2013-11-29 07:31:35 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:35 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:35 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:35 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:35 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:35 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:35 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:35 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:35 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:35 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:35 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:35 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:35 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:35 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:35 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:35 --> Model Class Initialized
ERROR - 2013-11-29 07:31:35 --> Could not find the language line "baner_image"
ERROR - 2013-11-29 07:31:35 --> Could not find the language line "content"
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-29 07:31:35 --> Severity: Notice  --> Undefined variable: user_client_table D:\xampp\htdocs\adminpanel\application\modules\cms\views\form.php 115
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/modules/cms/views/form.php
DEBUG - 2013-11-29 07:31:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:31:35 --> Final output sent to browser
DEBUG - 2013-11-29 07:31:35 --> Total execution time: 0.0609
DEBUG - 2013-11-29 07:31:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:40 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:40 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:40 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:40 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:40 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:40 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:40 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:40 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:40 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:40 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:40 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:40 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:40 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:40 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:40 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:40 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:40 --> Pagination Class Initialized
ERROR - 2013-11-29 07:31:40 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:31:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:31:40 --> Final output sent to browser
DEBUG - 2013-11-29 07:31:40 --> Total execution time: 0.0643
DEBUG - 2013-11-29 07:31:42 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:42 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:42 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:42 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:42 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:42 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:42 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:42 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:42 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:42 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:42 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:42 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:42 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:42 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:42 --> Model Class Initialized
ERROR - 2013-11-29 07:31:42 --> Could not find the language line "baner_image"
ERROR - 2013-11-29 07:31:42 --> Could not find the language line "content"
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-29 07:31:42 --> Severity: Notice  --> Undefined variable: user_client_table D:\xampp\htdocs\adminpanel\application\modules\cms\views\form.php 115
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/modules/cms/views/form.php
DEBUG - 2013-11-29 07:31:42 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:31:42 --> Final output sent to browser
DEBUG - 2013-11-29 07:31:42 --> Total execution time: 0.0997
DEBUG - 2013-11-29 07:31:45 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:45 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:45 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:45 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:45 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:45 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:45 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:45 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:45 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:45 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:45 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:45 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:45 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:45 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:45 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:31:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:31:45 --> URI Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Router Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Output Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Security Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Input Class Initialized
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> XSS Filtering completed
DEBUG - 2013-11-29 07:31:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:31:45 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Language Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Config Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Loader Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Controller Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:31:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:31:45 --> Session Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:31:45 --> Session routines successfully run
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:31:45 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:31:45 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:31:45 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:31:45 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:31:45 --> Model Class Initialized
DEBUG - 2013-11-29 07:31:45 --> Pagination Class Initialized
ERROR - 2013-11-29 07:31:45 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:31:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:31:45 --> Final output sent to browser
DEBUG - 2013-11-29 07:31:45 --> Total execution time: 0.0579
DEBUG - 2013-11-29 07:32:30 --> Config Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:32:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:32:30 --> URI Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Router Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Output Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Security Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Input Class Initialized
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:32:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:32:30 --> Language Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Language Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Config Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Loader Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Controller Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:32:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:32:30 --> Session Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:32:30 --> Session routines successfully run
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:32:30 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:32:30 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:32:30 --> Model Class Initialized
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:32:30 --> Model Class Initialized
DEBUG - 2013-11-29 07:32:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:32:30 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:32:30 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:32:30 --> Model Class Initialized
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:32:30 --> Model Class Initialized
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:32:30 --> Model Class Initialized
ERROR - 2013-11-29 07:32:30 --> Could not find the language line "baner_image"
ERROR - 2013-11-29 07:32:30 --> Could not find the language line "content"
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-29 07:32:30 --> Severity: Notice  --> Undefined variable: user_client_table D:\xampp\htdocs\adminpanel\application\modules\cms\views\form.php 115
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/modules/cms/views/form.php
DEBUG - 2013-11-29 07:32:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:32:30 --> Final output sent to browser
DEBUG - 2013-11-29 07:32:30 --> Total execution time: 0.0852
DEBUG - 2013-11-29 07:33:06 --> Config Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:33:06 --> URI Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Router Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Output Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Security Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Input Class Initialized
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:33:06 --> Language Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Language Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Config Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Loader Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Controller Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:33:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:33:06 --> Session Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:33:06 --> Session routines successfully run
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:33:06 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:33:06 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:33:06 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Config Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:33:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:33:06 --> URI Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Router Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Output Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Security Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Input Class Initialized
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> XSS Filtering completed
DEBUG - 2013-11-29 07:33:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:33:06 --> Language Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Language Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Config Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Loader Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Controller Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:33:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:33:06 --> Session Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:33:06 --> Session routines successfully run
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:33:06 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:33:06 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:33:06 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:33:06 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:33:06 --> Model Class Initialized
DEBUG - 2013-11-29 07:33:06 --> Pagination Class Initialized
ERROR - 2013-11-29 07:33:06 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:33:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:33:06 --> Final output sent to browser
DEBUG - 2013-11-29 07:33:06 --> Total execution time: 0.0700
DEBUG - 2013-11-29 07:37:24 --> Config Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:37:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:37:24 --> URI Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Router Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Output Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Security Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Input Class Initialized
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:37:24 --> Language Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Language Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Config Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Loader Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Controller Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 07:37:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:37:24 --> Session Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:37:24 --> Session routines successfully run
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:37:24 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:37:24 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:37:24 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:37:24 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:37:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 07:37:24 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Config Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:37:24 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:37:24 --> URI Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Router Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Output Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Security Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Input Class Initialized
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:24 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:37:24 --> Language Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Language Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Config Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Loader Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Controller Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Usergroups MX_Controller Initialized
DEBUG - 2013-11-29 07:37:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:37:24 --> Session Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:37:24 --> Session routines successfully run
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:37:24 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:37:24 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:37:24 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:37:24 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:37:24 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:37:24 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/modules/usergroups/models/mdl_usergroups.php
DEBUG - 2013-11-29 07:37:24 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:24 --> Pagination Class Initialized
ERROR - 2013-11-29 07:37:24 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/modules/usergroups/views/index.php
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:37:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:37:24 --> Final output sent to browser
DEBUG - 2013-11-29 07:37:24 --> Total execution time: 0.0564
DEBUG - 2013-11-29 07:37:28 --> Config Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:37:28 --> URI Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Router Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Output Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Security Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Input Class Initialized
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:37:28 --> Language Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Language Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Config Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Loader Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Controller Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:37:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:37:28 --> Session Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:37:28 --> Session routines successfully run
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:37:28 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:37:28 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:37:28 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:37:28 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:37:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:37:28 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:37:28 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:37:28 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Config Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:37:28 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:37:28 --> URI Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Router Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Output Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Security Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Input Class Initialized
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> XSS Filtering completed
DEBUG - 2013-11-29 07:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:37:28 --> Language Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Language Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Config Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Loader Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Controller Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:37:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:37:28 --> Session Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:37:28 --> Session routines successfully run
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:37:28 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:37:28 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:37:28 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:37:28 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:37:28 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:37:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:37:28 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:37:28 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:37:28 --> Model Class Initialized
DEBUG - 2013-11-29 07:37:29 --> Pagination Class Initialized
ERROR - 2013-11-29 07:37:29 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:37:29 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:37:29 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 07:37:29 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:37:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:37:29 --> Final output sent to browser
DEBUG - 2013-11-29 07:37:29 --> Total execution time: 0.0602
DEBUG - 2013-11-29 07:38:15 --> Config Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:38:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:38:15 --> URI Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Router Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Output Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Security Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Input Class Initialized
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:38:15 --> Language Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Language Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Config Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Loader Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Controller Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:38:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:38:15 --> Session Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:38:15 --> Session routines successfully run
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:38:15 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:38:15 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:38:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Config Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:38:15 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:38:15 --> URI Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Router Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Output Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Security Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Input Class Initialized
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> XSS Filtering completed
DEBUG - 2013-11-29 07:38:15 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:38:15 --> Language Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Language Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Config Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Loader Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Controller Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Cms MX_Controller Initialized
DEBUG - 2013-11-29 07:38:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:38:15 --> Session Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:38:15 --> Session routines successfully run
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:38:15 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:38:15 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:38:15 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:38:15 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/cms/models/mdl_cmscategory.php
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/custom_fields/models/mdl_pages_custom.php
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/cms/models/mdl_pages.php
DEBUG - 2013-11-29 07:38:15 --> Model Class Initialized
DEBUG - 2013-11-29 07:38:15 --> Pagination Class Initialized
ERROR - 2013-11-29 07:38:15 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/cms/views/partial_quote_table.php
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/cms/views/index.php
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:38:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:38:15 --> Final output sent to browser
DEBUG - 2013-11-29 07:38:15 --> Total execution time: 0.0641
DEBUG - 2013-11-29 07:39:50 --> Config Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:39:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:39:50 --> URI Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Router Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Output Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Security Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Input Class Initialized
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:39:50 --> Language Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Language Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Config Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Loader Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Controller Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:39:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:39:50 --> Session Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:39:50 --> Session routines successfully run
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:39:50 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:39:50 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:39:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:39:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:39:50 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:39:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Config Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:39:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:39:50 --> URI Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Router Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Output Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Security Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Input Class Initialized
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:39:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:39:50 --> Language Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Language Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Config Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Loader Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Controller Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:39:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:39:50 --> Session Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:39:50 --> Session routines successfully run
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:39:50 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:39:50 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:39:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:39:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:39:50 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:39:50 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:39:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:39:50 --> Pagination Class Initialized
ERROR - 2013-11-29 07:39:50 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:39:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:39:50 --> Final output sent to browser
DEBUG - 2013-11-29 07:39:50 --> Total execution time: 0.0571
DEBUG - 2013-11-29 07:47:30 --> Config Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:47:30 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:47:30 --> URI Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Router Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Output Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Security Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Input Class Initialized
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> XSS Filtering completed
DEBUG - 2013-11-29 07:47:30 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:47:30 --> Language Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Language Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Config Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Loader Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Controller Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:47:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:47:30 --> Session Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:47:30 --> Session routines successfully run
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:47:30 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:47:30 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:47:30 --> Model Class Initialized
DEBUG - 2013-11-29 07:47:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:47:30 --> Model Class Initialized
DEBUG - 2013-11-29 07:47:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:47:30 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:47:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:47:30 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:47:30 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:47:30 --> Model Class Initialized
DEBUG - 2013-11-29 07:47:30 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 07:47:30 --> Model Class Initialized
DEBUG - 2013-11-29 07:47:30 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 07:47:30 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:47:30 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 07:47:30 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:47:30 --> Final output sent to browser
DEBUG - 2013-11-29 07:47:30 --> Total execution time: 0.0629
DEBUG - 2013-11-29 07:58:50 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:58:50 --> URI Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Router Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Output Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Security Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Input Class Initialized
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:58:50 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Loader Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Controller Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:58:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:58:50 --> Session Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:58:50 --> Session routines successfully run
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:58:50 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:58:50 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:58:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:58:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:58:50 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:58:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:58:50 --> URI Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Router Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Output Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Security Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Input Class Initialized
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:58:50 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Loader Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Controller Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:58:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:58:50 --> Session Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:58:50 --> Session routines successfully run
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:58:50 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:58:50 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:58:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:58:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:58:50 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:58:50 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:58:50 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:50 --> Pagination Class Initialized
ERROR - 2013-11-29 07:58:50 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:58:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:58:50 --> Final output sent to browser
DEBUG - 2013-11-29 07:58:50 --> Total execution time: 0.0562
DEBUG - 2013-11-29 07:58:53 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:58:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:58:53 --> URI Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Router Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Output Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Security Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Input Class Initialized
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:58:53 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Loader Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Controller Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:58:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:58:53 --> Session Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:58:53 --> Session routines successfully run
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:58:53 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:58:53 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:58:53 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:58:53 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:58:53 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:58:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:58:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:58:53 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:58:53 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:53 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 07:58:53 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:53 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 07:58:53 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:58:53 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 07:58:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:58:53 --> Final output sent to browser
DEBUG - 2013-11-29 07:58:53 --> Total execution time: 0.0801
DEBUG - 2013-11-29 07:58:58 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:58:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:58:58 --> URI Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Router Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Output Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Security Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Input Class Initialized
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:58:58 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Loader Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Controller Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:58:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:58:58 --> Session Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:58:58 --> Session routines successfully run
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:58:58 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:58:58 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:58:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:58:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:58:58 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:58:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:58:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:58:58 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:58:58 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:58:58 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:58:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:58:59 --> URI Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Router Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Output Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Security Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Input Class Initialized
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> XSS Filtering completed
DEBUG - 2013-11-29 07:58:59 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:58:59 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Language Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Config Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Loader Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Controller Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:58:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:58:59 --> Session Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:58:59 --> Session routines successfully run
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:58:59 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:58:59 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:58:59 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:58:59 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:58:59 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:58:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:58:59 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:58:59 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:58:59 --> Model Class Initialized
DEBUG - 2013-11-29 07:58:59 --> Pagination Class Initialized
ERROR - 2013-11-29 07:58:59 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:58:59 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:58:59 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 07:58:59 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:58:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:58:59 --> Final output sent to browser
DEBUG - 2013-11-29 07:58:59 --> Total execution time: 0.0624
DEBUG - 2013-11-29 07:59:01 --> Config Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:59:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:59:01 --> URI Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Router Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Output Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Security Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Input Class Initialized
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:59:01 --> Language Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Language Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Config Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Loader Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Controller Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:59:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:59:01 --> Session Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:59:01 --> Session routines successfully run
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:59:01 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:59:01 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:59:01 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:59:01 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:59:01 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:59:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:59:01 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:59:01 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:59:01 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:01 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 07:59:01 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:01 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 07:59:01 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:59:01 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 07:59:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:59:01 --> Final output sent to browser
DEBUG - 2013-11-29 07:59:01 --> Total execution time: 0.0549
DEBUG - 2013-11-29 07:59:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:59:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:59:40 --> URI Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Router Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Output Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Security Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Input Class Initialized
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:59:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Loader Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Controller Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:59:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:59:40 --> Session Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:59:40 --> Session routines successfully run
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:59:40 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:59:40 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:59:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:59:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:59:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:59:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Hooks Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Utf8 Class Initialized
DEBUG - 2013-11-29 07:59:40 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 07:59:40 --> URI Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Router Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Output Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Security Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Input Class Initialized
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> XSS Filtering completed
DEBUG - 2013-11-29 07:59:40 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 07:59:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Language Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Config Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Loader Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Controller Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 07:59:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 07:59:40 --> Session Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: string_helper
DEBUG - 2013-11-29 07:59:40 --> Session routines successfully run
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: url_helper
DEBUG - 2013-11-29 07:59:40 --> Database Driver Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: form_helper
DEBUG - 2013-11-29 07:59:40 --> Form Validation Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: number_helper
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: date_helper
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 07:59:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 07:59:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 07:59:40 --> Helper loaded: language_helper
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 07:59:40 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 07:59:40 --> Model Class Initialized
DEBUG - 2013-11-29 07:59:40 --> Pagination Class Initialized
ERROR - 2013-11-29 07:59:40 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 07:59:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 07:59:40 --> Final output sent to browser
DEBUG - 2013-11-29 07:59:40 --> Total execution time: 0.0774
DEBUG - 2013-11-29 08:01:49 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:01:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:01:49 --> URI Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Router Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Output Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Security Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Input Class Initialized
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:01:49 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Loader Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Controller Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:01:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:01:49 --> Session Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:01:49 --> Session routines successfully run
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:01:49 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:01:49 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:01:49 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:01:49 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:01:49 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:01:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:01:49 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:01:49 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:01:49 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:49 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:01:49 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:49 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 08:01:49 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:01:49 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 08:01:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:01:49 --> Final output sent to browser
DEBUG - 2013-11-29 08:01:49 --> Total execution time: 0.0818
DEBUG - 2013-11-29 08:01:53 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:01:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:01:53 --> URI Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Router Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Output Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Security Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Input Class Initialized
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:01:53 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Loader Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Controller Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:01:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:01:53 --> Session Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:01:53 --> Session routines successfully run
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:01:53 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:01:53 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:01:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:01:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:01:53 --> URI Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Router Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Output Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Security Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Input Class Initialized
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:01:53 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Loader Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Controller Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:01:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:01:53 --> Session Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:01:53 --> Session routines successfully run
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:01:53 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:01:53 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:01:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:01:53 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:01:53 --> URI Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Router Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Output Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Security Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Input Class Initialized
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:53 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:01:53 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Loader Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Controller Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:01:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:01:53 --> Session Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:01:53 --> Session routines successfully run
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:01:53 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:01:53 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:01:53 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:01:53 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:01:53 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:53 --> Pagination Class Initialized
ERROR - 2013-11-29 08:01:53 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 08:01:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:01:53 --> Final output sent to browser
DEBUG - 2013-11-29 08:01:53 --> Total execution time: 0.0625
DEBUG - 2013-11-29 08:01:55 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:01:55 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:01:55 --> URI Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Router Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Output Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Security Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Input Class Initialized
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> XSS Filtering completed
DEBUG - 2013-11-29 08:01:55 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:01:55 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Language Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Config Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Loader Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Controller Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:01:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:01:55 --> Session Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:01:55 --> Session routines successfully run
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:01:55 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:01:55 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:01:55 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:01:55 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:01:55 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:01:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:01:55 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:01:55 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:01:55 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:55 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:01:55 --> Model Class Initialized
DEBUG - 2013-11-29 08:01:55 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 08:01:55 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:01:55 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 08:01:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:01:55 --> Final output sent to browser
DEBUG - 2013-11-29 08:01:55 --> Total execution time: 0.0864
DEBUG - 2013-11-29 08:03:08 --> Config Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:03:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:03:08 --> URI Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Router Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Output Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Security Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Input Class Initialized
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:03:08 --> Language Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Language Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Config Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Loader Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Controller Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:03:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:03:08 --> Session Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:03:08 --> Session routines successfully run
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:03:08 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:03:08 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:03:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:03:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:03:08 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:03:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:03:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2013-11-29 08:03:08 --> Config Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:03:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:03:08 --> URI Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Router Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Output Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Security Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Input Class Initialized
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:03:08 --> Language Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Language Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Config Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Loader Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Controller Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:03:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:03:08 --> Session Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:03:08 --> Session routines successfully run
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:03:08 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:03:08 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:03:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:03:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:03:08 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:03:08 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:03:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:03:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 08:03:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:03:08 --> Final output sent to browser
DEBUG - 2013-11-29 08:03:08 --> Total execution time: 0.0658
DEBUG - 2013-11-29 08:03:18 --> Config Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:03:18 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:03:18 --> URI Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Router Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Output Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Security Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Input Class Initialized
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> XSS Filtering completed
DEBUG - 2013-11-29 08:03:18 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:03:18 --> Language Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Language Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Config Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Loader Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Controller Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-29 08:03:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:03:18 --> Session Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:03:18 --> Session routines successfully run
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:03:18 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:03:18 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:03:18 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:03:18 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:03:18 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:03:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:03:18 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:03:18 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:03:18 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:18 --> File loaded: application/modules/sitepages/models/mdl_sitepages.php
DEBUG - 2013-11-29 08:03:18 --> Model Class Initialized
DEBUG - 2013-11-29 08:03:18 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-29 08:03:18 --> File loaded: application/modules/menu/views/modal_add_menu.php
DEBUG - 2013-11-29 08:03:18 --> Final output sent to browser
DEBUG - 2013-11-29 08:03:18 --> Total execution time: 0.0714
DEBUG - 2013-11-29 08:05:41 --> Config Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:05:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:05:41 --> URI Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Router Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Output Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Security Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Input Class Initialized
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:05:41 --> Language Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Language Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Config Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Loader Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Controller Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-29 08:05:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:05:41 --> Session Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:05:41 --> Session routines successfully run
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:05:41 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:05:41 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:05:41 --> Model Class Initialized
DEBUG - 2013-11-29 08:05:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:05:41 --> Model Class Initialized
DEBUG - 2013-11-29 08:05:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:05:41 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:05:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:05:41 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:05:41 --> Final output sent to browser
DEBUG - 2013-11-29 08:05:41 --> Total execution time: 0.1027
DEBUG - 2013-11-29 08:05:43 --> Config Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:05:43 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:05:43 --> URI Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Router Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Output Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Security Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Input Class Initialized
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> XSS Filtering completed
DEBUG - 2013-11-29 08:05:43 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:05:43 --> Language Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Language Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Config Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Loader Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Controller Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:05:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:05:43 --> Session Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:05:43 --> Session routines successfully run
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:05:43 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:05:43 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:05:43 --> Model Class Initialized
DEBUG - 2013-11-29 08:05:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:05:43 --> Model Class Initialized
DEBUG - 2013-11-29 08:05:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:05:43 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:05:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:05:43 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:05:43 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:05:43 --> Model Class Initialized
DEBUG - 2013-11-29 08:05:43 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:05:43 --> Model Class Initialized
DEBUG - 2013-11-29 08:05:43 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 08:05:43 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:05:43 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 08:05:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:05:43 --> Final output sent to browser
DEBUG - 2013-11-29 08:05:43 --> Total execution time: 0.0765
DEBUG - 2013-11-29 08:06:47 --> Config Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:06:47 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:06:47 --> URI Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Router Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Output Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Security Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Input Class Initialized
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> XSS Filtering completed
DEBUG - 2013-11-29 08:06:47 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:06:47 --> Language Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Language Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Config Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Loader Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Controller Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-29 08:06:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:06:47 --> Session Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:06:47 --> Session routines successfully run
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:06:47 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:06:47 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:06:47 --> Model Class Initialized
DEBUG - 2013-11-29 08:06:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:06:47 --> Model Class Initialized
DEBUG - 2013-11-29 08:06:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:06:47 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:06:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:06:47 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:06:47 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:06:47 --> Model Class Initialized
DEBUG - 2013-11-29 08:06:47 --> File loaded: application/modules/sitepages/models/mdl_sitepages.php
DEBUG - 2013-11-29 08:06:47 --> Model Class Initialized
DEBUG - 2013-11-29 08:06:47 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-29 08:06:47 --> File loaded: application/modules/menu/views/modal_edit_menu.php
DEBUG - 2013-11-29 08:06:47 --> Final output sent to browser
DEBUG - 2013-11-29 08:06:47 --> Total execution time: 0.0769
DEBUG - 2013-11-29 08:07:58 --> Config Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:07:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:07:58 --> URI Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Router Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Output Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Security Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Input Class Initialized
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:07:58 --> Language Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Language Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Config Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Loader Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Controller Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:07:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:07:58 --> Session Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:07:58 --> Session routines successfully run
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:07:58 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:07:58 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:07:58 --> Model Class Initialized
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:07:58 --> Model Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:07:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:07:58 --> Model Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Config Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:07:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:07:58 --> URI Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Router Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Output Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Security Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Input Class Initialized
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> XSS Filtering completed
DEBUG - 2013-11-29 08:07:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:07:58 --> Language Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Language Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Config Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Loader Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Controller Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:07:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:07:58 --> Session Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:07:58 --> Session routines successfully run
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:07:58 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:07:58 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:07:58 --> Model Class Initialized
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:07:58 --> Model Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:07:58 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:07:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:07:58 --> Model Class Initialized
DEBUG - 2013-11-29 08:07:58 --> Pagination Class Initialized
ERROR - 2013-11-29 08:07:58 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 08:07:58 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:07:58 --> Final output sent to browser
DEBUG - 2013-11-29 08:07:58 --> Total execution time: 0.0655
DEBUG - 2013-11-29 08:10:01 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:10:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:10:01 --> URI Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Router Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Output Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Security Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Input Class Initialized
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:10:01 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Loader Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Controller Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:10:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:10:01 --> Session Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:10:01 --> Session routines successfully run
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:10:01 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:10:01 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:10:01 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:10:01 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:10:01 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:10:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:10:01 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:10:01 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:10:01 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:01 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:10:01 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:01 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 08:10:01 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:10:01 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 08:10:01 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:10:01 --> Final output sent to browser
DEBUG - 2013-11-29 08:10:01 --> Total execution time: 0.0780
DEBUG - 2013-11-29 08:10:05 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:10:05 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:10:05 --> URI Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Router Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Output Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Security Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Input Class Initialized
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:10:05 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Loader Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Controller Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:10:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:10:05 --> Session Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:10:05 --> Session routines successfully run
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:10:05 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:10:05 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:10:05 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:10:05 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:10:05 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:10:05 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:10:05 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:10:05 --> URI Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Router Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Output Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Security Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Input Class Initialized
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:05 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:10:05 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Loader Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Controller Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:10:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:10:05 --> Session Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:10:05 --> Session routines successfully run
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:10:05 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:10:05 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:10:05 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:10:05 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:10:05 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:10:05 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:10:05 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:05 --> Pagination Class Initialized
ERROR - 2013-11-29 08:10:05 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 08:10:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:10:05 --> Final output sent to browser
DEBUG - 2013-11-29 08:10:05 --> Total execution time: 0.0621
DEBUG - 2013-11-29 08:10:08 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:10:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:10:08 --> URI Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Router Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Output Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Security Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Input Class Initialized
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:10:08 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Loader Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Controller Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:10:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:10:08 --> Session Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:10:08 --> Session routines successfully run
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:10:08 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:10:08 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:10:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:10:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:10:08 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:10:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:10:08 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:10:08 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:10:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:08 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:10:08 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:08 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 08:10:08 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:10:08 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 08:10:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:10:08 --> Final output sent to browser
DEBUG - 2013-11-29 08:10:08 --> Total execution time: 0.0830
DEBUG - 2013-11-29 08:10:16 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:10:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:10:16 --> URI Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Router Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Output Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Security Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Input Class Initialized
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:10:16 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Loader Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Controller Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:10:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:10:16 --> Session Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:10:16 --> Session routines successfully run
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:10:16 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:10:16 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:10:16 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:10:16 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:10:16 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:10:16 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:10:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:10:16 --> URI Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Router Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Output Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Security Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Input Class Initialized
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:10:16 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Loader Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Controller Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:10:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:10:16 --> Session Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:10:16 --> Session routines successfully run
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:10:16 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:10:16 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:10:16 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:10:16 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:10:16 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:10:16 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:10:16 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:16 --> Pagination Class Initialized
ERROR - 2013-11-29 08:10:16 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 08:10:16 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:10:16 --> Final output sent to browser
DEBUG - 2013-11-29 08:10:16 --> Total execution time: 0.0639
DEBUG - 2013-11-29 08:10:45 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Hooks Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Utf8 Class Initialized
DEBUG - 2013-11-29 08:10:45 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 08:10:45 --> URI Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Router Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Output Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Security Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Input Class Initialized
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> XSS Filtering completed
DEBUG - 2013-11-29 08:10:45 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 08:10:45 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Language Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Config Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Loader Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Controller Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 08:10:45 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 08:10:45 --> Session Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: string_helper
DEBUG - 2013-11-29 08:10:45 --> Session routines successfully run
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: url_helper
DEBUG - 2013-11-29 08:10:45 --> Database Driver Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: form_helper
DEBUG - 2013-11-29 08:10:45 --> Form Validation Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: number_helper
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: date_helper
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 08:10:45 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 08:10:45 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 08:10:45 --> Helper loaded: language_helper
DEBUG - 2013-11-29 08:10:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 08:10:45 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 08:10:45 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 08:10:45 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:45 --> File loaded: application/modules/custom_fields/models/mdl_menu_custom.php
DEBUG - 2013-11-29 08:10:45 --> Model Class Initialized
DEBUG - 2013-11-29 08:10:45 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 08:10:45 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 08:10:45 --> File loaded: application/modules/menu/views/form.php
DEBUG - 2013-11-29 08:10:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 08:10:45 --> Final output sent to browser
DEBUG - 2013-11-29 08:10:45 --> Total execution time: 0.1173
DEBUG - 2013-11-29 10:15:03 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:15:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:15:03 --> URI Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Router Class Initialized
DEBUG - 2013-11-29 10:15:03 --> No URI present. Default controller set.
DEBUG - 2013-11-29 10:15:03 --> Output Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Security Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Input Class Initialized
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:15:03 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Loader Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Controller Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 10:15:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:15:03 --> Session Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:15:03 --> A session cookie was not found.
DEBUG - 2013-11-29 10:15:03 --> Session routines successfully run
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:15:03 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:15:03 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:15:03 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:15:03 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:15:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:15:03 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:15:03 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:15:03 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:15:03 --> URI Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Router Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Output Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Security Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Input Class Initialized
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:03 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:15:03 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Loader Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Controller Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:15:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:15:03 --> Session Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:15:03 --> Session routines successfully run
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:15:03 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:15:03 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:15:03 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:15:03 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:15:03 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:15:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:15:03 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:15:03 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:15:03 --> Final output sent to browser
DEBUG - 2013-11-29 10:15:03 --> Total execution time: 0.1285
DEBUG - 2013-11-29 10:15:08 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:15:08 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:15:08 --> URI Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Router Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Output Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Security Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Input Class Initialized
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:08 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:15:08 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Loader Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Controller Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:15:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:15:08 --> Session Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:15:08 --> Session routines successfully run
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:15:08 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:15:08 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:15:08 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:15:08 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:15:08 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:15:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:15:08 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:15:08 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:15:08 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:08 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:15:08 --> Final output sent to browser
DEBUG - 2013-11-29 10:15:08 --> Total execution time: 0.1508
DEBUG - 2013-11-29 10:15:14 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:15:14 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:15:14 --> URI Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Router Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Output Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Security Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Input Class Initialized
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:14 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:15:14 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Loader Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Controller Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:15:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:15:14 --> Session Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:15:14 --> Session routines successfully run
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:15:14 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:15:14 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:15:14 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:15:14 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:15:14 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:15:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:15:14 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:15:14 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:15:14 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:14 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:15:14 --> Final output sent to browser
DEBUG - 2013-11-29 10:15:14 --> Total execution time: 0.1268
DEBUG - 2013-11-29 10:15:34 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:15:34 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:15:34 --> URI Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Router Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Output Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Security Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Input Class Initialized
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:34 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:15:34 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Loader Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Controller Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:15:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:15:34 --> Session Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:15:34 --> Session routines successfully run
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:15:34 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:15:34 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:15:34 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:15:34 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:15:34 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:15:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:15:34 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:15:34 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:15:34 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:34 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:15:34 --> Final output sent to browser
DEBUG - 2013-11-29 10:15:34 --> Total execution time: 0.1254
DEBUG - 2013-11-29 10:15:46 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:15:46 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:15:46 --> URI Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Router Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Output Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Security Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Input Class Initialized
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> XSS Filtering completed
DEBUG - 2013-11-29 10:15:46 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:15:46 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Language Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Config Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Loader Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Controller Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:15:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:15:46 --> Session Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:15:46 --> Session routines successfully run
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:15:46 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:15:46 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:15:46 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:15:46 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:15:46 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:15:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:15:46 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:15:46 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:15:46 --> Model Class Initialized
DEBUG - 2013-11-29 10:15:47 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:15:47 --> Final output sent to browser
DEBUG - 2013-11-29 10:15:47 --> Total execution time: 0.1275
DEBUG - 2013-11-29 10:16:02 --> Config Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:16:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:16:02 --> URI Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Router Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Output Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Security Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Input Class Initialized
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:16:02 --> Language Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Language Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Config Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Loader Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Controller Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:16:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:16:02 --> Session Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:16:02 --> Session routines successfully run
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:16:02 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:16:02 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:16:02 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:16:02 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:16:02 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:16:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:16:02 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:16:02 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:16:02 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:02 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:16:02 --> Final output sent to browser
DEBUG - 2013-11-29 10:16:02 --> Total execution time: 0.1246
DEBUG - 2013-11-29 10:16:38 --> Config Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:16:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:16:38 --> URI Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Router Class Initialized
DEBUG - 2013-11-29 10:16:38 --> No URI present. Default controller set.
DEBUG - 2013-11-29 10:16:38 --> Output Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Security Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Input Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:16:38 --> Language Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Language Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Config Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Loader Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Controller Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 10:16:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:16:38 --> Session Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:16:38 --> A session cookie was not found.
DEBUG - 2013-11-29 10:16:38 --> Session routines successfully run
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:16:38 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:16:38 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:16:38 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:16:38 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:16:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:16:38 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:16:38 --> Config Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:16:38 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:16:38 --> URI Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Router Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Output Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Security Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Input Class Initialized
DEBUG - 2013-11-29 10:16:38 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:38 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:16:38 --> Language Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Language Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Config Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Loader Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Controller Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:16:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:16:38 --> Session Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:16:38 --> Session routines successfully run
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:16:38 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:16:38 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:16:38 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:16:38 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:16:38 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:16:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:16:38 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:16:38 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:16:38 --> Final output sent to browser
DEBUG - 2013-11-29 10:16:38 --> Total execution time: 0.0412
DEBUG - 2013-11-29 10:16:41 --> Config Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:16:41 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:16:41 --> URI Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Router Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Output Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Security Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Input Class Initialized
DEBUG - 2013-11-29 10:16:41 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:41 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:41 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:41 --> XSS Filtering completed
DEBUG - 2013-11-29 10:16:41 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:16:41 --> Language Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Language Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Config Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Loader Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Controller Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:16:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:16:41 --> Session Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:16:41 --> Session routines successfully run
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:16:41 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:16:41 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:16:41 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:16:41 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:16:41 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:16:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:16:41 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:16:41 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:16:41 --> Model Class Initialized
DEBUG - 2013-11-29 10:16:42 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:16:42 --> Final output sent to browser
DEBUG - 2013-11-29 10:16:42 --> Total execution time: 0.1462
DEBUG - 2013-11-29 10:17:19 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:17:19 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:17:19 --> URI Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Router Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Output Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Security Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Input Class Initialized
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:19 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:17:19 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Loader Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Controller Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:17:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:17:19 --> Session Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:17:19 --> Session routines successfully run
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:17:19 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:17:19 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:17:19 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:17:19 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:17:19 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:17:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:17:19 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:17:19 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:17:19 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:19 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:17:19 --> Final output sent to browser
DEBUG - 2013-11-29 10:17:19 --> Total execution time: 0.1401
DEBUG - 2013-11-29 10:17:20 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:17:20 --> URI Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Router Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Output Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Security Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Input Class Initialized
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:17:20 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Loader Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Controller Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:17:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:17:20 --> Session Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:17:20 --> Session routines successfully run
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:17:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:17:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:17:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:17:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:17:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:17:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:17:20 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:17:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:20 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:17:20 --> Final output sent to browser
DEBUG - 2013-11-29 10:17:20 --> Total execution time: 0.0739
DEBUG - 2013-11-29 10:17:20 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:17:20 --> URI Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Router Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Output Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Security Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Input Class Initialized
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:17:20 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Loader Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Controller Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:17:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:17:20 --> Session Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:17:20 --> Session routines successfully run
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:17:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:17:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:17:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:17:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:17:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:17:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:17:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:17:20 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:17:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:20 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:17:20 --> Final output sent to browser
DEBUG - 2013-11-29 10:17:20 --> Total execution time: 0.0722
DEBUG - 2013-11-29 10:17:21 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:17:21 --> URI Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Router Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Output Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Security Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Input Class Initialized
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:17:21 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Loader Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Controller Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:17:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:17:21 --> Session Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:17:21 --> Session routines successfully run
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:17:21 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:17:21 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:17:21 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:17:21 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:17:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:17:21 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:17:21 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:17:21 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:21 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:17:21 --> Final output sent to browser
DEBUG - 2013-11-29 10:17:21 --> Total execution time: 0.0608
DEBUG - 2013-11-29 10:17:21 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:17:21 --> URI Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Router Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Output Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Security Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Input Class Initialized
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:17:21 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Loader Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Controller Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:17:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:17:21 --> Session Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:17:21 --> Session routines successfully run
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:17:21 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:17:21 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:17:21 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:17:21 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:17:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:17:21 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:17:21 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:17:21 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:21 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:17:21 --> Final output sent to browser
DEBUG - 2013-11-29 10:17:21 --> Total execution time: 0.0610
DEBUG - 2013-11-29 10:17:21 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:17:21 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:17:21 --> URI Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Router Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Output Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Security Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Input Class Initialized
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:21 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:17:21 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Loader Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Controller Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:17:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:17:21 --> Session Class Initialized
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:17:21 --> Session routines successfully run
DEBUG - 2013-11-29 10:17:21 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:17:21 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:17:22 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:17:22 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:17:22 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:17:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:17:22 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:17:22 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:17:22 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:22 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:17:22 --> Final output sent to browser
DEBUG - 2013-11-29 10:17:22 --> Total execution time: 0.0626
DEBUG - 2013-11-29 10:17:22 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:17:22 --> URI Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Router Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Output Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Security Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Input Class Initialized
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:22 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:17:22 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Loader Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Controller Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:17:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:17:22 --> Session Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:17:22 --> Session routines successfully run
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:17:22 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:17:22 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:17:22 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:17:22 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:17:22 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:17:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:17:22 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:17:22 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:17:22 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:22 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:17:22 --> Final output sent to browser
DEBUG - 2013-11-29 10:17:22 --> Total execution time: 0.0599
DEBUG - 2013-11-29 10:17:36 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:17:36 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:17:36 --> URI Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Router Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Output Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Security Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Input Class Initialized
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> XSS Filtering completed
DEBUG - 2013-11-29 10:17:36 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:17:36 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Language Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Config Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Loader Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Controller Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:17:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:17:36 --> Session Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:17:36 --> Session routines successfully run
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:17:36 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:17:36 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:17:36 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:17:36 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:17:36 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:17:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:17:36 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:17:36 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:17:36 --> Model Class Initialized
DEBUG - 2013-11-29 10:17:36 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:17:36 --> Final output sent to browser
DEBUG - 2013-11-29 10:17:36 --> Total execution time: 0.1482
DEBUG - 2013-11-29 10:19:02 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:19:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:19:02 --> URI Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Router Class Initialized
DEBUG - 2013-11-29 10:19:02 --> No URI present. Default controller set.
DEBUG - 2013-11-29 10:19:02 --> Output Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Security Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Input Class Initialized
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:19:02 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Loader Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Controller Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 10:19:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:19:02 --> Session Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:19:02 --> Session routines successfully run
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:19:02 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:19:02 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:19:02 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:19:02 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:19:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:19:02 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:19:02 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:19:02 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:19:02 --> URI Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Router Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Output Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Security Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Input Class Initialized
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:02 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:19:02 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Loader Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Controller Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:19:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:19:02 --> Session Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:19:02 --> Session routines successfully run
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:19:02 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:19:02 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:19:02 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:19:02 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:19:02 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:19:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:19:02 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:19:02 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:19:02 --> Final output sent to browser
DEBUG - 2013-11-29 10:19:02 --> Total execution time: 0.0595
DEBUG - 2013-11-29 10:19:06 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:19:06 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:19:06 --> URI Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Router Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Output Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Security Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Input Class Initialized
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:06 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:19:06 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Loader Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Controller Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:19:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:19:06 --> Session Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:19:06 --> Session routines successfully run
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:19:06 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:19:06 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:19:06 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:19:06 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:19:06 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:19:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:19:06 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:19:06 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:19:06 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:06 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:19:06 --> Final output sent to browser
DEBUG - 2013-11-29 10:19:06 --> Total execution time: 0.1319
DEBUG - 2013-11-29 10:19:20 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:19:20 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:19:20 --> URI Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Router Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Output Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Security Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Input Class Initialized
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:20 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:19:20 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Loader Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Controller Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:19:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:19:20 --> Session Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:19:20 --> Session routines successfully run
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:19:20 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:19:20 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:19:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:19:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:19:20 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:19:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:19:20 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:19:20 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:19:20 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:20 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:19:20 --> Final output sent to browser
DEBUG - 2013-11-29 10:19:20 --> Total execution time: 0.1345
DEBUG - 2013-11-29 10:19:58 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:19:58 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:19:58 --> URI Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Router Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Output Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Security Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Input Class Initialized
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> XSS Filtering completed
DEBUG - 2013-11-29 10:19:58 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:19:58 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Language Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Config Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Loader Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Controller Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:19:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:19:58 --> Session Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:19:58 --> Session routines successfully run
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:19:58 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:19:58 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:19:58 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:19:58 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:19:58 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:19:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:19:58 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:19:58 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:19:58 --> Model Class Initialized
DEBUG - 2013-11-29 10:19:58 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:19:58 --> Final output sent to browser
DEBUG - 2013-11-29 10:19:58 --> Total execution time: 0.1363
DEBUG - 2013-11-29 10:20:32 --> Config Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:20:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:20:32 --> URI Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Router Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Output Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Security Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Input Class Initialized
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:20:32 --> Language Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Language Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Config Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Loader Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Controller Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:20:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:20:32 --> Session Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:20:32 --> Session routines successfully run
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:20:32 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:20:32 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:20:32 --> Model Class Initialized
DEBUG - 2013-11-29 10:20:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:20:32 --> Model Class Initialized
DEBUG - 2013-11-29 10:20:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:20:32 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:20:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:20:32 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:20:32 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:20:32 --> Model Class Initialized
DEBUG - 2013-11-29 10:20:32 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:20:32 --> Final output sent to browser
DEBUG - 2013-11-29 10:20:32 --> Total execution time: 0.1360
DEBUG - 2013-11-29 10:20:37 --> Config Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:20:37 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:20:37 --> URI Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Router Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Output Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Security Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Input Class Initialized
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> XSS Filtering completed
DEBUG - 2013-11-29 10:20:37 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:20:37 --> Language Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Language Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Config Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Loader Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Controller Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:20:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:20:37 --> Session Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:20:37 --> Session routines successfully run
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:20:37 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:20:37 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:20:37 --> Model Class Initialized
DEBUG - 2013-11-29 10:20:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:20:37 --> Model Class Initialized
DEBUG - 2013-11-29 10:20:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:20:37 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:20:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:20:37 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:20:37 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:20:37 --> Model Class Initialized
DEBUG - 2013-11-29 10:20:37 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:20:37 --> Final output sent to browser
DEBUG - 2013-11-29 10:20:37 --> Total execution time: 0.1393
DEBUG - 2013-11-29 10:22:50 --> Config Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:22:50 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:22:50 --> URI Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Router Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Output Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Security Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Input Class Initialized
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> XSS Filtering completed
DEBUG - 2013-11-29 10:22:50 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:22:50 --> Language Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Language Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Config Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Loader Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Controller Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:22:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:22:50 --> Session Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:22:50 --> Session routines successfully run
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:22:50 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:22:50 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:22:50 --> Model Class Initialized
DEBUG - 2013-11-29 10:22:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:22:50 --> Model Class Initialized
DEBUG - 2013-11-29 10:22:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:22:50 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:22:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:22:50 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:22:50 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:22:50 --> Model Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Config Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:23:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:23:00 --> URI Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Router Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Output Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Security Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Input Class Initialized
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:23:00 --> Language Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Language Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Config Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Loader Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Controller Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:23:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:23:00 --> Session Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:23:00 --> Session routines successfully run
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:23:00 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:23:00 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:23:00 --> Model Class Initialized
DEBUG - 2013-11-29 10:23:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:23:00 --> Model Class Initialized
DEBUG - 2013-11-29 10:23:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:23:00 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:23:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:23:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:23:00 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:23:00 --> Model Class Initialized
DEBUG - 2013-11-29 10:23:00 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:23:00 --> Final output sent to browser
DEBUG - 2013-11-29 10:23:00 --> Total execution time: 0.2212
DEBUG - 2013-11-29 10:23:31 --> Config Class Initialized
DEBUG - 2013-11-29 10:23:31 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:23:31 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:23:31 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:23:31 --> URI Class Initialized
DEBUG - 2013-11-29 10:23:31 --> Router Class Initialized
DEBUG - 2013-11-29 10:23:31 --> Output Class Initialized
DEBUG - 2013-11-29 10:23:31 --> Security Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Input Class Initialized
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:23:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:23:32 --> Language Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Language Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Config Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Loader Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Controller Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:23:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:23:32 --> Session Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:23:32 --> Session routines successfully run
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:23:32 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:23:32 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:23:32 --> Model Class Initialized
DEBUG - 2013-11-29 10:23:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:23:32 --> Model Class Initialized
DEBUG - 2013-11-29 10:23:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:23:32 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:23:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:23:32 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:23:32 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:23:32 --> Model Class Initialized
DEBUG - 2013-11-29 10:23:32 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:23:32 --> Final output sent to browser
DEBUG - 2013-11-29 10:23:32 --> Total execution time: 0.2337
DEBUG - 2013-11-29 10:25:32 --> Config Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:25:32 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:25:32 --> URI Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Router Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Output Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Security Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Input Class Initialized
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:32 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:25:32 --> Language Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Language Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Config Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Loader Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Controller Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:25:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:25:32 --> Session Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:25:32 --> Session routines successfully run
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:25:32 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:25:32 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:25:32 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:25:32 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:25:32 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:25:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:25:32 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:25:32 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:25:33 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:33 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2013-11-29 10:25:33 --> Final output sent to browser
DEBUG - 2013-11-29 10:25:33 --> Total execution time: 0.1560
DEBUG - 2013-11-29 10:25:57 --> Config Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:25:57 --> URI Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Router Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Output Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Security Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Input Class Initialized
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:25:57 --> Language Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Language Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Config Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Loader Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Controller Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Sessions MX_Controller Initialized
DEBUG - 2013-11-29 10:25:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:25:57 --> Session Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:25:57 --> Session routines successfully run
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:25:57 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:25:57 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:25:57 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Config Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:25:57 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:25:57 --> URI Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Router Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Output Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Security Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Input Class Initialized
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> XSS Filtering completed
DEBUG - 2013-11-29 10:25:57 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:25:57 --> Language Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Language Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Config Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Loader Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Controller Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Dashboard MX_Controller Initialized
DEBUG - 2013-11-29 10:25:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:25:57 --> Session Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:25:57 --> Session routines successfully run
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:25:57 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:25:57 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:25:57 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:25:57 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/invoices/models/mdl_invoice_amounts.php
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/quotes/models/mdl_quote_amounts.php
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/quotes/models/mdl_quotes.php
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-29 10:25:57 --> Model Class Initialized
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2013-11-29 10:25:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 10:25:57 --> Final output sent to browser
DEBUG - 2013-11-29 10:25:57 --> Total execution time: 0.0844
DEBUG - 2013-11-29 10:26:01 --> Config Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Config Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:26:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:26:01 --> URI Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Router Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Output Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Security Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Input Class Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:26:01 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> URI Class Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Router Class Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Output Class Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:26:01 --> Security Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Language Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Input Class Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Language Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Config Class Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Loader Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Controller Class Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:26:01 --> XSS Filtering completed
DEBUG - 2013-11-29 10:26:01 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:26:01 --> Language Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Session Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:26:01 --> Session routines successfully run
DEBUG - 2013-11-29 10:26:01 --> Language Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Config Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:26:01 --> Loader Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Controller Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Ajax MX_Controller Initialized
DEBUG - 2013-11-29 10:26:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:26:01 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Session Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:26:01 --> Session routines successfully run
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:26:01 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:26:01 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Model Class Initialized
DEBUG - 2013-11-29 10:26:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:26:01 --> Model Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:26:01 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:26:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:26:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:26:01 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:26:01 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-29 10:26:01 --> Model Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Model Class Initialized
DEBUG - 2013-11-29 10:26:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:26:01 --> Model Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Final output sent to browser
DEBUG - 2013-11-29 10:26:01 --> Total execution time: 0.0733
DEBUG - 2013-11-29 10:26:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:26:01 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:26:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:26:01 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:26:01 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2013-11-29 10:26:01 --> Model Class Initialized
DEBUG - 2013-11-29 10:26:01 --> Final output sent to browser
DEBUG - 2013-11-29 10:26:01 --> Total execution time: 0.0872
DEBUG - 2013-11-29 10:27:13 --> Config Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:27:13 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:27:13 --> URI Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Router Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Output Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Security Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Input Class Initialized
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:13 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:27:13 --> Language Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Language Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Config Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Loader Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Controller Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Users MX_Controller Initialized
DEBUG - 2013-11-29 10:27:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:27:13 --> Session Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:27:13 --> Session routines successfully run
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:27:13 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:27:13 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:27:13 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:27:13 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:27:13 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:27:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:27:13 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:27:13 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-29 10:27:13 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:13 --> Pagination Class Initialized
DEBUG - 2013-11-29 10:27:13 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 10:27:13 --> File loaded: application/modules/users/views/index.php
DEBUG - 2013-11-29 10:27:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 10:27:13 --> Final output sent to browser
DEBUG - 2013-11-29 10:27:13 --> Total execution time: 0.0762
DEBUG - 2013-11-29 10:27:17 --> Config Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:27:17 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:27:17 --> URI Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Router Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Output Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Security Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Input Class Initialized
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> XSS Filtering completed
DEBUG - 2013-11-29 10:27:17 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:27:17 --> Language Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Language Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Config Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Loader Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Controller Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Users MX_Controller Initialized
DEBUG - 2013-11-29 10:27:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:27:17 --> Session Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:27:17 --> Session routines successfully run
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:27:17 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:27:17 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:27:17 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:27:17 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:27:17 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:27:17 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-29 10:27:17 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/custom_fields/models/mdl_user_custom.php
DEBUG - 2013-11-29 10:27:17 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/users/models/mdl_user_clients.php
DEBUG - 2013-11-29 10:27:17 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/clients/models/mdl_clients.php
DEBUG - 2013-11-29 10:27:17 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/custom_fields/models/mdl_custom_fields.php
DEBUG - 2013-11-29 10:27:17 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/invoices/models/mdl_invoices.php
DEBUG - 2013-11-29 10:27:17 --> Model Class Initialized
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/users/views/partial_user_client_table.php
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/clients/views/jquery_client_lookup.php
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/users/views/modal_user_client.php
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/layout/views/header_buttons.php
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/layout/views/alerts.php
ERROR - 2013-11-29 10:27:17 --> Could not find the language line "product_img"
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/users/views/form.php
DEBUG - 2013-11-29 10:27:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 10:27:17 --> Final output sent to browser
DEBUG - 2013-11-29 10:27:17 --> Total execution time: 0.0974
DEBUG - 2013-11-29 10:35:16 --> Config Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:35:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:35:16 --> URI Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Router Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Output Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Security Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Input Class Initialized
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:35:16 --> Language Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Language Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Config Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Loader Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Controller Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 10:35:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:35:16 --> Session Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:35:16 --> Session routines successfully run
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:35:16 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:35:16 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:35:16 --> Model Class Initialized
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:35:16 --> Model Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:35:16 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 10:35:16 --> Model Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Config Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Hooks Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Utf8 Class Initialized
DEBUG - 2013-11-29 10:35:16 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 10:35:16 --> URI Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Router Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Output Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Security Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Input Class Initialized
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> XSS Filtering completed
DEBUG - 2013-11-29 10:35:16 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 10:35:16 --> Language Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Language Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Config Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Loader Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Controller Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 10:35:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 10:35:16 --> Session Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: string_helper
DEBUG - 2013-11-29 10:35:16 --> Session routines successfully run
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: url_helper
DEBUG - 2013-11-29 10:35:16 --> Database Driver Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: form_helper
DEBUG - 2013-11-29 10:35:16 --> Form Validation Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: number_helper
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: date_helper
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 10:35:16 --> Model Class Initialized
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 10:35:16 --> Model Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 10:35:16 --> Helper loaded: language_helper
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 10:35:16 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 10:35:16 --> Model Class Initialized
DEBUG - 2013-11-29 10:35:16 --> Pagination Class Initialized
ERROR - 2013-11-29 10:35:16 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 10:35:16 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 10:35:16 --> Final output sent to browser
DEBUG - 2013-11-29 10:35:16 --> Total execution time: 0.0735
DEBUG - 2013-11-29 11:31:49 --> Config Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Hooks Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Utf8 Class Initialized
DEBUG - 2013-11-29 11:31:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 11:31:49 --> URI Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Router Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Output Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Security Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Input Class Initialized
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 11:31:49 --> Language Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Language Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Config Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Loader Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Controller Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 11:31:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 11:31:49 --> Session Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: string_helper
DEBUG - 2013-11-29 11:31:49 --> Session routines successfully run
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: url_helper
DEBUG - 2013-11-29 11:31:49 --> Database Driver Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: form_helper
DEBUG - 2013-11-29 11:31:49 --> Form Validation Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: number_helper
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: date_helper
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 11:31:49 --> Model Class Initialized
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 11:31:49 --> Model Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: language_helper
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 11:31:49 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 11:31:49 --> Model Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Config Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Hooks Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Utf8 Class Initialized
DEBUG - 2013-11-29 11:31:49 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 11:31:49 --> URI Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Router Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Output Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Security Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Input Class Initialized
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> XSS Filtering completed
DEBUG - 2013-11-29 11:31:49 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 11:31:49 --> Language Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Language Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Config Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Loader Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Controller Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Menu MX_Controller Initialized
DEBUG - 2013-11-29 11:31:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 11:31:49 --> Session Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: string_helper
DEBUG - 2013-11-29 11:31:49 --> Session routines successfully run
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: url_helper
DEBUG - 2013-11-29 11:31:49 --> Database Driver Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: form_helper
DEBUG - 2013-11-29 11:31:49 --> Form Validation Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: number_helper
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: date_helper
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 11:31:49 --> Model Class Initialized
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 11:31:49 --> Model Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 11:31:49 --> Helper loaded: language_helper
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 11:31:49 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/modules/menu/models/mdl_menu.php
DEBUG - 2013-11-29 11:31:49 --> Model Class Initialized
DEBUG - 2013-11-29 11:31:49 --> Pagination Class Initialized
ERROR - 2013-11-29 11:31:49 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/modules/menu/views/index.php
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 11:31:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 11:31:49 --> Final output sent to browser
DEBUG - 2013-11-29 11:31:49 --> Total execution time: 0.0769
DEBUG - 2013-11-29 11:32:00 --> Config Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Hooks Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Utf8 Class Initialized
DEBUG - 2013-11-29 11:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 11:32:00 --> URI Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Router Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Output Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Security Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Input Class Initialized
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 11:32:00 --> Language Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Language Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Config Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Loader Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Controller Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Useraccess MX_Controller Initialized
DEBUG - 2013-11-29 11:32:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 11:32:00 --> Session Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: string_helper
DEBUG - 2013-11-29 11:32:00 --> Session routines successfully run
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: url_helper
DEBUG - 2013-11-29 11:32:00 --> Database Driver Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: form_helper
DEBUG - 2013-11-29 11:32:00 --> Form Validation Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: number_helper
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: date_helper
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: language_helper
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 11:32:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/useraccess/models/mdl_useraccess.php
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/sitepages/models/mdl_sitepages.php
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Config Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Hooks Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Utf8 Class Initialized
DEBUG - 2013-11-29 11:32:00 --> UTF-8 Support Enabled
DEBUG - 2013-11-29 11:32:00 --> URI Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Router Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Output Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Security Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Input Class Initialized
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> XSS Filtering completed
DEBUG - 2013-11-29 11:32:00 --> Global POST and COOKIE data sanitized
DEBUG - 2013-11-29 11:32:00 --> Language Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Language Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Config Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Loader Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Controller Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Useraccess MX_Controller Initialized
DEBUG - 2013-11-29 11:32:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2013-11-29 11:32:00 --> Session Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: string_helper
DEBUG - 2013-11-29 11:32:00 --> Session routines successfully run
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: url_helper
DEBUG - 2013-11-29 11:32:00 --> Database Driver Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: form_helper
DEBUG - 2013-11-29 11:32:00 --> Form Validation Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: number_helper
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: pager_helper
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: invoice_helper
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: date_helper
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: redirect_helper
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2013-11-29 11:32:00 --> Helper loaded: language_helper
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2013-11-29 11:32:00 --> Layout MX_Controller Initialized
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/useraccess/models/mdl_useraccess.php
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/users/models/mdl_users.php
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/sitepages/models/mdl_sitepages.php
DEBUG - 2013-11-29 11:32:00 --> Model Class Initialized
DEBUG - 2013-11-29 11:32:00 --> Pagination Class Initialized
ERROR - 2013-11-29 11:32:00 --> Could not find the language line "filter_pages"
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/layout/views/alerts.php
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/useraccess/views/index.php
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/filter/views/jquery_filter.php
DEBUG - 2013-11-29 11:32:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2013-11-29 11:32:00 --> Final output sent to browser
DEBUG - 2013-11-29 11:32:00 --> Total execution time: 0.0819
