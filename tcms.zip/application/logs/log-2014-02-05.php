<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

DEBUG - 2014-02-05 11:12:09 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:12:09 --> URI Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Router Class Initialized
DEBUG - 2014-02-05 11:12:09 --> No URI present. Default controller set.
DEBUG - 2014-02-05 11:12:09 --> Output Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Security Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Input Class Initialized
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:12:09 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Loader Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Controller Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Session Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:12:09 --> A session cookie was not found.
DEBUG - 2014-02-05 11:12:09 --> Session routines successfully run
DEBUG - 2014-02-05 11:12:09 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-05 11:12:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:12:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:12:09 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:12:09 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:12:09 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:12:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:12:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:12:09 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:12:09 --> URI Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Router Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Output Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Security Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Input Class Initialized
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:12:09 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Loader Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Controller Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-05 11:12:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:12:09 --> Session Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:12:09 --> Session routines successfully run
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:12:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:12:09 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:12:09 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:12:09 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:12:09 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:12:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:12:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:12:09 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-05 11:12:09 --> Final output sent to browser
DEBUG - 2014-02-05 11:12:09 --> Total execution time: 0.0817
DEBUG - 2014-02-05 11:12:41 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:12:41 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:12:41 --> URI Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Router Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Output Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Security Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Input Class Initialized
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:12:41 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Loader Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Controller Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-05 11:12:41 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:12:41 --> Session Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:12:41 --> Session routines successfully run
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:12:41 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:12:41 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:12:41 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:41 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:12:41 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:41 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:12:41 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:12:41 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:12:41 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:12:41 --> File loaded: application/modules/sessions/views/session_login.php
DEBUG - 2014-02-05 11:12:41 --> Final output sent to browser
DEBUG - 2014-02-05 11:12:41 --> Total execution time: 0.0726
DEBUG - 2014-02-05 11:12:43 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:12:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:12:43 --> URI Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Router Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Output Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Security Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Input Class Initialized
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:12:43 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Loader Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Controller Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Sessions MX_Controller Initialized
DEBUG - 2014-02-05 11:12:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:12:43 --> Session Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:12:43 --> Session routines successfully run
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:12:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:12:43 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:12:43 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:12:43 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:12:43 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:12:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:12:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:12:43 --> File loaded: application/modules/sessions/models/mdl_sessions.php
DEBUG - 2014-02-05 11:12:43 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:12:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:12:44 --> URI Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Router Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Output Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Security Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Input Class Initialized
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:12:44 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Loader Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Controller Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Session Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:12:44 --> Session routines successfully run
DEBUG - 2014-02-05 11:12:44 --> Dashboard MX_Controller Initialized
DEBUG - 2014-02-05 11:12:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:12:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:12:44 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:12:44 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:12:44 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:12:44 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:12:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:12:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:12:44 --> File loaded: application/modules/dashboard/models/mdl_dashboard.php
DEBUG - 2014-02-05 11:12:44 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 11:12:44 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:44 --> File loaded: application/modules/dashboard/views/index.php
DEBUG - 2014-02-05 11:12:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 11:12:44 --> Final output sent to browser
DEBUG - 2014-02-05 11:12:44 --> Total execution time: 0.0777
DEBUG - 2014-02-05 11:12:47 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:12:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:12:47 --> URI Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Router Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Output Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Security Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Input Class Initialized
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> XSS Filtering completed
DEBUG - 2014-02-05 11:12:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:12:47 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Language Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Config Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Loader Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Controller Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Session Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:12:47 --> Session routines successfully run
DEBUG - 2014-02-05 11:12:47 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:12:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:12:47 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:12:47 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:12:47 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:12:47 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:12:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:12:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:12:47 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:12:47 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:47 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:12:47 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:12:47 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:47 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:12:47 --> Model Class Initialized
DEBUG - 2014-02-05 11:12:47 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 11:12:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 11:12:47 --> Final output sent to browser
DEBUG - 2014-02-05 11:12:47 --> Total execution time: 0.0694
DEBUG - 2014-02-05 11:13:06 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:13:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:13:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:13:06 --> URI Class Initialized
DEBUG - 2014-02-05 11:13:06 --> Router Class Initialized
DEBUG - 2014-02-05 11:13:06 --> Output Class Initialized
DEBUG - 2014-02-05 11:13:06 --> Security Class Initialized
DEBUG - 2014-02-05 11:13:06 --> Input Class Initialized
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:06 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:13:07 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Loader Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Controller Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Session Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:13:07 --> Session routines successfully run
DEBUG - 2014-02-05 11:13:07 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:13:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:13:07 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:13:07 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:13:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:13:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:13:07 --> URI Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Router Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Output Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Security Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Input Class Initialized
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:13:07 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Loader Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Controller Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Session Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:13:07 --> Session routines successfully run
DEBUG - 2014-02-05 11:13:07 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:13:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:13:07 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:13:07 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:13:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:13:07 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 11:13:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 11:13:07 --> Final output sent to browser
DEBUG - 2014-02-05 11:13:07 --> Total execution time: 0.0621
DEBUG - 2014-02-05 11:13:21 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:13:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:13:21 --> URI Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Router Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Output Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Security Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Input Class Initialized
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:13:21 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Loader Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Controller Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Session Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:13:21 --> Session routines successfully run
DEBUG - 2014-02-05 11:13:21 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:13:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:13:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:13:21 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:13:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:13:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:13:21 --> URI Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Router Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Output Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Security Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Input Class Initialized
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:13:21 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Loader Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Controller Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Session Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:13:21 --> Session routines successfully run
DEBUG - 2014-02-05 11:13:21 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:13:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:13:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:13:21 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:13:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:13:21 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 11:13:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 11:13:21 --> Final output sent to browser
DEBUG - 2014-02-05 11:13:21 --> Total execution time: 0.0624
DEBUG - 2014-02-05 11:13:36 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:13:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:13:36 --> URI Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Router Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Output Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Security Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Input Class Initialized
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:13:36 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Loader Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Controller Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Session Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:13:36 --> Session routines successfully run
DEBUG - 2014-02-05 11:13:36 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:13:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:13:36 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:13:36 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:13:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
ERROR - 2014-02-05 11:13:36 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\renalemr\application\modules\scheduler\controllers\scheduler.php 168
DEBUG - 2014-02-05 11:13:36 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:13:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:13:36 --> URI Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Router Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Output Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Security Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Input Class Initialized
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:13:36 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Loader Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Controller Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Session Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:13:36 --> Session routines successfully run
DEBUG - 2014-02-05 11:13:36 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:13:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:13:36 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:13:36 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:13:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:13:36 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 11:13:36 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 11:13:36 --> Final output sent to browser
DEBUG - 2014-02-05 11:13:36 --> Total execution time: 0.0727
DEBUG - 2014-02-05 11:13:56 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:13:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:13:56 --> URI Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Router Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Output Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Security Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Input Class Initialized
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:13:56 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Loader Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Controller Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Session Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:13:56 --> Session routines successfully run
DEBUG - 2014-02-05 11:13:56 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:13:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:13:56 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:13:56 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:13:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:13:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:13:56 --> URI Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Router Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Output Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Security Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Input Class Initialized
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 11:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:13:56 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Language Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Config Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Loader Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Controller Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Session Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:13:56 --> Session routines successfully run
DEBUG - 2014-02-05 11:13:56 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:13:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:13:56 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:13:56 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:13:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 11:13:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 11:13:56 --> Final output sent to browser
DEBUG - 2014-02-05 11:13:56 --> Total execution time: 0.0666
DEBUG - 2014-02-05 11:14:01 --> Config Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:14:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:14:01 --> URI Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Router Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Output Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Security Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Input Class Initialized
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:14:01 --> Language Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Language Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Config Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Loader Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Controller Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Session Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:14:01 --> Session routines successfully run
DEBUG - 2014-02-05 11:14:01 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:14:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:14:01 --> Database Driver Class Initialized
ERROR - 2014-02-05 11:14:01 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\renalemr\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:14:01 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:14:01 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:14:01 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:14:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:14:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:14:01 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:14:01 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:01 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:14:01 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:14:01 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:01 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:14:01 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:01 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-05 11:14:01 --> Final output sent to browser
DEBUG - 2014-02-05 11:14:01 --> Total execution time: 0.0571
DEBUG - 2014-02-05 11:14:23 --> Config Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:14:23 --> URI Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Router Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Output Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Security Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Input Class Initialized
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:14:23 --> Language Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Language Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Config Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Loader Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Controller Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Session Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:14:23 --> Session routines successfully run
DEBUG - 2014-02-05 11:14:23 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:14:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:14:23 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:14:23 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:14:23 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Config Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Hooks Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Utf8 Class Initialized
DEBUG - 2014-02-05 11:14:23 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 11:14:23 --> URI Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Router Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Output Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Security Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Input Class Initialized
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> XSS Filtering completed
DEBUG - 2014-02-05 11:14:23 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 11:14:23 --> Language Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Language Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Config Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Loader Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Controller Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Session Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: string_helper
DEBUG - 2014-02-05 11:14:23 --> Session routines successfully run
DEBUG - 2014-02-05 11:14:23 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 11:14:23 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: url_helper
DEBUG - 2014-02-05 11:14:23 --> Database Driver Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: form_helper
DEBUG - 2014-02-05 11:14:23 --> Form Validation Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: number_helper
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: date_helper
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: language_helper
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 11:14:23 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> Helper loaded: image_helper
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 11:14:23 --> Model Class Initialized
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 11:14:23 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 11:14:23 --> Final output sent to browser
DEBUG - 2014-02-05 11:14:23 --> Total execution time: 0.0626
DEBUG - 2014-02-05 12:02:54 --> Config Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:02:54 --> URI Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Router Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Output Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Security Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Input Class Initialized
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:02:54 --> Language Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Language Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Config Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Loader Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Controller Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Session Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:02:54 --> Session routines successfully run
DEBUG - 2014-02-05 12:02:54 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:02:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:02:54 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:02:54 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:02:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Config Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:02:54 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:02:54 --> URI Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Router Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Output Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Security Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Input Class Initialized
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> XSS Filtering completed
DEBUG - 2014-02-05 12:02:54 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:02:54 --> Language Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Language Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Config Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Loader Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Controller Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Session Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:02:54 --> Session routines successfully run
DEBUG - 2014-02-05 12:02:54 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:02:54 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:02:54 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:02:54 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:02:54 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:02:54 --> Model Class Initialized
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:02:54 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:02:54 --> Final output sent to browser
DEBUG - 2014-02-05 12:02:54 --> Total execution time: 0.0768
DEBUG - 2014-02-05 12:03:03 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:03 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:03 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:03 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:03 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:03 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:03 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:03 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:03 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:04 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:04 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:04 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:04 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:04 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:04 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:04 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:04 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:04 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:04 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:04 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:04 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:04 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:04 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:04 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:04 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:04 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:04 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:04 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:04 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:03:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:03:04 --> Final output sent to browser
DEBUG - 2014-02-05 12:03:04 --> Total execution time: 0.0683
DEBUG - 2014-02-05 12:03:14 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:14 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:14 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:14 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:14 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:14 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:14 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:14 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:14 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:14 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:14 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:03:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:03:14 --> Final output sent to browser
DEBUG - 2014-02-05 12:03:14 --> Total execution time: 0.0697
DEBUG - 2014-02-05 12:03:36 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:36 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:36 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:36 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:36 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:36 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:36 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:36 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:36 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:36 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:36 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:36 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:36 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:36 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:36 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:36 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:36 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:36 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:36 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:36 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:36 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:36 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:37 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:37 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:37 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:37 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:37 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:37 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:37 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:37 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:37 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:37 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:37 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:37 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:03:37 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:03:37 --> Final output sent to browser
DEBUG - 2014-02-05 12:03:37 --> Total execution time: 0.0785
DEBUG - 2014-02-05 12:03:48 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:48 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:48 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:48 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:48 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:48 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:48 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:48 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:48 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:48 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
ERROR - 2014-02-05 12:03:49 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\renalemr\application\modules\scheduler\controllers\scheduler.php 175
DEBUG - 2014-02-05 12:03:49 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:49 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:49 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:49 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:49 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:49 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:49 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:49 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:03:49 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:03:49 --> Final output sent to browser
DEBUG - 2014-02-05 12:03:49 --> Total execution time: 0.0755
DEBUG - 2014-02-05 12:03:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:59 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:59 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:59 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:59 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:03:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:03:59 --> URI Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Router Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Output Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Security Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Input Class Initialized
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:03:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:03:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Loader Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Controller Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Session Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:03:59 --> Session routines successfully run
DEBUG - 2014-02-05 12:03:59 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:03:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:03:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:03:59 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:03:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:03:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:03:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:03:59 --> Final output sent to browser
DEBUG - 2014-02-05 12:03:59 --> Total execution time: 0.0700
DEBUG - 2014-02-05 12:04:09 --> Config Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:04:09 --> URI Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Router Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Output Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Security Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Input Class Initialized
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:04:09 --> Language Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Language Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Config Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Loader Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Controller Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Session Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:04:09 --> Session routines successfully run
DEBUG - 2014-02-05 12:04:09 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:04:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:04:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:04:09 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:04:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
ERROR - 2014-02-05 12:04:09 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\renalemr\application\modules\scheduler\controllers\scheduler.php 175
DEBUG - 2014-02-05 12:04:09 --> Config Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:04:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:04:09 --> URI Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Router Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Output Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Security Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Input Class Initialized
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:04:09 --> Language Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Language Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Config Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Loader Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Controller Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Session Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:04:09 --> Session routines successfully run
DEBUG - 2014-02-05 12:04:09 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:04:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:04:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:04:09 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:04:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:04:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:04:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:04:09 --> Final output sent to browser
DEBUG - 2014-02-05 12:04:09 --> Total execution time: 0.0872
DEBUG - 2014-02-05 12:04:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:04:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:04:59 --> URI Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Router Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Output Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Security Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Input Class Initialized
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:04:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Loader Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Controller Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Session Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:04:59 --> Session routines successfully run
DEBUG - 2014-02-05 12:04:59 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:04:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:04:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:04:59 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:04:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
ERROR - 2014-02-05 12:04:59 --> Severity: Notice  --> Trying to get property of non-object D:\xampp\htdocs\renalemr\application\modules\scheduler\controllers\scheduler.php 175
DEBUG - 2014-02-05 12:04:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:04:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:04:59 --> URI Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Router Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Output Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Security Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Input Class Initialized
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:04:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:04:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Loader Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Controller Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Session Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:04:59 --> Session routines successfully run
DEBUG - 2014-02-05 12:04:59 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:04:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:04:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:04:59 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:04:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:04:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:04:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:04:59 --> Final output sent to browser
DEBUG - 2014-02-05 12:04:59 --> Total execution time: 0.0730
DEBUG - 2014-02-05 12:05:03 --> Config Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:05:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:05:03 --> URI Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Router Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Output Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Security Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Input Class Initialized
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:05:03 --> Language Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Language Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Config Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Loader Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Controller Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Session Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:05:03 --> Session routines successfully run
DEBUG - 2014-02-05 12:05:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:05:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:05:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:05:03 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:05:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:05:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:05:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:05:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:05:03 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:05:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:03 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:05:03 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:05:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:03 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:05:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:03 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-05 12:05:03 --> Final output sent to browser
DEBUG - 2014-02-05 12:05:03 --> Total execution time: 0.0573
DEBUG - 2014-02-05 12:05:17 --> Config Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:05:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:05:17 --> URI Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Router Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Output Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Security Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Input Class Initialized
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:05:17 --> Language Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Language Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Config Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Loader Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Controller Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Session Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:05:17 --> Session routines successfully run
DEBUG - 2014-02-05 12:05:17 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:05:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:05:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:05:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:05:17 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:05:17 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:05:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:05:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:05:17 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:05:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:05:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:05:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:05:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Config Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:05:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:05:18 --> URI Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Router Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Output Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Security Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Input Class Initialized
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> XSS Filtering completed
DEBUG - 2014-02-05 12:05:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:05:18 --> Language Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Language Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Config Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Loader Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Controller Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Session Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:05:18 --> Session routines successfully run
DEBUG - 2014-02-05 12:05:18 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:05:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:05:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:05:18 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:05:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:05:18 --> Model Class Initialized
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:05:18 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:05:18 --> Final output sent to browser
DEBUG - 2014-02-05 12:05:18 --> Total execution time: 0.0786
DEBUG - 2014-02-05 12:13:56 --> Config Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:13:56 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:13:56 --> URI Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Router Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Output Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Security Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Input Class Initialized
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> XSS Filtering completed
DEBUG - 2014-02-05 12:13:56 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:13:56 --> Language Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Language Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Config Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Loader Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Controller Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Session Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:13:56 --> Session routines successfully run
DEBUG - 2014-02-05 12:13:56 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:13:56 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:13:56 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:13:56 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 12:13:56 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 12:13:56 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:13:56 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:13:56 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:13:56 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:13:56 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 12:13:56 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:13:56 --> Model Class Initialized
DEBUG - 2014-02-05 12:13:56 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:13:56 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:13:56 --> Final output sent to browser
DEBUG - 2014-02-05 12:13:56 --> Total execution time: 0.0700
DEBUG - 2014-02-05 12:14:02 --> Config Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:14:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:14:02 --> URI Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Router Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Output Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Security Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Input Class Initialized
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:14:02 --> Language Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Language Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Config Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Loader Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Controller Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Session Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:14:02 --> Session routines successfully run
DEBUG - 2014-02-05 12:14:02 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:14:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:14:02 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:14:02 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:14:02 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:14:02 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:14:02 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:14:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:14:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:14:02 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:14:02 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:14:02 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Config Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:14:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:14:10 --> URI Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Router Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Output Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Security Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Input Class Initialized
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:14:10 --> Language Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Language Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Config Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Loader Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Controller Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Session Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:14:10 --> Session routines successfully run
DEBUG - 2014-02-05 12:14:10 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:14:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:14:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:14:10 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:14:10 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:14:10 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:14:10 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:14:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:14:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:14:10 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:14:10 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:14:10 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Config Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:14:22 --> URI Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Router Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Output Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Security Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Input Class Initialized
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:14:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:14:22 --> Language Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Language Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Config Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Loader Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Controller Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Session Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:14:22 --> Session routines successfully run
DEBUG - 2014-02-05 12:14:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:14:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:14:22 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:14:22 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:14:22 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:14:22 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:14:22 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:14:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:14:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:14:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:14:22 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:14:22 --> Model Class Initialized
DEBUG - 2014-02-05 12:14:22 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 12:14:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:14:22 --> Final output sent to browser
DEBUG - 2014-02-05 12:14:22 --> Total execution time: 0.0885
DEBUG - 2014-02-05 12:31:14 --> Config Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:31:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:31:14 --> URI Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Router Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Output Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Security Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Input Class Initialized
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> XSS Filtering completed
DEBUG - 2014-02-05 12:31:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:31:14 --> Language Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Language Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Config Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Loader Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Controller Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Session Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:31:14 --> Session routines successfully run
DEBUG - 2014-02-05 12:31:14 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:31:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:31:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:31:14 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:31:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:31:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:31:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:31:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:31:14 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:31:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:31:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:31:14 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:31:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:31:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:31:14 --> Model Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Config Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:33:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:33:33 --> URI Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Router Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Output Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Security Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Input Class Initialized
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:33:33 --> Language Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Language Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Config Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Loader Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Controller Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Session Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:33:33 --> Session routines successfully run
DEBUG - 2014-02-05 12:33:33 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:33:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:33:33 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:33:33 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:33:33 --> Model Class Initialized
DEBUG - 2014-02-05 12:33:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:33:33 --> Model Class Initialized
DEBUG - 2014-02-05 12:33:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:33:33 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:33:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:33:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:33:33 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:33:33 --> Model Class Initialized
DEBUG - 2014-02-05 12:33:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:33:33 --> Model Class Initialized
DEBUG - 2014-02-05 12:33:33 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:33:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:33:33 --> Final output sent to browser
DEBUG - 2014-02-05 12:33:33 --> Total execution time: 0.0762
DEBUG - 2014-02-05 12:33:38 --> Config Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:33:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:33:38 --> URI Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Router Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Output Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Security Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Input Class Initialized
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> XSS Filtering completed
DEBUG - 2014-02-05 12:33:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:33:38 --> Language Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Language Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Config Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Loader Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Controller Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Session Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:33:38 --> Session routines successfully run
DEBUG - 2014-02-05 12:33:38 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:33:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:33:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:33:38 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:33:38 --> Model Class Initialized
DEBUG - 2014-02-05 12:33:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:33:38 --> Model Class Initialized
DEBUG - 2014-02-05 12:33:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:33:38 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:33:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:33:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:33:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:33:38 --> Model Class Initialized
DEBUG - 2014-02-05 12:33:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:33:38 --> Model Class Initialized
DEBUG - 2014-02-05 12:34:16 --> Config Class Initialized
DEBUG - 2014-02-05 12:34:16 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:34:16 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:34:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:34:16 --> URI Class Initialized
DEBUG - 2014-02-05 12:34:16 --> Router Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Output Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Security Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Input Class Initialized
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:34:17 --> Language Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Language Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Config Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Loader Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Controller Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Session Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:34:17 --> Session routines successfully run
DEBUG - 2014-02-05 12:34:17 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:34:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:34:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:34:17 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:34:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:34:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:34:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:34:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:34:17 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:34:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:34:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:34:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:34:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:34:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:34:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:34:17 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:34:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:34:17 --> Final output sent to browser
DEBUG - 2014-02-05 12:34:17 --> Total execution time: 0.0664
DEBUG - 2014-02-05 12:34:21 --> Config Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:34:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:34:21 --> URI Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Router Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Output Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Security Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Input Class Initialized
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> XSS Filtering completed
DEBUG - 2014-02-05 12:34:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:34:21 --> Language Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Language Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Config Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Loader Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Controller Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Session Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:34:21 --> Session routines successfully run
DEBUG - 2014-02-05 12:34:21 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:34:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:34:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:34:21 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:34:21 --> Model Class Initialized
DEBUG - 2014-02-05 12:34:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:34:21 --> Model Class Initialized
DEBUG - 2014-02-05 12:34:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:34:21 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:34:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:34:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:34:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:34:21 --> Model Class Initialized
DEBUG - 2014-02-05 12:34:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:34:21 --> Model Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Config Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:35:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:35:11 --> URI Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Router Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Output Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Security Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Input Class Initialized
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:35:11 --> Language Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Language Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Config Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Loader Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Controller Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Session Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:35:11 --> Session routines successfully run
DEBUG - 2014-02-05 12:35:11 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:35:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:35:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:35:11 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:35:11 --> Model Class Initialized
DEBUG - 2014-02-05 12:35:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:35:11 --> Model Class Initialized
DEBUG - 2014-02-05 12:35:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:35:11 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:35:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:35:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:35:11 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:35:11 --> Model Class Initialized
DEBUG - 2014-02-05 12:35:11 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:35:11 --> Model Class Initialized
DEBUG - 2014-02-05 12:35:11 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:35:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:35:11 --> Final output sent to browser
DEBUG - 2014-02-05 12:35:11 --> Total execution time: 0.0761
DEBUG - 2014-02-05 12:35:15 --> Config Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:35:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:35:15 --> URI Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Router Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Output Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Security Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Input Class Initialized
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:35:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:35:15 --> Language Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Language Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Config Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Loader Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Controller Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Session Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:35:15 --> Session routines successfully run
DEBUG - 2014-02-05 12:35:15 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:35:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:35:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:35:15 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:35:15 --> Model Class Initialized
DEBUG - 2014-02-05 12:35:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:35:15 --> Model Class Initialized
DEBUG - 2014-02-05 12:35:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:35:15 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:35:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:35:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:35:15 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:35:15 --> Model Class Initialized
DEBUG - 2014-02-05 12:35:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:35:15 --> Model Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Config Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:38:53 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:38:53 --> URI Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Router Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Output Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Security Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Input Class Initialized
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:53 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:38:53 --> Language Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Language Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Config Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Loader Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Controller Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Session Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:38:53 --> Session routines successfully run
DEBUG - 2014-02-05 12:38:53 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:38:53 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:38:53 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:38:53 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:38:53 --> Model Class Initialized
DEBUG - 2014-02-05 12:38:53 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:38:53 --> Model Class Initialized
DEBUG - 2014-02-05 12:38:53 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:38:53 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:38:53 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:38:53 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:38:53 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:38:53 --> Model Class Initialized
DEBUG - 2014-02-05 12:38:53 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:38:53 --> Model Class Initialized
DEBUG - 2014-02-05 12:38:53 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:38:53 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:38:53 --> Final output sent to browser
DEBUG - 2014-02-05 12:38:53 --> Total execution time: 0.0770
DEBUG - 2014-02-05 12:38:57 --> Config Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:38:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:38:57 --> URI Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Router Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Output Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Security Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Input Class Initialized
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:38:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:38:57 --> Language Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Language Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Config Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Loader Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Controller Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Session Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:38:57 --> Session routines successfully run
DEBUG - 2014-02-05 12:38:57 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:38:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:38:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:38:57 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:38:57 --> Model Class Initialized
DEBUG - 2014-02-05 12:38:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:38:57 --> Model Class Initialized
DEBUG - 2014-02-05 12:38:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:38:57 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:38:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:38:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:38:57 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:38:57 --> Model Class Initialized
DEBUG - 2014-02-05 12:38:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:38:57 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Config Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:39:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:39:06 --> URI Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Router Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Output Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Security Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Input Class Initialized
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:39:06 --> Language Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Language Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Config Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Loader Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Controller Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Session Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:39:06 --> Session routines successfully run
DEBUG - 2014-02-05 12:39:06 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:39:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:39:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:39:06 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:39:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:39:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:39:06 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:39:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:39:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:39:06 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:39:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:39:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Config Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:39:15 --> URI Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Router Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Output Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Security Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Input Class Initialized
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:39:15 --> Language Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Language Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Config Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Loader Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Controller Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Session Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:39:15 --> Session routines successfully run
DEBUG - 2014-02-05 12:39:15 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:39:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:39:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:39:15 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:39:15 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:39:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:39:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:39:15 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Config Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:39:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:39:17 --> URI Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Router Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Output Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Security Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Input Class Initialized
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:39:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:39:17 --> Language Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Language Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Config Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Loader Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Controller Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Session Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:39:17 --> Session routines successfully run
DEBUG - 2014-02-05 12:39:17 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:39:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:39:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:39:17 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:39:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:39:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:39:17 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:39:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:39:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:39:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:39:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:39:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:39:17 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 12:39:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:39:17 --> Final output sent to browser
DEBUG - 2014-02-05 12:39:17 --> Total execution time: 0.0831
DEBUG - 2014-02-05 12:49:06 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:49:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:49:06 --> URI Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Router Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Output Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Security Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Input Class Initialized
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:49:06 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Loader Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Controller Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Session Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:49:06 --> Session routines successfully run
DEBUG - 2014-02-05 12:49:06 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:49:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:49:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:49:06 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:49:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:49:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:49:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:49:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:49:06 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:49:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:06 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:49:06 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:49:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:06 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:49:06 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:06 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:49:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:49:06 --> Final output sent to browser
DEBUG - 2014-02-05 12:49:06 --> Total execution time: 0.0789
DEBUG - 2014-02-05 12:49:19 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:49:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:49:19 --> URI Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Router Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Output Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Security Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Input Class Initialized
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:49:19 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Loader Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Controller Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Session Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:49:19 --> Session routines successfully run
DEBUG - 2014-02-05 12:49:19 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:49:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:49:19 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:49:19 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:49:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:49:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:49:19 --> URI Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Router Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Output Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Security Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Input Class Initialized
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:49:19 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Loader Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Controller Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Session Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:49:19 --> Session routines successfully run
DEBUG - 2014-02-05 12:49:19 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:49:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:49:19 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:49:19 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:49:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:49:19 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:49:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:49:19 --> Final output sent to browser
DEBUG - 2014-02-05 12:49:19 --> Total execution time: 0.0747
DEBUG - 2014-02-05 12:49:22 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:49:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:49:22 --> URI Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Router Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Output Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Security Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Input Class Initialized
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:49:22 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Loader Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Controller Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Session Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:49:22 --> Session routines successfully run
DEBUG - 2014-02-05 12:49:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:49:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:49:22 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:49:22 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:49:22 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:49:22 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:49:22 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:49:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:49:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:49:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:49:22 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:49:22 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:22 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:49:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:49:22 --> Final output sent to browser
DEBUG - 2014-02-05 12:49:22 --> Total execution time: 0.0609
DEBUG - 2014-02-05 12:49:26 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:49:26 --> URI Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Router Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Output Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Security Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Input Class Initialized
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:49:26 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Loader Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Controller Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Session Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:49:26 --> Session routines successfully run
DEBUG - 2014-02-05 12:49:26 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:49:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:49:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:49:26 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:49:26 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:49:26 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:49:26 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:49:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:49:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:49:26 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:49:26 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:49:26 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:49:35 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:49:35 --> URI Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Router Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Output Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Security Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Input Class Initialized
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:35 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:49:35 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Loader Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Controller Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Session Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:49:35 --> Session routines successfully run
DEBUG - 2014-02-05 12:49:35 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:49:35 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:49:35 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:49:35 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:49:35 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:35 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:49:35 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:35 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:49:35 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:49:35 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:49:35 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:49:35 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:49:35 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:35 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:49:35 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:35 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:49:35 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:49:35 --> Final output sent to browser
DEBUG - 2014-02-05 12:49:35 --> Total execution time: 0.0783
DEBUG - 2014-02-05 12:49:39 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:49:39 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:49:39 --> URI Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Router Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Output Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Security Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Input Class Initialized
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> XSS Filtering completed
DEBUG - 2014-02-05 12:49:39 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:49:39 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Language Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Config Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Loader Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Controller Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Session Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:49:39 --> Session routines successfully run
DEBUG - 2014-02-05 12:49:39 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:49:39 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:49:39 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:49:39 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:49:39 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:39 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:49:39 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:39 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:49:39 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:49:39 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:49:39 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:49:39 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:49:39 --> Model Class Initialized
DEBUG - 2014-02-05 12:49:39 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:49:39 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Config Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:50:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:50:00 --> URI Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Router Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Output Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Security Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Input Class Initialized
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:50:00 --> Language Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Language Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Config Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Loader Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Controller Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Session Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:50:00 --> Session routines successfully run
DEBUG - 2014-02-05 12:50:00 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:50:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:50:00 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:50:00 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:50:00 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:50:00 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:50:00 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:50:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:50:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:50:00 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:50:00 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:00 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:50:00 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:00 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:50:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:50:00 --> Final output sent to browser
DEBUG - 2014-02-05 12:50:00 --> Total execution time: 0.0818
DEBUG - 2014-02-05 12:50:05 --> Config Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:50:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:50:05 --> URI Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Router Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Output Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Security Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Input Class Initialized
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:50:05 --> Language Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Language Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Config Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Loader Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Controller Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Session Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:50:05 --> Session routines successfully run
DEBUG - 2014-02-05 12:50:05 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:50:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:50:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:50:05 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:50:05 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:50:05 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:50:05 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:50:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:50:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:50:05 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:50:05 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:50:05 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Config Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:50:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:50:11 --> URI Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Router Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Output Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Security Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Input Class Initialized
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> XSS Filtering completed
DEBUG - 2014-02-05 12:50:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:50:11 --> Language Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Language Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Config Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Loader Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Controller Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Session Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:50:11 --> Session routines successfully run
DEBUG - 2014-02-05 12:50:11 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:50:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:50:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:50:11 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:50:11 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:50:11 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:50:11 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:50:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:50:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:50:11 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:50:11 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:11 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:50:11 --> Model Class Initialized
DEBUG - 2014-02-05 12:50:11 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 12:50:11 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:50:11 --> Final output sent to browser
DEBUG - 2014-02-05 12:50:11 --> Total execution time: 0.0719
DEBUG - 2014-02-05 12:52:20 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:52:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:52:20 --> URI Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Router Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Output Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Security Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Input Class Initialized
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:52:20 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Loader Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Controller Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Session Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:52:20 --> Session routines successfully run
DEBUG - 2014-02-05 12:52:20 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:52:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:52:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:52:20 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:52:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:52:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:52:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:52:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:52:20 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:52:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:20 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:52:20 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:52:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:20 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:52:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:20 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:52:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:52:20 --> Final output sent to browser
DEBUG - 2014-02-05 12:52:20 --> Total execution time: 0.0652
DEBUG - 2014-02-05 12:52:46 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:52:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:52:46 --> URI Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Router Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Output Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Security Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Input Class Initialized
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:52:46 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Loader Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Controller Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Session Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:52:46 --> Session routines successfully run
DEBUG - 2014-02-05 12:52:46 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:52:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:52:46 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:52:46 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:52:46 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:52:46 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:52:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:52:46 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:52:46 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:52:46 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:46 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:52:46 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:52:46 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:46 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:52:46 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:46 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:52:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:52:46 --> Final output sent to browser
DEBUG - 2014-02-05 12:52:46 --> Total execution time: 0.0684
DEBUG - 2014-02-05 12:52:50 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:52:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:52:50 --> URI Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Router Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Output Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Security Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Input Class Initialized
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:52:50 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Loader Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Controller Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Session Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:52:50 --> Session routines successfully run
DEBUG - 2014-02-05 12:52:50 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:52:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:52:50 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:52:50 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:52:50 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:52:50 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:52:50 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:52:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:52:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:52:50 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:52:50 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:52:50 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:50 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:52:50 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:52:50 --> Final output sent to browser
DEBUG - 2014-02-05 12:52:50 --> Total execution time: 0.0650
DEBUG - 2014-02-05 12:52:55 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:52:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:52:55 --> URI Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Router Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Output Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Security Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Input Class Initialized
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:52:55 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Loader Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Controller Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Session Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:52:55 --> Session routines successfully run
DEBUG - 2014-02-05 12:52:55 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:52:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:52:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:52:55 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:52:55 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:52:55 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:52:55 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:52:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:52:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:52:55 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:52:55 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:52:55 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:52:57 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:52:57 --> URI Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Router Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Output Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Security Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Input Class Initialized
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> XSS Filtering completed
DEBUG - 2014-02-05 12:52:57 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:52:57 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Language Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Config Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Loader Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Controller Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Session Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:52:57 --> Session routines successfully run
DEBUG - 2014-02-05 12:52:57 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:52:57 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:52:57 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:52:57 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:52:57 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:57 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:52:57 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:57 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:52:57 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:52:57 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:52:57 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:52:57 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:52:57 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:57 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:52:57 --> Model Class Initialized
DEBUG - 2014-02-05 12:52:57 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 12:52:57 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:52:57 --> Final output sent to browser
DEBUG - 2014-02-05 12:52:57 --> Total execution time: 0.0901
DEBUG - 2014-02-05 12:53:20 --> Config Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:53:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:53:20 --> URI Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Router Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Output Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Security Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Input Class Initialized
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> XSS Filtering completed
DEBUG - 2014-02-05 12:53:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:53:20 --> Language Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Language Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Config Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Loader Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Controller Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Session Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:53:20 --> Session routines successfully run
DEBUG - 2014-02-05 12:53:20 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:53:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:53:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:53:20 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:53:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:53:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:53:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:53:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:53:20 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:53:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:53:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:53:20 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:53:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:53:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:53:20 --> Model Class Initialized
DEBUG - 2014-02-05 12:53:20 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:53:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:53:20 --> Final output sent to browser
DEBUG - 2014-02-05 12:53:20 --> Total execution time: 0.0770
DEBUG - 2014-02-05 12:56:17 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:56:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:56:17 --> URI Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Router Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Output Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Security Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Input Class Initialized
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:56:17 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Loader Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Controller Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Session Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:56:17 --> Session routines successfully run
DEBUG - 2014-02-05 12:56:17 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:56:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:56:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:56:17 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:56:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:56:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:56:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:56:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:56:17 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:56:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:17 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:56:17 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:56:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:56:17 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:17 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:56:17 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:56:17 --> Final output sent to browser
DEBUG - 2014-02-05 12:56:17 --> Total execution time: 0.0682
DEBUG - 2014-02-05 12:56:29 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:56:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:56:29 --> URI Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Router Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Output Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Security Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Input Class Initialized
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:56:29 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Loader Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Controller Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Session Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:56:29 --> Session routines successfully run
DEBUG - 2014-02-05 12:56:29 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:56:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:56:29 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:56:29 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:56:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:56:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:56:29 --> URI Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Router Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Output Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Security Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Input Class Initialized
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:56:29 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Loader Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Controller Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Session Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:56:29 --> Session routines successfully run
DEBUG - 2014-02-05 12:56:29 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 12:56:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:56:29 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:56:29 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:56:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> Helper loaded: image_helper
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:56:29 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 12:56:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:56:29 --> Final output sent to browser
DEBUG - 2014-02-05 12:56:29 --> Total execution time: 0.0769
DEBUG - 2014-02-05 12:56:34 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:56:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:56:34 --> URI Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Router Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Output Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Security Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Input Class Initialized
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:56:34 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Loader Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Controller Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Session Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:56:34 --> Session routines successfully run
DEBUG - 2014-02-05 12:56:34 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:56:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:56:34 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:56:34 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:56:34 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:56:34 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:56:34 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:56:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:56:34 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:56:34 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:56:34 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:34 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:56:34 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:34 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:56:34 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:56:34 --> Final output sent to browser
DEBUG - 2014-02-05 12:56:34 --> Total execution time: 0.0632
DEBUG - 2014-02-05 12:56:40 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:56:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:56:40 --> URI Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Router Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Output Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Security Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Input Class Initialized
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> XSS Filtering completed
DEBUG - 2014-02-05 12:56:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:56:40 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Language Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Config Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Loader Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Controller Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Session Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:56:40 --> Session routines successfully run
DEBUG - 2014-02-05 12:56:40 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:56:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:56:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:56:40 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:56:40 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:56:40 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:56:40 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:56:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:56:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:56:40 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:56:40 --> Model Class Initialized
DEBUG - 2014-02-05 12:56:40 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:56:40 --> Model Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:57:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:57:59 --> URI Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Router Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Output Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Security Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Input Class Initialized
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:57:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:57:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Loader Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Controller Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Session Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:57:59 --> Session routines successfully run
DEBUG - 2014-02-05 12:57:59 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:57:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:57:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:57:59 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:57:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:57:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:57:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:57:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:57:59 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:57:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:57:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:57:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:57:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:57:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:57:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:57:59 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:57:59 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:57:59 --> Final output sent to browser
DEBUG - 2014-02-05 12:57:59 --> Total execution time: 0.0586
DEBUG - 2014-02-05 12:58:03 --> Config Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:58:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:58:03 --> URI Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Router Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Output Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Security Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Input Class Initialized
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:58:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:58:03 --> Language Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Language Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Config Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Loader Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Controller Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Session Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:58:03 --> Session routines successfully run
DEBUG - 2014-02-05 12:58:03 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:58:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:58:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:58:03 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:58:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:58:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:58:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:58:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:58:03 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:58:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:58:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:58:03 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:58:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:58:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:58:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Config Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:59:03 --> URI Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Router Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Output Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Security Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Input Class Initialized
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:59:03 --> Language Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Language Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Config Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Loader Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Controller Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Session Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:59:03 --> Session routines successfully run
DEBUG - 2014-02-05 12:59:03 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:59:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:59:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:59:03 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:59:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:59:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:59:03 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:59:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:59:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:59:03 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:59:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:03 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:59:03 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:03 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:59:03 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:59:03 --> Final output sent to browser
DEBUG - 2014-02-05 12:59:03 --> Total execution time: 0.0722
DEBUG - 2014-02-05 12:59:09 --> Config Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:59:09 --> URI Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Router Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Output Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Security Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Input Class Initialized
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:59:09 --> Language Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Language Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Config Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Loader Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Controller Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Session Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:59:09 --> Session routines successfully run
DEBUG - 2014-02-05 12:59:09 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:59:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:59:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:59:09 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:59:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:59:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:59:09 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:59:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:59:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:59:09 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:59:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:59:09 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Config Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:59:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:59:55 --> URI Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Router Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Output Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Security Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Input Class Initialized
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:59:55 --> Language Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Language Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Config Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Loader Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Controller Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Session Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:59:55 --> Session routines successfully run
DEBUG - 2014-02-05 12:59:55 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:59:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:59:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:59:55 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:59:55 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:59:55 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:59:55 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:59:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:59:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:59:55 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:59:55 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:59:55 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:55 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 12:59:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 12:59:55 --> Final output sent to browser
DEBUG - 2014-02-05 12:59:55 --> Total execution time: 0.0891
DEBUG - 2014-02-05 12:59:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Hooks Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Utf8 Class Initialized
DEBUG - 2014-02-05 12:59:59 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 12:59:59 --> URI Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Router Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Output Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Security Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Input Class Initialized
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> XSS Filtering completed
DEBUG - 2014-02-05 12:59:59 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 12:59:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Language Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Config Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Loader Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Controller Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Session Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: string_helper
DEBUG - 2014-02-05 12:59:59 --> Session routines successfully run
DEBUG - 2014-02-05 12:59:59 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 12:59:59 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: url_helper
DEBUG - 2014-02-05 12:59:59 --> Database Driver Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: form_helper
DEBUG - 2014-02-05 12:59:59 --> Form Validation Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: number_helper
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: date_helper
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 12:59:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:59 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 12:59:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:59 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 12:59:59 --> Helper loaded: language_helper
DEBUG - 2014-02-05 12:59:59 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 12:59:59 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 12:59:59 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 12:59:59 --> Model Class Initialized
DEBUG - 2014-02-05 12:59:59 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 12:59:59 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:02:02 --> URI Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Router Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Output Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Security Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Input Class Initialized
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:02:02 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Loader Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Controller Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Session Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:02:02 --> Session routines successfully run
DEBUG - 2014-02-05 13:02:02 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:02:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:02:02 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:02:02 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:02:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:02:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:02:02 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:02 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:02:02 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:02 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:02:02 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:02 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:02:02 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:02:02 --> Final output sent to browser
DEBUG - 2014-02-05 13:02:02 --> Total execution time: 0.0792
DEBUG - 2014-02-05 13:02:15 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:02:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:02:15 --> URI Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Router Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Output Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Security Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Input Class Initialized
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:02:15 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Loader Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Controller Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Session Class Initialized
DEBUG - 2014-02-05 13:02:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:02:15 --> Session routines successfully run
DEBUG - 2014-02-05 13:02:15 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:02:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:02:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:02:16 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:02:16 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:02:16 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:02:16 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:02:16 --> URI Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Router Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Output Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Security Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Input Class Initialized
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:16 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:02:16 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Loader Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Controller Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Session Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:02:16 --> Session routines successfully run
DEBUG - 2014-02-05 13:02:16 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:02:16 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:02:16 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:02:16 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:02:16 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:02:16 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:02:16 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:02:16 --> Final output sent to browser
DEBUG - 2014-02-05 13:02:16 --> Total execution time: 0.0758
DEBUG - 2014-02-05 13:02:31 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:02:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:02:31 --> URI Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Router Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Output Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Security Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Input Class Initialized
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:02:31 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Loader Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Controller Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Session Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:02:31 --> Session routines successfully run
DEBUG - 2014-02-05 13:02:31 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:02:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:02:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:02:31 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:02:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:02:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:02:31 --> URI Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Router Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Output Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Security Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Input Class Initialized
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:02:31 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Loader Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Controller Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Session Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:02:31 --> Session routines successfully run
DEBUG - 2014-02-05 13:02:31 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:02:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:02:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:02:31 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:02:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:02:31 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:02:31 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:02:31 --> Final output sent to browser
DEBUG - 2014-02-05 13:02:31 --> Total execution time: 0.0726
DEBUG - 2014-02-05 13:02:44 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:02:44 --> URI Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Router Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Output Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Security Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Input Class Initialized
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:02:44 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Loader Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Controller Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Session Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:02:44 --> Session routines successfully run
DEBUG - 2014-02-05 13:02:44 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:02:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:02:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:02:44 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:02:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:02:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:02:44 --> URI Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Router Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Output Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Security Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Input Class Initialized
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:02:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:02:44 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Language Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Config Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Loader Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Controller Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Session Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:02:44 --> Session routines successfully run
DEBUG - 2014-02-05 13:02:44 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:02:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:02:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:02:44 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:02:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:02:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:02:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:02:44 --> Final output sent to browser
DEBUG - 2014-02-05 13:02:44 --> Total execution time: 0.0693
DEBUG - 2014-02-05 13:03:03 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:03:03 --> URI Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Router Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Output Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Security Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Input Class Initialized
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:03:03 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Loader Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Controller Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Session Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:03:03 --> Session routines successfully run
DEBUG - 2014-02-05 13:03:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:03:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:03:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:03:03 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:03:03 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:03:03 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:03:03 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:03:03 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:03 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:03:03 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:03:03 --> URI Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Router Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Output Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Security Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Input Class Initialized
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:03 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:03:03 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Loader Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Controller Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Session Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:03:03 --> Session routines successfully run
DEBUG - 2014-02-05 13:03:03 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:03:03 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:03:03 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:03:03 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:03:03 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:03 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:03:03 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:04 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:03:04 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:03:04 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:03:04 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:03:04 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:03:04 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:04 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:03:04 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:03:04 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:04 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:03:04 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:04 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:03:04 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:03:04 --> Final output sent to browser
DEBUG - 2014-02-05 13:03:04 --> Total execution time: 0.0787
DEBUG - 2014-02-05 13:03:19 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:03:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:03:19 --> URI Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Router Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Output Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Security Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Input Class Initialized
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:03:19 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Loader Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Controller Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Session Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:03:19 --> Session routines successfully run
DEBUG - 2014-02-05 13:03:19 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:03:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:03:19 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:03:19 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:03:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:03:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:03:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:03:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:03:19 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:03:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:19 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:03:19 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:03:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:19 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:03:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:03:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:03:20 --> URI Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Router Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Output Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Security Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Input Class Initialized
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:03:20 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Loader Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Controller Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Session Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:03:20 --> Session routines successfully run
DEBUG - 2014-02-05 13:03:20 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:03:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:03:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:03:20 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:03:20 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:03:20 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:03:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:03:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:03:20 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:03:20 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:20 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:03:20 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:03:20 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:20 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:03:20 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:20 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:03:20 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:03:20 --> Final output sent to browser
DEBUG - 2014-02-05 13:03:20 --> Total execution time: 0.0732
DEBUG - 2014-02-05 13:03:22 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:03:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:03:22 --> URI Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Router Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Output Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Security Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Input Class Initialized
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:03:22 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Loader Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Controller Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Session Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:03:22 --> Session routines successfully run
DEBUG - 2014-02-05 13:03:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:03:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:03:22 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:03:22 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:03:22 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:22 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:03:22 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:22 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:03:22 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:03:22 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:03:22 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:03:22 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:03:22 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:22 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:03:22 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:22 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:03:22 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:03:22 --> Final output sent to browser
DEBUG - 2014-02-05 13:03:22 --> Total execution time: 0.0598
DEBUG - 2014-02-05 13:03:26 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:03:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:03:26 --> URI Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Router Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Output Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Security Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Input Class Initialized
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> XSS Filtering completed
DEBUG - 2014-02-05 13:03:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:03:26 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Language Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Config Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Loader Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Controller Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Session Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:03:26 --> Session routines successfully run
DEBUG - 2014-02-05 13:03:26 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:03:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:03:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:03:26 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:03:26 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:03:26 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:03:26 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:03:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:03:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:03:26 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:03:26 --> Model Class Initialized
DEBUG - 2014-02-05 13:03:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:03:26 --> Model Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Config Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:04:10 --> URI Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Router Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Output Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Security Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Input Class Initialized
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:04:10 --> Language Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Language Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Config Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Loader Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Controller Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Session Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:04:10 --> Session routines successfully run
DEBUG - 2014-02-05 13:04:10 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:04:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:04:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:04:10 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:04:10 --> Model Class Initialized
DEBUG - 2014-02-05 13:04:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:04:10 --> Model Class Initialized
DEBUG - 2014-02-05 13:04:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:04:10 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:04:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:04:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:04:10 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:04:10 --> Model Class Initialized
DEBUG - 2014-02-05 13:04:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:04:10 --> Model Class Initialized
DEBUG - 2014-02-05 13:04:10 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:04:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:04:10 --> Final output sent to browser
DEBUG - 2014-02-05 13:04:10 --> Total execution time: 0.0571
DEBUG - 2014-02-05 13:04:19 --> Config Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:04:19 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:04:19 --> URI Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Router Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Output Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Security Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Input Class Initialized
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> XSS Filtering completed
DEBUG - 2014-02-05 13:04:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:04:19 --> Language Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Language Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Config Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Loader Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Controller Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Session Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:04:19 --> Session routines successfully run
DEBUG - 2014-02-05 13:04:19 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:04:19 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:04:19 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:04:19 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:04:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:04:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:04:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:04:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:04:19 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:04:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:04:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:04:19 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:04:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:04:19 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:04:19 --> Model Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Config Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:08:33 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:08:33 --> URI Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Router Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Output Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Security Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Input Class Initialized
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:33 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:08:33 --> Language Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Language Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Config Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Loader Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Controller Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Session Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:08:33 --> Session routines successfully run
DEBUG - 2014-02-05 13:08:33 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:08:33 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:08:33 --> Database Driver Class Initialized
ERROR - 2014-02-05 13:08:33 --> Severity: Notice  --> mysql_pconnect() [<a href='function.mysql-pconnect'>function.mysql-pconnect</a>]: send of 5 bytes failed with errno=10053 An established connection was aborted by the software in your host machine.
 D:\xampp\htdocs\renalemr\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:08:33 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:08:33 --> Model Class Initialized
DEBUG - 2014-02-05 13:08:33 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:08:33 --> Model Class Initialized
DEBUG - 2014-02-05 13:08:33 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:08:33 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:08:33 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:08:33 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:08:33 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:08:33 --> Model Class Initialized
DEBUG - 2014-02-05 13:08:33 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:08:33 --> Model Class Initialized
DEBUG - 2014-02-05 13:08:33 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:08:33 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:08:33 --> Final output sent to browser
DEBUG - 2014-02-05 13:08:33 --> Total execution time: 0.0773
DEBUG - 2014-02-05 13:08:37 --> Config Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:08:37 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:08:37 --> URI Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Router Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Output Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Security Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Input Class Initialized
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> XSS Filtering completed
DEBUG - 2014-02-05 13:08:37 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:08:37 --> Language Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Language Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Config Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Loader Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Controller Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Session Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:08:37 --> Session routines successfully run
DEBUG - 2014-02-05 13:08:37 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:08:37 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:08:37 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:08:37 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:08:37 --> Model Class Initialized
DEBUG - 2014-02-05 13:08:37 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:08:37 --> Model Class Initialized
DEBUG - 2014-02-05 13:08:37 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:08:37 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:08:37 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:08:37 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:08:37 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:08:37 --> Model Class Initialized
DEBUG - 2014-02-05 13:08:37 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:08:37 --> Model Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Config Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:09:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:09:44 --> URI Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Router Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Output Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Security Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Input Class Initialized
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:09:44 --> Language Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Language Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Config Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Loader Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Controller Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Session Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:09:44 --> Session routines successfully run
DEBUG - 2014-02-05 13:09:44 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:09:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:09:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:09:44 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:09:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:09:44 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:09:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:09:44 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:09:44 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:09:44 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:09:44 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:09:44 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:09:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:09:44 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:09:44 --> Model Class Initialized
DEBUG - 2014-02-05 13:09:44 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:09:44 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:09:44 --> Final output sent to browser
DEBUG - 2014-02-05 13:09:44 --> Total execution time: 0.0598
DEBUG - 2014-02-05 13:09:49 --> Config Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:09:49 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:09:49 --> URI Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Router Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Output Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Security Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Input Class Initialized
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> XSS Filtering completed
DEBUG - 2014-02-05 13:09:49 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:09:49 --> Language Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Language Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Config Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Loader Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Controller Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Session Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:09:49 --> Session routines successfully run
DEBUG - 2014-02-05 13:09:49 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:09:49 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:09:49 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:09:49 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:09:49 --> Model Class Initialized
DEBUG - 2014-02-05 13:09:49 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:09:49 --> Model Class Initialized
DEBUG - 2014-02-05 13:09:49 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:09:49 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:09:49 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:09:49 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:09:49 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:09:49 --> Model Class Initialized
DEBUG - 2014-02-05 13:09:49 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:09:49 --> Model Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Config Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:10:25 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:10:25 --> URI Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Router Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Output Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Security Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Input Class Initialized
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:10:25 --> Language Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Language Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Config Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Loader Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Controller Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Session Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:10:25 --> Session routines successfully run
DEBUG - 2014-02-05 13:10:25 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:10:25 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:10:25 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:10:25 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:10:25 --> Model Class Initialized
DEBUG - 2014-02-05 13:10:25 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:10:25 --> Model Class Initialized
DEBUG - 2014-02-05 13:10:25 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:10:25 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:10:25 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:10:25 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:10:25 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:10:25 --> Model Class Initialized
DEBUG - 2014-02-05 13:10:25 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:10:25 --> Model Class Initialized
DEBUG - 2014-02-05 13:10:25 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:10:25 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:10:25 --> Final output sent to browser
DEBUG - 2014-02-05 13:10:25 --> Total execution time: 0.0587
DEBUG - 2014-02-05 13:10:32 --> Config Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:10:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:10:32 --> URI Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Router Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Output Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Security Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Input Class Initialized
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> XSS Filtering completed
DEBUG - 2014-02-05 13:10:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:10:32 --> Language Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Language Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Config Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Loader Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Controller Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Session Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:10:32 --> Session routines successfully run
DEBUG - 2014-02-05 13:10:32 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:10:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:10:32 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:10:32 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:10:32 --> Model Class Initialized
DEBUG - 2014-02-05 13:10:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:10:32 --> Model Class Initialized
DEBUG - 2014-02-05 13:10:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:10:32 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:10:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:10:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:10:32 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:10:32 --> Model Class Initialized
DEBUG - 2014-02-05 13:10:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:10:32 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:21:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:21:05 --> URI Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Router Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Output Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Security Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Input Class Initialized
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:21:05 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Loader Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Controller Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Session Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:21:05 --> Session routines successfully run
DEBUG - 2014-02-05 13:21:05 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 13:21:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:21:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:21:05 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:21:05 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:21:05 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:21:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:21:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:21:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:21:05 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:05 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:21:05 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-05 13:21:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:21:05 --> Final output sent to browser
DEBUG - 2014-02-05 13:21:05 --> Total execution time: 0.0856
DEBUG - 2014-02-05 13:21:06 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:21:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:21:06 --> URI Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Router Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Output Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Security Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Input Class Initialized
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:21:06 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Loader Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Controller Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Session Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:21:06 --> Session routines successfully run
DEBUG - 2014-02-05 13:21:06 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:21:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:21:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:21:06 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:21:06 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:21:06 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:21:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:21:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:21:06 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:21:06 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:06 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:21:06 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:21:06 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:06 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:21:06 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:06 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:21:06 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:21:06 --> Final output sent to browser
DEBUG - 2014-02-05 13:21:06 --> Total execution time: 0.0724
DEBUG - 2014-02-05 13:21:14 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:21:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:21:14 --> URI Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Router Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Output Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Security Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Input Class Initialized
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:21:14 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Loader Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Controller Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Session Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:21:14 --> Session routines successfully run
DEBUG - 2014-02-05 13:21:14 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:21:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:21:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:21:14 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:21:14 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:21:14 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:21:14 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:21:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:21:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:21:14 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:21:14 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:21:14 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:14 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:21:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:21:14 --> Final output sent to browser
DEBUG - 2014-02-05 13:21:14 --> Total execution time: 0.0574
DEBUG - 2014-02-05 13:21:18 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:21:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:21:18 --> URI Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Router Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Output Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Security Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Input Class Initialized
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:21:18 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Loader Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Controller Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Session Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:21:18 --> Session routines successfully run
DEBUG - 2014-02-05 13:21:18 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:21:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:21:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:21:18 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:21:18 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:18 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:21:18 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:18 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:21:18 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:21:18 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:21:18 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:21:18 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:21:18 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:18 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:21:18 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:21:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:21:43 --> URI Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Router Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Output Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Security Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Input Class Initialized
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:21:43 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Loader Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Controller Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Session Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:21:43 --> Session routines successfully run
DEBUG - 2014-02-05 13:21:43 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:21:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:21:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:21:43 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:21:43 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:21:43 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:21:43 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:21:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:21:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:21:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:21:43 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:21:43 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:43 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:21:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:21:43 --> Final output sent to browser
DEBUG - 2014-02-05 13:21:43 --> Total execution time: 0.0747
DEBUG - 2014-02-05 13:21:47 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:21:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:21:47 --> URI Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Router Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Output Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Security Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Input Class Initialized
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:21:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:21:47 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Language Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Config Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Loader Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Controller Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Session Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:21:47 --> Session routines successfully run
DEBUG - 2014-02-05 13:21:47 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:21:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:21:47 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:21:47 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:21:47 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:21:47 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:21:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:21:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:21:47 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:21:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:21:48 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:21:48 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:21:48 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:21:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:21:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:21:48 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:21:48 --> Model Class Initialized
DEBUG - 2014-02-05 13:21:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:21:48 --> Model Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Config Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:22:10 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:22:10 --> URI Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Router Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Output Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Security Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Input Class Initialized
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:10 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:22:10 --> Language Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Language Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Config Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Loader Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Controller Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Session Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:22:10 --> Session routines successfully run
DEBUG - 2014-02-05 13:22:10 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:22:10 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:22:10 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:22:10 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:22:10 --> Model Class Initialized
DEBUG - 2014-02-05 13:22:10 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:22:10 --> Model Class Initialized
DEBUG - 2014-02-05 13:22:10 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:22:10 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:22:10 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:22:10 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:22:10 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:22:10 --> Model Class Initialized
DEBUG - 2014-02-05 13:22:10 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:22:10 --> Model Class Initialized
DEBUG - 2014-02-05 13:22:10 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:22:10 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:22:10 --> Final output sent to browser
DEBUG - 2014-02-05 13:22:10 --> Total execution time: 0.0830
DEBUG - 2014-02-05 13:22:14 --> Config Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:22:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:22:14 --> URI Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Router Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Output Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Security Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Input Class Initialized
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> XSS Filtering completed
DEBUG - 2014-02-05 13:22:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:22:14 --> Language Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Language Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Config Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Loader Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Controller Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Session Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:22:14 --> Session routines successfully run
DEBUG - 2014-02-05 13:22:14 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:22:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:22:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:22:14 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:22:14 --> Model Class Initialized
DEBUG - 2014-02-05 13:22:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:22:14 --> Model Class Initialized
DEBUG - 2014-02-05 13:22:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:22:14 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:22:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:22:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:22:14 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:22:14 --> Model Class Initialized
DEBUG - 2014-02-05 13:22:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:22:14 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:23:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:23:29 --> URI Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Router Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Output Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Security Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Input Class Initialized
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:23:29 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Loader Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Controller Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Session Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:23:29 --> Session routines successfully run
DEBUG - 2014-02-05 13:23:29 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:23:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:23:29 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:23:29 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:23:29 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:23:29 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:23:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:23:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:23:29 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:23:29 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:29 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:23:29 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:23:29 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:29 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:23:29 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:29 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:23:29 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:23:29 --> Final output sent to browser
DEBUG - 2014-02-05 13:23:29 --> Total execution time: 0.0857
DEBUG - 2014-02-05 13:23:40 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:23:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:23:40 --> URI Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Router Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Output Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Security Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Input Class Initialized
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:23:40 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Loader Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Controller Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Session Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:23:40 --> Session routines successfully run
DEBUG - 2014-02-05 13:23:40 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:23:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:23:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:23:40 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:23:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:23:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:23:40 --> URI Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Router Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Output Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Security Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Input Class Initialized
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:23:40 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Loader Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Controller Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Session Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:23:40 --> Session routines successfully run
DEBUG - 2014-02-05 13:23:40 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 13:23:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:23:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:23:40 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:23:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> Helper loaded: image_helper
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:23:40 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 13:23:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:23:40 --> Final output sent to browser
DEBUG - 2014-02-05 13:23:40 --> Total execution time: 0.0750
DEBUG - 2014-02-05 13:23:43 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:23:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:23:43 --> URI Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Router Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Output Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Security Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Input Class Initialized
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:23:43 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Loader Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Controller Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Session Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:23:43 --> Session routines successfully run
DEBUG - 2014-02-05 13:23:43 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:23:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:23:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:23:43 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:23:43 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:23:43 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:23:43 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:23:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:23:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:23:43 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:23:43 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:23:43 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:43 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 13:23:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 13:23:43 --> Final output sent to browser
DEBUG - 2014-02-05 13:23:43 --> Total execution time: 0.0699
DEBUG - 2014-02-05 13:23:47 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Hooks Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Utf8 Class Initialized
DEBUG - 2014-02-05 13:23:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 13:23:47 --> URI Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Router Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Output Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Security Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Input Class Initialized
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> XSS Filtering completed
DEBUG - 2014-02-05 13:23:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 13:23:47 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Language Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Config Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Loader Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Controller Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Session Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: string_helper
DEBUG - 2014-02-05 13:23:47 --> Session routines successfully run
DEBUG - 2014-02-05 13:23:47 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 13:23:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: url_helper
DEBUG - 2014-02-05 13:23:47 --> Database Driver Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: form_helper
DEBUG - 2014-02-05 13:23:47 --> Form Validation Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: number_helper
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: date_helper
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 13:23:47 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 13:23:47 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 13:23:47 --> Helper loaded: language_helper
DEBUG - 2014-02-05 13:23:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 13:23:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 13:23:47 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 13:23:47 --> Model Class Initialized
DEBUG - 2014-02-05 13:23:47 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 13:23:47 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Hooks Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Utf8 Class Initialized
DEBUG - 2014-02-05 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 14:39:14 --> URI Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Router Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Output Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Security Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Input Class Initialized
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 14:39:14 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Loader Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Controller Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Session Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: string_helper
DEBUG - 2014-02-05 14:39:14 --> Session routines successfully run
DEBUG - 2014-02-05 14:39:14 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 14:39:14 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: url_helper
DEBUG - 2014-02-05 14:39:14 --> Database Driver Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: form_helper
DEBUG - 2014-02-05 14:39:14 --> Form Validation Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: number_helper
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: date_helper
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 14:39:14 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:14 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 14:39:14 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:14 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 14:39:14 --> Helper loaded: language_helper
DEBUG - 2014-02-05 14:39:14 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 14:39:14 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 14:39:14 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 14:39:14 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:14 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 14:39:14 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:14 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 14:39:14 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 14:39:14 --> Final output sent to browser
DEBUG - 2014-02-05 14:39:14 --> Total execution time: 0.0897
DEBUG - 2014-02-05 14:39:15 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 14:39:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 14:39:15 --> URI Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Router Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Output Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Security Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Input Class Initialized
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 14:39:15 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Loader Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Controller Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Session Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 14:39:15 --> Session routines successfully run
DEBUG - 2014-02-05 14:39:15 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 14:39:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 14:39:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: form_helper
DEBUG - 2014-02-05 14:39:15 --> Form Validation Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: number_helper
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: date_helper
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 14:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 14:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: language_helper
DEBUG - 2014-02-05 14:39:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 14:39:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 14:39:15 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 14:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:15 --> Helper loaded: image_helper
DEBUG - 2014-02-05 14:39:15 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 14:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:15 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 14:39:15 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:15 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 14:39:15 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 14:39:15 --> Final output sent to browser
DEBUG - 2014-02-05 14:39:15 --> Total execution time: 0.0614
DEBUG - 2014-02-05 14:39:18 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Hooks Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Utf8 Class Initialized
DEBUG - 2014-02-05 14:39:18 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 14:39:18 --> URI Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Router Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Output Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Security Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Input Class Initialized
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:18 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 14:39:18 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Loader Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Controller Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Session Class Initialized
DEBUG - 2014-02-05 14:39:18 --> Helper loaded: string_helper
DEBUG - 2014-02-05 14:39:18 --> Session routines successfully run
DEBUG - 2014-02-05 14:39:18 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 14:39:18 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 14:39:18 --> Helper loaded: url_helper
DEBUG - 2014-02-05 14:39:18 --> Database Driver Class Initialized
DEBUG - 2014-02-05 14:39:19 --> Helper loaded: form_helper
DEBUG - 2014-02-05 14:39:19 --> Form Validation Class Initialized
DEBUG - 2014-02-05 14:39:19 --> Helper loaded: number_helper
DEBUG - 2014-02-05 14:39:19 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 14:39:19 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 14:39:19 --> Helper loaded: date_helper
DEBUG - 2014-02-05 14:39:19 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 14:39:19 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:19 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 14:39:19 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:19 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 14:39:19 --> Helper loaded: language_helper
DEBUG - 2014-02-05 14:39:19 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 14:39:19 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 14:39:19 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 14:39:19 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:19 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 14:39:19 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:19 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 14:39:19 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 14:39:19 --> Final output sent to browser
DEBUG - 2014-02-05 14:39:19 --> Total execution time: 0.0523
DEBUG - 2014-02-05 14:39:22 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Hooks Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Utf8 Class Initialized
DEBUG - 2014-02-05 14:39:22 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 14:39:22 --> URI Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Router Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Output Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Security Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Input Class Initialized
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:22 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 14:39:22 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Loader Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Controller Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Session Class Initialized
DEBUG - 2014-02-05 14:39:22 --> Helper loaded: string_helper
DEBUG - 2014-02-05 14:39:22 --> Session routines successfully run
DEBUG - 2014-02-05 14:39:22 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 14:39:22 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 14:39:22 --> Helper loaded: url_helper
DEBUG - 2014-02-05 14:39:23 --> Database Driver Class Initialized
DEBUG - 2014-02-05 14:39:23 --> Helper loaded: form_helper
DEBUG - 2014-02-05 14:39:23 --> Form Validation Class Initialized
DEBUG - 2014-02-05 14:39:23 --> Helper loaded: number_helper
DEBUG - 2014-02-05 14:39:23 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 14:39:23 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 14:39:23 --> Helper loaded: date_helper
DEBUG - 2014-02-05 14:39:23 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 14:39:23 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:23 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 14:39:23 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:23 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 14:39:23 --> Helper loaded: language_helper
DEBUG - 2014-02-05 14:39:23 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 14:39:23 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 14:39:23 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 14:39:23 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:23 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 14:39:23 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Hooks Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Utf8 Class Initialized
DEBUG - 2014-02-05 14:39:34 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 14:39:34 --> URI Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Router Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Output Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Security Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Input Class Initialized
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> XSS Filtering completed
DEBUG - 2014-02-05 14:39:34 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 14:39:34 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Language Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Config Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Loader Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Controller Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Session Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: string_helper
DEBUG - 2014-02-05 14:39:34 --> Session routines successfully run
DEBUG - 2014-02-05 14:39:34 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 14:39:34 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: url_helper
DEBUG - 2014-02-05 14:39:34 --> Database Driver Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: form_helper
DEBUG - 2014-02-05 14:39:34 --> Form Validation Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: number_helper
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: date_helper
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 14:39:34 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:34 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 14:39:34 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:34 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 14:39:34 --> Helper loaded: language_helper
DEBUG - 2014-02-05 14:39:34 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 14:39:34 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 14:39:34 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 14:39:34 --> Model Class Initialized
DEBUG - 2014-02-05 14:39:34 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 14:39:34 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Config Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Hooks Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Utf8 Class Initialized
DEBUG - 2014-02-05 14:40:00 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 14:40:00 --> URI Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Router Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Output Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Security Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Input Class Initialized
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:00 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 14:40:00 --> Language Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Language Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Config Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Loader Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Controller Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Session Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: string_helper
DEBUG - 2014-02-05 14:40:00 --> Session routines successfully run
DEBUG - 2014-02-05 14:40:00 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 14:40:00 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: url_helper
DEBUG - 2014-02-05 14:40:00 --> Database Driver Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: form_helper
DEBUG - 2014-02-05 14:40:00 --> Form Validation Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: number_helper
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: date_helper
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 14:40:00 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:00 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 14:40:00 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: language_helper
DEBUG - 2014-02-05 14:40:00 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 14:40:00 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 14:40:00 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 14:40:00 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:00 --> Helper loaded: image_helper
DEBUG - 2014-02-05 14:40:00 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 14:40:00 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:00 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 14:40:00 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:00 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 14:40:00 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 14:40:00 --> Final output sent to browser
DEBUG - 2014-02-05 14:40:00 --> Total execution time: 0.0949
DEBUG - 2014-02-05 14:40:08 --> Config Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Hooks Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Utf8 Class Initialized
DEBUG - 2014-02-05 14:40:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 14:40:08 --> URI Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Router Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Output Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Security Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Input Class Initialized
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 14:40:08 --> Language Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Language Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Config Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Loader Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Controller Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Session Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: string_helper
DEBUG - 2014-02-05 14:40:08 --> Session routines successfully run
DEBUG - 2014-02-05 14:40:08 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 14:40:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: url_helper
DEBUG - 2014-02-05 14:40:08 --> Database Driver Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: form_helper
DEBUG - 2014-02-05 14:40:08 --> Form Validation Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: number_helper
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: date_helper
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 14:40:08 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 14:40:08 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 14:40:08 --> Helper loaded: language_helper
DEBUG - 2014-02-05 14:40:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 14:40:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 14:40:08 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 14:40:08 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 14:40:08 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Config Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 14:40:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 14:40:15 --> URI Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Router Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Output Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Security Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Input Class Initialized
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> XSS Filtering completed
DEBUG - 2014-02-05 14:40:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 14:40:15 --> Language Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Language Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Config Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Loader Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Controller Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Session Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 14:40:15 --> Session routines successfully run
DEBUG - 2014-02-05 14:40:15 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 14:40:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 14:40:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: form_helper
DEBUG - 2014-02-05 14:40:15 --> Form Validation Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: number_helper
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: date_helper
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 14:40:15 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 14:40:15 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 14:40:15 --> Helper loaded: language_helper
DEBUG - 2014-02-05 14:40:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 14:40:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 14:40:15 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 14:40:15 --> Model Class Initialized
DEBUG - 2014-02-05 14:40:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 14:40:15 --> Model Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Config Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:23:48 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:23:48 --> URI Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Router Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Output Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Security Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Input Class Initialized
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> XSS Filtering completed
DEBUG - 2014-02-05 15:23:48 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:23:48 --> Language Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Language Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Config Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Loader Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Controller Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Session Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:23:48 --> Session routines successfully run
DEBUG - 2014-02-05 15:23:48 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:23:48 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:23:48 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:23:48 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:23:48 --> Model Class Initialized
DEBUG - 2014-02-05 15:23:48 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:23:48 --> Model Class Initialized
DEBUG - 2014-02-05 15:23:48 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:23:48 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:23:48 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:23:48 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:23:48 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:23:48 --> Model Class Initialized
DEBUG - 2014-02-05 15:23:48 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:23:48 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:25:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:25:05 --> URI Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Router Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Output Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Security Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Input Class Initialized
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:25:05 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Loader Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Controller Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Session Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:25:05 --> Session routines successfully run
DEBUG - 2014-02-05 15:25:05 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:25:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:25:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:25:05 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:25:05 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:25:05 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:25:05 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:25:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:25:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:25:05 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:25:05 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:25:05 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:05 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 15:25:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:25:05 --> Final output sent to browser
DEBUG - 2014-02-05 15:25:05 --> Total execution time: 0.0656
DEBUG - 2014-02-05 15:25:11 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:25:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:25:11 --> URI Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Router Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Output Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Security Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Input Class Initialized
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:25:11 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Loader Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Controller Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Session Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:25:11 --> Session routines successfully run
DEBUG - 2014-02-05 15:25:11 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:25:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:25:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:25:11 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:25:11 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:25:11 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:25:11 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:25:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:25:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:25:11 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:25:11 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:11 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:25:11 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:25:26 --> URI Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Router Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Output Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Security Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Input Class Initialized
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:25:26 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Loader Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Controller Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Session Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:25:26 --> Session routines successfully run
DEBUG - 2014-02-05 15:25:26 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:25:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:25:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:25:26 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:25:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:25:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:25:26 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:25:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:25:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:25:26 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:25:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:26 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:25:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:26 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 15:25:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:25:26 --> Final output sent to browser
DEBUG - 2014-02-05 15:25:26 --> Total execution time: 0.0742
DEBUG - 2014-02-05 15:25:31 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:25:31 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:25:31 --> URI Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Router Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Output Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Security Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Input Class Initialized
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:25:31 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Loader Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Controller Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Session Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:25:31 --> Session routines successfully run
DEBUG - 2014-02-05 15:25:31 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:25:31 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:25:31 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:25:31 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:25:31 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:31 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:25:31 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:31 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:25:31 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:25:31 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:25:31 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:25:31 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:25:31 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:31 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:25:31 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:25:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:25:38 --> URI Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Router Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Output Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Security Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Input Class Initialized
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:25:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:25:38 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Language Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Config Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Loader Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Controller Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Session Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:25:38 --> Session routines successfully run
DEBUG - 2014-02-05 15:25:38 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:25:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:25:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:25:38 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:25:38 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:25:38 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:25:38 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:25:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:25:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:25:38 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:25:38 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:25:38 --> Model Class Initialized
DEBUG - 2014-02-05 15:25:38 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 15:25:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:25:38 --> Final output sent to browser
DEBUG - 2014-02-05 15:25:38 --> Total execution time: 0.0724
DEBUG - 2014-02-05 15:26:24 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:26:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:26:24 --> URI Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Router Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Output Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Security Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Input Class Initialized
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:26:24 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Loader Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Controller Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Session Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:26:24 --> Session routines successfully run
DEBUG - 2014-02-05 15:26:24 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:26:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:26:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:26:24 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:26:24 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:26:24 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:26:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:26:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:26:24 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:26:24 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:24 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:26:24 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-05 15:26:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:26:24 --> Final output sent to browser
DEBUG - 2014-02-05 15:26:24 --> Total execution time: 0.0565
DEBUG - 2014-02-05 15:26:26 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:26:26 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:26:26 --> URI Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Router Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Output Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Security Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Input Class Initialized
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:26:26 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Loader Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Controller Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Session Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:26:26 --> Session routines successfully run
DEBUG - 2014-02-05 15:26:26 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 15:26:26 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:26:26 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:26:26 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:26:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:26 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:26:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:26:26 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:26:26 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:26:26 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 15:26:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:26 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:26:26 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 15:26:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:26 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:26:26 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:26 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 15:26:26 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:26:26 --> Final output sent to browser
DEBUG - 2014-02-05 15:26:26 --> Total execution time: 0.0839
DEBUG - 2014-02-05 15:26:43 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:26:43 --> URI Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Router Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Output Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Security Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Input Class Initialized
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:26:43 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Loader Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Controller Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Session Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:26:43 --> Session routines successfully run
DEBUG - 2014-02-05 15:26:43 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:26:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:26:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:26:43 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:26:43 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:26:43 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:26:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:26:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:26:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:26:43 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:43 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:26:43 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-05 15:26:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:26:43 --> Final output sent to browser
DEBUG - 2014-02-05 15:26:43 --> Total execution time: 0.0588
DEBUG - 2014-02-05 15:26:46 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:26:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:26:46 --> URI Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Router Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Output Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Security Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Input Class Initialized
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:46 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:26:46 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Loader Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Controller Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Session Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:26:46 --> Session routines successfully run
DEBUG - 2014-02-05 15:26:46 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:26:46 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:26:46 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:26:46 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:26:46 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:46 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:26:46 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:26:46 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:26:46 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:26:46 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:26:46 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:46 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:26:46 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-05 15:26:46 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:26:46 --> Final output sent to browser
DEBUG - 2014-02-05 15:26:46 --> Total execution time: 0.0650
DEBUG - 2014-02-05 15:26:47 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:26:47 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:26:47 --> URI Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Router Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Output Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Security Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Input Class Initialized
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> XSS Filtering completed
DEBUG - 2014-02-05 15:26:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:26:47 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Language Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Config Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Loader Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Controller Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Session Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:26:47 --> Session routines successfully run
DEBUG - 2014-02-05 15:26:47 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:26:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:26:47 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:26:47 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:26:47 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:26:47 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:26:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:26:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:26:47 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:26:47 --> Model Class Initialized
DEBUG - 2014-02-05 15:26:47 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:26:47 --> File loaded: application/modules/patient/views/patient_financial_profile.php
DEBUG - 2014-02-05 15:26:47 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:26:47 --> Final output sent to browser
DEBUG - 2014-02-05 15:26:47 --> Total execution time: 0.0784
DEBUG - 2014-02-05 15:27:05 --> Config Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:27:05 --> URI Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Router Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Output Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Security Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Input Class Initialized
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:05 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:27:05 --> Language Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Language Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Config Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Loader Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Controller Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Session Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:27:05 --> Session routines successfully run
DEBUG - 2014-02-05 15:27:05 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:27:05 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:27:05 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:27:05 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:27:05 --> Model Class Initialized
DEBUG - 2014-02-05 15:27:05 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:27:05 --> Model Class Initialized
DEBUG - 2014-02-05 15:27:05 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:27:05 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:27:05 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:27:05 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:27:05 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:27:05 --> Model Class Initialized
DEBUG - 2014-02-05 15:27:05 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:27:05 --> Model Class Initialized
DEBUG - 2014-02-05 15:27:05 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 15:27:05 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:27:05 --> Final output sent to browser
DEBUG - 2014-02-05 15:27:05 --> Total execution time: 0.0654
DEBUG - 2014-02-05 15:27:09 --> Config Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:27:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:27:09 --> URI Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Router Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Output Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Security Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Input Class Initialized
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:27:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:27:09 --> Language Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Language Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Config Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Loader Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Controller Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Session Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:27:09 --> Session routines successfully run
DEBUG - 2014-02-05 15:27:09 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:27:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:27:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:27:09 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:27:09 --> Model Class Initialized
DEBUG - 2014-02-05 15:27:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:27:09 --> Model Class Initialized
DEBUG - 2014-02-05 15:27:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:27:09 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:27:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:27:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:27:09 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:27:09 --> Model Class Initialized
DEBUG - 2014-02-05 15:27:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:27:09 --> Model Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Config Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:28:07 --> URI Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Router Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Output Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Security Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Input Class Initialized
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:28:07 --> Language Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Language Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Config Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Loader Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Controller Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Session Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:28:07 --> Session routines successfully run
DEBUG - 2014-02-05 15:28:07 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:28:07 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:28:07 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:28:07 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:28:07 --> Model Class Initialized
DEBUG - 2014-02-05 15:28:07 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:28:07 --> Model Class Initialized
DEBUG - 2014-02-05 15:28:07 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:28:07 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:28:07 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:28:07 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:28:07 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:28:07 --> Model Class Initialized
DEBUG - 2014-02-05 15:28:07 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:28:07 --> Model Class Initialized
DEBUG - 2014-02-05 15:28:07 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 15:28:07 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:28:07 --> Final output sent to browser
DEBUG - 2014-02-05 15:28:07 --> Total execution time: 0.0601
DEBUG - 2014-02-05 15:28:13 --> Config Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:28:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:28:13 --> URI Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Router Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Output Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Security Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Input Class Initialized
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:28:13 --> Language Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Language Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Config Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Loader Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Controller Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Session Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:28:13 --> Session routines successfully run
DEBUG - 2014-02-05 15:28:13 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:28:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:28:13 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:28:13 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:28:13 --> Model Class Initialized
DEBUG - 2014-02-05 15:28:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:28:13 --> Model Class Initialized
DEBUG - 2014-02-05 15:28:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:28:13 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:28:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:28:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:28:13 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:28:13 --> Model Class Initialized
DEBUG - 2014-02-05 15:28:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:28:13 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:01 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:01 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:01 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:01 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:01 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:01 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:30:01 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:01 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:01 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:01 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:01 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:01 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:01 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:01 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:01 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:01 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:01 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:30:01 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:01 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:30:01 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:09 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:09 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:09 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:09 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:09 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:30:09 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:09 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:09 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:09 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:09 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:09 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:09 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:09 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:09 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:09 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:09 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:30:09 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:09 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:30:09 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:09 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 15:30:09 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:30:09 --> Final output sent to browser
DEBUG - 2014-02-05 15:30:09 --> Total execution time: 0.0826
DEBUG - 2014-02-05 15:30:21 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:21 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:21 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:21 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:21 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:30:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:21 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:30:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:21 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:30:21 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-05 15:30:21 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:30:21 --> Final output sent to browser
DEBUG - 2014-02-05 15:30:21 --> Total execution time: 0.0816
DEBUG - 2014-02-05 15:30:24 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:24 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:24 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:24 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:24 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:24 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:24 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 15:30:24 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:24 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:24 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:24 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:24 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:24 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:24 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:24 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:24 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 15:30:24 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:24 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:30:24 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 15:30:24 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:24 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:30:24 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:24 --> File loaded: application/modules/scheduler/views/scheduler.php
DEBUG - 2014-02-05 15:30:24 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:30:24 --> Final output sent to browser
DEBUG - 2014-02-05 15:30:24 --> Total execution time: 0.0859
DEBUG - 2014-02-05 15:30:30 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:30 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:30 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:30 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:30 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:30 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:30 --> Scheduler MX_Controller Initialized
DEBUG - 2014-02-05 15:30:30 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:30 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:30 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:30 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:30 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:30 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:30 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:30 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:30 --> File loaded: application/modules/scheduler/models/mdl_scheduler.php
DEBUG - 2014-02-05 15:30:30 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:30 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:30:30 --> File loaded: application/modules/admin/models/mdl_admin.php
DEBUG - 2014-02-05 15:30:30 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:30 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:30:30 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:31 --> File loaded: application/modules/scheduler/views/edit_scheduler.php
DEBUG - 2014-02-05 15:30:31 --> Final output sent to browser
DEBUG - 2014-02-05 15:30:31 --> Total execution time: 0.0612
DEBUG - 2014-02-05 15:30:38 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:38 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:38 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:38 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:38 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:38 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:38 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:30:38 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:38 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:38 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:38 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:38 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:38 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:38 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:38 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:38 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:30:38 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:38 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:30:38 --> File loaded: application/modules/patient/views/patient.php
DEBUG - 2014-02-05 15:30:38 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:30:38 --> Final output sent to browser
DEBUG - 2014-02-05 15:30:38 --> Total execution time: 0.0844
DEBUG - 2014-02-05 15:30:40 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:40 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:40 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:40 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:40 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:40 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:30:40 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:40 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:40 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:40 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:40 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:40 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:40 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:40 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:40 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:30:40 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:40 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:30:40 --> File loaded: application/modules/patient/views/patient_profile.php
DEBUG - 2014-02-05 15:30:40 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:30:40 --> Final output sent to browser
DEBUG - 2014-02-05 15:30:40 --> Total execution time: 0.0561
DEBUG - 2014-02-05 15:30:43 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:43 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:43 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:43 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:43 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:43 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:43 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:30:43 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:43 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:43 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:43 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:43 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:43 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:43 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:43 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:43 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:30:43 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:43 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:30:43 --> File loaded: application/modules/patient/views/admission_data.php
DEBUG - 2014-02-05 15:30:43 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:30:43 --> Final output sent to browser
DEBUG - 2014-02-05 15:30:43 --> Total execution time: 0.0924
DEBUG - 2014-02-05 15:30:44 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:30:44 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:30:44 --> URI Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Router Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Output Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Security Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Input Class Initialized
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> XSS Filtering completed
DEBUG - 2014-02-05 15:30:44 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:30:44 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Language Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Config Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Loader Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Controller Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Session Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:30:44 --> Session routines successfully run
DEBUG - 2014-02-05 15:30:44 --> Patient MX_Controller Initialized
DEBUG - 2014-02-05 15:30:44 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:30:44 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:30:44 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:30:44 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:30:44 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:30:45 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:30:45 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:30:45 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:30:45 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:30:45 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:45 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:30:45 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:45 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:30:45 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:30:45 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:30:45 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:30:45 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:30:45 --> Model Class Initialized
DEBUG - 2014-02-05 15:30:45 --> Helper loaded: image_helper
DEBUG - 2014-02-05 15:30:45 --> File loaded: application/modules/patient/views/patient_financial_profile.php
DEBUG - 2014-02-05 15:30:45 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 15:30:45 --> Final output sent to browser
DEBUG - 2014-02-05 15:30:45 --> Total execution time: 0.0587
DEBUG - 2014-02-05 15:33:15 --> Config Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:33:15 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:33:15 --> URI Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Router Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Output Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Security Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Input Class Initialized
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:15 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:33:15 --> Language Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Language Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Config Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Loader Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Controller Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Session Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:33:15 --> Session routines successfully run
DEBUG - 2014-02-05 15:33:15 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:33:15 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:33:15 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:33:15 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:33:15 --> Model Class Initialized
DEBUG - 2014-02-05 15:33:15 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:33:15 --> Model Class Initialized
DEBUG - 2014-02-05 15:33:15 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:33:15 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:33:15 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:33:15 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:33:15 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:33:15 --> Model Class Initialized
DEBUG - 2014-02-05 15:33:15 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:33:15 --> Model Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Config Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:33:29 --> URI Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Router Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Output Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Security Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Input Class Initialized
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> XSS Filtering completed
DEBUG - 2014-02-05 15:33:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:33:29 --> Language Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Language Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Config Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Loader Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Controller Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Session Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:33:29 --> Session routines successfully run
DEBUG - 2014-02-05 15:33:29 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:33:29 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:33:29 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:33:29 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:33:29 --> Model Class Initialized
DEBUG - 2014-02-05 15:33:29 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:33:29 --> Model Class Initialized
DEBUG - 2014-02-05 15:33:29 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:33:29 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:33:29 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:33:29 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:33:29 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:33:29 --> Model Class Initialized
DEBUG - 2014-02-05 15:33:29 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:33:29 --> Model Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Config Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:35:52 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:35:52 --> URI Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Router Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Output Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Security Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Input Class Initialized
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> XSS Filtering completed
DEBUG - 2014-02-05 15:35:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:35:52 --> Language Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Language Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Config Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Loader Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Controller Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Session Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:35:52 --> Session routines successfully run
DEBUG - 2014-02-05 15:35:52 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:35:52 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:35:52 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:35:52 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:35:52 --> Model Class Initialized
DEBUG - 2014-02-05 15:35:52 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:35:52 --> Model Class Initialized
DEBUG - 2014-02-05 15:35:52 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:35:52 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:35:52 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:35:52 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:35:52 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:35:52 --> Model Class Initialized
DEBUG - 2014-02-05 15:35:52 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:35:52 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Config Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:36:11 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:36:11 --> URI Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Router Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Output Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Security Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Input Class Initialized
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:36:11 --> Language Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Language Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Config Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Loader Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Controller Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Session Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:36:11 --> Session routines successfully run
DEBUG - 2014-02-05 15:36:11 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:36:11 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:36:11 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:36:11 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:36:11 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:11 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:36:11 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:11 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:36:11 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:36:11 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:36:11 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:36:11 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:36:11 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:11 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:36:11 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Config Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:36:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:36:13 --> URI Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Router Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Output Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Security Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Input Class Initialized
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:36:13 --> Language Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Language Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Config Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Loader Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Controller Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Session Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:36:13 --> Session routines successfully run
DEBUG - 2014-02-05 15:36:13 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:36:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:36:13 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:36:13 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:36:13 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:36:13 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:36:13 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:36:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:36:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:36:13 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:36:13 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:36:13 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Config Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:36:20 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:36:20 --> URI Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Router Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Output Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Security Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Input Class Initialized
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> XSS Filtering completed
DEBUG - 2014-02-05 15:36:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:36:20 --> Language Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Language Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Config Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Loader Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Controller Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Session Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:36:20 --> Session routines successfully run
DEBUG - 2014-02-05 15:36:20 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:36:20 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:36:20 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:36:20 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:36:20 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:20 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:36:20 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:20 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:36:20 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:36:20 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:36:20 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:36:20 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:36:20 --> Model Class Initialized
DEBUG - 2014-02-05 15:36:20 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:36:20 --> Model Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Config Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:37:28 --> URI Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Router Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Output Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Security Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Input Class Initialized
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> XSS Filtering completed
DEBUG - 2014-02-05 15:37:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:37:28 --> Language Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Language Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Config Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Loader Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Controller Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Session Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:37:28 --> Session routines successfully run
DEBUG - 2014-02-05 15:37:28 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:37:28 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:37:28 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:37:28 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:37:28 --> Model Class Initialized
DEBUG - 2014-02-05 15:37:28 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:37:28 --> Model Class Initialized
DEBUG - 2014-02-05 15:37:28 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:37:28 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:37:28 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:37:28 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:37:28 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:37:28 --> Model Class Initialized
DEBUG - 2014-02-05 15:37:28 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:37:28 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Config Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:40:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:40:21 --> URI Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Router Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Output Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Security Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Input Class Initialized
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:40:21 --> Language Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Language Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Config Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Loader Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Controller Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Session Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:40:21 --> Session routines successfully run
DEBUG - 2014-02-05 15:40:21 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:40:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:40:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:40:21 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:40:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:40:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:40:21 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:40:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:40:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:40:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:40:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:40:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Config Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:40:27 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:40:27 --> URI Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Router Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Output Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Security Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Input Class Initialized
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:27 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:40:27 --> Language Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Language Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Config Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Loader Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Controller Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Session Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:40:27 --> Session routines successfully run
DEBUG - 2014-02-05 15:40:27 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:40:27 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:40:27 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:40:27 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:40:27 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:27 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:40:27 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:27 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:40:27 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:40:27 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:40:27 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:40:27 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:40:27 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:27 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:40:27 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Config Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:40:50 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:40:50 --> URI Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Router Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Output Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Security Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Input Class Initialized
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> XSS Filtering completed
DEBUG - 2014-02-05 15:40:50 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:40:50 --> Language Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Language Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Config Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Loader Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Controller Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Session Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:40:50 --> Session routines successfully run
DEBUG - 2014-02-05 15:40:50 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:40:50 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:40:50 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:40:50 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:40:50 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:50 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:40:50 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:50 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:40:50 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:40:50 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:40:50 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:40:50 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:40:50 --> Model Class Initialized
DEBUG - 2014-02-05 15:40:50 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:40:50 --> Model Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Config Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:41:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:41:06 --> URI Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Router Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Output Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Security Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Input Class Initialized
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> XSS Filtering completed
DEBUG - 2014-02-05 15:41:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:41:06 --> Language Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Language Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Config Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Loader Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Controller Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Session Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:41:06 --> Session routines successfully run
DEBUG - 2014-02-05 15:41:06 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:41:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:41:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:41:06 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:41:06 --> Model Class Initialized
DEBUG - 2014-02-05 15:41:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:41:06 --> Model Class Initialized
DEBUG - 2014-02-05 15:41:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:41:06 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:41:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:41:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:41:06 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:41:06 --> Model Class Initialized
DEBUG - 2014-02-05 15:41:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:41:06 --> Model Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Config Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:43:21 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:43:21 --> URI Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Router Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Output Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Security Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Input Class Initialized
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:43:21 --> Language Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Language Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Config Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Loader Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Controller Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Session Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:43:21 --> Session routines successfully run
DEBUG - 2014-02-05 15:43:21 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:43:21 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:43:21 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:43:21 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:43:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:43:21 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:43:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:43:21 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:43:21 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:43:21 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:43:21 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:43:21 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:43:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:43:21 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:43:21 --> Model Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Config Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Hooks Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Utf8 Class Initialized
DEBUG - 2014-02-05 15:43:58 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 15:43:58 --> URI Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Router Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Output Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Security Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Input Class Initialized
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> XSS Filtering completed
DEBUG - 2014-02-05 15:43:58 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 15:43:58 --> Language Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Language Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Config Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Loader Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Controller Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Session Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: string_helper
DEBUG - 2014-02-05 15:43:58 --> Session routines successfully run
DEBUG - 2014-02-05 15:43:58 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 15:43:58 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: url_helper
DEBUG - 2014-02-05 15:43:58 --> Database Driver Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: form_helper
DEBUG - 2014-02-05 15:43:58 --> Form Validation Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: number_helper
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: date_helper
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 15:43:58 --> Model Class Initialized
DEBUG - 2014-02-05 15:43:58 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 15:43:58 --> Model Class Initialized
DEBUG - 2014-02-05 15:43:58 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 15:43:58 --> Helper loaded: language_helper
DEBUG - 2014-02-05 15:43:58 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 15:43:58 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 15:43:58 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 15:43:58 --> Model Class Initialized
DEBUG - 2014-02-05 15:43:58 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 15:43:58 --> Model Class Initialized
DEBUG - 2014-02-05 16:54:46 --> Config Class Initialized
DEBUG - 2014-02-05 16:54:46 --> Hooks Class Initialized
DEBUG - 2014-02-05 16:54:46 --> Utf8 Class Initialized
DEBUG - 2014-02-05 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 16:54:46 --> URI Class Initialized
DEBUG - 2014-02-05 16:54:46 --> Router Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Output Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Security Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Input Class Initialized
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> XSS Filtering completed
DEBUG - 2014-02-05 16:54:47 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 16:54:47 --> Language Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Language Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Config Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Loader Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Controller Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Session Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: string_helper
DEBUG - 2014-02-05 16:54:47 --> Session routines successfully run
DEBUG - 2014-02-05 16:54:47 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 16:54:47 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: url_helper
DEBUG - 2014-02-05 16:54:47 --> Database Driver Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: form_helper
DEBUG - 2014-02-05 16:54:47 --> Form Validation Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: number_helper
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: date_helper
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 16:54:47 --> Model Class Initialized
DEBUG - 2014-02-05 16:54:47 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 16:54:47 --> Model Class Initialized
DEBUG - 2014-02-05 16:54:47 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 16:54:47 --> Helper loaded: language_helper
DEBUG - 2014-02-05 16:54:47 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 16:54:47 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 16:54:47 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 16:54:47 --> Model Class Initialized
DEBUG - 2014-02-05 16:54:47 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 16:54:47 --> Model Class Initialized
DEBUG - 2014-02-05 16:54:47 --> DB Transaction Failure
ERROR - 2014-02-05 16:54:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '>= '2014-02-01' && s.start_date between <= '2014-02-28' and sd.event_id=s.id' at line 1
DEBUG - 2014-02-05 16:54:47 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-02-05 16:55:02 --> Config Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Hooks Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Utf8 Class Initialized
DEBUG - 2014-02-05 16:55:02 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 16:55:02 --> URI Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Router Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Output Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Security Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Input Class Initialized
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> XSS Filtering completed
DEBUG - 2014-02-05 16:55:02 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 16:55:02 --> Language Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Language Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Config Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Loader Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Controller Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Session Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: string_helper
DEBUG - 2014-02-05 16:55:02 --> Session routines successfully run
DEBUG - 2014-02-05 16:55:02 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 16:55:02 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: url_helper
DEBUG - 2014-02-05 16:55:02 --> Database Driver Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: form_helper
DEBUG - 2014-02-05 16:55:02 --> Form Validation Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: number_helper
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: date_helper
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 16:55:02 --> Model Class Initialized
DEBUG - 2014-02-05 16:55:02 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 16:55:02 --> Model Class Initialized
DEBUG - 2014-02-05 16:55:02 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 16:55:02 --> Helper loaded: language_helper
DEBUG - 2014-02-05 16:55:02 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 16:55:02 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 16:55:02 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 16:55:02 --> Model Class Initialized
DEBUG - 2014-02-05 16:55:02 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 16:55:02 --> Model Class Initialized
DEBUG - 2014-02-05 16:55:02 --> DB Transaction Failure
ERROR - 2014-02-05 16:55:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '>= '2014-02-01' and s.start_date between <= '2014-02-28' and sd.event_id=s.id' at line 1
DEBUG - 2014-02-05 16:55:02 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-02-05 16:57:06 --> Config Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Hooks Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Utf8 Class Initialized
DEBUG - 2014-02-05 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 16:57:06 --> URI Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Router Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Output Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Security Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Input Class Initialized
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:06 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 16:57:06 --> Language Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Language Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Config Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Loader Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Controller Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Session Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: string_helper
DEBUG - 2014-02-05 16:57:06 --> Session routines successfully run
DEBUG - 2014-02-05 16:57:06 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 16:57:06 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: url_helper
DEBUG - 2014-02-05 16:57:06 --> Database Driver Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: form_helper
DEBUG - 2014-02-05 16:57:06 --> Form Validation Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: number_helper
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: date_helper
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 16:57:06 --> Model Class Initialized
DEBUG - 2014-02-05 16:57:06 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 16:57:06 --> Model Class Initialized
DEBUG - 2014-02-05 16:57:06 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 16:57:06 --> Helper loaded: language_helper
DEBUG - 2014-02-05 16:57:06 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 16:57:06 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 16:57:06 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 16:57:06 --> Model Class Initialized
DEBUG - 2014-02-05 16:57:06 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 16:57:06 --> Model Class Initialized
DEBUG - 2014-02-05 16:57:06 --> DB Transaction Failure
ERROR - 2014-02-05 16:57:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '>= '2014-02-01' and s.start_date between <= '2014-02-28') and sd.event_id=s.id' at line 1
DEBUG - 2014-02-05 16:57:06 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-02-05 16:57:17 --> Config Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Hooks Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Utf8 Class Initialized
DEBUG - 2014-02-05 16:57:17 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 16:57:17 --> URI Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Router Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Output Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Security Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Input Class Initialized
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> XSS Filtering completed
DEBUG - 2014-02-05 16:57:17 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 16:57:17 --> Language Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Language Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Config Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Loader Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Controller Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Session Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: string_helper
DEBUG - 2014-02-05 16:57:17 --> Session routines successfully run
DEBUG - 2014-02-05 16:57:17 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 16:57:17 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: url_helper
DEBUG - 2014-02-05 16:57:17 --> Database Driver Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: form_helper
DEBUG - 2014-02-05 16:57:17 --> Form Validation Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: number_helper
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: date_helper
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 16:57:17 --> Model Class Initialized
DEBUG - 2014-02-05 16:57:17 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 16:57:17 --> Model Class Initialized
DEBUG - 2014-02-05 16:57:17 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 16:57:17 --> Helper loaded: language_helper
DEBUG - 2014-02-05 16:57:17 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 16:57:17 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 16:57:17 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 16:57:17 --> Model Class Initialized
DEBUG - 2014-02-05 16:57:17 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 16:57:17 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Config Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:08:32 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:08:32 --> URI Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Router Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Output Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Security Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Input Class Initialized
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:08:32 --> Language Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Language Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Config Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Loader Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Controller Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Session Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:08:32 --> Session routines successfully run
DEBUG - 2014-02-05 17:08:32 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 17:08:32 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:08:32 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: form_helper
DEBUG - 2014-02-05 17:08:32 --> Form Validation Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: number_helper
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: date_helper
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 17:08:32 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:32 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 17:08:32 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:32 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 17:08:32 --> Helper loaded: language_helper
DEBUG - 2014-02-05 17:08:32 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 17:08:32 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 17:08:32 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 17:08:32 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:32 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 17:08:32 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:32 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 17:08:32 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 17:08:32 --> Final output sent to browser
DEBUG - 2014-02-05 17:08:32 --> Total execution time: 0.0711
DEBUG - 2014-02-05 17:08:55 --> Config Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:08:55 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:08:55 --> URI Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Router Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Output Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Security Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Input Class Initialized
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> XSS Filtering completed
DEBUG - 2014-02-05 17:08:55 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:08:55 --> Language Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Language Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Config Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Loader Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Controller Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Session Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:08:55 --> Session routines successfully run
DEBUG - 2014-02-05 17:08:55 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 17:08:55 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:08:55 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: form_helper
DEBUG - 2014-02-05 17:08:55 --> Form Validation Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: number_helper
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: date_helper
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 17:08:55 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:55 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 17:08:55 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:55 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 17:08:55 --> Helper loaded: language_helper
DEBUG - 2014-02-05 17:08:55 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 17:08:55 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 17:08:55 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 17:08:55 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:55 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 17:08:55 --> Model Class Initialized
DEBUG - 2014-02-05 17:08:55 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 17:08:55 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 17:08:55 --> Final output sent to browser
DEBUG - 2014-02-05 17:08:55 --> Total execution time: 0.0575
DEBUG - 2014-02-05 17:09:08 --> Config Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:09:08 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:09:08 --> URI Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Router Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Output Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Security Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Input Class Initialized
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:09:08 --> Language Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Language Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Config Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Loader Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Controller Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Session Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:09:08 --> Session routines successfully run
DEBUG - 2014-02-05 17:09:08 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 17:09:08 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:09:08 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: form_helper
DEBUG - 2014-02-05 17:09:08 --> Form Validation Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: number_helper
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: date_helper
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 17:09:08 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:08 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 17:09:08 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:08 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 17:09:08 --> Helper loaded: language_helper
DEBUG - 2014-02-05 17:09:08 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 17:09:08 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 17:09:08 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 17:09:08 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:08 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 17:09:08 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:08 --> File loaded: application/modules/billing/views/monthlyinvoice.php
DEBUG - 2014-02-05 17:09:08 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 17:09:08 --> Final output sent to browser
DEBUG - 2014-02-05 17:09:08 --> Total execution time: 0.0606
DEBUG - 2014-02-05 17:09:12 --> Config Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:09:12 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:09:12 --> URI Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Router Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Output Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Security Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Input Class Initialized
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:12 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:09:12 --> Language Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Language Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Config Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Loader Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Controller Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Session Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:09:12 --> Session routines successfully run
DEBUG - 2014-02-05 17:09:12 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 17:09:12 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:09:12 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: form_helper
DEBUG - 2014-02-05 17:09:12 --> Form Validation Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: number_helper
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: date_helper
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 17:09:12 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:12 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 17:09:12 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:12 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 17:09:12 --> Helper loaded: language_helper
DEBUG - 2014-02-05 17:09:12 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 17:09:12 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 17:09:12 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 17:09:12 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:12 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 17:09:12 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Config Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Hooks Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Utf8 Class Initialized
DEBUG - 2014-02-05 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2014-02-05 17:09:13 --> URI Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Router Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Output Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Security Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Input Class Initialized
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> XSS Filtering completed
DEBUG - 2014-02-05 17:09:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-02-05 17:09:13 --> Language Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Language Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Config Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Loader Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Controller Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Session Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: string_helper
DEBUG - 2014-02-05 17:09:13 --> Session routines successfully run
DEBUG - 2014-02-05 17:09:13 --> Billing MX_Controller Initialized
DEBUG - 2014-02-05 17:09:13 --> Config file loaded: application/config/fusion_invoice.php
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: url_helper
DEBUG - 2014-02-05 17:09:13 --> Database Driver Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: form_helper
DEBUG - 2014-02-05 17:09:13 --> Form Validation Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: number_helper
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: pager_helper
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: invoice_helper
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: date_helper
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: redirect_helper
DEBUG - 2014-02-05 17:09:13 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:13 --> File loaded: application/modules/settings/models/mdl_settings.php
DEBUG - 2014-02-05 17:09:13 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:13 --> Language file loaded: language/english/fi_lang.php
DEBUG - 2014-02-05 17:09:13 --> Helper loaded: language_helper
DEBUG - 2014-02-05 17:09:13 --> File loaded: application/controllers/../modules/layout/controllers/layout.php
DEBUG - 2014-02-05 17:09:13 --> Layout MX_Controller Initialized
DEBUG - 2014-02-05 17:09:13 --> File loaded: application/modules/billing/models/mdl_billing.php
DEBUG - 2014-02-05 17:09:13 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:13 --> File loaded: application/modules/patient/models/mdl_patient.php
DEBUG - 2014-02-05 17:09:13 --> Model Class Initialized
DEBUG - 2014-02-05 17:09:13 --> File loaded: application/modules/billing/views/monthly_details.php
DEBUG - 2014-02-05 17:09:13 --> File loaded: application/modules/layout/views/layout.php
DEBUG - 2014-02-05 17:09:13 --> Final output sent to browser
DEBUG - 2014-02-05 17:09:13 --> Total execution time: 0.0850
